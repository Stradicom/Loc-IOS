import { relations } from 'drizzle-orm';
import { integer, pgTable, serial, text, timestamp } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(),
  email: text('email').notNull(),
  fullName: text('full_name'),
  role: text('role'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const properties = pgTable('properties', {
  id: serial('id').primaryKey(),
  propertyId: text('property_id').notNull().unique(),
  title: text('title').notNull(),
  type: text('type'),
  city: text('city'),
  neighborhood: text('neighborhood'),
  price: integer('price'),
  status: text('status'),
  createdAt: timestamp('created_at').defaultNow(),
});
