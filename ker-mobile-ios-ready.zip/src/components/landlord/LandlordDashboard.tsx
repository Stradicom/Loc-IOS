import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Building2, 
  Wallet, 
  Users, 
  CheckCircle2, 
  ShieldCheck, 
  TrendingUp, 
  Clock, 
  ArrowUpRight, 
  FileText,
  BadgeCheck,
  BellRing,
  Settings,
  Calendar,
  MessageSquare,
  Eye,
  EyeOff,
  Pencil,
  Coins,
  Send,
  AlertCircle,
  Sparkles,
  Smartphone,
  Landmark,
  UserCheck,
  ChevronRight,
  ArrowRight,
  Zap
} from 'lucide-react';
import { 
  Property, 
  TenantApplication, 
  UserProfile, 
  VisitAppointment, 
  ChatConversation, 
  BrokerAccreditationRequest 
} from '../../types';
import { formatFCFA, calculateLandlordPlan, getCurrentPeriod } from '../../utils/finance';
import { ApplicationsList } from './ApplicationsList';
import { LandlordClientsTab } from './LandlordClientsTab';
import { LandlordProfileModal } from './LandlordProfileModal';
import { PropertyDetailManageModal } from './PropertyDetailManageModal';
import { BrokerAccreditationModal } from './BrokerAccreditationModal';
import { AppointmentsManager } from '../common/AppointmentsManager';

interface LandlordDashboardProps {
  properties: Property[];
  applications: TenantApplication[];
  currentUser?: UserProfile | null;
  appointments?: VisitAppointment[];
  conversations?: ChatConversation[];
  paidThisMonth?: number;
  microPayments?: any[];
  onOpenNewPropertyModal: () => void;
  onApproveApplication: (applicationId: string) => void;
  onRejectApplication: (applicationId: string) => void;
  onOpenLeaseModal: (application: TenantApplication) => void;
  onTogglePropertyAvailability?: (propertyId: string, isAvailable: boolean) => void;
  onUpdateProfile?: (updated: UserProfile) => void;
  onConfirmAppointment?: (appointmentId: string) => void;
  onCancelAppointment?: (appointmentId: string) => void;
  onAddAppointment?: (newAppt: VisitAppointment) => void;
  onUpdateAppointment?: (appointmentId: string, updates: Partial<VisitAppointment>) => void;
  onSendMessage?: (conversationId: string, text: string) => void;
  onSendLeaseSignatureNotification?: (applicationId: string, tenantName: string) => void;
  onSubmitAccreditation?: (req: BrokerAccreditationRequest) => void;
  onTriggerPayoutRequest?: (amount: number) => void;
  onEditProperty?: (property: Property) => void;
  onDeleteProperty?: (propertyId: string) => void;
  activeTab?: 'revenues' | 'chat' | 'clients' | 'applications' | 'properties' | 'appointments';
  onTabChange?: (tab: 'revenues' | 'chat' | 'clients' | 'applications' | 'properties' | 'appointments') => void;
}

export const LandlordDashboard: React.FC<LandlordDashboardProps> = ({
  properties,
  applications,
  currentUser,
  appointments = [],
  conversations = [],
  paidThisMonth,
  microPayments,
  onOpenNewPropertyModal,
  onApproveApplication,
  onRejectApplication,
  onOpenLeaseModal,
  onTogglePropertyAvailability,
  onUpdateProfile,
  onConfirmAppointment,
  onCancelAppointment,
  onAddAppointment,
  onUpdateAppointment,
  onSendMessage,
  onSendLeaseSignatureNotification,
  onSubmitAccreditation,
  onTriggerPayoutRequest,
  onEditProperty,
  onDeleteProperty,
  activeTab: propActiveTab,
  onTabChange,
}) => {
  const [internalTab, setInternalTab] = useState<'revenues' | 'chat' | 'clients' | 'applications' | 'properties' | 'appointments'>(() => {
    try {
      const saved = localStorage.getItem('ker_landlord_tab');
      return (saved as any) || 'revenues';
    } catch {
      return 'revenues';
    }
  });

  const activeTab = propActiveTab || internalTab;

  const setActiveTab = (tab: 'revenues' | 'chat' | 'clients' | 'applications' | 'properties' | 'appointments') => {
    setInternalTab(tab);
    if (onTabChange) onTabChange(tab);
    try {
      localStorage.setItem('ker_landlord_tab', tab);
    } catch (e) {
      console.warn('Could not persist landlord tab:', e);
    }
  };

  useEffect(() => {
    if (propActiveTab) {
      setInternalTab(propActiveTab);
    }
  }, [propActiveTab]);

  useEffect(() => {
    try {
      localStorage.setItem('ker_landlord_tab', activeTab);
    } catch (e) {
      console.warn('Could not persist landlord tab:', e);
    }
  }, [activeTab]);

  // Modals state
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isAccreditationModalOpen, setIsAccreditationModalOpen] = useState(false);
  const [selectedPropertyForDetail, setSelectedPropertyForDetail] = useState<Property | null>(null);

  // Payout request logic (Enabled from the 1st of each month)
  const today = new Date();
  const currentDayOfMonth = today.getDate(); // 1-31
  const isPayoutAvailable = currentDayOfMonth >= 1; // Available from 1st of month
  const [payoutState, setPayoutState] = useState<'none' | 'pending' | 'completed'>(() => {
    try {
      const saved = localStorage.getItem('ker_landlord_payout_state');
      return (saved as any) || 'none';
    } catch {
      return 'none';
    }
  });

  // User Type (Propriétaire vs Courtier)
  const isBroker = currentUser?.landlordType === 'courtier';
  const isAccredited = currentUser?.isAccreditedAgency ?? isBroker;
  const isNewUser = currentUser?.isNewUser ?? false;

  // Real-time financial calculations
  // If brand new user without transactions: starts at 0 Frs CFA
  const totalMonthlyRents = isNewUser ? 0 : properties.reduce((sum, p) => sum + p.monthlyRent, 0);
  const totalGuaranteedDeposits = isNewUser ? 0 : totalMonthlyRents * 2;
  
  // Calculate tenant funds collected and pending balance
  const completedMicroPaymentsTotal = (microPayments || [])
    .filter((p: any) => p.status === 'completed')
    .reduce((sum: number, p: any) => sum + (p.amount || 0), 0);
  
  // Real-time tenant payments: if paidThisMonth is provided, use it; else fallback to completed payments or standard base
  const totalCollectedFromTenants = paidThisMonth !== undefined && paidThisMonth > 0
    ? paidThisMonth
    : (completedMicroPaymentsTotal > 0 ? completedMicroPaymentsTotal : (isNewUser ? 0 : 200000));

  const totalRentDue = totalMonthlyRents > 0 ? totalMonthlyRents : 250000;
  const remainingRentToCollect = Math.max(0, totalRentDue - totalCollectedFromTenants);
  const isAllRentPaid = remainingRentToCollect === 0;

  // Available payout request amount:
  // If tenant has paid an accompte of 200 000 FCFA (with 50 000 FCFA remaining), available payout amount is 200 000 FCFA.
  // If all rent is paid (100%), available payout is 100% of the rent (e.g. 250 000 FCFA).
  const availablePayoutGross = isAllRentPaid ? totalRentDue : totalCollectedFromTenants;

  // Commission LOC pour les propriétaires et agences (3% du montant du loyer)
  // Prise en charge de la gestion locative, baux certifiés OHADA, 100% loyers garantis à date fixe, zéro impayé
  const landlordPlan = calculateLandlordPlan(totalMonthlyRents || totalRentDue, true, 0.03, isBroker);
  const landlordManagementCommission = !isBroker ? Math.round(availablePayoutGross * 0.03) : 0;
  const availablePayoutNet = !isBroker ? Math.round(availablePayoutGross * 0.97) : availablePayoutGross;
  const netMonthlyRentPayout = availablePayoutNet;

  // Brokerage split:
  // For broker: 50% of the 3rd month deposit is retroceded to the broker agency
  const brokerCommissionVolume = isBroker ? Math.round(totalMonthlyRents * 0.5) : 0;

  const pendingApplicationsCount = applications.filter(a => a.status === 'pending').length;

  const handleRequestPayout = () => {
    if (!isPayoutAvailable || availablePayoutGross <= 0) return;
    if (onTriggerPayoutRequest) {
      onTriggerPayoutRequest(availablePayoutGross);
    }
    setPayoutState('completed');
    try {
      localStorage.setItem('ker_landlord_payout_state', 'completed');

      const savedSettlementsRaw = localStorage.getItem('ker_settlements_list');
      const existingList = savedSettlementsRaw ? JSON.parse(savedSettlementsRaw) : [];

      const newRef = `PAY-2026-09-${Math.floor(100 + Math.random() * 900)}`;
      const newSettlement = {
        id: `stl-req-${Date.now()}`,
        reference: newRef,
        beneficiaryName: currentUser?.fullName || (isBroker ? 'Teranga Immo' : 'Mamadou Diop'),
        beneficiaryType: isBroker ? 'broker' : 'landlord',
        companyName: currentUser?.companyName || (isBroker ? 'Teranga Immo SARL' : undefined),
        phone: currentUser?.phone || '+221 77 654 32 10',
        amount: availablePayoutNet,
        grossAmount: availablePayoutGross,
        commissionKer: landlordManagementCommission,
        description: isBroker
          ? `Règlement Instantané Commission Agence / Courtier (3% frais plateforme LOC déduits)`
          : `Règlement Instantané Loyer Net Garanti LOC (Frais 3% déduits)`,
        propertyTitle: `Portefeuille ${properties.length} bien(s) sous mandat`,
        payoutMethod: (currentUser?.preferredPayoutMethod === 'wave' ? 'Wave Business' : currentUser?.preferredPayoutMethod === 'orange_money' ? 'Orange Money' : 'Virement Bancaire'),
        payoutAccount: currentUser?.payoutPhoneOrRib || currentUser?.phone || '+221 77 654 32 10',
        dueDate: 'Règlement Instantané Validé',
        status: 'settled',
        settledAt: new Date().toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' }),
      };

      const updatedList = [newSettlement, ...existingList];
      localStorage.setItem('ker_settlements_list', JSON.stringify(updatedList));
      window.dispatchEvent(new Event('ker_settlement_updated'));
    } catch (e) {
      console.warn(e);
    }
  };

  return (
    <div className="p-3 sm:p-5 pb-24 space-y-4 text-slate-800">
      {/* Top Header Card with User Type Tag & Profile Switch */}
      <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-6 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="relative">
              {currentUser?.avatarUrl ? (
                <img
                  src={currentUser.avatarUrl}
                  alt={currentUser.fullName}
                  className="w-13 h-13 rounded-2xl object-cover border-2 border-blue-600 shadow-sm"
                />
              ) : (
                <div className="w-13 h-13 rounded-2xl bg-blue-100 border border-blue-200 text-blue-700 flex items-center justify-center font-black text-base shadow-sm">
                  {currentUser?.avatarText || (isBroker ? 'TI' : 'MD')}
                </div>
              )}
              {currentUser?.isIdVerified && (
                <div className="absolute -bottom-1 -right-1 bg-emerald-500 text-white rounded-full p-0.5" title="Compte CNI Vérifié">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </div>
              )}
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-lg font-black text-slate-900">
                  {currentUser?.fullName || (isBroker ? 'Mamadou Diop (Teranga Immo)' : 'Mamadou Diop')}
                </h2>
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold border ${
                  isBroker
                    ? 'bg-blue-100 text-blue-800 border-blue-200'
                    : 'bg-emerald-100 text-emerald-800 border-emerald-200'
                }`}>
                  {isBroker ? 'Courtier / Agence Partenaire' : 'Propriétaire Bailleur'}
                </span>
                {isBroker && isAccredited && (
                  <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-200 text-[10px] font-bold flex items-center gap-1">
                    <BadgeCheck className="w-3 h-3 text-amber-700" />
                    Agréé LOC
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 font-medium">
                {currentUser?.companyName || (isBroker ? 'Agence Teranga Immo Dakar' : 'Bailleur Privé Dakar')} • Mode de virement :{' '}
                <strong className="text-slate-800 capitalize">{currentUser?.preferredPayoutMethod?.replace('_', ' ') || 'Wave Business'}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
            <button
              onClick={() => setIsProfileModalOpen(true)}
              className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition-all"
              title="Modifier photo, coordonnées et mode de paiement"
            >
              <Settings className="w-4 h-4" />
              <span>Mon Profil</span>
            </button>

            {isBroker && !isAccredited && (
              <button
                onClick={() => setIsAccreditationModalOpen(true)}
                className="py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all"
              >
                <BadgeCheck className="w-4 h-4" />
                <span>Devenir Agence Agréée</span>
              </button>
            )}

            <button
              onClick={onOpenNewPropertyModal}
              className="py-2.5 px-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Publier un Bien</span>
            </button>
          </div>
        </div>

        {/* Dynamic Guarantee Banner adapted to user type */}
        <div className={`rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-white shadow-sm ${
          isBroker
            ? 'bg-gradient-to-r from-blue-700 via-indigo-700 to-purple-700'
            : 'bg-gradient-to-r from-blue-600 to-emerald-600'
        }`}>
          <div className="space-y-0.5">
            <span className="text-[11px] font-bold text-blue-100 uppercase tracking-wider flex items-center gap-1">
              <ShieldCheck className="w-4 h-4 text-emerald-300" />
              {isBroker ? 'Convention Courtage & Caution LOC 50/50' : 'Offre LOC Propriétaire • Gestion de Bail & Caution J1'}
            </span>
            <p className="text-xs text-white/95 font-medium">
              {isBroker
                ? 'Avance 100% caution (2 mois) pour votre mandant + 50% du 3ème mois reversé à votre agence (frais plateforme LOC de 3%).'
                : 'Gestion complète de votre bail pour seulement 3% de frais de plateforme sur le loyer • 100% loyers garantis à date fixe & 2 mois de caution perçus dès J+1.'}
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-xs font-bold px-3 py-1 rounded-xl bg-white/20 text-white border border-white/30">
              {isBroker ? 'Frais Plateforme LOC 3%' : '3% Frais Gestion LOC (97% Net)'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-6 gap-1.5 p-1 bg-slate-100 border border-slate-200 rounded-2xl">
        <button
          onClick={() => setActiveTab('revenues')}
          className={`py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'revenues'
              ? 'bg-white text-blue-600 shadow-xs border border-slate-200/60'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Wallet className="w-3.5 h-3.5" />
          <span>Revenus</span>
        </button>

        <button
          onClick={() => setActiveTab('chat')}
          className={`py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 relative cursor-pointer ${
            activeTab === 'chat'
              ? 'bg-white text-blue-600 shadow-xs border border-slate-200/60'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5 text-blue-600" />
          <span>Messagerie ({conversations.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('appointments')}
          className={`py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 relative cursor-pointer ${
            activeTab === 'appointments'
              ? 'bg-white text-blue-600 shadow-xs border border-slate-200/60'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Rendez-vous ({appointments.length})</span>
          {appointments.filter(a => a.status === 'pending').length > 0 && (
            <span className="ml-0.5 px-1.5 py-0.2 rounded-full text-[10px] bg-blue-600 text-white font-black">
              {appointments.filter(a => a.status === 'pending').length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('clients')}
          className={`py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'clients'
              ? 'bg-white text-blue-600 shadow-xs border border-slate-200/60'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Mes Clients</span>
        </button>

        <button
          onClick={() => setActiveTab('applications')}
          className={`py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 relative cursor-pointer ${
            activeTab === 'applications'
              ? 'bg-white text-blue-600 shadow-xs border border-slate-200/60'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Candidatures</span>
          {pendingApplicationsCount > 0 && (
            <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500 text-white font-black">
              {pendingApplicationsCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('properties')}
          className={`py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'properties'
              ? 'bg-white text-blue-600 shadow-xs border border-slate-200/60'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Mes Biens ({properties.length})</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: REVENUES & PAYMENT REQUEST (Demande de paiement du 1er du mois)     */}
      {/* ========================================================================= */}
      {activeTab === 'revenues' && (
        <div className="space-y-4 animate-fade-in">
          {/* Action Bar: Demande de Paiement (Actif dès le 1er du mois & ajusté aux fonds disponibles) */}
          <div className="p-4 rounded-3xl bg-white border border-slate-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <Coins className="w-4 h-4 text-emerald-600" />
                <h3 className="font-bold text-xs sm:text-sm text-slate-900">
                  {isBroker ? 'Déclenchement du Virement des Honoraires & Loyers' : 'Virement Net Garanti au Propriétaire'}
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold border border-emerald-200">
                  {isAllRentPaid ? '🎉 100% des loyers réglés' : 'Fonds disponibles au prorata'}
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                {!isBroker ? (
                  <>
                    Somme versée par les locataires : <strong className="text-slate-900">{formatFCFA(totalCollectedFromTenants)}</strong>
                    {remainingRentToCollect > 0 ? (
                      <> • Reste en cours de versement : <strong className="text-amber-700">{formatFCFA(remainingRentToCollect)}</strong></>
                    ) : (
                      <> • <strong className="text-emerald-700">Intégralité des loyers soldée (100%)</strong></>
                    )}
                    {' '}• Virement disponible : <strong className="text-emerald-700">{formatFCFA(netMonthlyRentPayout)}</strong> sur votre compte <strong>{currentUser?.preferredPayoutMethod?.replace('_', ' ') || 'Wave'}</strong>.
                  </>
                ) : (
                  <>
                    Honoraires disponibles : <strong className="text-emerald-700">{formatFCFA(netMonthlyRentPayout)}</strong> virés directement sur votre compte <strong>{currentUser?.preferredPayoutMethod || 'Wave'}</strong>.
                  </>
                )}
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-end sm:items-center gap-2 shrink-0">
              <button
                onClick={handleRequestPayout}
                disabled={availablePayoutGross <= 0}
                className={`py-2.5 px-4 rounded-2xl text-xs font-bold flex items-center gap-2 shadow-sm transition-all shrink-0 ${
                  availablePayoutGross <= 0
                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                    : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white hover:scale-105 cursor-pointer shadow-emerald-200'
                }`}
                title="Déclenche le règlement instantané sur votre compte sans délai de validation"
              >
                <Send className="w-4 h-4" />
                <span>Règlement Instantané ({formatFCFA(netMonthlyRentPayout)})</span>
              </button>
            </div>
          </div>

          {payoutState === 'completed' && (
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center justify-between gap-3 animate-fade-in shadow-xs">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>
                  <strong>Règlement instantané validé :</strong> Le montant net de <strong>{formatFCFA(netMonthlyRentPayout)}</strong> (frais de 3% déduits) a été viré directement sur votre compte <strong>{currentUser?.preferredPayoutMethod?.replace('_', ' ') || 'Wave'}</strong>.
                </span>
              </div>
              <span className="text-[10px] font-bold bg-emerald-600 text-white px-2.5 py-1 rounded-full shrink-0">
                Viré avec succès
              </span>
            </div>
          )}

          {/* Key Financial Metrics Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {/* Box 1: Somme Versée Locataires */}
            <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 space-y-1 shadow-sm">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                {isNewUser ? 'Fonds Collectés (0 Frs CFA)' : 'Fonds Collectés Locataires'}
              </span>
              <span className="text-xl font-black text-slate-900 font-mono block">
                {formatFCFA(totalCollectedFromTenants)}
              </span>
              <span className="text-xs text-emerald-700 flex items-center gap-1 pt-1 font-semibold">
                <TrendingUp className="w-3.5 h-3.5" />
                {remainingRentToCollect > 0 ? `Reste : ${formatFCFA(remainingRentToCollect)}` : '100% collecté'}
              </span>
            </div>

            {/* Box 2: Commission LOC (3% pour propriétaires, 50% honoraires pour courtier) */}
            <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 space-y-1 shadow-sm">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                {isBroker ? 'Honoraires Courtage Partagés (50/50)' : 'Frais Plateforme LOC (3%)'}
              </span>
              <span className={`text-xl font-black font-mono block ${isBroker ? 'text-purple-700' : 'text-blue-700'}`}>
                {isBroker ? formatFCFA(brokerCommissionVolume) : formatFCFA(landlordManagementCommission)}
              </span>
              <span className="text-xs text-blue-700 flex items-center gap-1 pt-1 font-semibold">
                <BadgeCheck className="w-3.5 h-3.5" />
                {isBroker ? '50% du 3ème mois d\'agence' : '3% sur loyers • 0% risque impayé'}
              </span>
            </div>

            {/* Box 3: Net Reversé Propriétaire (97%) */}
            <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 space-y-1 shadow-sm">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                {isBroker ? 'Biens Sous Mandat' : 'Virement Net Disponible (97%)'}
              </span>
              <span className="text-xl font-black text-emerald-700 font-mono block">
                {isBroker ? `${properties.length} Biens Actifs` : formatFCFA(netMonthlyRentPayout)}
              </span>
              <span className="text-xs text-emerald-700 flex items-center gap-1 pt-1 font-semibold">
                <ShieldCheck className="w-3.5 h-3.5" />
                {isBroker ? 'Actifs en temps réel' : 'Disponible dès le 1er du mois'}
              </span>
            </div>

            {/* Box 4: Cautions Garantie (2 mois à J+1) */}
            <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 space-y-1 shadow-sm">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                Caution Garantie Reçue (J+1)
              </span>
              <span className="text-xl font-black text-blue-700 font-mono block">
                {formatFCFA(totalGuaranteedDeposits || 500000)}
              </span>
              <span className="text-xs text-blue-700 flex items-center gap-1 pt-1 font-semibold">
                <ShieldCheck className="w-3.5 h-3.5" />
                Débloquée sous 24h par LOC
              </span>
            </div>
          </div>

          {/* Live Bank & Mobile Money Reconciliation */}
          <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BellRing className="w-4 h-4 text-blue-600" />
                <h3 className="font-bold text-slate-900 text-sm">
                  Flux Locatifs & Rapprochement Bancaire en Temps Réel
                </h3>
              </div>
              <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full border border-emerald-200">
                Live Wave / OM / Virement
              </span>
            </div>

            {isNewUser ? (
              <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 text-center space-y-2">
                <Wallet className="w-8 h-8 text-slate-400 mx-auto" />
                <p className="text-xs font-bold text-slate-700">Aucune transaction pour le moment</p>
                <p className="text-[11px] text-slate-500">
                  Votre tableau de bord s'actualisera en temps réel dès le paiement de la première tranche par votre locataire.
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {[
                  ...(!isBroker ? [{
                    tenant: 'LOC Gestion Mandat Propriétaire',
                    prop: 'Tous Biens — Baux gérés',
                    amount: netMonthlyRentPayout > 0 ? netMonthlyRentPayout : 116400,
                    date: '01 Septembre 2026 08:00',
                    method: `${currentUser?.preferredPayoutMethod?.replace('_', ' ') || 'Wave Business'}`,
                    type: 'Loyer Net Reversé (97% après commission LOC 3%)',
                  }] : []),
                  {
                    tenant: 'Aïssatou Sow',
                    prop: 'Studio Cosy — Almadies',
                    amount: 25000,
                    date: '02 Septembre 2026 09:42',
                    method: 'Wave Business',
                    type: 'Micro-tranche Loyer (Fractionnée)',
                  },
                  {
                    tenant: 'Aïssatou Sow',
                    prop: 'Studio Cosy — Almadies',
                    amount: 25000,
                    date: '01 Septembre 2026 18:30',
                    method: 'Orange Money',
                    type: 'Micro-tranche Loyer',
                  },
                  {
                    tenant: 'Fonds de Garantie LOC SAS',
                    prop: 'Studio Cosy — Almadies',
                    amount: 240000,
                    date: '01 Septembre 2026 14:00',
                    method: 'Virement Intégral Garanti',
                    type: 'Caution Intégrale J+1 (2 mois versés à 100%)',
                  },
                ].map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-2xl bg-slate-50 border border-slate-200/90 flex items-center justify-between text-xs hover:border-blue-300 transition-colors"
                  >
                    <div>
                      <span className="font-bold text-slate-900 block">{item.tenant}</span>
                      <span className="text-[10px] text-slate-500">{item.prop} • {item.method}</span>
                      <span className="text-[9px] text-slate-400 block">{item.date}</span>
                    </div>

                    <div className="text-right">
                      <span className="font-black text-emerald-700 block font-mono">
                        +{formatFCFA(item.amount)}
                      </span>
                      <span className="text-[10px] text-blue-700 font-semibold">{item.type}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB CHAT: MESSAGERIE EN DIRECT (Propriétaires & Courtiers vs Locataires) */}
      {/* ========================================================================= */}
      {activeTab === 'chat' && (
        <LandlordClientsTab
          initialSubTab="chat"
          appointments={appointments}
          applications={applications}
          conversations={conversations}
          onConfirmAppointment={onConfirmAppointment}
          onCancelAppointment={onCancelAppointment}
          onAddAppointment={onAddAppointment}
          onSendMessage={onSendMessage}
          onSendLeaseSignatureNotification={onSendLeaseSignatureNotification}
          onOpenLeaseModal={onOpenLeaseModal}
        />
      )}

      {/* ========================================================================= */}
      {/* TAB 2: MES CLIENTS & CANDIDATS (Visites RDV, Chat, Notifications)         */}
      {/* ========================================================================= */}
      {activeTab === 'clients' && (
        <LandlordClientsTab
          initialSubTab="visits"
          appointments={appointments}
          applications={applications}
          conversations={conversations}
          onConfirmAppointment={onConfirmAppointment}
          onCancelAppointment={onCancelAppointment}
          onAddAppointment={onAddAppointment}
          onSendMessage={onSendMessage}
          onSendLeaseSignatureNotification={onSendLeaseSignatureNotification}
          onOpenLeaseModal={onOpenLeaseModal}
        />
      )}

      {/* ========================================================================= */}
      {/* TAB 3: CANDIDATURES (Dossiers de location reçus)                          */}
      {/* ========================================================================= */}
      {activeTab === 'applications' && (
        <ApplicationsList
          applications={applications}
          onApprove={onApproveApplication}
          onReject={onRejectApplication}
          onOpenLease={onOpenLeaseModal}
        />
      )}

      {/* ========================================================================= */}
      {/* TAB 4: MES BIENS (Disponibilité, Voir plus, Gestion)                      */}
      {/* ========================================================================= */}
      {activeTab === 'properties' && (
        <div className="space-y-3 animate-fade-in">
          <div className="flex justify-between items-center px-1">
            <div>
              <h3 className="text-xs font-bold text-slate-900">Catalogue des Biens Gérés</h3>
              <p className="text-[11px] text-slate-500">
                Basculez directement la disponibilité ou cliquez sur "Voir plus" pour inspecter chaque pièce.
              </p>
            </div>
            <button
              onClick={onOpenNewPropertyModal}
              className="py-1.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1 shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Ajouter un bien</span>
            </button>
          </div>

          <div className="space-y-2.5">
            {properties.map((p) => {
              const isAvailable = p.isAvailable ?? true;
              return (
                <div
                  key={p.id}
                  className="p-4 rounded-3xl bg-white border border-slate-200 shadow-sm hover:border-blue-300 transition-all space-y-3"
                >
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={p.images[0]}
                        alt={p.title}
                        referrerPolicy="no-referrer"
                        className="w-16 h-16 rounded-2xl object-cover bg-slate-100 shrink-0 border border-slate-200"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-xs font-bold text-slate-900 truncate">{p.title}</span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-semibold">
                            {p.typeLabel} • {p.rooms} pièce(s)
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500">{p.address || p.neighborhood}, Dakar</p>
                        
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xs font-black text-blue-700 font-mono">
                            {formatFCFA(p.monthlyRent)}/mois
                          </span>
                          <span className="text-[10px] text-emerald-800 font-semibold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 font-mono">
                            Caution {formatFCFA(p.monthlyRent * p.depositMonths)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Quick Availability Toggle Switch & "Voir plus" Button */}
                    <div className="flex items-center gap-2 w-full sm:w-auto justify-end pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                      {/* Availability Switch */}
                      <button
                        type="button"
                        onClick={() => onTogglePropertyAvailability && onTogglePropertyAvailability(p.id, !isAvailable)}
                        className={`py-1.5 px-2.5 rounded-xl text-[11px] font-bold flex items-center gap-1.5 transition-all border ${
                          isAvailable
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                            : 'bg-amber-50 text-amber-800 border-amber-300 hover:bg-amber-100'
                        }`}
                        title="Cliquez pour changer la disponibilité"
                      >
                        {isAvailable ? (
                          <>
                            <Eye className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Disponible</span>
                          </>
                        ) : (
                          <>
                            <EyeOff className="w-3.5 h-3.5 text-amber-600" />
                            <span>Non disponible</span>
                          </>
                        )}
                      </button>

                      {/* "Éditer" Button */}
                      {onEditProperty && (
                        <button
                          type="button"
                          onClick={() => onEditProperty(p)}
                          className="py-1.5 px-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 text-[11px] font-bold flex items-center gap-1 transition-colors border border-amber-200"
                          title="Modifier la fiche du bien"
                        >
                          <Pencil className="w-3.5 h-3.5 text-amber-600" />
                          <span>Éditer</span>
                        </button>
                      )}

                      {/* "Voir plus" Button */}
                      <button
                        type="button"
                        onClick={() => setSelectedPropertyForDetail(p)}
                        className="py-1.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-[11px] font-bold flex items-center gap-1 transition-colors"
                      >
                        <span>Voir plus</span>
                        <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                      </button>
                    </div>
                  </div>

                  {/* Tenant Rent Progression Banner when property is rented */}
                  {!isAvailable && (() => {
                    const currentPeriod = getCurrentPeriod();
                    const isDemoProp = p.id === 'prop-5' || p.monthlyRent === 100000;
                    const depositInstallment = Math.round((p.monthlyRent * 2) / 6);
                    const totalDue = isDemoProp ? 133333 : p.monthlyRent + (p.depositMonths ? depositInstallment : 0);
                    
                    let amountPaid = 0;
                    if (isDemoProp) {
                      const completed = (microPayments || []).filter((m: any) => m.status === 'completed' && (m.forMonth === currentPeriod || !m.forMonth));
                      amountPaid = completed.reduce((acc: number, item: any) => acc + (item.amount || 0), 0);
                    } else {
                      amountPaid = p.monthlyRent;
                    }

                    const progressPct = Math.min(100, Math.round((amountPaid / totalDue) * 100));
                    const isFullyPaid = progressPct >= 100;
                    const remaining = Math.max(0, totalDue - amountPaid);

                    return (
                      <div className={`mt-2 p-3 rounded-2xl border transition-all text-xs ${
                        isFullyPaid ? 'bg-emerald-50 border-emerald-200' : 'bg-blue-50 border-blue-200'
                      }`}>
                        <div className="flex items-center justify-between gap-2 mb-1.5">
                          <div className="flex items-center gap-1.5">
                            <UserCheck className="w-3.5 h-3.5 text-blue-700" />
                            <span className="font-bold text-slate-900">
                              Locataire en place • Progression loyer ({currentPeriod})
                            </span>
                          </div>
                          {isFullyPaid ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-200 text-emerald-900 border border-emerald-300">
                              100% Soldé
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-200 text-blue-900 border border-blue-300 flex items-center gap-1">
                              <Zap className="w-2.5 h-2.5 text-amber-500 animate-pulse" />
                              {progressPct}% ({formatFCFA(amountPaid)} / {formatFCFA(totalDue)})
                            </span>
                          )}
                        </div>

                        {/* Visual bar */}
                        <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden mb-1">
                          <div 
                            className={`h-full rounded-full transition-all duration-500 ${
                              isFullyPaid ? 'bg-emerald-500' : 'bg-blue-600'
                            }`}
                            style={{ width: `${progressPct}%` }}
                          />
                        </div>

                        <div className="flex items-center justify-between text-[10px] text-slate-500 font-medium">
                          <span>Reçu : <strong className="text-emerald-700 font-mono">{formatFCFA(amountPaid)}</strong></span>
                          <span>Solde restant : <strong className="text-slate-800 font-mono">{formatFCFA(remaining)}</strong></span>
                          <span className="text-blue-700 font-bold">Garantie LOC 100%</span>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB: APPOINTMENTS (Gestion des Rendez-vous Bailleur / Courtier)           */}
      {/* ========================================================================= */}
      {activeTab === 'appointments' && (
        <div className="space-y-4 animate-fade-in">
          <AppointmentsManager
            appointments={appointments}
            properties={properties}
            userRole="landlord"
            currentUserId={currentUser?.id}
            currentUserName={currentUser?.name}
            onConfirmAppointment={onConfirmAppointment}
            onCancelAppointment={onCancelAppointment}
            onAddAppointment={onAddAppointment}
            onUpdateAppointment={onUpdateAppointment}
          />
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODALES DÉDIÉES PROPRIÉTAIRE                                              */}
      {/* ========================================================================= */}
      {currentUser && (
        <LandlordProfileModal
          isOpen={isProfileModalOpen}
          onClose={() => setIsProfileModalOpen(false)}
          currentUser={currentUser}
          onUpdateProfile={(updated) => {
            if (onUpdateProfile) onUpdateProfile(updated);
          }}
          onOpenAccreditationModal={() => setIsAccreditationModalOpen(true)}
        />
      )}

      <BrokerAccreditationModal
        isOpen={isAccreditationModalOpen}
        onClose={() => setIsAccreditationModalOpen(false)}
        currentUser={currentUser || null}
        onSubmitRequest={(req) => {
          if (onSubmitAccreditation) onSubmitAccreditation(req);
        }}
      />

      <PropertyDetailManageModal
        property={selectedPropertyForDetail}
        onClose={() => setSelectedPropertyForDetail(null)}
        onEditProperty={onEditProperty}
        onDeleteProperty={onDeleteProperty}
        onToggleAvailability={(propId, newAvail) => {
          if (onTogglePropertyAvailability) onTogglePropertyAvailability(propId, newAvail);
          if (selectedPropertyForDetail) {
            setSelectedPropertyForDetail({ ...selectedPropertyForDetail, isAvailable: newAvail });
          }
        }}
      />
    </div>
  );
};
