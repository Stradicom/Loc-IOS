import React, { useState, useEffect } from 'react';
import { 
  X, 
  Home, 
  Plus, 
  Sparkles, 
  Image as ImageIcon, 
  Check, 
  CheckCircle2, 
  ShieldCheck, 
  Upload, 
  Camera, 
  Building, 
  UserCheck, 
  Layers, 
  Trash2,
  Eye,
  BadgeCheck,
  Smartphone,
  CheckSquare,
  Square,
  Bed,
  Bath,
  MapPin,
  Tag,
  FileText,
  AlignLeft,
  Wand2,
  Navigation,
  Locate,
  ExternalLink,
  Loader2,
  Globe
} from 'lucide-react';
import { Property, PropertyType, RoomPhotoConfig, UserProfile } from '../../types';
import { formatFCFA } from '../../utils/finance';
import { dakarNeighborhoods, getNeighborhoodCoordinates } from '../../data/dakarNeighborhoods';

interface NewPropertyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddProperty: (newProp: Property) => void;
  onUpdateProperty?: (updatedProp: Property) => void;
  onDeleteProperty?: (propertyId: string) => void;
  onToggleAvailability?: (propertyId: string, isAvailable: boolean) => void;
  propertyToEdit?: Property | null;
  currentUser?: UserProfile | null;
}

// Preset photo catalogs for Senegal / Dakar
const dakarRoomPresets: Record<string, string[]> = {
  salon: [
    'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80'
  ],
  chambre: [
    'https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1616594039964-ae9021a400a0?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1560185127-6ed189bf02f4?auto=format&fit=crop&w=800&q=80'
  ],
  cuisine: [
    'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1507089947368-19c1da9775ae?auto=format&fit=crop&w=800&q=80'
  ],
  salle_de_bain: [
    'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?auto=format&fit=crop&w=800&q=80'
  ],
  facade: [
    'https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=800&q=80'
  ]
};

// Available amenities checklist
const ALL_AMENITIES = [
  { id: 'climatisation', label: 'Climatisation', icon: '❄️' },
  { id: 'wifi', label: 'Wifi Fibre Optique', icon: '📶' },
  { id: 'gardien', label: 'Gardiennage 24/7', icon: '🛡️' },
  { id: 'groupe', label: 'Groupe électrogène', icon: '⚡' },
  { id: 'reservoir', label: 'Réservoir d\'eau & Surpresseur', icon: '💧' },
  { id: 'cuisine_equipee', label: 'Cuisine équipée', icon: '🍳' },
  { id: 'salle_de_bain_privee', label: 'Salle de bain privée', icon: '🚿' },
  { id: 'chauffe_eau', label: 'Chauffe-eau', icon: '🔥' },
  { id: 'meuble_dressing', label: 'Meublé & Dressing', icon: '🛋️' },
  { id: 'balcon', label: 'Balcon / Terrasse', icon: '🌅' },
  { id: 'parking', label: 'Parking / Garage', icon: '🚗' },
  { id: 'ascenseur', label: 'Ascenseur', icon: '🛗' },
  { id: 'buanderie', label: 'Buanderie / Lave-linge', icon: '🧺' },
  { id: 'cameras', label: 'Caméras de surveillance CCTV', icon: '📹' },
  { id: 'cour_jardin', label: 'Cour / Espace Jardin', icon: '🌳' },
  { id: 'vue_mer', label: 'Vue Mer / Dégagée', icon: '🌊' }
];

export type ChambreOption = 
  | '1_piece_non_meublee'
  | '1_piece_avec_sdb'
  | '1_piece_chambre_meublee'
  | '1_piece_chambre_meublee_avec_sdb';

const CHAMBRE_TYPOLOGIES: { 
  id: ChambreOption; 
  label: string; 
  furnished: boolean; 
  hasBathroom: boolean; 
  description: string;
}[] = [
  {
    id: '1_piece_non_meublee',
    label: '1 pièce non meublée',
    furnished: false,
    hasBathroom: false,
    description: 'Chambre individuelle non meublée (sanitaires partagés ou externes)'
  },
  {
    id: '1_piece_avec_sdb',
    label: '1 pièce avec salle de bain',
    furnished: false,
    hasBathroom: true,
    description: 'Chambre individuelle non meublée avec salle d\'eau / douche privative'
  },
  {
    id: '1_piece_chambre_meublee',
    label: '1 pièce chambre meublée',
    furnished: true,
    hasBathroom: false,
    description: 'Chambre meublée prête à vivre (lit, placard, bureau)'
  },
  {
    id: '1_piece_chambre_meublee_avec_sdb',
    label: '1 pièce chambre meublée avec salle de bain',
    furnished: true,
    hasBathroom: true,
    description: 'Chambre meublée haut standing avec salle de bain privée attenante'
  }
];

export type StudioOption = 
  | 'studio_1_piece_standard'
  | 'studio_americain_meuble'
  | 'studio_avec_coin_nuit'
  | 'studio_standing_balcon';

const STUDIO_TYPOLOGIES: {
  id: StudioOption;
  tag: string;
  label: string;
  description: string;
  furnished: boolean;
  defaultSurface: number;
}[] = [
  {
    id: 'studio_1_piece_standard',
    tag: 'Standard',
    label: 'Studio 1 Pièce Classique',
    description: 'Pièce de vie principale avec kitchenette et salle d’eau moderne',
    furnished: false,
    defaultSurface: 35
  },
  {
    id: 'studio_americain_meuble',
    tag: 'Meublé',
    label: 'Studio Américain Meublé',
    description: 'Cuisine américaine équipée, séjour meublé & salle d’eau privative',
    furnished: true,
    defaultSurface: 40
  },
  {
    id: 'studio_avec_coin_nuit',
    tag: 'Alcôve',
    label: 'Studio avec Coin Nuit / Alcôve',
    description: 'Salon convivial + alcôve chambre séparée & commodités complètes',
    furnished: true,
    defaultSurface: 45
  },
  {
    id: 'studio_standing_balcon',
    tag: 'Standing',
    label: 'Studio Standing avec Balcon',
    description: 'Grande pièce lumineuse, balcon/terrasse & finitions soignées',
    furnished: true,
    defaultSurface: 50
  }
];

export const NewPropertyModal: React.FC<NewPropertyModalProps> = ({
  isOpen,
  onClose,
  onAddProperty,
  onUpdateProperty,
  onDeleteProperty,
  onToggleAvailability,
  propertyToEdit,
  currentUser,
}) => {
  // Determine publisher type from logged in user or form state
  const initialPublisher = currentUser?.landlordType || 'proprietaire';
  const [publisherType, setPublisherType] = useState<'proprietaire' | 'courtier'>(initialPublisher);
  const [brokerLicense, setBrokerLicense] = useState(currentUser?.brokerLicenseNumber || 'AGR-DK-2026/89');
  const [brokerAgencyName, setBrokerAgencyName] = useState(currentUser?.companyName || 'Teranga Immo Dakar');
  
  const [type, setType] = useState<PropertyType>('appartement');
  const [chambreOption, setChambreOption] = useState<ChambreOption>('1_piece_chambre_meublee_avec_sdb');
  const [studioOption, setStudioOption] = useState<StudioOption>('studio_americain_meuble');
  const [title, setTitle] = useState('');
  const [refNumber, setRefNumber] = useState<string>(`LOC-2026-${Math.floor(1000 + Math.random() * 9000)}`);
  const [isAvailable, setIsAvailable] = useState<boolean>(true);
  const [floorLevel, setFloorLevel] = useState<string>('1er étage');
  const [neighborhood, setNeighborhood] = useState('Almadies');
  const [address, setAddress] = useState('');
  const [monthlyRent, setMonthlyRent] = useState<number>(180000);

  // Populate state if propertyToEdit is provided
  useEffect(() => {
    if (propertyToEdit && isOpen) {
      setTitle(propertyToEdit.title || '');
      setRefNumber(propertyToEdit.refNumber || `LOC-2026-${Math.floor(1000 + Math.random() * 9000)}`);
      setIsAvailable(propertyToEdit.isAvailable ?? true);
      setFloorLevel(propertyToEdit.floorLevel || '1er étage');
      setType(propertyToEdit.type || 'appartement');
      setNeighborhood(propertyToEdit.neighborhood || 'Almadies');
      setAddress(propertyToEdit.address || '');
      setMonthlyRent(propertyToEdit.monthlyRent || 180000);
      setSurface(propertyToEdit.surface || 65);
      setRooms(propertyToEdit.rooms || 2);
      setBathrooms(propertyToEdit.bathrooms || 1);
      setFurnished(propertyToEdit.furnished ?? true);
      setDescription(propertyToEdit.description || '');
      if (propertyToEdit.amenities && propertyToEdit.amenities.length > 0) {
        setSelectedAmenities(propertyToEdit.amenities);
      }
      if (propertyToEdit.coordinates) {
        setGeoLat(propertyToEdit.coordinates.lat);
        setGeoLng(propertyToEdit.coordinates.lng);
      }
      if (propertyToEdit.googleMapsUrl) {
        setMapsUrl(propertyToEdit.googleMapsUrl);
      }
      if (propertyToEdit.images && propertyToEdit.images.length > 0) {
        setRoomPhotos(propertyToEdit.images.map((imgUrl, i) => ({
          roomId: `edit-photo-${i}`,
          roomName: i === 0 ? 'Photo Couverture / Façade' : `Photo ${i + 1}`,
          roomType: 'salon',
          imageUrl: imgUrl,
          isCover: i === 0
        })));
      }
    } else if (!propertyToEdit && isOpen) {
      // Reset for new creation & generate new algorithm refNumber
      setTitle('');
      setRefNumber(`LOC-2026-${Math.floor(1000 + Math.random() * 9000)}`);
      setIsAvailable(true);
      setType('appartement');
      setNeighborhood('Almadies');
      setAddress('');
      setMonthlyRent(180000);
      setSurface(65);
      setRooms(2);
      setBathrooms(1);
      setFurnished(true);
      setDescription('');
    }
  }, [propertyToEdit, isOpen]);
  
  // Google Maps & GPS Geolocation State
  const initialCoords = getNeighborhoodCoordinates('Almadies');
  const [geoLat, setGeoLat] = useState<number>(initialCoords.lat);
  const [geoLng, setGeoLng] = useState<number>(initialCoords.lng);
  const [mapsUrl, setMapsUrl] = useState<string>(`https://www.google.com/maps?q=${initialCoords.lat},${initialCoords.lng}`);
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [locatingStatus, setLocatingStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const depositMonths = 2;
  const brokerFeeMonths = publisherType === 'courtier' ? 1 : 0;

  const [surface, setSurface] = useState<number>(65);
  const [rooms, setRooms] = useState<number>(2);
  const [bathrooms, setBathrooms] = useState<number>(1);
  const [furnished, setFurnished] = useState<boolean>(true);
  const [description, setDescription] = useState('');
  const [customAmenity, setCustomAmenity] = useState('');
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([
    'Climatisation',
    'Wifi Fibre Optique',
    'Groupe électrogène',
    'Gardiennage 24/7',
    'Cuisine équipée'
  ]);

  // Dynamic Room Photos State
  const [roomPhotos, setRoomPhotos] = useState<RoomPhotoConfig[]>([]);

  // Automatically adjust `rooms`, `furnished`, `bathrooms`, `surface` when `type`, `chambreOption`, `studioOption` changes
  useEffect(() => {
    if (type === 'chambre') {
      setRooms(1);
      const selectedTypo = CHAMBRE_TYPOLOGIES.find(c => c.id === chambreOption);
      if (selectedTypo) {
        setFurnished(selectedTypo.furnished);
        setBathrooms(selectedTypo.hasBathroom ? 1 : 0);
      }
      if (surface === 65 || surface === 90 || surface === 130) {
        setSurface(20);
      }
    } else if (type === 'studio') {
      setRooms(1);
      const selectedStudio = STUDIO_TYPOLOGIES.find(s => s.id === studioOption);
      if (selectedStudio) {
        setFurnished(selectedStudio.furnished);
        setBathrooms(1);
        if (surface === 65 || surface === 20 || surface === 90) {
          setSurface(selectedStudio.defaultSurface);
        }
      } else {
        setFurnished(true);
        setBathrooms(1);
      }
    } else if (type === 'appartement') {
      if (rooms < 2) {
        setRooms(2);
        setSurface(60);
      }
    } else if (type === 'maison') {
      if (rooms < 3) {
        setRooms(4);
        setSurface(160);
      }
    }
  }, [type, chambreOption, studioOption]);

  // Update map coordinates when neighborhood changes (if not custom located)
  const handleNeighborhoodChange = (newNeighborhood: string) => {
    setNeighborhood(newNeighborhood);
    const coords = getNeighborhoodCoordinates(newNeighborhood);
    setGeoLat(coords.lat);
    setGeoLng(coords.lng);
    setMapsUrl(`https://www.google.com/maps?q=${coords.lat},${coords.lng}`);
    setLocatingStatus(null);
  };

  // GPS Geolocation Handler
  const handleGetGPSLocation = () => {
    if (!navigator.geolocation) {
      setLocatingStatus({
        type: 'error',
        message: 'La géolocalisation n’est pas disponible sur cet appareil ou navigateur.'
      });
      return;
    }

    setIsLocating(true);
    setLocatingStatus(null);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = Number(position.coords.latitude.toFixed(6));
        const lng = Number(position.coords.longitude.toFixed(6));
        setGeoLat(lat);
        setGeoLng(lng);
        const newUrl = `https://www.google.com/maps?q=${lat},${lng}`;
        setMapsUrl(newUrl);
        setIsLocating(false);
        setLocatingStatus({
          type: 'success',
          message: `Position GPS exacte enregistrée : ${lat}, ${lng} (Précision: ±${Math.round(position.coords.accuracy || 10)}m)`
        });
      },
      (error) => {
        console.warn('Erreur de géolocalisation:', error);
        const fallbackCoords = getNeighborhoodCoordinates(neighborhood);
        setGeoLat(fallbackCoords.lat);
        setGeoLng(fallbackCoords.lng);
        setMapsUrl(`https://www.google.com/maps?q=${fallbackCoords.lat},${fallbackCoords.lng}`);
        setIsLocating(false);
        setLocatingStatus({
          type: 'error',
          message: `Accès GPS non autorisé. Repère automatique de ${neighborhood} appliqué (${fallbackCoords.lat}, ${fallbackCoords.lng}).`
        });
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 }
    );
  };

  const handleManualMapsUrlChange = (value: string) => {
    setMapsUrl(value);
    // Parse latitude / longitude if user pastes coordinates or Google maps URL
    const match = value.match(/(-?\d+\.\d+)[,\s]+(-?\d+\.\d+)/);
    if (match) {
      setGeoLat(parseFloat(match[1]));
      setGeoLng(parseFloat(match[2]));
      setLocatingStatus({
        type: 'success',
        message: `Coordonnées extraites : ${match[1]}, ${match[2]}`
      });
    }
  };

  // Regenerate room slots whenever `rooms`, `type`, `chambreOption`, `studioOption` changes
  useEffect(() => {
    const slots: RoomPhotoConfig[] = [];

    if (type === 'chambre') {
      const isMeublee = chambreOption.includes('meublee');
      const hasSdb = chambreOption.includes('sdb');

      slots.push({
        roomId: 'room-chambre-main',
        roomName: isMeublee ? 'Chambre Meublée Principale' : 'Chambre Principale',
        roomType: 'chambre',
        imageUrl: dakarRoomPresets.chambre[0],
        isCover: true
      });

      if (hasSdb) {
        slots.push({
          roomId: 'room-sdb',
          roomName: 'Salle d’eau Privative',
          roomType: 'salle_de_bain',
          imageUrl: dakarRoomPresets.salle_de_bain[0],
          isCover: false
        });
      }

      slots.push({
        roomId: 'room-facade',
        roomName: 'Façade / Entrée',
        roomType: 'facade',
        imageUrl: dakarRoomPresets.facade[0],
        isCover: false
      });
    } else if (type === 'studio') {
      const currentStudio = STUDIO_TYPOLOGIES.find(s => s.id === studioOption);
      // 1. Espace Salon
      slots.push({
        roomId: 'room-salon',
        roomName: 'Espace Séjour / Salon',
        roomType: 'salon',
        imageUrl: dakarRoomPresets.salon[0],
        isCover: true
      });
      // 2. Chambre / Espace Nuit (Ajout spécifique pour les studios)
      slots.push({
        roomId: 'room-chambre',
        roomName: currentStudio?.id === 'studio_avec_coin_nuit' ? 'Espace Nuit / Alcôve Séparée' : 'Chambre / Coin Nuit',
        roomType: 'chambre',
        imageUrl: dakarRoomPresets.chambre[0],
        isCover: false
      });
      // 3. Kitchenette
      slots.push({
        roomId: 'room-kitchenette',
        roomName: 'Kitchenette équipée',
        roomType: 'cuisine',
        imageUrl: dakarRoomPresets.cuisine[0],
        isCover: false
      });
      // 4. Salle d'eau
      slots.push({
        roomId: 'room-sdb',
        roomName: 'Salle d’eau Moderne',
        roomType: 'salle_de_bain',
        imageUrl: dakarRoomPresets.salle_de_bain[0],
        isCover: false
      });
      // 5. Façade
      slots.push({
        roomId: 'room-facade',
        roomName: 'Façade / Immeuble',
        roomType: 'facade',
        imageUrl: dakarRoomPresets.facade[0],
        isCover: false
      });
    } else {
      // Appartement ou Maison
      // 1. Salon / Salle de séjour
      slots.push({
        roomId: 'room-salon',
        roomName: type === 'maison' ? 'Grand Salon & Salle à Manger' : 'Salon / Séjour Lumineux',
        roomType: 'salon',
        imageUrl: dakarRoomPresets.salon[0],
        isCover: true
      });

      // 2. Chambres selon le nombre de pièces déclarées
      const nbBedrooms = Math.max(1, rooms - 1);
      for (let i = 1; i <= nbBedrooms; i++) {
        const imgPreset = dakarRoomPresets.chambre[(i - 1) % dakarRoomPresets.chambre.length];
        slots.push({
          roomId: `room-bedroom-${i}`,
          roomName: i === 1 ? 'Chambre Parentale' : `Chambre ${i}`,
          roomType: 'chambre',
          imageUrl: imgPreset,
          isCover: false
        });
      }

      // 3. Cuisine
      slots.push({
        roomId: 'room-kitchen',
        roomName: 'Cuisine Moderne Équipée',
        roomType: 'cuisine',
        imageUrl: dakarRoomPresets.cuisine[0],
        isCover: false
      });

      // 4. Salle d'eau
      slots.push({
        roomId: 'room-bathroom',
        roomName: 'Salle de Bain / Douche Italienne',
        roomType: 'salle_de_bain',
        imageUrl: dakarRoomPresets.salle_de_bain[0],
        isCover: false
      });

      // 5. Façade / Balcon / Jardin
      slots.push({
        roomId: 'room-facade',
        roomName: type === 'maison' ? 'Façade, Jardin & Cour' : 'Façade / Balcon Vue Dégagée',
        roomType: 'facade',
        imageUrl: dakarRoomPresets.facade[0],
        isCover: false
      });
    }

    setRoomPhotos(slots);
  }, [rooms, type, chambreOption, studioOption]);

  if (!isOpen) return null;

  const handleGenerateSmartDescription = () => {
    let generated = '';
    const amenitiesText = selectedAmenities.length > 0 ? selectedAmenities.join(', ') : 'commodités essentielles';
    
    if (type === 'chambre') {
      const typo = CHAMBRE_TYPOLOGIES.find(c => c.id === chambreOption);
      generated = `Très belle chambre individuelle (${typo ? typo.label : '1 pièce'}) située au cœur du quartier recherché de ${neighborhood} (Dakar).\n\nLe logement bénéficie d'une surface confortable d'environ ${surface} m² avec ${typo?.hasBathroom ? 'salle de bain privative' : 'accès aux commodités'}. Équipements inclus : ${amenitiesText}.\n\nIdéal pour étudiant ou jeune professionnel cherchant un cadre de vie calme, propre et parfaitement sécurisé. Éligible au paiement échelonné de la caution avec la garantie LOC.`;
    } else if (type === 'studio') {
      const currentStudio = STUDIO_TYPOLOGIES.find(s => s.id === studioOption);
      generated = `Charmant ${currentStudio ? currentStudio.label : 'Studio moderne'} d'environ ${surface} m² situé à ${neighborhood}, Dakar.\n\nComposé d'un séjour accueillant, d'un espace nuit/chambre dédié, d'une kitchenette équipée et d'une salle d'eau contemporaine. Inclus : ${amenitiesText}.\n\nEmplacement stratégique proche des grands axes, commerces et transports. Logement certifié éligible à la caution LOC 100% garantie.`;
    } else if (type === 'appartement') {
      generated = `Magnifique appartement de standing de ${rooms} pièces (F${rooms}) d'une superficie de ${surface} m² situé dans un secteur prisé de ${neighborhood}, Dakar.\n\nIl offre un grand salon lumineux, ${rooms - 1} chambre(s) spacieuse(s), cuisine moderne et finitions soignées. Équipements & prestations : ${amenitiesText}.\n\nRésidence sécurisée avec accès facile. Prêt à habiter, idéal pour famille ou cadres. Caution légale garantie LOC.`;
    } else {
      generated = `Superbe maison / villa de ${rooms} pièces offrant une surface généreuse de ${surface} m² située à ${neighborhood}, Dakar.\n\nComprend de vastes espaces de réception, chambres confortables, cuisine aménagée et espaces extérieurs agréables. Prestations incluses : ${amenitiesText}.\n\nEnvironnement calme et résidentiel. Dossier sécurisé et éligible à la caution LOC.`;
    }

    setDescription(generated);
  };

  const handleInsertTag = (tag: string) => {
    setDescription(prev => {
      const trimmed = prev.trim();
      if (!trimmed) return tag;
      return `${trimmed}\n• ${tag}`;
    });
  };

  const handleToggleAmenity = (amenityLabel: string) => {
    setSelectedAmenities(prev => 
      prev.includes(amenityLabel)
        ? prev.filter(item => item !== amenityLabel)
        : [...prev, amenityLabel]
    );
  };

  const handleAddCustomAmenity = () => {
    if (customAmenity.trim() && !selectedAmenities.includes(customAmenity.trim())) {
      setSelectedAmenities(prev => [...prev, customAmenity.trim()]);
      setCustomAmenity('');
    }
  };

  const handleSelectAllAmenities = () => {
    setSelectedAmenities(ALL_AMENITIES.map(a => a.label));
  };

  const handleClearAmenities = () => {
    setSelectedAmenities([]);
  };

  const handleUpdateRoomPhoto = (roomId: string, newUrl: string) => {
    setRoomPhotos(prev =>
      prev.map(slot => slot.roomId === roomId ? { ...slot, imageUrl: newUrl } : slot)
    );
  };

  const handleCyclePresetPhoto = (roomId: string, roomType: string) => {
    const presets = dakarRoomPresets[roomType] || dakarRoomPresets.salon;
    setRoomPhotos(prev =>
      prev.map(slot => {
        if (slot.roomId === roomId) {
          const currentIndex = presets.indexOf(slot.imageUrl);
          const nextIndex = (currentIndex + 1) % presets.length;
          return { ...slot, imageUrl: presets[nextIndex] };
        }
        return slot;
      })
    );
  };

  // Direct Camera / Gallery Upload via FileReader
  const handleDirectFileUpload = (roomId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          handleUpdateRoomPhoto(roomId, event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const categoryLabels: Record<PropertyType, string> = {
      chambre: 'Chambre',
      studio: 'Studio',
      appartement: 'Appartement',
      maison: 'Maison / Villa',
    };

    let calculatedTitle = title;
    let calculatedCategoryDesc = '';

    if (type === 'chambre') {
      const chosenTypo = CHAMBRE_TYPOLOGIES.find(c => c.id === chambreOption);
      const typoLabel = chosenTypo ? chosenTypo.label : '1 pièce';
      calculatedTitle = title || `Chambre (${typoLabel}) — ${neighborhood}`;
      calculatedCategoryDesc = chosenTypo ? chosenTypo.description : `Chambre 1 pièce à ${neighborhood}`;
    } else if (type === 'studio') {
      const chosenStudio = STUDIO_TYPOLOGIES.find(s => s.id === studioOption);
      const studioLabel = chosenStudio ? chosenStudio.label : 'Studio';
      calculatedTitle = title || `${studioLabel} — ${neighborhood}`;
      calculatedCategoryDesc = chosenStudio ? chosenStudio.description : `Studio moderne à ${neighborhood}`;
    } else {
      calculatedTitle = title || `${categoryLabels[type]} ${rooms > 1 ? `F${rooms}` : ''} Standing — ${neighborhood}`;
      calculatedCategoryDesc = `${categoryLabels[type]} ${rooms} pièce(s) ${furnished ? 'meublé' : 'non-meublé'} avec photos vérifiées`;
    }

    const finalImages = roomPhotos.map(r => r.imageUrl).filter(Boolean);

    if (propertyToEdit && onUpdateProperty) {
      const updatedProp: Property = {
        ...propertyToEdit,
        title: calculatedTitle,
        refNumber: refNumber || propertyToEdit.refNumber || `LOC-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        isAvailable,
        floorLevel: floorLevel || propertyToEdit.floorLevel || '1er étage',
        type,
        typeLabel: type === 'chambre' 
          ? (CHAMBRE_TYPOLOGIES.find(c => c.id === chambreOption)?.label || 'Chambre') 
          : type === 'studio'
          ? (STUDIO_TYPOLOGIES.find(s => s.id === studioOption)?.label || 'Studio')
          : categoryLabels[type],
        categoryDesc: calculatedCategoryDesc,
        city: 'Dakar',
        neighborhood,
        address: address || `Rue Principale, ${neighborhood}`,
        coordinates: geoLat && geoLng ? { lat: geoLat, lng: geoLng } : undefined,
        googleMapsUrl: mapsUrl || `https://www.google.com/maps?q=${geoLat || 14.7454},${geoLng || -17.5144}`,
        monthlyRent,
        surface,
        rooms: (type === 'chambre' || type === 'studio') ? 1 : rooms,
        bathrooms,
        furnished,
        images: finalImages.length > 0 ? finalImages : propertyToEdit.images,
        description: description || propertyToEdit.description,
        amenities: selectedAmenities,
      };
      onUpdateProperty(updatedProp);
      onClose();
      return;
    }

    const newProp: Property = {
      id: `prop-${Date.now()}`,
      refNumber: refNumber || `LOC-2026-${Math.floor(100 + Math.random() * 900)}`,
      floorLevel: floorLevel || '1er étage',
      title: calculatedTitle,
      type,
      typeLabel: type === 'chambre' 
        ? (CHAMBRE_TYPOLOGIES.find(c => c.id === chambreOption)?.label || 'Chambre') 
        : type === 'studio'
        ? (STUDIO_TYPOLOGIES.find(s => s.id === studioOption)?.label || 'Studio')
        : categoryLabels[type],
      categoryDesc: calculatedCategoryDesc,
      city: 'Dakar',
      neighborhood,
      address: address || `Rue Principale, ${neighborhood}`,
      coordinates: geoLat && geoLng ? { lat: geoLat, lng: geoLng } : undefined,
      googleMapsUrl: mapsUrl || `https://www.google.com/maps?q=${geoLat || 14.7454},${geoLng || -17.5144}`,
      monthlyRent,
      depositMonths: 2,
      brokerFeeMonths: publisherType === 'courtier' ? 1 : 0,
      totalPackageMonths: publisherType === 'courtier' ? 3 : 2,
      chargesIncluded: true,
      surface,
      rooms: (type === 'chambre' || type === 'studio') ? 1 : rooms,
      bathrooms,
      furnished,
      featured: true,
      images: finalImages.length > 0 ? finalImages : dakarRoomPresets.salon,
      description: description || `Superbe bien immobilier (${type === 'chambre' ? (CHAMBRE_TYPOLOGIES.find(c => c.id === chambreOption)?.label || 'Chambre') : type === 'studio' ? (STUDIO_TYPOLOGIES.find(s => s.id === studioOption)?.label || 'Studio') : `${rooms} pièces`}) situé à ${neighborhood}, éligible au programme de caution LOC 100% garanti.`,
      amenities: selectedAmenities,
      landlordId: currentUser?.id || (publisherType === 'courtier' ? 'broker-1' : 'landlord-1'),
      landlordName: currentUser?.fullName || (publisherType === 'courtier' ? `${brokerAgencyName} (Courtier Agréé)` : 'Mamadou Diop (Propriétaire)'),
      landlordPhone: currentUser?.phone || '+221 77 654 32 10',
      verifiedLandlord: currentUser?.isIdVerified ?? true,
      isAvailable: true,
      approvalStatus: 'pending',
      createdAt: new Date().toISOString().split('T')[0],
    };

    onAddProperty(newProp);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fade-in text-slate-800">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-2xl relative max-h-[94vh] overflow-y-auto space-y-5">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="space-y-1 pr-8">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs font-semibold border border-blue-200">
            <Plus className="w-3.5 h-3.5" />
            {propertyToEdit ? 'Édition de Fiche Catalogue' : 'Publication d\'Annonce Immobilière'}
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900">
            {propertyToEdit ? 'Modifier la Fiche du Bien' : 'Ajouter un Nouveau Bien'}
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            {propertyToEdit
              ? 'Mettez à jour les prix, la description, les caractéristiques et les visuels de ce bien.'
              : 'Renseignez les caractéristiques, équipements et photos pour publier votre annonce sur LOC.'}
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-5">
          {/* 1. Profil Bailleur (Propriétaire vs Courtier) */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <label className="text-xs font-bold text-slate-800 block uppercase tracking-wider">
              1. Statut du Publiant :
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <label
                onClick={() => setPublisherType('proprietaire')}
                className={`p-3.5 rounded-xl border flex items-start gap-3 cursor-pointer transition-all ${
                  publisherType === 'proprietaire'
                    ? 'bg-blue-50 border-blue-500 text-slate-900 shadow-sm'
                    : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                }`}
              >
                <input
                  type="radio"
                  name="publisherType"
                  checked={publisherType === 'proprietaire'}
                  onChange={() => setPublisherType('proprietaire')}
                  className="mt-0.5 accent-blue-600"
                />
                <div className="space-y-0.5">
                  <span className="font-bold text-xs block text-slate-900">Propriétaire Particulier / SCI</span>
                  <p className="text-[11px] text-slate-500">
                    Caution standard LOC limitée à 2 mois (versée d'un bloc dès J+1).
                  </p>
                </div>
              </label>

              <label
                onClick={() => setPublisherType('courtier')}
                className={`p-3.5 rounded-xl border flex items-start gap-3 cursor-pointer transition-all ${
                  publisherType === 'courtier'
                    ? 'bg-blue-50 border-blue-500 text-slate-900 shadow-sm'
                    : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                }`}
              >
                <input
                  type="radio"
                  name="publisherType"
                  checked={publisherType === 'courtier'}
                  onChange={() => setPublisherType('courtier')}
                  className="mt-0.5 accent-blue-600"
                />
                <div className="space-y-0.5">
                  <span className="font-bold text-xs block text-slate-900">Courtier / Agence Immobilière</span>
                  <p className="text-[11px] text-slate-500">
                    Offre caution 2 mois + Frais de courtage (1 mois) avec convention 50/50 LOC.
                  </p>
                </div>
              </label>
            </div>

            {publisherType === 'courtier' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-slate-200 animate-fade-in">
                <div>
                  <label className="text-[10px] text-slate-500 block mb-1 font-medium">Nom de l'Agence / Cabinet :</label>
                  <input
                    type="text"
                    value={brokerAgencyName}
                    onChange={(e) => setBrokerAgencyName(e.target.value)}
                    placeholder="Ex: Teranga Immo"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-900"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-500 block mb-1 font-medium">N° Agrément Ministériel :</label>
                  <input
                    type="text"
                    value={brokerLicense}
                    onChange={(e) => setBrokerLicense(e.target.value)}
                    placeholder="Ex: AGR-DK-2026/89"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-900 font-mono"
                  />
                </div>
              </div>
            )}
          </div>

          {/* 2. Typologie des Biens */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-800 block">
              2. Catégorie du Bien Immobilier :
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'chambre', label: 'Chambre', icon: '🛏️' },
                { id: 'studio', label: 'Studio', icon: '🛋️' },
                { id: 'appartement', label: 'Appartement', icon: '🏢' },
                { id: 'maison', label: 'Maison / Villa', icon: '🏡' },
              ].map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setType(cat.id as PropertyType)}
                  className={`p-2.5 rounded-2xl border text-center transition-all ${
                    type === cat.id
                      ? 'bg-blue-600 border-blue-600 text-white font-bold shadow-sm'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span className="text-xl block mb-1">{cat.icon}</span>
                  <span className="text-xs block">{cat.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 3. Nombre de Pièces & Typologie adaptée (Boutons interactifs) */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div>
              <label className="text-xs font-bold text-slate-800 block mb-1">
                3. Typologie & Nombre de pièces ({type === 'chambre' ? 'Chambre' : type === 'studio' ? 'Studio' : type === 'appartement' ? 'Appartement' : 'Maison / Villa'}) :
              </label>
              <p className="text-[11px] text-slate-500 font-medium">
                Sélectionnez la configuration exacte du logement en cliquant sur le bouton correspondant.
              </p>
            </div>

            {/* A. TYPOLOGIE POUR CHAMBRE */}
            {type === 'chambre' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {CHAMBRE_TYPOLOGIES.map((typo) => (
                  <button
                    key={typo.id}
                    type="button"
                    onClick={() => setChambreOption(typo.id)}
                    className={`p-3 rounded-xl border flex items-start gap-2.5 text-left transition-all ${
                      chambreOption === typo.id
                        ? 'bg-blue-50/90 border-blue-500 ring-2 ring-blue-400/30 text-slate-900 shadow-xs'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300'
                    }`}
                  >
                    <div className={`mt-0.5 w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                      chambreOption === typo.id ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-300 bg-white'
                    }`}>
                      {chambreOption === typo.id && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                    </div>
                    <div className="space-y-0.5 flex-1">
                      <span className="text-xs font-black block text-slate-900">{typo.label}</span>
                      <p className="text-[10px] text-slate-500 leading-snug">{typo.description}</p>
                    </div>
                  </button>
                ))}
              </div>
            )}

            {/* B. TYPOLOGIE POUR STUDIO (BOUTONS INTERACTIFS RÉACTIFS) */}
            {type === 'studio' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {STUDIO_TYPOLOGIES.map((item) => {
                  const isSelected = studioOption === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setStudioOption(item.id);
                        setRooms(1);
                        setFurnished(item.furnished);
                        setSurface(item.defaultSurface);
                      }}
                      className={`p-3 rounded-xl border flex items-start gap-2.5 text-left transition-all ${
                        isSelected
                          ? 'bg-blue-50/90 border-blue-500 ring-2 ring-blue-400/30 text-slate-900 shadow-xs'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300'
                      }`}
                    >
                      <div className={`mt-0.5 w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                        isSelected ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-300 bg-white'
                      }`}>
                        {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                      </div>
                      <div className="space-y-0.5 flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-black block text-slate-900">{item.label}</span>
                          <span className={`text-[9px] px-1.5 py-0.2 rounded font-bold ${
                            isSelected ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-700'
                          }`}>
                            {item.tag}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-500 leading-snug">{item.description}</p>
                        <span className="text-[10px] text-slate-400 font-medium block pt-0.5">
                          ~{item.defaultSurface} m² • {item.furnished ? 'Meublé' : 'Non meublé'}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}

            {/* C. TYPOLOGIE POUR APPARTEMENT (SOUS FORME DE BOUTONS) */}
            {type === 'appartement' && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { r: 2, tag: 'F2', label: '2 Pièces', desc: 'Salon + 1 Chambre', defaultSurface: 60 },
                  { r: 3, tag: 'F3', label: '3 Pièces', desc: 'Salon + 2 Chambres', defaultSurface: 90 },
                  { r: 4, tag: 'F4', label: '4 Pièces', desc: 'Salon + 3 Chambres', defaultSurface: 130 },
                  { r: 5, tag: 'F5+', label: '5+ Pièces', desc: 'Salon + 4 Ch. / Standing', defaultSurface: 180 },
                ].map((item) => {
                  const isSelected = rooms === item.r || (item.r === 5 && rooms >= 5);
                  return (
                    <button
                      key={item.r}
                      type="button"
                      onClick={() => {
                        setRooms(item.r);
                        if ([60, 65, 90, 130, 180].includes(surface)) {
                          setSurface(item.defaultSurface);
                        }
                      }}
                      className={`p-3 rounded-xl border flex flex-col justify-between text-left transition-all relative ${
                        isSelected
                          ? 'bg-blue-600 border-blue-600 text-white shadow-sm ring-2 ring-blue-500/30'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between w-full mb-1">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${
                          isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-700'
                        }`}>
                          {item.tag}
                        </span>
                        {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-white shrink-0" />}
                      </div>
                      <span className={`text-xs font-black block ${isSelected ? 'text-white' : 'text-slate-900'}`}>
                        {item.label}
                      </span>
                      <p className={`text-[10px] mt-0.5 leading-snug ${isSelected ? 'text-blue-100' : 'text-slate-500'}`}>
                        {item.desc}
                      </p>
                    </button>
                  );
                })}
              </div>
            )}

            {/* D. TYPOLOGIE POUR MAISON / VILLA (SOUS FORME DE BOUTONS) */}
            {type === 'maison' && (
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {[
                  { r: 3, tag: 'F3', label: 'Villa F3', desc: '3 Pièces (Plain-pied)', defaultSurface: 120 },
                  { r: 4, tag: 'F4', label: 'Villa F4', desc: '4 Pièces (Avec cour)', defaultSurface: 160 },
                  { r: 5, tag: 'F5', label: 'Villa F5', desc: '5 Pièces (Duplex)', defaultSurface: 220 },
                  { r: 6, tag: 'F6', label: 'Villa F6', desc: '6 Pièces (Jardin)', defaultSurface: 300 },
                  { r: 8, tag: 'F8+', label: 'Résidence', desc: '8+ Pièces / Immeuble', defaultSurface: 450 },
                ].map((item) => {
                  const isSelected = rooms === item.r;
                  return (
                    <button
                      key={item.r}
                      type="button"
                      onClick={() => {
                        setRooms(item.r);
                        if ([65, 120, 160, 220, 300, 450].includes(surface)) {
                          setSurface(item.defaultSurface);
                        }
                      }}
                      className={`p-3 rounded-xl border flex flex-col justify-between text-left transition-all ${
                        isSelected
                          ? 'bg-blue-600 border-blue-600 text-white shadow-sm ring-2 ring-blue-500/30'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between w-full mb-1">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${
                          isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-700'
                        }`}>
                          {item.tag}
                        </span>
                        {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-white shrink-0" />}
                      </div>
                      <span className={`text-xs font-black block ${isSelected ? 'text-white' : 'text-slate-900'}`}>
                        {item.label}
                      </span>
                      <p className={`text-[9px] mt-0.5 leading-snug ${isSelected ? 'text-blue-100' : 'text-slate-500'}`}>
                        {item.desc}
                      </p>
                    </button>
                  );
                })}
              </div>
            )}

            {/* Référence & Niveau du bien (Étage) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 border-t border-slate-200">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[10px] text-slate-700 font-bold flex items-center gap-1">
                    <Tag className="w-3 h-3 text-blue-600" />
                    N° de Référence du bien :
                  </label>
                  <span className="text-[9px] px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-bold border border-blue-200">
                    ⚡ Algorithmique (Automatique)
                  </span>
                </div>
                <input
                  type="text"
                  value={refNumber}
                  readOnly
                  className="w-full bg-slate-100 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 font-mono font-bold shadow-2xs cursor-not-allowed select-none"
                  title="Le numéro de référence est automatiquement attribué par l'algorithme LOC"
                />
                <p className="text-[10px] text-slate-400 mt-1">
                  Code unique généré automatiquement par l'algorithme.
                </p>
              </div>

              <div>
                <label className="text-[10px] text-slate-700 block mb-1 font-bold flex items-center gap-1">
                  <Layers className="w-3 h-3 text-blue-600" />
                  Niveau / Étage du bien :
                </label>
                <select
                  value={floorLevel}
                  onChange={(e) => setFloorLevel(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-bold shadow-2xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="RDC">Rez-de-Chaussée (RDC)</option>
                  <option value="1er étage">1er Étage</option>
                  <option value="2ème étage">2ème Étage</option>
                  <option value="3ème étage">3ème Étage</option>
                  <option value="4ème étage">4ème Étage</option>
                  <option value="5ème étage">5ème Étage</option>
                  <option value="Dernier étage">Dernier Étage (Penthouse)</option>
                  <option value="Villa R+1 / Maison">Villa R+1 / Maison Entière</option>
                  <option value="Sous-sol / Semi-enterré">Sous-sol / Semi-enterré</option>
                </select>
              </div>
            </div>

            {/* Localisation & Surface */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2 border-t border-slate-200">
              {/* Quartier (Tous les quartiers de Dakar) */}
              <div className="sm:col-span-2">
                <label className="text-[10px] text-slate-700 block mb-1 font-bold flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-blue-600" />
                  Quartier (Dakar) :
                </label>
                <select
                  value={neighborhood}
                  onChange={(e) => handleNeighborhoodChange(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-2xs"
                >
                  {dakarNeighborhoods.map((n) => (
                    <option key={n} value={n}>{n}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] text-slate-700 block mb-1 font-bold">Surface estimée (m²) :</label>
                <input
                  type="number"
                  value={surface}
                  onChange={(e) => setSurface(Number(e.target.value))}
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-bold shadow-2xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* ENREGISTREMENT POSITION GOOGLE MAPS & GPS */}
            <div className="p-3.5 rounded-2xl bg-white border border-blue-200/80 space-y-2.5 mt-2 shadow-2xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <Navigation className="w-3.5 h-3.5 text-blue-600" />
                    Enregistrement de la position sur Google Maps
                  </span>
                  <p className="text-[10px] text-slate-500">
                    Enregistrez la position GPS exacte du logement pour guider précisément les locataires lors des visites.
                  </p>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  {/* Bouton GPS Direct */}
                  <button
                    type="button"
                    onClick={handleGetGPSLocation}
                    disabled={isLocating}
                    className="px-2.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold flex items-center gap-1.5 transition-all shadow-xs disabled:opacity-50 cursor-pointer"
                  >
                    {isLocating ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Recherche GPS...</span>
                      </>
                    ) : (
                      <>
                        <Locate className="w-3.5 h-3.5" />
                        <span>📍 Détecter ma position GPS</span>
                      </>
                    )}
                  </button>

                  {/* Bouton Repère Quartier */}
                  <button
                    type="button"
                    onClick={() => {
                      const c = getNeighborhoodCoordinates(neighborhood);
                      setGeoLat(c.lat);
                      setGeoLng(c.lng);
                      setMapsUrl(`https://www.google.com/maps?q=${c.lat},${c.lng}`);
                      setLocatingStatus({
                        type: 'success',
                        message: `Position calée sur le centre de ${neighborhood} (${c.lat}, ${c.lng})`
                      });
                    }}
                    className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-semibold flex items-center gap-1 transition-all"
                  >
                    <Globe className="w-3.5 h-3.5 text-slate-500" />
                    <span>Centrer sur {neighborhood}</span>
                  </button>
                </div>
              </div>

              {/* Input lien Maps ou Coordonnées */}
              <div className="space-y-1.5 pt-1">
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <input
                      type="text"
                      value={mapsUrl}
                      onChange={(e) => handleManualMapsUrlChange(e.target.value)}
                      placeholder="Collez un lien Google Maps ou saisissez vos coordonnées (ex: 14.7454, -17.5144)"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-800 font-mono placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <MapPin className="w-3.5 h-3.5 text-red-500 absolute left-2.5 top-2" />
                  </div>

                  {mapsUrl && (
                    <a
                      href={mapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold flex items-center gap-1 transition-colors shrink-0"
                    >
                      <ExternalLink className="w-3.5 h-3.5 text-blue-600" />
                      <span>Tester sur Maps</span>
                    </a>
                  )}
                </div>

                {/* Status & Coordinates feedback badge */}
                <div className="flex flex-wrap items-center justify-between gap-1 text-[10px]">
                  <div className="flex items-center gap-1 font-mono text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md">
                    <span className="font-bold text-slate-800">Coordonnées GPS :</span>
                    <span>{geoLat?.toFixed(5) || '14.74540'}, {geoLng?.toFixed(5) || '-17.51440'}</span>
                  </div>

                  {locatingStatus && (
                    <span className={`font-semibold flex items-center gap-1 ${
                      locatingStatus.type === 'success' ? 'text-emerald-700' : 'text-amber-700'
                    }`}>
                      {locatingStatus.type === 'success' ? (
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      ) : (
                        <MapPin className="w-3 h-3 text-amber-600" />
                      )}
                      {locatingStatus.message}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Titre et Adresse personnalisés (Facultatif) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="text-[10px] text-slate-700 block mb-1 font-bold">
                Titre de l'annonce (optionnel) :
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={`Ex: ${type === 'chambre' ? 'Chambre meublée tout confort' : 'Superbe appartement haut standing'} — ${neighborhood}`}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-700 block mb-1 font-bold">
                Adresse précise / Repère (optionnel) :
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Ex: Près du rond-point Ngor, Rue 14"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* 4. ÉQUIPEMENTS & COMMODITÉS À COCHER */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <Tag className="w-4 h-4 text-blue-600" />
                  4. Équipements & Commodités inclus ({selectedAmenities.length} sélectionnés) :
                </span>
                <p className="text-[11px] text-slate-500 font-medium">
                  Cochez les commodités disponibles pour valoriser votre bien auprès des locataires.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSelectAllAmenities}
                  className="text-[10px] font-bold text-blue-600 hover:text-blue-800 transition-colors"
                >
                  Tout cocher
                </button>
                <span className="text-slate-300">•</span>
                <button
                  type="button"
                  onClick={handleClearAmenities}
                  className="text-[10px] font-bold text-slate-500 hover:text-slate-700 transition-colors"
                >
                  Désélectionner
                </button>
              </div>
            </div>

            {/* Checklist Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 pt-1">
              {ALL_AMENITIES.map((amenity) => {
                const isChecked = selectedAmenities.includes(amenity.label);
                return (
                  <button
                    key={amenity.id}
                    type="button"
                    onClick={() => handleToggleAmenity(amenity.label)}
                    className={`p-2 rounded-xl border text-left flex items-center gap-2 transition-all text-xs ${
                      isChecked
                        ? 'bg-blue-50 border-blue-400 text-blue-950 font-bold shadow-xs'
                        : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="text-sm shrink-0">{amenity.icon}</span>
                    <span className="truncate flex-1 text-[11px]">{amenity.label}</span>
                    {isChecked ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    ) : (
                      <div className="w-3.5 h-3.5 rounded-full border border-slate-300 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Custom amenity input */}
            <div className="pt-2 border-t border-slate-200 flex items-center gap-2">
              <input
                type="text"
                placeholder="Ajouter un équipement personnalisé (ex: Salle de sport, Piscine)..."
                value={customAmenity}
                onChange={(e) => setCustomAmenity(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddCustomAmenity();
                  }
                }}
                className="flex-1 bg-white border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="button"
                onClick={handleAddCustomAmenity}
                className="px-3 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold transition-colors"
              >
                + Ajouter
              </button>
            </div>
          </div>

          {/* 5. DESCRIPTION DU BIEN IMMOBILIER */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-blue-600" />
                  5. Description du bien immobilier :
                </span>
                <p className="text-[11px] text-slate-500 font-medium">
                  Rédigez une description attrayante pour présenter les points forts de votre logement.
                </p>
              </div>

              <button
                type="button"
                onClick={handleGenerateSmartDescription}
                className="px-3 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 text-xs font-bold flex items-center gap-1.5 transition-all shadow-2xs self-start sm:self-center"
              >
                <Wand2 className="w-3.5 h-3.5 text-blue-600" />
                <span>✨ Rédiger automatiquement</span>
              </button>
            </div>

            {/* Description Textarea */}
            <div className="relative">
              <textarea
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder={`Décrivez votre bien en détail (ex: ambiance du quartier, standing de l'immeuble, proximité commerces, calme, luminosité, conditions de location)...`}
                className="w-full bg-white border border-slate-200 rounded-2xl p-3.5 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 leading-relaxed shadow-inner"
              />
              <div className="absolute right-3 bottom-3 text-[10px] text-slate-400 font-mono">
                {description.length} caractères
              </div>
            </div>

            {/* Quick Keyword Suggestions */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[10px] font-bold text-slate-500 block">
                Ajout rapide de mentions clés en 1 clic :
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'Immeuble calme et sécurisé',
                  'Proche transports et commerces',
                  'Entièrement rénové',
                  'Cuisine moderne aménagée',
                  'Très lumineux et bien aéré',
                  'Idéal jeune cadre ou étudiant',
                  'Gardiennage permanent 24h/24',
                  'Accès direct aux grands axes'
                ].map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => handleInsertTag(tag)}
                    className="px-2 py-1 rounded-lg bg-white hover:bg-blue-50 text-slate-700 hover:text-blue-700 border border-slate-200 hover:border-blue-300 text-[10px] font-medium transition-all"
                  >
                    + {tag}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 6. DYNAMIC ROOM-BY-ROOM PHOTO UPLOAD (Avec option Chambre pour Studio) */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <Camera className="w-4 h-4 text-blue-600" />
                  6. Photos par Pièce Déclarée ({roomPhotos.length} emplacements générés) :
                </span>
                <p className="text-[11px] text-slate-500 font-medium">
                  {type === 'studio' 
                    ? 'Inclus : Salon, Chambre / Espace Nuit, Kitchenette, Salle d’eau et Façade.' 
                    : 'Prenez une photo en direct ou choisissez depuis votre galerie pour chaque pièce.'}
                </p>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-bold border border-blue-200">
                Adapté {type}
              </span>
            </div>

            {/* Room Photo Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {roomPhotos.map((room) => (
                <div
                  key={room.roomId}
                  className="p-3 rounded-2xl bg-white border border-slate-200 space-y-2 relative shadow-sm hover:border-slate-300 transition-all"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900 flex items-center gap-1">
                      {room.roomName}
                      {room.isCover && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-blue-600 text-white font-bold">
                          Couverture
                        </span>
                      )}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCyclePresetPhoto(room.roomId, room.roomType)}
                      className="text-[10px] text-blue-600 hover:text-blue-800 font-semibold"
                    >
                      Preset alternatif
                    </button>
                  </div>

                  {/* Thumbnail Preview */}
                  <div className="relative h-28 rounded-xl overflow-hidden bg-slate-100 border border-slate-200 group">
                    <img
                      src={room.imageUrl}
                      alt={room.roomName}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent flex items-end justify-between p-2">
                      <span className="text-[10px] text-slate-200 font-mono">
                        {room.roomType.toUpperCase()}
                      </span>

                      {/* Direct Upload / Camera Button on Overlay */}
                      <label className="py-1 px-2.5 rounded-lg bg-white/90 hover:bg-white text-slate-800 text-[10px] font-bold flex items-center gap-1 cursor-pointer shadow-md transition-all">
                        <Camera className="w-3.5 h-3.5 text-blue-600" />
                        <span>Galerie / Appareil</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleDirectFileUpload(room.roomId, e)}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>

                  {/* Custom URL Input */}
                  <input
                    type="url"
                    placeholder="Ou collez l'URL de votre photo"
                    value={room.imageUrl.startsWith('data:') ? 'Photo personnalisée importée' : room.imageUrl}
                    onChange={(e) => handleUpdateRoomPhoto(room.roomId, e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-[10px] text-slate-700 focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* 7. Loyer & Caution adaptée au Profil */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-slate-500 block mb-1 font-bold">Loyer Mensuel (FCFA) :</label>
                <input
                  type="number"
                  step="5000"
                  value={monthlyRent}
                  onChange={(e) => setMonthlyRent(Number(e.target.value))}
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-500 block mb-1 font-bold">
                  Caution & Frais selon votre Profil :
                </label>
                <div className="p-2 bg-white rounded-xl border border-slate-200 text-xs space-y-0.5">
                  {publisherType === 'proprietaire' ? (
                    <div>
                      <span className="font-bold text-slate-900 block">2 mois de caution légale (Standard LOC)</span>
                      <span className="text-[10px] text-emerald-700 font-semibold">
                        Garantie 100% perçue dès J+1 : {formatFCFA(monthlyRent * 2)}
                      </span>
                    </div>
                  ) : (
                    <div>
                      <span className="font-bold text-slate-900 block">2 mois caution + 1 mois frais courtage (3 mois)</span>
                      <span className="text-[10px] text-blue-700 font-semibold">
                        Convention 50/50 : Partage de {formatFCFA(monthlyRent * 0.5)} d'honoraires pour l'agence
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="text-[11px] text-blue-800 flex items-center gap-1.5 pt-1">
              <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
              <span>
                Garantie LOC : Le bailleur perçoit <strong className="text-slate-900 font-mono font-bold">{formatFCFA(monthlyRent * 2)}</strong> de caution immédiatement dès la validation administrative !
              </span>
            </div>
          </div>

          {/* Availability Control when Editing */}
          {propertyToEdit && (
            <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">Statut de Disponibilité du Bien :</span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${isAvailable ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' : 'bg-amber-100 text-amber-800 border border-amber-200'}`}>
                  {isAvailable ? '🟢 Actuellement Disponible' : '🟠 Loué / Non disponible'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsAvailable(true)}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all border ${isAvailable ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'}`}
                >
                  🟢 Marquer comme Disponible
                </button>
                <button
                  type="button"
                  onClick={() => setIsAvailable(false)}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all border ${!isAvailable ? 'bg-amber-600 text-white border-amber-600 shadow-sm' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'}`}
                >
                  🟠 Marquer comme Indisponible (Loué)
                </button>
              </div>
            </div>
          )}

          {/* Submit & Delete Buttons */}
          <div className="pt-2 flex flex-col sm:flex-row items-center gap-2">
            <button
              type="submit"
              className="flex-1 w-full py-3.5 px-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-sm flex items-center justify-center gap-2 transition-all"
            >
              {propertyToEdit ? <Sparkles className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
              <span>{propertyToEdit ? 'Enregistrer les Modifications' : 'Publier le Bien sur LOC'}</span>
            </button>

            {propertyToEdit && onDeleteProperty && (
              <button
                type="button"
                onClick={() => {
                  if (window.confirm(`Êtes-vous sûr de vouloir supprimer définitivement le bien "${propertyToEdit.title}" (${propertyToEdit.refNumber || propertyToEdit.id}) du catalogue ?`)) {
                    onDeleteProperty(propertyToEdit.id);
                    onClose();
                  }
                }}
                className="w-full sm:w-auto py-3.5 px-4 rounded-2xl bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs border border-red-200 flex items-center justify-center gap-1.5 transition-all shrink-0"
              >
                <Trash2 className="w-4 h-4 text-red-600" />
                <span>Supprimer le Bien</span>
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};

