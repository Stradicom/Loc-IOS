import React, { useState } from 'react';
import { CheckCircle2, XCircle, FileText, UserCheck, ShieldCheck, Phone, Mail, Sparkles, Clock, AlertTriangle, Lock, Eye, ExternalLink, Building2 } from 'lucide-react';
import { TenantApplication } from '../../types';
import { formatFCFA } from '../../utils/finance';
import { CandidateDetailModal } from '../admin/CandidateDetailModal';

interface ApplicationsListProps {
  applications: TenantApplication[];
  onApprove?: (applicationId: string) => void;
  onReject?: (applicationId: string) => void;
  onOpenLease: (application: TenantApplication) => void;
  onOpenChatWithTenant?: (tenantName: string, tenantPhone: string) => void;
  onApproveWithAppointment?: (application: TenantApplication) => void;
  isAdminView?: boolean;
}

export const ApplicationsList: React.FC<ApplicationsListProps> = ({
  applications,
  onApprove,
  onReject,
  onOpenLease,
  onOpenChatWithTenant,
  onApproveWithAppointment,
  isAdminView = false,
}) => {
  const [selectedCandidateApp, setSelectedCandidateApp] = useState<TenantApplication | null>(null);

  return (
    <div className="space-y-3 text-slate-800">
      {/* Candidate Modal */}
      {selectedCandidateApp && (
        <CandidateDetailModal
          application={selectedCandidateApp}
          onClose={() => setSelectedCandidateApp(null)}
          onApprove={onApprove}
          onReject={onReject}
          onOpenLease={onOpenLease}
          onOpenChatWithTenant={onOpenChatWithTenant}
          onApproveWithAppointment={onApproveWithAppointment}
          isAdminView={isAdminView}
        />
      )}

      {/* Landlord Notice regarding LOC Guarantee & Validation Protocol */}
      {!isAdminView && (
        <div className="p-4 rounded-3xl bg-blue-50 border border-blue-200 flex items-start gap-3 shadow-sm">
          <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
          <div className="space-y-0.5 text-xs">
            <span className="font-bold text-slate-900 block">Protocole de Sécurité & Garantie LOC :</span>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              Pour vous garantir le <strong>versement à 100% de la caution dès le 1er jour</strong>, l'audit de solvabilité et l'approbation finale des candidatures sont <strong>exclusivement validés par les Administrateurs LOC</strong>.
            </p>
          </div>
        </div>
      )}

      {applications.length === 0 ? (
        <div className="p-8 text-center bg-white rounded-3xl border border-slate-200 shadow-sm space-y-2">
          <UserCheck className="w-8 h-8 text-slate-300 mx-auto" />
          <p className="text-xs font-semibold text-slate-600">Aucune candidature reçue pour le moment.</p>
          <p className="text-[11px] text-slate-400">Lorsqu'un candidat postule pour un bien, sa fiche détaillée et son score KYC apparaîtront ici.</p>
        </div>
      ) : (
        applications.map((app) => (
          <div
            key={app.id}
            className="bg-white border border-slate-200 hover:border-blue-300 rounded-3xl p-4 sm:p-5 shadow-sm space-y-4 transition-all group"
          >
            {/* Header info - Clickable card header */}
            <div 
              onClick={() => setSelectedCandidateApp(app)}
              className="flex items-start justify-between cursor-pointer"
            >
              <div className="space-y-0.5">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-xs font-black text-slate-900 group-hover:text-blue-600 transition-colors flex items-center gap-1">
                    {app.tenantName}
                    <Eye className="w-3.5 h-3.5 text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-100 text-slate-600 font-medium">
                    {app.tenantProfession}
                  </span>
                  {app.applicationOption === 'classic_direct' || (!app.applicationOption && Boolean(app.preferredVisitDate)) ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-slate-900 text-white shadow-xs">
                      Formule classique
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-50 text-blue-700 border border-blue-200 shadow-xs">
                      Formule Micro-caution
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-blue-600 font-semibold">{app.propertyTitle}</p>
                <p className="text-[10px] text-slate-400">Candidature reçue le {app.appliedAt}</p>
              </div>

              {/* Status Badge */}
              <div>
                {app.status === 'approved' ? (
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    Validé par l'Administration LOC
                  </span>
                ) : app.status === 'rejected' ? (
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-red-100 text-red-800 border border-red-200">
                    Non Validé
                  </span>
                ) : (
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    Audit Risque en cours (Admin)
                  </span>
                )}
              </div>
            </div>

            {/* Solvency & KYC Metrics - Clickable */}
            <div 
              onClick={() => setSelectedCandidateApp(app)}
              className="grid grid-cols-3 gap-2 p-3 rounded-2xl bg-slate-50 border border-slate-200 text-center cursor-pointer hover:bg-blue-50/50 transition-colors"
            >
              <div>
                <span className="text-[10px] text-slate-500 block">Score Solvabilité :</span>
                <span className="text-sm font-extrabold text-emerald-700">
                  {app.kycScore}/100
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block">
                  {isAdminView ? 'Revenu Mensuel :' : 'Justificatifs :'}
                </span>
                {isAdminView ? (
                  <span className="text-xs font-bold text-slate-900 font-mono">
                    {formatFCFA(app.monthlyIncome)}
                  </span>
                ) : (
                  <span className="text-xs font-bold text-emerald-700 flex items-center justify-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    Transmis
                  </span>
                )}
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block">Garant Solidaire :</span>
                <span className="text-xs font-bold text-blue-700">
                  {app.hasGuarantor ? 'Oui (Validé)' : 'Sans'}
                </span>
              </div>
            </div>

            {/* Financial notice based on formula */}
            {(app.applicationOption === 'classic_direct' || (!app.applicationOption && Boolean(app.preferredVisitDate))) ? (
              <div className="p-3 rounded-2xl bg-slate-100 border border-slate-200 text-[11px] text-slate-700 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-slate-900">
                  <Building2 className="w-3.5 h-3.5 text-blue-600" />
                  <span>Formule Classique (Comptant 3 mois) :</span>
                </div>
                <p className="text-[10px] text-slate-600 leading-relaxed">
                  Paiement direct au comptant : 3 mois de loyer (<strong className="text-slate-900 font-mono">{formatFCFA(app.depositAmount || app.monthlyRent * 3)}</strong>) remis directement à la signature du bail après visite des lieux.
                  {app.preferredVisitDate && <span className="block font-semibold text-blue-700 mt-0.5">🗓️ Date de visite souhaitée : {app.preferredVisitDate}</span>}
                </p>
              </div>
            ) : (
              <div className="p-3 rounded-2xl bg-blue-50/60 border border-blue-100 text-[11px] text-slate-700 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-blue-800">
                  <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                  <span>Garantie Caution Immobilière (Micro-caution) :</span>
                </div>
                <p className="text-[10px] text-slate-600 leading-relaxed">
                  Caution garantie : <strong className="text-slate-900 font-mono">{formatFCFA(app.depositAmount)}</strong>. Versement automatique à 100% sur votre compte dès validation du bail par l'administrateur LOC.
                </p>
              </div>
            )}

            {/* View Full Candidate File Button */}
            <button
              onClick={() => setSelectedCandidateApp(app)}
              className="w-full py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-all border border-slate-200"
            >
              <Eye className="w-3.5 h-3.5 text-blue-600" />
              <span>
                {isAdminView 
                  ? 'Consulter la Fiche Complète du Candidat (Dossier KYC & Justificatifs)' 
                  : 'Consulter l\'Audit Solvabilité & Pièces Justificatives (✅ Conformes)'}
              </span>
            </button>

            {/* Actions */}
            <div className="flex items-center gap-2 pt-2 border-t border-slate-200">
              {isAdminView && app.status === 'pending' && onApprove && onReject ? (
                <>
                  <button
                    onClick={() => {
                      if (onApproveWithAppointment) {
                        onApproveWithAppointment(app);
                      } else {
                        onApprove(app.id);
                      }
                    }}
                    className="flex-1 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-sm"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Valider & Planifier RDV (Admin)</span>
                  </button>
                  <button
                    onClick={() => onReject(app.id)}
                    className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-red-50 text-slate-600 hover:text-red-700 border border-slate-200 hover:border-red-200 text-xs font-semibold transition-all"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Rejeter</span>
                  </button>
                </>
              ) : !isAdminView && app.status === 'pending' ? (
                <div className="w-full py-2.5 px-3 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-500 text-center flex items-center justify-center gap-2">
                  <Lock className="w-3.5 h-3.5 text-amber-500" />
                  <span>Instruction en cours par le Superviseur Risque LOC</span>
                </div>
              ) : app.status === 'approved' ? (
                <button
                  onClick={() => onOpenLease(app)}
                  className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Consulter le Contrat de Bail Électronique LOC (Validé)</span>
                </button>
              ) : null}
            </div>
          </div>
        ))
      )}
    </div>
  );
};
