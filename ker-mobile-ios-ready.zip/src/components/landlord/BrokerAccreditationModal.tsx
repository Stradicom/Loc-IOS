import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  FileText, 
  Upload, 
  Building2, 
  CheckCircle2, 
  AlertCircle, 
  BadgeCheck, 
  Sparkles,
  Paperclip
} from 'lucide-react';
import { BrokerAccreditationRequest, UserProfile } from '../../types';

interface BrokerAccreditationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  onSubmitRequest: (request: BrokerAccreditationRequest) => void;
}

export const BrokerAccreditationModal: React.FC<BrokerAccreditationModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onSubmitRequest,
}) => {
  const [agencyName, setAgencyName] = useState(currentUser?.companyName || 'Teranga Immo Dakar');
  const [managerName, setManagerName] = useState(currentUser?.fullName || 'Mamadou Diop');
  const [licenseNumber, setLicenseNumber] = useState(currentUser?.brokerLicenseNumber || 'AGR-DK-2026/89');
  const [ninea, setNinea] = useState(currentUser?.ninea || '009874523 2V1');
  const [rccm, setRccm] = useState(currentUser?.rccm || 'SN.DKR.2024.B.14890');
  const [email, setEmail] = useState(currentUser?.email || 'direction@terangaimmo.sn');
  const [phone, setPhone] = useState(currentUser?.phone || '+221 77 654 32 10');
  const [hasUploadedDocs, setHasUploadedDocs] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!agencyName || !managerName || !licenseNumber || !ninea || !rccm) {
      setError('Veuillez renseigner tous les champs obligatoires (N° Agrément, NINEA, RCCM).');
      return;
    }

    const request: BrokerAccreditationRequest = {
      id: `accred-${Date.now()}`,
      userId: currentUser?.id || 'broker-user',
      agencyName,
      managerName,
      licenseNumber,
      ninea,
      rccm,
      email,
      phone,
      idCardUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=800&q=80',
      status: 'pending',
      submittedAt: new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })
    };

    onSubmitRequest(request);
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fade-in text-slate-800">
      <div className="w-full max-w-xl bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-2xl relative max-h-[92vh] overflow-y-auto space-y-4">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="space-y-1 pr-8">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs font-bold border border-blue-200">
            <BadgeCheck className="w-3.5 h-3.5" />
            Accréditation Officielle LOC
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900">Demande d'Agrément Agence Partenaire</h2>
          <p className="text-xs text-slate-500 font-medium">
            Bénéficiez du badge <strong>"Agence Agréée LOC"</strong>, de la rémunération garantie de 50% sur le 3ème mois de caution et de l'avance intégrale des cautions pour vos mandants.
          </p>
        </div>

        {isSuccess ? (
          <div className="p-6 rounded-2xl bg-emerald-50 border border-emerald-200 text-center space-y-3 animate-fade-in">
            <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-emerald-900">Dossier d'Agrément Déposé !</h3>
            <p className="text-xs text-emerald-700 leading-relaxed">
              Vos documents (Agrément Ministériel, NINEA, RCCM) ont été transmis au pôle conformité LOC. La vérification est effectuée sous 24h ouvrées.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{error}</span>
              </div>
            )}

            {/* Avantages Agence Agréée */}
            <div className="p-3.5 rounded-2xl bg-blue-50/80 border border-blue-100 text-xs text-blue-900 space-y-1.5">
              <span className="font-bold flex items-center gap-1.5 text-blue-950">
                <Sparkles className="w-4 h-4 text-blue-600" />
                Convention Partenaire 50/50 LOC :
              </span>
              <ul className="text-[11px] text-blue-800 space-y-1 pl-4 list-disc font-medium">
                <li>Versement de 100% de la caution (2 mois) à votre propriétaire mandant dès J+1.</li>
                <li>Rétrocession automatique de <strong>50% du 3ème mois de caution</strong> à votre agence pour frais de courtage.</li>
                <li>Mise en avant prioritaire de vos annonces certifiées sur le catalogue LOC.</li>
              </ul>
            </div>

            {/* Identité Entreprise */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Raison Sociale / Agence *</label>
                <input
                  type="text"
                  value={agencyName}
                  onChange={(e) => setAgencyName(e.target.value)}
                  placeholder="Ex: Teranga Immo Dakar"
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Nom du Gérant / Directeur *</label>
                <input
                  type="text"
                  value={managerName}
                  onChange={(e) => setManagerName(e.target.value)}
                  placeholder="Ex: Mamadou Diop"
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Justificatifs Légaux */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-700">N° Agrément Ministère *</label>
                <input
                  type="text"
                  value={licenseNumber}
                  onChange={(e) => setLicenseNumber(e.target.value)}
                  placeholder="AGR-2026/..."
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono focus:bg-white focus:border-blue-500 outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-700">NINEA *</label>
                <input
                  type="text"
                  value={ninea}
                  onChange={(e) => setNinea(e.target.value)}
                  placeholder="009874523 2V1"
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono focus:bg-white focus:border-blue-500 outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-700">RCCM *</label>
                <input
                  type="text"
                  value={rccm}
                  onChange={(e) => setRccm(e.target.value)}
                  placeholder="SN.DKR.2024.B..."
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono focus:bg-white focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Téléversement des Pièces */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Paperclip className="w-3.5 h-3.5 text-blue-600" />
                Pièces justificatives requises (PDF / Scan JPEG) :
              </span>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div 
                  onClick={() => setHasUploadedDocs(true)}
                  className={`p-3 rounded-xl border border-dashed flex items-center justify-between cursor-pointer transition-all ${
                    hasUploadedDocs ? 'bg-emerald-50 border-emerald-300 text-emerald-800' : 'bg-white border-slate-300 hover:border-blue-400'
                  }`}
                >
                  <div className="space-y-0.5">
                    <span className="font-bold text-[11px] block">1. Arrêté d'Agrément + RCCM</span>
                    <span className="text-[10px] text-slate-500">{hasUploadedDocs ? 'Document attaché (2.4 Mo)' : 'Cliquez pour joindre le fichier'}</span>
                  </div>
                  <Upload className="w-4 h-4 text-slate-400 shrink-0" />
                </div>

                <div 
                  onClick={() => setHasUploadedDocs(true)}
                  className={`p-3 rounded-xl border border-dashed flex items-center justify-between cursor-pointer transition-all ${
                    hasUploadedDocs ? 'bg-emerald-50 border-emerald-300 text-emerald-800' : 'bg-white border-slate-300 hover:border-blue-400'
                  }`}
                >
                  <div className="space-y-0.5">
                    <span className="font-bold text-[11px] block">2. CNI du Représentant Légal</span>
                    <span className="text-[10px] text-slate-500">{hasUploadedDocs ? 'CNI_Gerant.pdf joint' : 'Joindre CNI Recto/Verso'}</span>
                  </div>
                  <Upload className="w-4 h-4 text-slate-400 shrink-0" />
                </div>
              </div>
            </div>

            <div className="pt-2 flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="flex-2 py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Soumettre la Demande d'Agrément</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
