import React, { useState } from 'react';
import { 
  X, 
  User, 
  Camera, 
  Phone, 
  Mail, 
  Building, 
  CreditCard, 
  CheckCircle2, 
  AlertCircle, 
  ShieldCheck, 
  BadgeCheck, 
  Upload, 
  FileText,
  Lock,
  Smartphone,
  Landmark
} from 'lucide-react';
import { UserProfile } from '../../types';

interface LandlordProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onUpdateProfile: (updatedProfile: UserProfile) => void;
  onOpenAccreditationModal: () => void;
}

export const LandlordProfileModal: React.FC<LandlordProfileModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUpdateProfile,
  onOpenAccreditationModal,
}) => {
  const [firstName, setFirstName] = useState(currentUser.firstName || currentUser.fullName.split(' ')[0] || '');
  const [lastName, setLastName] = useState(currentUser.lastName || currentUser.fullName.split(' ').slice(1).join(' ') || '');
  const [companyName, setCompanyName] = useState(currentUser.companyName || '');
  const [phone, setPhone] = useState(currentUser.phone || '');
  const [email, setEmail] = useState(currentUser.email || '');
  const [profession, setProfession] = useState(currentUser.profession || (currentUser.landlordType === 'courtier' ? 'Courtier Immobilier' : 'Propriétaire Bailleur'));
  const [avatarText, setAvatarText] = useState(currentUser.avatarText || 'MD');
  const [avatarUrl, setAvatarUrl] = useState(currentUser.avatarUrl || '');
  
  // Payment methods
  const [payoutMethod, setPayoutMethod] = useState<'wave' | 'orange_money' | 'virement_bancaire'>(
    currentUser.preferredPayoutMethod || 'wave'
  );
  const [payoutPhoneOrRib, setPayoutPhoneOrRib] = useState(
    currentUser.payoutPhoneOrRib || (currentUser.phone ? currentUser.phone.replace('+221 ', '') : '77 654 32 10')
  );

  // ID Card Verification State
  const [isIdVerified, setIsIdVerified] = useState(currentUser.isIdVerified ?? true);
  const [idCardUrl, setIdCardUrl] = useState(currentUser.idCardDocumentUrl || 'CNI_Senegal_Recto_Verso.pdf');

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAvatarImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setAvatarUrl(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleIdDocUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIdCardUrl(`CNI_${file.name}`);
      setIsIdVerified(true);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const full = `${firstName.trim()} ${lastName.trim()}`.trim() || currentUser.fullName;
    const initials = (firstName ? firstName[0] : '') + (lastName ? lastName[0] : '') || avatarText;

    const updated: UserProfile = {
      ...currentUser,
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      fullName: full,
      companyName: companyName.trim() || undefined,
      phone: phone.trim(),
      email: email.trim(),
      profession: profession.trim(),
      avatarText: initials.toUpperCase() || 'PR',
      avatarUrl: avatarUrl || undefined,
      preferredPayoutMethod: payoutMethod,
      payoutPhoneOrRib: payoutPhoneOrRib.trim(),
      isIdVerified: isIdVerified,
      idCardDocumentUrl: idCardUrl,
      badgeLabel: currentUser.landlordType === 'courtier' 
        ? (currentUser.isAccreditedAgency ? 'Agence Agréée LOC' : 'Courtier Partenaire')
        : 'Propriétaire Certifié',
    };

    onUpdateProfile(updated);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fade-in text-slate-800">
      <div className="w-full max-w-xl bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-2xl relative max-h-[92vh] overflow-y-auto space-y-4">
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="space-y-1 pr-8">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs font-bold border border-blue-200">
            <User className="w-3.5 h-3.5" />
            Paramètres & Identité
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900">
            Profil {currentUser.landlordType === 'courtier' ? 'Courtier / Agence' : 'Propriétaire'}
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            Gérez vos coordonnées, coordonnées de paiement (Wave, OM, Banque) et vérifiez votre identité CNI.
          </p>
        </div>

        {savedSuccess ? (
          <div className="p-6 rounded-2xl bg-emerald-50 border border-emerald-200 text-center space-y-2 animate-fade-in">
            <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
            <h3 className="text-base font-bold text-emerald-900">Profil mis à jour avec succès !</h3>
            <p className="text-xs text-emerald-700">Vos préférences de versement et informations sont synchronisées.</p>
          </div>
        ) : (
          <form onSubmit={handleSave} className="space-y-4">
            {errorMessage && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Photo / Avatar Section */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center gap-4">
              <div className="relative">
                {avatarUrl ? (
                  <img
                    src={avatarUrl}
                    alt={currentUser.fullName}
                    className="w-16 h-16 rounded-2xl object-cover border-2 border-blue-600 shadow-sm"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-2xl bg-blue-600 text-white font-black text-xl flex items-center justify-center shadow-sm">
                    {avatarText}
                  </div>
                )}
                <label className="absolute -bottom-1.5 -right-1.5 p-1.5 rounded-full bg-white border border-slate-200 text-slate-700 hover:text-blue-600 cursor-pointer shadow-sm">
                  <Camera className="w-3.5 h-3.5" />
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarImageUpload}
                    className="hidden"
                  />
                </label>
              </div>

              <div className="space-y-0.5 flex-1 min-w-0">
                <h4 className="text-xs font-bold text-slate-900">Photo de Profil ou Logo d'Agence</h4>
                <p className="text-[11px] text-slate-500">
                  Cliquez sur l'icône appareil photo pour importer une image depuis votre galerie.
                </p>
                {avatarUrl && (
                  <button
                    type="button"
                    onClick={() => setAvatarUrl('')}
                    className="text-[10px] text-rose-600 font-bold hover:underline"
                  >
                    Supprimer la photo
                  </button>
                )}
              </div>
            </div>

            {/* Identité : Prénom, Nom, Raison Sociale */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Prénom *</label>
                <input
                  type="text"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  placeholder="Ex: Mamadou"
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Nom de Famille *</label>
                <input
                  type="text"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  placeholder="Ex: Diop"
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">Raison Sociale / Nom d'Agence ou SCI (Optionnel)</label>
              <div className="relative">
                <input
                  type="text"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="Ex: Agence Teranga Immo ou SCI Keur Gorgui"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none pl-8"
                />
                <Building className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              </div>
            </div>

            {/* Téléphone & Email */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Numéro de Téléphone *</label>
                <div className="relative">
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none pl-8"
                  />
                  <Phone className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Adresse Email *</label>
                <div className="relative">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none pl-8"
                  />
                  <Mail className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                </div>
              </div>
            </div>

            {/* MODE DE PAIEMENT PRÉFÉRÉ (Wave / OM / Virement Bancaire) */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="space-y-0.5">
                <label className="text-xs font-bold text-slate-900 block flex items-center gap-1.5">
                  <CreditCard className="w-4 h-4 text-blue-600" />
                  Mode de Paiement Préféré pour Réception des Loyers & Cautions :
                </label>
                <p className="text-[11px] text-slate-500">
                  LOC transfère automatiquement vos loyers et l'avance de caution vers ce moyen de paiement.
                </p>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPayoutMethod('wave')}
                  className={`p-3 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                    payoutMethod === 'wave'
                      ? 'bg-blue-50 border-blue-600 text-blue-900 shadow-sm'
                      : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <Smartphone className="w-4 h-4 text-sky-500" />
                  <span className="text-xs font-bold">Wave</span>
                  <span className="text-[9px] text-slate-500">Instantané</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPayoutMethod('orange_money')}
                  className={`p-3 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                    payoutMethod === 'orange_money'
                      ? 'bg-orange-50 border-orange-600 text-orange-900 shadow-sm'
                      : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <Smartphone className="w-4 h-4 text-orange-500" />
                  <span className="text-xs font-bold">Orange Money</span>
                  <span className="text-[9px] text-slate-500">Instantané</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPayoutMethod('virement_bancaire')}
                  className={`p-3 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                    payoutMethod === 'virement_bancaire'
                      ? 'bg-emerald-50 border-emerald-600 text-emerald-900 shadow-sm'
                      : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <Landmark className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs font-bold">Virement Bancaire</span>
                  <span className="text-[9px] text-slate-500">CBAO / BOA / etc.</span>
                </button>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-700">
                  {payoutMethod === 'virement_bancaire' ? 'RIB Bancaire (IBAN Sénégal) :' : 'Numéro de Compte / Téléphone pour Réception :'}
                </label>
                <input
                  type="text"
                  value={payoutPhoneOrRib}
                  onChange={(e) => setPayoutPhoneOrRib(e.target.value)}
                  placeholder={payoutMethod === 'virement_bancaire' ? 'SN012 01001 02345678901 45' : '77 654 32 10'}
                  required
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono text-slate-900 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* AUTHENTIFICATION CARTE D'IDENTITÉ (CNI) */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    Authentification du Compte (CNI / Passeport)
                  </span>
                  <p className="text-[11px] text-slate-500">
                    Obligatoire pour débloquer la subvention LOC et rendre visibles vos biens.
                  </p>
                </div>
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                  isIdVerified 
                    ? 'bg-emerald-100 text-emerald-800 border-emerald-200' 
                    : 'bg-amber-100 text-amber-800 border-amber-200'
                }`}>
                  {isIdVerified ? 'Certifié & Subventionné' : 'En attente CNI'}
                </span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-white border border-slate-200 text-xs">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue-600" />
                  <span className="font-semibold text-slate-800 text-[11px]">
                    {idCardUrl || 'Aucun document téléversé'}
                  </span>
                </div>

                <label className="text-[10px] text-blue-600 font-bold hover:underline cursor-pointer">
                  <span>Changer document</span>
                  <input
                    type="file"
                    accept="image/*,application/pdf"
                    onChange={handleIdDocUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            {/* Demande d'agrément si courtier */}
            {currentUser.landlordType === 'courtier' && (
              <div className="p-3.5 rounded-2xl bg-blue-50/70 border border-blue-200 flex items-center justify-between text-xs">
                <div className="space-y-0.5">
                  <span className="font-bold text-blue-950 flex items-center gap-1">
                    <BadgeCheck className="w-4 h-4 text-blue-600" />
                    Statut Agence Agréée LOC
                  </span>
                  <p className="text-[10px] text-blue-800">
                    Déposez votre NINEA, RCCM et arrêté d'agrément pour toucher 50% du 3ème mois.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenAccreditationModal();
                  }}
                  className="py-1.5 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-[10px] shrink-0 shadow-sm"
                >
                  Déposer Agrément
                </button>
              </div>
            )}

            {/* Save Buttons */}
            <div className="pt-2 flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="flex-2 py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Enregistrer les Modifications</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
