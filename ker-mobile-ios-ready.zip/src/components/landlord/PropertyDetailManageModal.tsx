import React, { useState } from 'react';
import { 
  X, 
  Building2, 
  MapPin, 
  ShieldCheck, 
  CheckCircle2, 
  Layers, 
  Sparkles, 
  Eye, 
  EyeOff, 
  KeyRound, 
  Coins, 
  UserCheck, 
  Phone, 
  Calendar,
  AlertCircle,
  Pencil,
  Trash2,
  Tag
} from 'lucide-react';
import { Property } from '../../types';
import { formatFCFA } from '../../utils/finance';

interface PropertyDetailManageModalProps {
  property: Property | null;
  onClose: () => void;
  onToggleAvailability: (propertyId: string, newAvailability: boolean) => void;
  onEditProperty?: (property: Property) => void;
  onDeleteProperty?: (propertyId: string) => void;
}

export const PropertyDetailManageModal: React.FC<PropertyDetailManageModalProps> = ({
  property,
  onClose,
  onToggleAvailability,
  onEditProperty,
  onDeleteProperty,
}) => {
  const [activeImageIdx, setActiveImageIdx] = useState(0);

  if (!property) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fade-in text-slate-800">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-2xl relative max-h-[92vh] overflow-y-auto space-y-4">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 transition-colors z-10"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Top Header */}
        <div className="space-y-1 pr-8">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs font-bold border border-blue-200">
              {property.typeLabel} • {property.neighborhood}
            </span>
            <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-800 text-xs font-mono font-bold border border-slate-200 flex items-center gap-1">
              <Tag className="w-3 h-3 text-blue-600" />
              {property.refNumber || property.id}
            </span>
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${
              property.isAvailable
                ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                : 'bg-amber-100 text-amber-800 border-amber-200'
            }`}>
              {property.isAvailable ? '🟢 Actuellement Disponible' : '🟠 Non disponible (Loué / Maintenance)'}
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900">{property.title}</h2>
          <p className="text-xs text-slate-500 flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5 text-blue-600" />
            {property.address}, Dakar
          </p>
        </div>

        {/* Gallery Preview */}
        <div className="space-y-2">
          <div className="h-56 sm:h-64 rounded-2xl overflow-hidden bg-slate-100 border border-slate-200 relative">
            <img
              src={property.images[activeImageIdx] || property.images[0]}
              alt={property.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-lg text-white text-[10px] font-bold">
              Photo {activeImageIdx + 1} sur {property.images.length}
            </div>
          </div>

          {/* Thumbnails */}
          {property.images.length > 1 && (
            <div className="flex gap-2 overflow-x-auto pb-1">
              {property.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIdx(idx)}
                  className={`w-16 h-12 rounded-xl overflow-hidden border-2 shrink-0 transition-all ${
                    activeImageIdx === idx ? 'border-blue-600 scale-105 shadow-sm' : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Availability Toggle Switch */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="space-y-0.5">
            <span className="text-xs font-bold text-slate-900 block">
              Disponibilité Publique de l'Annonce :
            </span>
            <p className="text-[11px] text-slate-500">
              Activez ou désactivez la visibilité du bien sur le moteur de recherche pour les locataires.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => onToggleAvailability(property.id, true)}
              className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
                property.isAvailable
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Disponible</span>
            </button>

            <button
              onClick={() => onToggleAvailability(property.id, false)}
              className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
                !property.isAvailable
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <EyeOff className="w-3.5 h-3.5" />
              <span>Non disponible</span>
            </button>
          </div>
        </div>

        {/* Financial & Room Specs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-[10px] text-slate-400 font-bold block uppercase">Loyer Mensuel</span>
            <span className="text-sm font-black text-slate-900 font-mono block">{formatFCFA(property.monthlyRent)}</span>
          </div>

          <div className="p-3 rounded-2xl bg-blue-50 border border-blue-200">
            <span className="text-[10px] text-blue-600 font-bold block uppercase">Caution Garantie LOC</span>
            <span className="text-sm font-black text-blue-900 font-mono block">{formatFCFA(property.monthlyRent * property.depositMonths)}</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-[10px] text-slate-400 font-bold block uppercase">Pièces / Surface</span>
            <span className="text-sm font-bold text-slate-900 block">{property.rooms} pièce(s) • {property.surface} m²</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-[10px] text-slate-400 font-bold block uppercase">Ameublement</span>
            <span className="text-sm font-bold text-slate-900 block">{property.furnished ? 'Meublé Standing' : 'Non-meublé'}</span>
          </div>
        </div>

        {/* Description & Equipments */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-slate-900">Description Complète du Bien :</h4>
          <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-2xl border border-slate-200">
            {property.description}
          </p>

          <h4 className="text-xs font-bold text-slate-900 pt-1">Équipements & Commodités :</h4>
          <div className="flex flex-wrap gap-1.5">
            {property.amenities.map((item, idx) => (
              <span
                key={idx}
                className="px-2.5 py-1 rounded-xl bg-slate-100 border border-slate-200 text-[11px] font-medium text-slate-700 flex items-center gap-1"
              >
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                {item}
              </span>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="pt-2 flex flex-wrap items-center gap-2">
          {onEditProperty && (
            <button
              onClick={() => {
                onClose();
                onEditProperty(property);
              }}
              className="flex-1 min-w-[140px] py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-sm"
            >
              <Pencil className="w-4 h-4" />
              <span>Modifier la Fiche</span>
            </button>
          )}

          {onDeleteProperty && (
            <button
              onClick={() => {
                if (window.confirm(`Êtes-vous sûr de vouloir supprimer définitivement le bien "${property.title}" (${property.refNumber || property.id}) ?`)) {
                  onDeleteProperty(property.id);
                  onClose();
                }
              }}
              className="py-3 px-4 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs border border-red-200 flex items-center justify-center gap-1.5 transition-all"
            >
              <Trash2 className="w-4 h-4 text-red-600" />
              <span>Supprimer le Bien</span>
            </button>
          )}

          <button
            onClick={onClose}
            className="flex-1 min-w-[120px] py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition-colors"
          >
            Fermer la Fiche
          </button>
        </div>
      </div>
    </div>
  );
};
