import React, { useState } from 'react';
import { 
  X, 
  FileText, 
  CheckCircle2, 
  ShieldCheck, 
  PenTool, 
  Download, 
  Lock, 
  User, 
  Building2, 
  Calendar,
  Sparkles,
  QrCode
} from 'lucide-react';
import { TenantApplication, Role } from '../../types';
import { formatFCFA } from '../../utils/finance';
import confetti from 'canvas-confetti';

interface LeaseModalProps {
  application: TenantApplication | null;
  onClose: () => void;
  onSignComplete: (applicationId: string, roleSigned?: 'tenant' | 'landlord') => void;
  currentRole?: Role;
  currentUserName?: string;
}

export const LeaseModal: React.FC<LeaseModalProps> = ({
  application,
  onClose,
  onSignComplete,
  currentRole = 'tenant',
  currentUserName,
}) => {
  const isTenantSigning = currentRole === 'tenant';
  const defaultSignName = currentUserName || (isTenantSigning ? (application?.tenantName || 'Aïssatou Sow') : 'Mamadou Diop');
  
  const [signatureName, setSignatureName] = useState(defaultSignName);
  const [hasAgreedTerms, setHasAgreedTerms] = useState(true);
  const [isSignedComplete, setIsSignedComplete] = useState(false);
  const [signatureToken] = useState(() => `OHADA-LOC-CERT-${Math.random().toString(36).substring(2, 10).toUpperCase()}`);

  if (!application) return null;

  const handleSign = () => {
    if (!signatureName.trim()) return;
    setIsSignedComplete(true);
    try {
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.5 },
      });
    } catch {
      // Confetti fallback
    }

    setTimeout(() => {
      onSignComplete(application.id, isTenantSigning ? 'tenant' : 'landlord');
    }, 2200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-fade-in text-slate-800">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-2xl relative max-h-[92vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="space-y-1 pr-8">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs font-semibold border border-blue-200">
            <FileText className="w-3.5 h-3.5" />
            Contrat de Bail Conforme OHADA & République du Sénégal
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900">
            {isTenantSigning ? 'Consulter & Signer mon Bail de Location' : 'E-Signature du Bail par le Bailleur'}
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            Garantie de caution LOC 100% activée dès signature électronique certifiée.
          </p>
        </div>

        {/* Contract Status Banner */}
        <div className="mt-4 p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-500">Bien :</span>
            <strong className="text-slate-900">{application.propertyTitle}</strong>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-slate-500">Loyer mensuel :</span>
            <strong className="text-blue-700 font-mono font-black">{formatFCFA(application.monthlyRent)}</strong>
          </div>
          <div className="flex items-center gap-1.5 text-emerald-700 font-bold bg-emerald-50 px-2.5 py-1 rounded-xl border border-emerald-200">
            <ShieldCheck className="w-4 h-4" />
            <span>Caution 100% garantie</span>
          </div>
        </div>

        {/* Contract Preview Paper */}
        <div className="mt-4 p-5 rounded-2xl bg-slate-50/80 border border-slate-200 font-sans text-xs space-y-3.5 text-slate-700 max-h-72 overflow-y-auto leading-relaxed">
          <div className="text-center font-black text-slate-900 uppercase tracking-wider pb-2 border-b border-slate-200">
            CONTRAT DE BAIL À USAGE D'HABITATION SOUS GARANTIE LOC
          </div>

          <p>
            <strong>ENTRE LES SOUSSIGNÉS :</strong><br />
            <strong>1. Le Bailleur :</strong> M. Mamadou Diop / Bailleur Partenaire LOC, domicilié à Dakar, Sénégal.<br />
            <strong>2. Le Preneur (Locataire) :</strong> <strong>{application.tenantName}</strong>, Téléphone : {application.tenantPhone}, Dossier KYC et solvabilité vérifiés et certifiés par la plateforme LOC.<br />
            <strong>3. Le Garant & Opérateur de Caution :</strong> LOC S.A., Société de microfinancement et cautionnement locatif.
          </p>

          <p>
            <strong>ARTICLE 1 — OBJET & DÉSIGNATION DU LOGEMENT :</strong><br />
            Le bailleur donne en location le bien situé à : <span className="text-slate-900 font-bold">{application.propertyAddress || 'Dakar, Sénégal'}</span> ({application.propertyTitle}).
          </p>

          <p>
            <strong>ARTICLE 2 — CONDITIONS FINANCIÈRES & MICRO-PAIEMENTS :</strong><br />
            Le loyer mensuel est fixé à <strong className="text-slate-900 font-mono">{formatFCFA(application.monthlyRent)}</strong>.
            Le Preneur bénéficie de la flexibilité de régler son loyer sous forme de tranches personnalisées (Wave, Orange Money, Free Money ou Carte Bancaire) du 1er au 30 de chaque mois civil.
          </p>

          <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-blue-950 space-y-1">
            <strong>ARTICLE 3 — CLAUSE PARTICULIÈRE DE CAUTION ÉCHELONNÉE LOC :</strong>
            <p className="text-[11px]">
              La caution d'un montant de <strong className="text-blue-900 font-mono">{formatFCFA(application.depositAmount || application.monthlyRent * 2)}</strong> est intégralement débloquée et garantie au Bailleur dès le 1er jour par LOC. Le Preneur s'acquitte de son tiers d'apport initial à l'entrée et rembourse le solde de ladite caution par tranches étalées sur les six (6) premiers mois.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-950 space-y-1">
            <strong>ARTICLE 4 — RÈGLE D'ÉLIGIBILITÉ IMMOBILIÈRE JUSQU'AU REMBOURSEMENT :</strong>
            <p className="text-[11px]">
              En vertu des règles de sécurité financière LOC, le présent logement est immédiatement retiré du catalogue (rendu inéligible). Le Preneur ne pourra souscrire à aucun autre logement du réseau LOC pendant toute la durée d'amortissement de la caution (Mois 1 à 6). La rééligibilité complète du profil est réactivée automatiquement au <strong>Mois 7</strong> dès solde complet des mensualités de caution.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-950 space-y-1">
            <strong>ARTICLE 5 — MANDAT DE GESTION DU BAIL PAR LOC & COMMISSION PROPRIÉTAIRE (3%) :</strong>
            <p className="text-[11px]">
              Pour les propriétaires bailleurs direct dont le bail est administré via LOC, une commission de trois pour cent (3%) du loyer mensuel (soit <strong className="font-mono text-emerald-900">{formatFCFA(application.monthlyRent * 0.03)}</strong>) est prélevée pour la gestion intégrale et la garantie loyer 100% zéro impayé. Le montant net de 97% (<strong className="font-mono text-emerald-900">{formatFCFA(application.monthlyRent * 0.97)}</strong>) est garanti et versé au propriétaire le 1er du mois. <em>(Note : Cette commission de 3% est réservée exclusivement aux propriétaires bailleurs sous mandat de gestion et ne s'applique pas aux courtiers/agences accrédités sous convention de courtage 50/50).</em>
            </p>
          </div>
        </div>

        {/* Signature Box */}
        <div className="mt-4 space-y-3">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-800 flex items-center gap-1.5">
                <PenTool className="w-3.5 h-3.5 text-blue-600" />
                {isTenantSigning ? 'Signature Électronique du Locataire Preneur :' : 'Signature Électronique du Bailleur :'}
              </span>
              <span className="text-[10px] text-slate-500 font-mono flex items-center gap-1">
                <Lock className="w-3 h-3 text-emerald-600" />
                Certificat Crypté OHADA 256-bit
              </span>
            </div>

            <div className="relative">
              <input
                type="text"
                value={signatureName}
                onChange={(e) => setSignatureName(e.target.value)}
                placeholder="Tapez votre prénom et nom pour apposer votre signature"
                className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm text-slate-900 font-serif italic focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <label className="flex items-center gap-2 text-xs text-slate-600 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={hasAgreedTerms}
                onChange={(e) => setHasAgreedTerms(e.target.checked)}
                className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300"
              />
              <span>
                Je certifie avoir lu et accepté l'ensemble des clauses du contrat de bail et du protocole de caution LOC.
              </span>
            </label>
          </div>

          {/* Action Button */}
          <button
            onClick={handleSign}
            disabled={isSignedComplete || !signatureName.trim() || !hasAgreedTerms}
            className={`w-full py-3.5 px-4 rounded-2xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-xs cursor-pointer ${
              isSignedComplete
                ? 'bg-emerald-600 text-white'
                : !hasAgreedTerms || !signatureName.trim()
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                : 'bg-blue-600 hover:bg-blue-700 text-white'
            }`}
          >
            {isSignedComplete ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Bail Signé avec Succès ! Certificat N° {signatureToken}</span>
              </>
            ) : (
              <>
                <PenTool className="w-4 h-4" />
                <span>{isTenantSigning ? 'Signer et Valider mon Bail Électronique' : 'Signer et Transmettre le Bail au Locataire'}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
