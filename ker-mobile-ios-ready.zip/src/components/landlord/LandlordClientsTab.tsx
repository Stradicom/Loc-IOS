import React, { useState } from 'react';
import { 
  Calendar, 
  Clock, 
  MessageSquare, 
  Send, 
  UserCheck, 
  CheckCircle2, 
  XCircle, 
  Bell, 
  FileText, 
  Plus, 
  User, 
  Phone, 
  ShieldCheck, 
  Sparkles,
  MapPin,
  Check,
  ChevronRight,
  AlertCircle
} from 'lucide-react';
import { VisitAppointment, ChatConversation, ChatMessage, TenantApplication, Role } from '../../types';
import { formatFCFA } from '../../utils/finance';

interface LandlordClientsTabProps {
  initialSubTab?: 'visits' | 'chat' | 'lease_alerts';
  appointments: VisitAppointment[];
  applications: TenantApplication[];
  conversations: ChatConversation[];
  onConfirmAppointment: (appointmentId: string) => void;
  onCancelAppointment: (appointmentId: string) => void;
  onAddAppointment: (newAppt: VisitAppointment) => void;
  onSendMessage: (conversationId: string, text: string) => void;
  onSendLeaseSignatureNotification: (applicationId: string, tenantName: string) => void;
  onOpenLeaseModal: (application: TenantApplication) => void;
}

export const LandlordClientsTab: React.FC<LandlordClientsTabProps> = ({
  initialSubTab = 'visits',
  appointments,
  applications,
  conversations,
  onConfirmAppointment,
  onCancelAppointment,
  onAddAppointment,
  onSendMessage,
  onSendLeaseSignatureNotification,
  onOpenLeaseModal,
}) => {
  const [subTab, setSubTab] = useState<'visits' | 'chat' | 'lease_alerts'>(initialSubTab);
  const [chatFilter, setChatFilter] = useState<'all' | 'tenant' | 'landlord'>('all');
  const [selectedConversationId, setSelectedConversationId] = useState<string>(
    conversations[0]?.id || 'conv-1'
  );
  const [messageInput, setMessageInput] = useState<string>('');
  const [isAddingVisit, setIsAddingVisit] = useState<boolean>(false);
  const [notificationSentMap, setNotificationSentMap] = useState<Record<string, boolean>>({});

  // New Visit Form State
  const [visitTenantName, setVisitTenantName] = useState<string>('');
  const [visitTenantPhone, setVisitTenantPhone] = useState<string>('');
  const [visitPropertyTitle, setVisitPropertyTitle] = useState<string>('Studio Cosy — Almadies');
  const [visitDate, setVisitDate] = useState<string>('05 Septembre 2026');
  const [visitTimeSlot, setVisitTimeSlot] = useState<string>('16:00 - 17:00');
  const [visitNotes, setVisitNotes] = useState<string>('');

  const activeConversation = conversations.find(c => c.id === selectedConversationId) || conversations[0];

  const handleSendChatMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim() || !activeConversation) return;

    onSendMessage(activeConversation.id, messageInput.trim());
    setMessageInput('');
  };

  const handleTriggerLeaseNotification = (app: TenantApplication) => {
    onSendLeaseSignatureNotification(app.id, app.tenantName);
    setNotificationSentMap(prev => ({ ...prev, [app.id]: true }));
  };

  const handleCreateVisit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!visitTenantName || !visitTenantPhone) return;

    const newAppt: VisitAppointment = {
      id: `visit-${Date.now()}`,
      propertyId: 'prop-custom',
      propertyTitle: visitPropertyTitle,
      propertyAddress: 'Dakar, Sénégal',
      tenantId: `tenant-${Date.now()}`,
      tenantName: visitTenantName,
      tenantPhone: visitTenantPhone.startsWith('+221') ? visitTenantPhone : `+221 ${visitTenantPhone}`,
      tenantAvatar: visitTenantName.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || 'CL',
      date: visitDate,
      timeSlot: visitTimeSlot,
      status: 'confirmed',
      notes: visitNotes || 'Rendez-vous de visite fixé via LOC.',
    };

    onAddAppointment(newAppt);
    setIsAddingVisit(false);
    setVisitTenantName('');
    setVisitTenantPhone('');
    setVisitNotes('');
  };

  return (
    <div className="space-y-4 text-slate-800">
      {/* Sub Tabs: Visites / Chat Candidats / Notification Baux */}
      <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 border border-slate-200 rounded-2xl">
        <button
          type="button"
          onClick={() => setSubTab('visits')}
          className={`py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
            subTab === 'visits'
              ? 'bg-white text-blue-600 shadow-sm border border-slate-200/60'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Visites ({appointments.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('chat')}
          className={`py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
            subTab === 'chat'
              ? 'bg-white text-blue-600 shadow-sm border border-slate-200/60'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>Chat Candidats</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('lease_alerts')}
          className={`py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
            subTab === 'lease_alerts'
              ? 'bg-white text-blue-600 shadow-sm border border-slate-200/60'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Bell className="w-3.5 h-3.5" />
          <span>Signature Baux</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 1. GESTION DES VISITES SUR RENDEZ-VOUS                                    */}
      {/* ========================================================================= */}
      {subTab === 'visits' && (
        <div className="space-y-4 animate-fade-in">
          <div className="flex items-center justify-between px-1">
            <div>
              <h3 className="text-sm font-black text-slate-900">Planning des Visites sur Rendez-vous</h3>
              <p className="text-[11px] text-slate-500">
                Gérez les visites sollicitées par les candidats locataires ou fixez un créneau direct.
              </p>
            </div>

            <button
              onClick={() => setIsAddingVisit(!isAddingVisit)}
              className="py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Programmer Visite</span>
            </button>
          </div>

          {/* Form to add a new visit appointment */}
          {isAddingVisit && (
            <form onSubmit={handleCreateVisit} className="p-4 rounded-3xl bg-blue-50/70 border border-blue-200 space-y-3 animate-fade-in">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-blue-900 flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-blue-600" />
                  Nouveau Rendez-vous de Visite
                </span>
                <button
                  type="button"
                  onClick={() => setIsAddingVisit(false)}
                  className="text-xs text-slate-400 hover:text-slate-700"
                >
                  Fermer
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[10px] font-bold text-slate-700 block mb-1">Nom du Candidat :</label>
                  <input
                    type="text"
                    value={visitTenantName}
                    onChange={(e) => setVisitTenantName(e.target.value)}
                    placeholder="Ex: Ibrahima Ndiaye"
                    required
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-700 block mb-1">Téléphone (WhatsApp/SMS) :</label>
                  <input
                    type="tel"
                    value={visitTenantPhone}
                    onChange={(e) => setVisitTenantPhone(e.target.value)}
                    placeholder="77 123 45 67"
                    required
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="text-[10px] font-bold text-slate-700 block mb-1">Bien à visiter :</label>
                  <select
                    value={visitPropertyTitle}
                    onChange={(e) => setVisitPropertyTitle(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900"
                  >
                    <option value="Studio Cosy & Lumineux — Almadies">Studio Cosy — Almadies</option>
                    <option value="Appartement F3 Moderne — Mermoz">Appartement F3 — Mermoz</option>
                    <option value="Appartement F4 Standing Vue Mer — Ngor">Appartement F4 — Ngor</option>
                    <option value="Villa Duplex 5 Pièces — Fann Résidence">Villa Duplex — Fann Résidence</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-700 block mb-1">Date :</label>
                  <input
                    type="text"
                    value={visitDate}
                    onChange={(e) => setVisitDate(e.target.value)}
                    placeholder="Ex: 05 Septembre 2026"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-700 block mb-1">Créneau horaire :</label>
                  <select
                    value={visitTimeSlot}
                    onChange={(e) => setVisitTimeSlot(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900"
                  >
                    <option value="10:00 - 11:00">10:00 - 11:00 (Matin)</option>
                    <option value="11:30 - 12:30">11:30 - 12:30 (Matin)</option>
                    <option value="15:00 - 16:00">15:00 - 16:00 (Après-midi)</option>
                    <option value="16:30 - 17:30">16:30 - 17:30 (Après-midi)</option>
                    <option value="18:00 - 19:00">18:00 - 19:00 (Fin de journée)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-700 block mb-1">Remarques ou instructions :</label>
                <input
                  type="text"
                  value={visitNotes}
                  onChange={(e) => setVisitNotes(e.target.value)}
                  placeholder="Ex: Remettre les clés au gardien ou attendre devant l'immeuble."
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900"
                />
              </div>

              <div className="pt-1 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddingVisit(false)}
                  className="py-2 px-3.5 rounded-xl bg-white border border-slate-200 text-slate-700 text-xs font-bold"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm"
                >
                  Confirmer et Notifier le Candidat
                </button>
              </div>
            </form>
          )}

          {/* Visits List */}
          <div className="space-y-3">
            {appointments.map((appt) => (
              <div
                key={appt.id}
                className="p-4 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-3 hover:border-blue-300 transition-colors"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-blue-100 text-blue-700 font-black text-sm flex items-center justify-center shrink-0">
                      {appt.tenantAvatar || 'CL'}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-slate-900">{appt.tenantName}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase border ${
                          appt.status === 'confirmed'
                            ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                            : appt.status === 'pending'
                            ? 'bg-amber-100 text-amber-800 border-amber-200'
                            : 'bg-slate-100 text-slate-600 border-slate-200'
                        }`}>
                          {appt.status === 'confirmed' ? 'Confirmé' : appt.status === 'pending' ? 'À Confirmer' : 'Passé'}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500">{appt.propertyTitle}</p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-bold text-blue-700 flex items-center gap-1 justify-end">
                      <Clock className="w-3.5 h-3.5" />
                      {appt.timeSlot}
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">{appt.date}</span>
                  </div>
                </div>

                {appt.notes && (
                  <p className="text-[11px] text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    💬 {appt.notes}
                  </p>
                )}

                <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-xs">
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                    <Phone className="w-3.5 h-3.5 text-blue-600" />
                    <span>
                      {appt.tenantPhone 
                        ? `${appt.tenantPhone.slice(0, 7)} •• •• ${appt.tenantPhone.slice(-2)} (Canal LOC)`
                        : 'Numéro protégé par LOC'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {appt.status === 'pending' && (
                      <>
                        <button
                          onClick={() => onCancelAppointment(appt.id)}
                          className="py-1 px-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold"
                        >
                          Décliner
                        </button>
                        <button
                          onClick={() => onConfirmAppointment(appt.id)}
                          className="py-1 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-bold flex items-center gap-1"
                        >
                          <Check className="w-3 h-3" />
                          <span>Confirmer Visite</span>
                        </button>
                      </>
                    )}
                    {appt.status === 'confirmed' && (
                      <button
                        onClick={() => {
                          setSubTab('chat');
                        }}
                        className="py-1 px-3 rounded-lg bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100 text-[10px] font-bold flex items-center gap-1"
                      >
                        <MessageSquare className="w-3 h-3" />
                        <span>Contacter Candidat</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. CHAT EN DIRECT AVEC LES LOCATAIRES ET COURTIERS                        */}
      {/* ========================================================================= */}
      {subTab === 'chat' && (
        <div className="space-y-3 animate-fade-in">
          {/* Chat Filter Pills */}
          <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
            <span className="text-xs font-bold text-slate-500 mr-1">Filtrer par interlocuteur :</span>
            {[
              { id: 'all', label: `Tous (${conversations.length})` },
              { id: 'tenant', label: `Locataires (${conversations.filter(c => c.participantRole === 'tenant').length})` },
              { id: 'landlord', label: `Courtiers & Bailleurs (${conversations.filter(c => c.participantRole === 'landlord' || c.participantRole === 'broker').length})` },
            ].map(f => (
              <button
                key={f.id}
                type="button"
                onClick={() => setChatFilter(f.id as any)}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  chatFilter === f.id
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {/* Conversations List */}
            <div className="bg-white border border-slate-200 rounded-3xl p-3 shadow-xs space-y-2 h-[480px] overflow-y-auto">
              <span className="text-xs font-black text-slate-900 block px-2 pt-1">
                Discussions en cours
              </span>
              <div className="space-y-1">
                {conversations
                  .filter(conv => {
                    if (chatFilter === 'tenant') return conv.participantRole === 'tenant';
                    if (chatFilter === 'landlord') return conv.participantRole === 'landlord' || conv.participantRole === 'broker';
                    return true;
                  })
                  .map((conv) => {
                    const isUrlAvatar = conv.participantAvatar && (conv.participantAvatar.startsWith('http') || conv.participantAvatar.startsWith('data:') || conv.participantAvatar.startsWith('blob:')) && !conv.participantAvatar.includes('unsplash.com');
                    const isSelected = selectedConversationId === conv.id;
                    const initials = conv.participantAvatar && !conv.participantAvatar.startsWith('http')
                      ? conv.participantAvatar
                      : (conv.participantName || 'KC').split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);

                    return (
                      <div
                        key={conv.id}
                        onClick={() => setSelectedConversationId(conv.id)}
                        className={`p-2.5 rounded-2xl cursor-pointer transition-all flex items-center gap-2.5 ${
                          isSelected
                            ? 'bg-blue-50 border border-blue-200 text-slate-900 shadow-2xs'
                            : 'hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <div className="w-10 h-10 rounded-xl bg-blue-600 text-white font-bold text-xs flex items-center justify-center shrink-0 overflow-hidden shadow-2xs">
                          {isUrlAvatar ? (
                            <img src={conv.participantAvatar} alt={conv.participantName} className="w-full h-full object-cover" />
                          ) : (
                            <span>{initials}</span>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-xs truncate block">{conv.participantName}</span>
                            <span className="text-[9px] text-slate-400 font-mono">{conv.lastMessageTime}</span>
                          </div>
                          <div className="flex items-center gap-1 mt-0.5">
                            <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-extrabold ${
                              conv.participantRole === 'tenant'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-blue-100 text-blue-800'
                            }`}>
                              {conv.participantRole === 'tenant' ? 'Locataire' : conv.participantRole === 'broker' ? 'Courtier' : 'Bailleur'}
                            </span>
                            <p className="text-[10px] text-slate-500 truncate flex-1">{conv.lastMessage}</p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>

            {/* Active Chat Conversation Pane */}
            <div className="md:col-span-2 bg-white border border-slate-200 rounded-3xl p-4 shadow-xs flex flex-col h-[480px]">
              {activeConversation ? (
                <>
                  {/* Chat Header */}
                  <div className="pb-3 border-b border-slate-200 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-xl bg-blue-600 text-white font-bold text-xs flex items-center justify-center overflow-hidden shadow-2xs">
                        {activeConversation.participantAvatar && (activeConversation.participantAvatar.startsWith('http') || activeConversation.participantAvatar.startsWith('data:') || activeConversation.participantAvatar.startsWith('blob:')) && !activeConversation.participantAvatar.includes('unsplash.com') ? (
                          <img src={activeConversation.participantAvatar} alt={activeConversation.participantName} className="w-full h-full object-cover" />
                        ) : (
                          <span>
                            {activeConversation.participantAvatar && !activeConversation.participantAvatar.startsWith('http')
                              ? activeConversation.participantAvatar
                              : (activeConversation.participantName || 'KC').split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}
                          </span>
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-black text-slate-900">{activeConversation.participantName}</h4>
                          <span className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold ${
                            activeConversation.participantRole === 'tenant'
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                              : 'bg-blue-100 text-blue-800 border border-blue-200'
                          }`}>
                            {activeConversation.participantRole === 'tenant' ? 'Locataire' : activeConversation.participantRole === 'broker' ? 'Courtier' : 'Bailleur'}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-500 font-medium">{activeConversation.propertyTitle || 'Interlocuteur LOC'}</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold font-mono text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                      {activeConversation.participantPhone}
                    </span>
                  </div>

                  {/* Message History */}
                  <div className="flex-1 overflow-y-auto py-3 space-y-2.5 pr-1">
                    {activeConversation.messages.map((msg) => {
                      const isMe = msg.senderRole === 'landlord' || msg.senderRole === 'admin';
                      return (
                        <div
                          key={msg.id}
                          className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                        >
                          <div
                            className={`max-w-[82%] p-3 rounded-2xl text-xs space-y-1 ${
                              isMe
                                ? 'bg-blue-600 text-white rounded-br-none shadow-xs'
                                : 'bg-slate-100 text-slate-800 rounded-bl-none'
                            }`}
                          >
                            <span className="text-[9px] opacity-75 font-semibold block">{msg.senderName}</span>
                            <p className="text-xs leading-relaxed">{msg.text}</p>
                          </div>
                          <span className="text-[9px] text-slate-400 px-1 mt-0.5 font-mono">{msg.timestamp}</span>
                        </div>
                      );
                    })}
                  </div>

                  {/* Send Input */}
                  <form onSubmit={handleSendChatMessage} className="pt-2 border-t border-slate-100 flex gap-2">
                    <input
                      type="text"
                      value={messageInput}
                      onChange={(e) => setMessageInput(e.target.value)}
                      placeholder={`Écrivez votre message à ${activeConversation.participantName}...`}
                      className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none"
                    />
                    <button
                      type="submit"
                      className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white shadow-xs transition-all shrink-0 cursor-pointer"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </form>
                </>
              ) : (
                <div className="flex-1 flex items-center justify-center text-xs text-slate-400">
                  Sélectionnez une discussion pour débuter le chat.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. ALERTE & NOTIFICATION POUR SIGNATURE DE CONTRAT DE BAIL                */}
      {/* ========================================================================= */}
      {subTab === 'lease_alerts' && (
        <div className="space-y-4 animate-fade-in">
          <div className="p-4 rounded-3xl bg-blue-50/80 border border-blue-200 text-xs text-blue-900 flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <span className="font-bold text-blue-950 block">Module Signature Électronique Certifiée LOC</span>
              <p className="text-[11px] leading-relaxed text-blue-800">
                Dès qu'une candidature est approuvée, envoyez une notification instantanée au candidat pour signature numérique. Dès signatures des deux parties, LOC déclenche le versement des 2 mois de caution garantie !
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {applications.map((app) => {
              const isNotified = notificationSentMap[app.id];
              return (
                <div
                  key={app.id}
                  className="p-4 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-3 hover:border-blue-300 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-slate-900">{app.tenantName}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-bold">
                          Score KYC {app.kycScore}/100
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500">{app.propertyTitle}</p>
                      <span className="text-xs font-black text-slate-900 font-mono block mt-1">
                        Loyer : {formatFCFA(app.monthlyRent)} • Caution LOC : {formatFCFA(app.monthlyRent * 2)}
                      </span>
                    </div>

                    <span className={`px-2.5 py-1 rounded-xl text-[10px] font-black uppercase border ${
                      app.status === 'lease_signed'
                        ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                        : app.status === 'approved'
                        ? 'bg-blue-100 text-blue-800 border-blue-200'
                        : 'bg-amber-100 text-amber-800 border-amber-200'
                    }`}>
                      {app.status === 'lease_signed' ? 'Bail Signé' : app.status === 'approved' ? 'Prêt pour Signature' : 'En examen'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
                    <div className="flex items-center gap-2 text-[11px] text-slate-500">
                      <FileText className="w-3.5 h-3.5 text-blue-600" />
                      <span>Bail Type Conforme OHADA & Sénégal</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleTriggerLeaseNotification(app)}
                        className={`py-1.5 px-3 rounded-xl text-[11px] font-bold flex items-center gap-1.5 transition-all ${
                          isNotified
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                        }`}
                      >
                        {isNotified ? (
                          <>
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Notification SMS / Push Envoyée</span>
                          </>
                        ) : (
                          <>
                            <Bell className="w-3.5 h-3.5 text-blue-600" />
                            <span>Activer Notification Signature</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => onOpenLeaseModal(app)}
                        className="py-1.5 px-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold shadow-sm transition-all flex items-center gap-1"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>Ouvrir & Signer le Bail</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
