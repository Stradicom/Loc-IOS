import React, { useState } from 'react';
import { 
  X, 
  Bell, 
  CheckCheck, 
  CheckCircle2, 
  AlertTriangle, 
  Info, 
  TrendingUp,
  Clock,
  ArrowRight,
  ShieldAlert,
  Calendar,
  FileText
} from 'lucide-react';
import { AppNotification, Role, UserProfile, AdminUser } from '../../types';
import { 
  markNotificationAsReadInFirestore, 
  markAllNotificationsAsReadInFirestore 
} from '../../services/firebaseService';

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: AppNotification[];
  currentUser: UserProfile | null;
  currentAdmin: AdminUser | null;
  activeRole: Role;
  onNavigateTab?: (tab: string) => void;
  onConsultNotification?: (notif: AppNotification) => void;
  onOpenLeaseModal?: () => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  isOpen,
  onClose,
  notifications,
  currentUser,
  currentAdmin,
  activeRole,
  onNavigateTab,
  onConsultNotification,
}) => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'unread'>('all');

  if (!isOpen) return null;

  // Filter for the active role / current user
  const userNotifications = notifications.filter(notif => {
    if (!currentUser && !currentAdmin) return false;
    
    if (activeRole === 'admin') {
      return notif.role === 'admin' || notif.userId === 'admin' || notif.userId === 'all' || (currentAdmin && notif.userId === currentAdmin.id);
    }
    
    if (activeRole === 'landlord') {
      return notif.role === 'landlord' || (currentUser && notif.userId === currentUser.id) || notif.userId === 'all';
    }
    
    if (activeRole === 'tenant') {
      return notif.role === 'tenant' && (notif.userId === 'all' || (currentUser && notif.userId === currentUser.id) || notif.userId === 'tenant-demo');
    }
    
    return false;
  }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const displayedNotifications = userNotifications.filter(n => {
    if (activeCategory === 'unread') return !n.isRead;
    return true;
  });

  const unreadCount = userNotifications.filter(n => !n.isRead).length;

  const getCategoryStyles = (category: AppNotification['category']) => {
    switch (category) {
      case 'dossier':
        return { icon: CheckCircle2, color: 'text-emerald-600 bg-emerald-50 border-emerald-100' };
      case 'property':
        return { icon: TrendingUp, color: 'text-blue-600 bg-blue-50 border-blue-100' };
      case 'feature':
        return { icon: CheckCircle2, color: 'text-purple-600 bg-purple-50 border-purple-100' };
      case 'payment_reminder':
        return { icon: Clock, color: 'text-amber-600 bg-amber-50 border-amber-100' };
      case 'payment_delay':
        return { icon: AlertTriangle, color: 'text-orange-600 bg-orange-50 border-orange-100' };
      case 'penalty':
        return { icon: ShieldAlert, color: 'text-rose-600 bg-rose-50 border-rose-100' };
      default:
        return { icon: Info, color: 'text-slate-600 bg-slate-50 border-slate-100' };
    }
  };

  const handleMarkAsRead = async (id: string) => {
    try {
      await markNotificationAsReadInFirestore(id);
    } catch (e) {
      console.error('Error marking read:', e);
    }
  };

  const handleMarkAllRead = async () => {
    const unreadIds = displayedNotifications.filter(n => !n.isRead).map(n => n.id);
    if (unreadIds.length === 0) return;
    try {
      await markAllNotificationsAsReadInFirestore(unreadIds);
    } catch (e) {
      console.error('Error marking all read:', e);
    }
  };

  const handleConsultClick = (notif: AppNotification) => {
    if (onConsultNotification) {
      onConsultNotification(notif);
    } else {
      if (onNavigateTab) {
        if (notif.category === 'property') {
          onNavigateTab('explore');
        } else if (notif.category === 'payment_reminder' || notif.category === 'payment_delay') {
          onNavigateTab('dashboard');
        }
      }
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity cursor-pointer"
        onClick={onClose}
      />

      {/* Slide-out Panel */}
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col z-10 animate-slide-in-right">
        
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-slate-50 text-slate-700">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-slate-900">Centre de Notifications</h2>
              <p className="text-xs text-slate-500">
                {unreadCount === 0 ? 'Aucun message non lu' : `${unreadCount} notification(s) non lue(s)`}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Categories Tab */}
        <div className="px-6 py-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveCategory('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
                activeCategory === 'all' 
                  ? 'bg-slate-900 text-white shadow-xs' 
                  : 'text-slate-600 hover:bg-slate-200/50'
              }`}
            >
              Toutes
            </button>
            <button
              onClick={() => setActiveCategory('unread')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                activeCategory === 'unread' 
                  ? 'bg-slate-900 text-white shadow-xs' 
                  : 'text-slate-600 hover:bg-slate-200/50'
              }`}
            >
              <span>Non lues</span>
              {unreadCount > 0 && (
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
              )}
            </button>
          </div>

          {unreadCount > 0 && (
            <button
              onClick={handleMarkAllRead}
              className="text-xs font-medium text-blue-600 hover:text-blue-800 flex items-center gap-1 transition-colors cursor-pointer"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              Tout marquer lu
            </button>
          )}
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-100 px-3">
          {displayedNotifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full py-12 text-center px-6">
              <div className="w-12 h-12 rounded-full bg-slate-50 flex items-center justify-center text-slate-300 mb-3">
                <Bell className="w-6 h-6" />
              </div>
              <p className="text-sm font-medium text-slate-700">Aucun message pour le moment</p>
              <p className="text-xs text-slate-400 mt-1">Vous serez informé dès que de nouvelles alertes ou événements surviendront.</p>
            </div>
          ) : (
            displayedNotifications.map((notif) => {
              const { icon: CategoryIcon, color: catColor } = getCategoryStyles(notif.category);
              return (
                <div 
                  key={notif.id}
                  onClick={() => handleConsultClick(notif)}
                  className={`p-4 transition-all flex gap-4 cursor-pointer rounded-2xl hover:bg-slate-50 border border-transparent hover:border-slate-200/80 ${
                    notif.isRead ? 'opacity-70 hover:opacity-100' : 'bg-blue-50/40 border-blue-100/60'
                  }`}
                >
                  {/* Category Status Indicator Circle */}
                  <div className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${catColor}`}>
                    <CategoryIcon className="w-5 h-5" />
                  </div>

                  {/* Message details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className={`text-sm font-semibold text-slate-900 leading-tight ${!notif.isRead ? 'font-black text-blue-950' : ''}`}>
                        {notif.title}
                      </h4>
                      {!notif.isRead && (
                        <span className="w-2.5 h-2.5 rounded-full bg-blue-600 shrink-0 mt-1 animate-pulse" />
                      )}
                    </div>
                    
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                      {notif.message}
                    </p>

                    {/* Meta & Actions */}
                    <div className="flex items-center justify-between mt-3 gap-2">
                      <span className="text-[10px] text-slate-400 font-medium">
                        {new Date(notif.createdAt).toLocaleDateString('fr-FR', {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleConsultClick(notif);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-extrabold flex items-center gap-1 shadow-xs transition-all cursor-pointer"
                        >
                          <span>Consulter</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>

                        {!notif.isRead && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleMarkAsRead(notif.id);
                            }}
                            className="text-[11px] font-semibold text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 px-2 py-1 rounded-lg transition-all cursor-pointer"
                          >
                            Lu
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
