import React, { useState } from 'react';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  MapPin, 
  User, 
  Phone, 
  Building2, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Plus, 
  Search, 
  Filter, 
  Send, 
  CalendarCheck, 
  CalendarClock,
  Sparkles,
  MessageSquare,
  FileText,
  X
} from 'lucide-react';
import { VisitAppointment, Property, TenantApplication, Role, AppNotification } from '../../types';
import { formatFCFA } from '../../utils/finance';
import { saveNotificationToFirestore } from '../../services/firebaseService';

interface AppointmentsManagerProps {
  appointments: VisitAppointment[];
  properties?: Property[];
  applications?: TenantApplication[];
  userRole: 'admin' | 'landlord';
  onConfirmAppointment?: (appointmentId: string) => void;
  onCancelAppointment?: (appointmentId: string) => void;
  onAddAppointment?: (newAppt: VisitAppointment) => void;
  onUpdateAppointment?: (appointmentId: string, updates: Partial<VisitAppointment>) => void;
  onSendMessage?: (recipientId: string, text: string) => void;
}

export const AppointmentsManager: React.FC<AppointmentsManagerProps> = ({
  appointments = [],
  properties = [],
  applications = [],
  userRole,
  onConfirmAppointment,
  onCancelAppointment,
  onAddAppointment,
  onUpdateAppointment,
  onSendMessage,
}) => {
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'confirmed' | 'completed' | 'cancelled'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [selectedApptForReschedule, setSelectedApptForReschedule] = useState<VisitAppointment | null>(null);
  
  // New appointment form state
  const [newPropertyId, setNewPropertyId] = useState(properties[0]?.id || '');
  const [newTenantName, setNewTenantName] = useState('');
  const [newTenantPhone, setNewTenantPhone] = useState('+221 77 ');
  const [newDate, setNewDate] = useState('Demain');
  const [newTimeSlot, setNewTimeSlot] = useState('11:00 - 12:00');
  const [newPurpose, setNewPurpose] = useState('Visite des lieux et signature du bail');
  const [newNotes, setNewNotes] = useState('');

  // Reschedule form state
  const [rescheduleDate, setRescheduleDate] = useState('');
  const [rescheduleTime, setRescheduleTime] = useState('');

  // Filtered list
  const filteredAppointments = appointments.filter((appt) => {
    const matchesStatus = filterStatus === 'all' ? true : appt.status === filterStatus;
    const matchesSearch = 
      appt.propertyTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      appt.tenantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      appt.date.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const getStatusBadge = (status: VisitAppointment['status']) => {
    switch (status) {
      case 'confirmed':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Confirmé
          </span>
        );
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-200">
            <CalendarCheck className="w-3.5 h-3.5 text-blue-600" />
            Effectué
          </span>
        );
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-200">
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            Annulé
          </span>
        );
      case 'pending':
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-200">
            <CalendarClock className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
            En attente de validation
          </span>
        );
    }
  };

  const handleCreateAppointment = (e: React.FormEvent) => {
    e.preventDefault();
    const targetProp = properties.find((p) => p.id === newPropertyId) || properties[0];
    const newAppt: VisitAppointment = {
      id: `appt-${Date.now()}`,
      propertyId: targetProp?.id || 'prop-default',
      propertyRefNumber: targetProp?.refNumber || targetProp?.id?.toUpperCase() || 'LOC-DKR-001',
      propertyTitle: targetProp?.title || 'Logement Loc Dakar',
      propertyAddress: targetProp?.address || 'Dakar, Sénégal',
      tenantId: `tenant-${Date.now()}`,
      tenantName: newTenantName || 'Candidat Locataire',
      tenantPhone: newTenantPhone,
      date: newDate,
      timeSlot: newTimeSlot,
      status: 'confirmed',
      notes: `${newPurpose}. ${newNotes ? `Note : ${newNotes}` : ''}`,
      validatedByTenant: true,
      validatedAt: new Date().toISOString(),
    };

    if (onAddAppointment) {
      onAddAppointment(newAppt);
    }
    setIsNewModalOpen(false);
    setNewTenantName('');
    setNewTenantPhone('+221 77 ');
    setNewNotes('');
  };

  const handleSaveReschedule = async () => {
    if (!selectedApptForReschedule) return;

    // Format date for nice display
    let displayDate = rescheduleDate;
    if (rescheduleDate && rescheduleDate.includes('-')) {
      try {
        const parts = rescheduleDate.split('-');
        if (parts.length === 3) {
          const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
          displayDate = d.toLocaleDateString('fr-FR', {
            weekday: 'long',
            day: 'numeric',
            month: 'long',
            year: 'numeric'
          });
          // Capitalize first letter
          displayDate = displayDate.charAt(0).toUpperCase() + displayDate.slice(1);
        }
      } catch {}
    }

    const finalTime = rescheduleTime || selectedApptForReschedule.timeSlot || '15:00 - 16:00';

    if (onUpdateAppointment) {
      onUpdateAppointment(selectedApptForReschedule.id, {
        date: displayDate,
        timeSlot: finalTime,
        status: 'confirmed',
        validatedByTenant: true,
        validatedAt: new Date().toISOString(),
      });
    } else if (onConfirmAppointment) {
      onConfirmAppointment(selectedApptForReschedule.id);
    }

    // Aviser le Bailleur et le Candidat en temps réel
    const notifLandlord: AppNotification = {
      id: `notif-landlord-resched-${Date.now()}`,
      title: `📅 RDV Reprogrammé & Confirmé — ${selectedApptForReschedule.propertyTitle}`,
      message: `Le rendez-vous avec ${selectedApptForReschedule.tenantName} pour "${selectedApptForReschedule.propertyTitle}" a été reprogrammé et confirmé au ${displayDate} à ${finalTime}.`,
      type: 'success',
      createdAt: new Date().toISOString(),
      isRead: false,
      role: 'landlord',
      userId: 'all',
      category: 'visite',
      actionUrl: selectedApptForReschedule.id
    };

    const notifTenant: AppNotification = {
      id: `notif-tenant-resched-${Date.now()}`,
      title: `📅 Visite Reprogrammée & Confirmée — ${selectedApptForReschedule.propertyTitle}`,
      message: `Votre rendez-vous pour la visite de "${selectedApptForReschedule.propertyTitle}" a été confirmé pour le ${displayDate} de ${finalTime}.`,
      type: 'success',
      createdAt: new Date().toISOString(),
      isRead: false,
      role: 'tenant',
      userId: selectedApptForReschedule.tenantId || 'all',
      category: 'visite',
      actionUrl: selectedApptForReschedule.id
    };

    try {
      await saveNotificationToFirestore(notifLandlord);
      await saveNotificationToFirestore(notifTenant);
    } catch (err) {
      console.warn('Error saving reschedule notifications:', err);
    }

    setSelectedApptForReschedule(null);
  };

  return (
    <div className="space-y-5 animate-fade-in text-slate-800" id="appointments-manager-container">
      {/* Header Bar */}
      <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-6 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
              <CalendarIcon className="w-4 h-4" />
            </div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900">
              Gestion des Rendez-vous & Visites
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-800 border border-blue-200">
              {appointments.length} RDV
            </span>
          </div>
          <p className="text-xs text-slate-500 font-medium">
            {userRole === 'admin' 
              ? 'Supervisez tous les créneaux de visite, validation du bail et états des lieux du réseau Loc.' 
              : 'Gérez vos créneaux de visite physique et signatures de bail avec vos candidats locataires.'}
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsNewModalOpen(true)}
          className="px-4 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-2 shadow-xs transition-all shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Programmer un Rendez-vous</span>
        </button>
      </div>

      {/* Filter Tabs & Search */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white border border-slate-200 rounded-2xl p-3 shadow-xs">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          {[
            { id: 'all', label: 'Tous', count: appointments.length },
            { id: 'pending', label: 'En attente', count: appointments.filter((a) => a.status === 'pending').length },
            { id: 'confirmed', label: 'Confirmés', count: appointments.filter((a) => a.status === 'confirmed').length },
            { id: 'completed', label: 'Effectués', count: appointments.filter((a) => a.status === 'completed').length },
            { id: 'cancelled', label: 'Annulés', count: appointments.filter((a) => a.status === 'cancelled').length },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterStatus(tab.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                filterStatus === tab.id
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <span>{tab.label}</span>
              <span
                className={`px-1.5 py-0.2 rounded-md text-[10px] font-mono ${
                  filterStatus === tab.id ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'
                }`}
              >
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher candidat, bien..."
            className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Appointments List */}
      {filteredAppointments.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-3xl p-10 text-center space-y-3">
          <CalendarIcon className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="text-base font-bold text-slate-800">Aucun rendez-vous trouvé</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Aucun créneau ne correspond à vos critères actuels. Cliquez sur « Programmer un Rendez-vous » pour en créer un.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filteredAppointments.map((appt) => (
            <div
              key={appt.id}
              className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-4 hover:border-slate-300 transition-all flex flex-col justify-between"
            >
              <div className="space-y-3">
                {/* Card Header */}
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="text-[10px] font-mono font-bold text-slate-400 uppercase block">
                        RÉF RDV : #{appt.id.toUpperCase().slice(-8)}
                      </span>
                      <span className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-900 text-[10px] font-mono font-bold border border-blue-200">
                        Réf Bien : {appt.propertyRefNumber || appt.propertyId.toUpperCase()}
                      </span>
                    </div>
                    <h3 className="text-sm sm:text-base font-black text-slate-900 line-clamp-1">
                      {appt.propertyTitle}
                    </h3>
                  </div>
                  {getStatusBadge(appt.status)}
                </div>

                {/* Date & Location Pill */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 rounded-2xl bg-blue-50/70 border border-blue-100 flex items-center gap-2 text-blue-950 font-bold">
                    <CalendarIcon className="w-4 h-4 text-blue-600 shrink-0" />
                    <span>{appt.date} • {appt.timeSlot}</span>
                  </div>

                  <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center gap-2 text-slate-700">
                    <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
                    <span className="truncate">{appt.propertyAddress || 'Sur place au logement'}</span>
                  </div>
                </div>

                {/* Candidate Info */}
                <div className="p-3 rounded-2xl bg-slate-50/80 border border-slate-200 flex items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-full bg-blue-600 text-white font-black text-xs flex items-center justify-center shrink-0">
                      {appt.tenantName.charAt(0)}
                    </div>
                    <div className="min-w-0">
                      <span className="font-bold text-slate-900 block truncate">{appt.tenantName}</span>
                      <span className="text-slate-500 font-mono text-[11px] block">{appt.tenantPhone}</span>
                    </div>
                  </div>

                  <a
                    href={`tel:${appt.tenantPhone}`}
                    className="p-2 rounded-xl bg-white border border-slate-200 text-slate-700 hover:text-blue-600 hover:border-blue-300 transition-all flex items-center gap-1 font-bold text-[11px]"
                  >
                    <Phone className="w-3.5 h-3.5 text-blue-600" />
                    <span className="hidden sm:inline">Appeler</span>
                  </a>
                </div>

                {/* Notes & Purpose */}
                {appt.notes && (
                  <p className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <strong className="text-slate-800">Objet :</strong> {appt.notes}
                  </p>
                )}
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-1.5">
                  {appt.status === 'pending' && onConfirmAppointment && (
                    <button
                      type="button"
                      onClick={() => onConfirmAppointment(appt.id)}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-1 shadow-xs transition-all cursor-pointer"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Confirmer le RDV</span>
                    </button>
                  )}

                  {appt.status === 'confirmed' && onUpdateAppointment && (
                    <button
                      type="button"
                      onClick={() => onUpdateAppointment(appt.id, { status: 'completed' })}
                      className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold flex items-center gap-1 shadow-xs transition-all cursor-pointer"
                    >
                      <CalendarCheck className="w-3.5 h-3.5" />
                      <span>Marquer Effectué</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      setSelectedApptForReschedule(appt);
                      const todayISO = new Date().toISOString().split('T')[0];
                      setRescheduleDate(appt.date && appt.date.includes('-') ? appt.date : todayISO);
                      setRescheduleTime(appt.timeSlot || '15:00 - 16:00');
                    }}
                    className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-all cursor-pointer"
                  >
                    Reprogrammer
                  </button>
                </div>

                {appt.status !== 'cancelled' && onCancelAppointment && (
                  <button
                    type="button"
                    onClick={() => onCancelAppointment(appt.id)}
                    className="px-2.5 py-1.5 rounded-xl text-rose-600 hover:bg-rose-50 font-bold transition-all cursor-pointer"
                  >
                    Annuler
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal: Programmer un nouveau Rendez-vous */}
      {isNewModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in text-slate-800">
          <div className="w-full max-w-md bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setIsNewModalOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="space-y-1 mb-5">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs font-semibold">
                <CalendarIcon className="w-3.5 h-3.5" />
                Nouveau Rendez-vous Loc
              </div>
              <h3 className="text-lg font-black text-slate-900">Programmer une Visite / Signature</h3>
            </div>

            <form onSubmit={handleCreateAppointment} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Bien immobilier concerné :</label>
                <select
                  value={newPropertyId}
                  onChange={(e) => setNewPropertyId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {properties.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.title} ({p.neighborhood}) — {formatFCFA(p.monthlyRent)}/m
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Nom complet du locataire :</label>
                <input
                  type="text"
                  required
                  value={newTenantName}
                  onChange={(e) => setNewTenantName(e.target.value)}
                  placeholder="Ex : Moussa Diagne"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Numéro de téléphone :</label>
                <input
                  type="text"
                  required
                  value={newTenantPhone}
                  onChange={(e) => setNewTenantPhone(e.target.value)}
                  placeholder="+221 77 000 00 00"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-mono font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Date :</label>
                  <input
                    type="text"
                    required
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    placeholder="Ex : Samedi 5 Sept."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Créneau horaire :</label>
                  <input
                    type="text"
                    required
                    value={newTimeSlot}
                    onChange={(e) => setNewTimeSlot(e.target.value)}
                    placeholder="15:00 - 16:00"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Motif principal :</label>
                <select
                  value={newPurpose}
                  onChange={(e) => setNewPurpose(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Visite des lieux et signature du bail">Visite des lieux et signature du bail</option>
                  <option value="Visite découverte du logement">Visite découverte du logement</option>
                  <option value="État des lieux entrant & remise des clés">État des lieux entrant & remise des clés</option>
                  <option value="Entretien technique & vérification">Entretien technique & vérification</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Notes complémentaires (facultatif) :</label>
                <textarea
                  rows={2}
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  placeholder="Consignes d'accès, code portail, parking..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-all cursor-pointer"
                >
                  Enregistrer et Notifier le Candidat
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Reprogrammer un rendez-vous */}
      {selectedApptForReschedule && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in text-slate-800">
          <div className="w-full max-w-sm bg-white border border-slate-200 rounded-3xl p-5 shadow-2xl relative">
            <button
              onClick={() => setSelectedApptForReschedule(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="text-base font-black text-slate-900 mb-1">Reprogrammer le Rendez-vous</h3>
            <p className="text-xs text-slate-500 mb-4">{selectedApptForReschedule.propertyTitle} — {selectedApptForReschedule.tenantName}</p>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Sélectionner la Nouvelle Date (Calendrier) :</label>
                <input
                  type="date"
                  min={new Date().toISOString().split('T')[0]}
                  value={rescheduleDate.includes('-') ? rescheduleDate : new Date().toISOString().split('T')[0]}
                  onChange={(e) => setRescheduleDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Nouveau Créneau Horaire :</label>
                <select
                  value={rescheduleTime}
                  onChange={(e) => setRescheduleTime(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
                >
                  <option value="09:00 - 10:00">09:00 - 10:00 (Matin)</option>
                  <option value="10:00 - 11:00">10:00 - 11:00 (Matin)</option>
                  <option value="11:00 - 12:00">11:00 - 12:00 (Matin)</option>
                  <option value="14:00 - 15:00">14:00 - 15:00 (Après-midi)</option>
                  <option value="15:30 - 16:30">15:30 - 16:30 (Après-midi)</option>
                  <option value="17:00 - 18:00">17:00 - 18:00 (Fin de journée)</option>
                </select>
              </div>

              <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200 text-[11px] text-blue-900">
                ℹ️ Lors de la confirmation, des notifications instantanées seront envoyées au <strong>bailleur</strong> et au <strong>candidat</strong>.
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedApptForReschedule(null)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold hover:bg-slate-200 transition-all"
                >
                  Annuler
                </button>
                <button
                  type="button"
                  onClick={handleSaveReschedule}
                  className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-xs transition-all"
                >
                  Confirmer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
