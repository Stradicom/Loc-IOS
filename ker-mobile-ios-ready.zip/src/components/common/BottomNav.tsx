import React from 'react';
import { Home, Search, User, Calculator } from 'lucide-react';
import { Role } from '../../types';

interface BottomNavProps {
  activeRole: Role;
  currentTab: string;
  onTabChange: (tab: string) => void;
  onOpenCalculator: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeRole,
  currentTab,
  onTabChange,
  onOpenCalculator,
}) => {
  if (activeRole === 'tenant') {
    return (
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-xl border-t border-slate-200 px-3 py-2 flex items-center justify-around z-30 shadow-lg text-slate-700">
        <button
          onClick={() => onTabChange('dashboard')}
          className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-2xl transition-all ${
            currentTab === 'dashboard' 
              ? 'text-blue-600 font-bold bg-blue-50 border border-blue-200' 
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Home className="w-4 h-4" />
          <span className="text-[10px] tracking-tight font-bold">Mon Espace Locataire</span>
        </button>

        <button
          onClick={() => onTabChange('explore')}
          className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-2xl transition-all ${
            currentTab === 'explore' 
              ? 'text-blue-600 font-bold bg-blue-50 border border-blue-200' 
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Search className="w-4 h-4" />
          <span className="text-[10px] tracking-tight font-bold">Rechercher un logement</span>
        </button>

        <button
          onClick={onOpenCalculator}
          className="flex flex-col items-center gap-1 px-3 py-1 text-slate-500 hover:text-blue-600 transition-all"
        >
          <div className="w-8 h-8 rounded-2xl bg-blue-600 text-white flex items-center justify-center -mt-1 shadow-md shadow-blue-600/30">
            <Calculator className="w-4 h-4" />
          </div>
          <span className="text-[10px] tracking-tight font-semibold text-slate-700">Simulateur</span>
        </button>
      </div>
    );
  }

  return null;
};
