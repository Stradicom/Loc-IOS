import React from 'react';
import { Smartphone, Monitor, Shield, Home, KeyRound, Wifi, Battery, Signal, LogIn } from 'lucide-react';
import { Role } from '../../types';
import { LogoLoc } from './LogoKer';

interface DeviceFrameProps {
  children: React.ReactNode;
  activeRole: Role;
  onRoleChange: (role: Role) => void;
  onOpenAuth?: () => void;
  deviceMode: 'ios' | 'android' | 'responsive';
  onDeviceModeChange: (mode: 'ios' | 'android' | 'responsive') => void;
}

export const DeviceFrame: React.FC<DeviceFrameProps> = ({
  children,
  activeRole,
  onRoleChange,
  onOpenAuth,
  deviceMode,
  onDeviceModeChange,
}) => {
  const currentTime = '09:41';

  return (
    <div className="min-h-screen bg-[#FAFAFC] text-slate-800 flex flex-col items-center justify-start p-2 sm:p-4 lg:p-6 selection:bg-blue-600 selection:text-white">
      {/* Top Utility Bar - Role Switcher & Device Frame Controls */}
      <header className="w-full max-w-5xl mb-4 bg-white border border-slate-200 rounded-2xl p-3 sm:p-4 shadow-sm flex flex-wrap items-center justify-between gap-3">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <LogoLoc className="w-10 h-10 shadow-sm" />
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-lg sm:text-xl tracking-tight text-[#165CF7] font-['Space_Grotesk']">
                LOC
              </span>
              <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                Fintech Immo
              </span>
            </div>
            <p className="text-xs text-slate-500 hidden sm:block">
              Caution échelonnée & gestion locative par tranche
            </p>
          </div>
        </div>

        {/* Portals & Auth */}
        <div className="flex items-center gap-2">
          {/* Role Portals Switcher */}
          <div className="flex items-center bg-slate-50 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => onRoleChange('tenant')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeRole === 'tenant'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Home className="w-3.5 h-3.5" />
              <span>Locataire</span>
            </button>
            <button
              onClick={() => onRoleChange('landlord')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeRole === 'landlord'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>Propriétaire</span>
            </button>
            <button
              onClick={() => onRoleChange('admin')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeRole === 'admin'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Admin</span>
            </button>
          </div>

          {/* Connexion / Switch Portal Button */}
          {onOpenAuth && (
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all border border-slate-200 shadow-xs"
              title="Interface de connexion dédiée"
            >
              <LogIn className="w-3.5 h-3.5 text-blue-600" />
              <span className="hidden sm:inline">Portail Connexion</span>
            </button>
          )}
        </div>

        {/* Device Viewport Toggle */}
        <div className="hidden md:flex items-center gap-1 bg-slate-50 p-1 rounded-xl border border-slate-200 text-xs">
          <button
            onClick={() => onDeviceModeChange('ios')}
            title="Vue iPhone iOS"
            className={`px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 font-medium transition-all ${
              deviceMode === 'ios' ? 'bg-white shadow-xs text-blue-600 font-bold border border-slate-200' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>iOS</span>
          </button>
          <button
            onClick={() => onDeviceModeChange('android')}
            title="Vue Android Galaxy"
            className={`px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 font-medium transition-all ${
              deviceMode === 'android' ? 'bg-white shadow-xs text-blue-600 font-bold border border-slate-200' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Android</span>
          </button>
          <button
            onClick={() => onDeviceModeChange('responsive')}
            title="Vue Plein Écran Web"
            className={`px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 font-medium transition-all ${
              deviceMode === 'responsive' ? 'bg-white shadow-xs text-blue-600 font-bold border border-slate-200' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Large</span>
          </button>
        </div>
      </header>

      {/* Main Container / Mobile Mockup */}
      <main className="w-full flex justify-center items-start flex-1">
        {deviceMode === 'responsive' ? (
          <div className="w-full max-w-5xl bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden min-h-[820px] flex flex-col">
            {children}
          </div>
        ) : (
          <div
            className={`relative transition-all duration-300 w-full max-w-[420px] bg-slate-100 rounded-[48px] p-3.5 shadow-xl border-[4px] ${
              deviceMode === 'ios' ? 'border-slate-300' : 'border-slate-300'
            }`}
          >
            {/* Phone Outer Frame */}
            <div className="relative w-full bg-white rounded-[38px] overflow-hidden flex flex-col h-[840px] border border-slate-200">
              {/* Native Status Bar */}
              <div className="w-full h-11 bg-slate-50 text-slate-700 px-6 flex items-center justify-between text-xs font-semibold select-none z-30 shrink-0 border-b border-slate-100">
                <span>{currentTime}</span>

                {/* Dynamic Island / Camera cutout */}
                {deviceMode === 'ios' ? (
                  <div className="w-24 h-5 bg-slate-900 rounded-full flex items-center justify-center px-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-slate-700 mr-2" />
                    <div className="w-2 h-2 rounded-full bg-blue-500/80 animate-pulse" />
                  </div>
                ) : (
                  <div className="w-3.5 h-3.5 rounded-full bg-slate-800 border border-slate-300" />
                )}

                <div className="flex items-center gap-1.5 text-slate-500">
                  <Signal className="w-3.5 h-3.5" />
                  <Wifi className="w-3.5 h-3.5" />
                  <Battery className="w-4 h-4 text-slate-700" />
                </div>
              </div>

              {/* Mobile Screen Content */}
              <div className="flex-1 overflow-y-auto overflow-x-hidden flex flex-col bg-white text-slate-800">
                {children}
              </div>

              {/* iOS Home Indicator / Android Bar */}
              <div className="w-full h-6 bg-slate-50 flex items-center justify-center shrink-0 z-30 border-t border-slate-100">
                {deviceMode === 'ios' ? (
                  <div className="w-32 h-1 bg-slate-300 rounded-full" />
                ) : (
                  <div className="w-16 h-1 bg-slate-400 rounded-full" />
                )}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
