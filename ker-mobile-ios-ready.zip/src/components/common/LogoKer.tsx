import React, { useState } from 'react';

interface LogoLocProps {
  className?: string;
  variant?: 'squircle' | 'raw';
}

export const LogoLoc: React.FC<LogoLocProps> = ({ 
  className = "w-9 h-9 sm:w-10 sm:h-10",
  variant = 'squircle'
}) => {
  const [imgSrc, setImgSrc] = useState('/assets/aistudio/Logo_Loc_trimmed.png');

  return (
    <div 
      className={`${className} shrink-0 inline-flex items-center justify-center overflow-hidden rounded-2xl shadow-xs transition-transform duration-200 select-none bg-[#165CF7]`}
    >
      <img 
        src={imgSrc} 
        alt="Loc Logo" 
        onError={() => setImgSrc('/assets/aistudio/Logo_Loc_51a19714.png')}
        className={variant === 'squircle' ? "w-full h-full object-cover scale-[1.03]" : "w-full h-full object-contain"}
        loading="eager"
      />
    </div>
  );
};

// Backwards compatibility alias
export const LogoKer = LogoLoc;
