import React, { useState } from 'react';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  FileText, 
  Send, 
  Sparkles, 
  ShieldCheck,
  Check,
  ChevronDown
} from 'lucide-react';
import { Role } from '../../types';

interface CalendarInviteCardProps {
  invite: {
    appointmentId: string;
    propertyId: string;
    propertyTitle: string;
    propertyAddress?: string;
    date: string;
    timeSlot: string;
    location: string;
    purpose?: string;
    note?: string;
    isConfirmedByTenant?: boolean;
  };
  currentRole?: Role | 'guest';
  isConfirmed?: boolean;
  onValidateAppointment?: (
    appointmentId: string,
    date: string,
    timeSlot: string,
    location: string
  ) => void;
}

export const CalendarInviteCard: React.FC<CalendarInviteCardProps> = ({
  invite,
  currentRole = 'tenant',
  isConfirmed = false,
  onValidateAppointment,
}) => {
  const confirmed = isConfirmed || invite.isConfirmedByTenant;

  const [selectedDate, setSelectedDate] = useState<string>(invite.date || 'Demain');
  const [selectedTime, setSelectedTime] = useState<string>(invite.timeSlot || '11:00');
  const [selectedLocation, setSelectedLocation] = useState<string>(
    invite.location || (invite.propertyAddress ? `Sur place : ${invite.propertyAddress}` : 'Sur place au logement')
  );
  const [isCustomizing, setIsCustomizing] = useState(false);
  const [hasValidatedLocal, setHasValidatedLocal] = useState(confirmed);

  const handleValidate = () => {
    setHasValidatedLocal(true);
    if (onValidateAppointment) {
      onValidateAppointment(invite.appointmentId, selectedDate, selectedTime, selectedLocation);
    }
  };

  const isTenant = currentRole === 'tenant' || currentRole === 'guest';

  return (
    <div className="mt-2.5 mb-1 p-4 rounded-2xl bg-gradient-to-br from-blue-50 via-white to-indigo-50/50 border-2 border-blue-300 text-slate-800 shadow-sm space-y-3.5 max-w-md animate-fade-in">
      {/* Card Header */}
      <div className="flex items-start justify-between gap-2 border-b border-blue-100 pb-2.5">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
            <Calendar className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] font-black uppercase tracking-wider text-blue-700 block">
              Prise de Rendez-vous Officielle
            </span>
            <h4 className="text-xs font-black text-slate-900 leading-tight">
              Visite & Validation du Bail Loc
            </h4>
          </div>
        </div>

        {hasValidatedLocal ? (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1 shrink-0">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            RDV Validé
          </span>
        ) : (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-blue-100 text-blue-800 border border-blue-200 flex items-center gap-1 shrink-0">
            <Clock className="w-3 h-3 text-blue-600" />
            À Valider
          </span>
        )}
      </div>

      {/* Property & Details Box */}
      <div className="space-y-1.5 text-xs">
        <div className="p-2.5 rounded-xl bg-white/90 border border-blue-100 space-y-1">
          <div className="font-extrabold text-slate-900 line-clamp-1">
            🏡 {invite.propertyTitle}
          </div>
          <div className="text-[11px] text-slate-600 flex items-center gap-1">
            <MapPin className="w-3 h-3 text-blue-600 shrink-0" />
            <span className="truncate">{selectedLocation}</span>
          </div>
          {invite.purpose && (
            <div className="text-[10.5px] text-blue-800 font-medium pt-0.5">
              📌 {invite.purpose}
            </div>
          )}
        </div>

        {/* Selected Slot Display */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <div className="p-2 rounded-xl bg-blue-50/80 border border-blue-200 text-center">
            <span className="text-[9.5px] font-bold text-slate-500 block uppercase">Date du RDV</span>
            <span className="text-xs font-black text-blue-900">{selectedDate}</span>
          </div>
          <div className="p-2 rounded-xl bg-blue-50/80 border border-blue-200 text-center">
            <span className="text-[9.5px] font-bold text-slate-500 block uppercase">Créneau Horaire</span>
            <span className="text-xs font-black text-blue-900">{selectedTime}</span>
          </div>
        </div>
      </div>

      {/* Candidate Customization Option before Validation */}
      {isTenant && !hasValidatedLocal && (
        <div className="space-y-2 pt-1 border-t border-blue-100">
          {!isCustomizing ? (
            <button
              type="button"
              onClick={() => setIsCustomizing(true)}
              className="text-[11px] text-blue-700 hover:text-blue-900 font-bold underline flex items-center gap-1"
            >
              <span>Modifier la date ou l'heure du rendez-vous</span>
              <ChevronDown className="w-3 h-3" />
            </button>
          ) : (
            <div className="p-2.5 rounded-xl bg-white border border-blue-200 space-y-2 text-xs">
              <span className="text-[10px] font-bold text-slate-700 block">
                Choisissez votre créneau préféré :
              </span>
              <div className="grid grid-cols-2 gap-1.5">
                <div>
                  <label className="text-[9px] font-bold text-slate-500 block mb-0.5">Date :</label>
                  <input
                    type="date"
                    value={selectedDate.includes('-') ? selectedDate : new Date().toISOString().split('T')[0]}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="w-full p-1.5 rounded-lg border border-slate-200 text-xs"
                  />
                </div>
                <div>
                  <label className="text-[9px] font-bold text-slate-500 block mb-0.5">Heure :</label>
                  <select
                    value={selectedTime}
                    onChange={(e) => setSelectedTime(e.target.value)}
                    className="w-full p-1.5 rounded-lg border border-slate-200 text-xs"
                  >
                    <option value="09:00 - 10:00">09:00 - 10:00</option>
                    <option value="10:00 - 11:00">10:00 - 11:00</option>
                    <option value="11:00 - 12:00">11:00 - 12:00</option>
                    <option value="14:00 - 15:00">14:00 - 15:00</option>
                    <option value="15:30 - 16:30">15:30 - 16:30</option>
                    <option value="17:00 - 18:00">17:00 - 18:00</option>
                  </select>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Validation Controls / Status */}
      {isTenant && !hasValidatedLocal ? (
        <button
          type="button"
          onClick={handleValidate}
          className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
        >
          <CheckCircle2 className="w-4 h-4 text-emerald-200" />
          <span>Valider ce créneau de visite & validation du bail</span>
        </button>
      ) : hasValidatedLocal ? (
        <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 space-y-1 text-center">
          <div className="flex items-center justify-center gap-1.5 text-xs font-black text-emerald-800">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Rendez-vous Confirmé avec Succès !</span>
          </div>
          <p className="text-[10px] text-emerald-700">
            L'Administration Loc et le bailleur ont reçu la confirmation instantanée dans leur messagerie et tableau de bord.
          </p>
        </div>
      ) : (
        <div className="p-2 rounded-xl bg-slate-100 text-[10px] text-slate-600 text-center font-medium">
          ⏳ En attente de validation du calendrier par le candidat locataire.
        </div>
      )}
    </div>
  );
};
