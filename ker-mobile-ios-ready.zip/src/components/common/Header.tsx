import React from 'react';
import { 
  Bell, 
  Calculator, 
  UserCheck, 
  ArrowLeftRight, 
  Home, 
  KeyRound, 
  Shield, 
  LogIn, 
  LogOut, 
  Sparkles, 
  ShieldCheck, 
  Building2,
  FileCheck,
  UserPlus,
  User
} from 'lucide-react';
import { Role, UserProfile } from '../../types';
import { LogoKer } from './LogoKer';

interface HeaderProps {
  activeRole: Role;
  currentUser: UserProfile | null;
  onRoleChange: (role: Role) => void;
  onOpenCalculator: () => void;
  onOpenKYC?: () => void;
  onOpenProfile?: () => void;
  onOpenAuth: (role?: Role) => void;
  onLogout: () => void;
  onNavigateHome: () => void;
  onNavigateCatalog?: () => void;
  kycScore?: number;
  unreadNotificationsCount?: number;
  isSuperAdminLoggedIn?: boolean;
  onToggleNotifications?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeRole,
  currentUser,
  onRoleChange,
  onOpenCalculator,
  onOpenKYC,
  onOpenProfile,
  onOpenAuth,
  onLogout,
  onNavigateHome,
  onNavigateCatalog,
  kycScore = 88,
  unreadNotificationsCount = 2,
  isSuperAdminLoggedIn = false,
  onToggleNotifications,
}) => {
  const isLoggedIn = currentUser !== null;

  return (
    <header className="w-full bg-white/95 backdrop-blur-md border-b border-slate-200 sticky top-0 z-30 shadow-sm text-slate-800">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2.5 sm:py-3.5 flex items-center justify-between gap-2 sm:gap-4">
        
        {/* Brand Logo & Title */}
        <div className="flex items-center gap-2.5 sm:gap-3.5 min-w-0">
          <button 
            onClick={onNavigateHome}
            className="flex items-center gap-2.5 group text-left"
          >
            <LogoKer className="w-9 h-9 sm:w-10 sm:h-10 group-hover:scale-105 transition-transform" />
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="font-black text-base sm:text-xl tracking-tight text-[#165CF7] font-mono">
                  LOC
                </span>
                {isLoggedIn ? (
                  <span className="text-[10px] sm:text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-bold border border-blue-200 whitespace-nowrap">
                    {activeRole === 'tenant' ? 'Espace Locataire' : activeRole === 'landlord' ? 'Espace Propriétaire' : 'Supervision Admin'}
                  </span>
                ) : (
                  <span className="hidden xs:inline-block text-[10px] sm:text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold border border-emerald-200">
                    Apport 1/3 Garanti
                  </span>
                )}
              </div>
              <div className="text-[11px] text-slate-500 truncate font-medium">
                {isLoggedIn ? (
                  <span className="font-semibold text-slate-700">{currentUser.fullName}</span>
                ) : (
                  <span>Fintech Immobilière Dakar</span>
                )}
              </div>
            </div>
          </button>
        </div>

        {/* Navigation Middle: Public Links or Authenticated Switcher */}
        {!isLoggedIn ? (
          <nav className="hidden md:flex items-center gap-1 lg:gap-2 text-xs font-semibold text-slate-600">
            <button
              onClick={onNavigateHome}
              className="px-3 py-1.5 rounded-xl hover:text-blue-600 hover:bg-slate-50 transition-colors"
            >
              Accueil
            </button>
            {onNavigateCatalog && (
              <button
                onClick={onNavigateCatalog}
                className="px-3 py-1.5 rounded-xl hover:text-blue-600 hover:bg-slate-50 transition-colors flex items-center gap-1.5"
              >
                <Building2 className="w-3.5 h-3.5 text-blue-600" />
                <span>Logements disponibles</span>
              </button>
            )}
          </nav>
        ) : (
          <div className="hidden md:flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200">
            {activeRole === 'tenant' && (
              <div
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-white text-blue-600 shadow-xs border border-slate-200/80 cursor-default select-none"
              >
                <Home className="w-3.5 h-3.5 text-blue-600" />
                <span>Espace Locataire</span>
              </div>
            )}

            {activeRole === 'landlord' && (
              <div
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-white text-blue-600 shadow-xs border border-slate-200/80 cursor-default select-none"
              >
                <KeyRound className="w-3.5 h-3.5 text-blue-600" />
                <span>Espace Propriétaire / Courtier</span>
              </div>
            )}

            {activeRole === 'admin' && (
              <div
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-white text-blue-600 shadow-xs border border-slate-200/80 cursor-default select-none"
              >
                <Shield className="w-3.5 h-3.5 text-blue-600" />
                <span>Admin</span>
                {isSuperAdminLoggedIn && (
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                )}
              </div>
            )}
          </div>
        )}

        {/* Action Buttons Right */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          
          {/* Guarantee Fund Indicator (Desktop) */}
          <div className="hidden xl:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <div>
              <span className="text-[9px] text-slate-500 block uppercase tracking-wider font-semibold">Fonds de Garantie</span>
              <span className="font-mono font-black text-emerald-700 text-[11px]">150 000 000 FCFA</span>
            </div>
          </div>

          {/* Quick Simulator button */}
          <button
            onClick={onOpenCalculator}
            title="Simulateur d'apport initial et caution échelonnée"
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-xl bg-blue-50 border border-blue-200 text-blue-700 hover:bg-blue-100 text-xs font-bold transition-all shadow-sm"
          >
            <Calculator className="w-3.5 h-3.5 text-blue-600" />
            <span className="hidden sm:inline">Simulateur</span>
          </button>

          {/* KYC Badge when logged in as tenant */}
          {isLoggedIn && activeRole === 'tenant' && onOpenKYC && (
            <button
              onClick={onOpenKYC}
              title="Mon Dossier de Solvabilité"
              className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 hover:bg-emerald-100 text-xs font-bold transition-all"
            >
              <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>{kycScore}/100</span>
            </button>
          )}

          {/* If NOT logged in: Connect & Register buttons */}
          {!isLoggedIn ? (
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => onOpenAuth()}
                className="flex items-center gap-1.5 px-3.5 py-1.5 sm:py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-sm"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Accès / Inscription</span>
              </button>
            </div>
          ) : (
            /* If LOGGED IN: Role switch on mobile + Profile + Logout button */
            <div className="flex items-center gap-1.5">
              {currentUser && onOpenProfile && (
                <button
                  onClick={onOpenProfile}
                  title="Modifier mon profil"
                  className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-xl bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-800 text-xs font-bold transition-all cursor-pointer"
                >
                  {currentUser.avatarUrl ? (
                    <img src={currentUser.avatarUrl} alt="" className="w-4 h-4 rounded-full object-cover" />
                  ) : (
                    <User className="w-3.5 h-3.5 text-blue-600" />
                  )}
                  <span className="hidden sm:inline">Profil</span>
                </button>
              )}

              <button
                onClick={() => onOpenAuth()}
                title="Changer d'espace"
                className="md:hidden flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-200"
              >
                <ArrowLeftRight className="w-3.5 h-3.5 text-blue-600" />
                <span className="text-[11px]">Espaces</span>
              </button>

              <button
                onClick={onLogout}
                title="Se déconnecter"
                className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-xl bg-rose-50 border border-rose-200 hover:bg-rose-100 text-rose-700 text-xs font-bold transition-all"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Déconnexion</span>
              </button>
            </div>
          )}

          {/* Notifications Icon (when logged in) */}
          {isLoggedIn && (
            <div className="relative">
              <button
                onClick={onToggleNotifications}
                className="p-2 sm:p-2.5 rounded-xl bg-slate-100 border border-slate-200 text-slate-600 hover:text-slate-900 transition-colors relative"
                title="Notifications"
              >
                <Bell className="w-4 h-4" />
                {unreadNotificationsCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-600 text-white rounded-full text-[9px] font-bold flex items-center justify-center animate-pulse">
                    {unreadNotificationsCount}
                  </span>
                )}
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
