import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageSquare, 
  X, 
  Send, 
  Minus, 
  Sparkles, 
  ShieldCheck, 
  Phone, 
  CheckCircle2, 
  Clock, 
  Building2,
  ChevronDown
} from 'lucide-react';
import { ChatConversation, ChatMessage, UserProfile, SupportTicket } from '../../types';
import { CalendarInviteCard } from './CalendarInviteCard';
import { LogoLoc } from './LogoKer';

interface FloatingChatWidgetProps {
  currentUser?: UserProfile | null;
  conversations?: ChatConversation[];
  onSendMessage?: (conversationId: string, text: string) => void;
  onCreateTicket?: (ticket: Partial<SupportTicket>) => void;
  isOpenExternal?: boolean;
  onToggleExternal?: () => void;
  initialPropertyMessage?: { refNumber?: string; title?: string } | null;
  onValidateAppointment?: (appointmentId: string, date: string, timeSlot: string, location: string) => void;
}

export const FloatingChatWidget: React.FC<FloatingChatWidgetProps> = ({
  currentUser,
  conversations = [],
  onSendMessage,
  onCreateTicket,
  isOpenExternal,
  onToggleExternal,
  initialPropertyMessage,
  onValidateAppointment,
}) => {
  // RULE 1: Floating Widget is NOT visible for Admin (only session simple, tenant, landlord/broker)
  if (currentUser?.role === 'admin') {
    return null;
  }

  const [internalIsOpen, setInternalIsOpen] = useState(false);
  const [inputText, setInputText] = useState('');
  const [isMinimized, setIsMinimized] = useState(false);
  const [localMessages, setLocalMessages] = useState<ChatMessage[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const prevUserRef = useRef<UserProfile | null | undefined>(currentUser);

  const isOpen = isOpenExternal !== undefined ? isOpenExternal : internalIsOpen;

  // RULE 2: Logout session reset (reset to blank session simple)
  useEffect(() => {
    if (prevUserRef.current && !currentUser) {
      // User logged out -> Reset to fresh blank conversation for session simple
      setLocalMessages([
        {
          id: `welcome-guest-${Date.now()}`,
          senderId: 'loc-support',
          senderName: 'Conseiller Loc & Pôle Risque',
          senderRole: 'admin',
          text: `Bonjour ! 👋 Bienvenue sur le support en direct Loc. Vous êtes en mode session simple (invité). Comment pouvons-nous vous aider aujourd'hui ?`,
          timestamp: 'À l\'instant',
          isRead: true,
        }
      ]);
      setInputText('');
    }
    prevUserRef.current = currentUser;
  }, [currentUser]);
  const toggleOpen = () => {
    if (onToggleExternal) {
      onToggleExternal();
    } else {
      setInternalIsOpen(!internalIsOpen);
    }
  };

  const activeUserId = currentUser?.id || 'tenant-demo';
  const activeRole = currentUser?.role || 'tenant';
  const targetConv = conversations.find(
    c => c.participantId === activeUserId || c.id === `conv-${activeUserId}` || c.participantRole === activeRole
  ) || conversations[0];

  // Initialize initial welcome message if conversation is empty
  useEffect(() => {
    if (targetConv && targetConv.messages && targetConv.messages.length > 0) {
      setLocalMessages(targetConv.messages);
    } else if (localMessages.length === 0) {
      setLocalMessages([
        {
          id: 'welcome-msg',
          senderId: 'loc-support',
          senderName: 'Conseiller Loc & Pôle Risque',
          senderRole: 'admin',
          text: `Bonjour ${currentUser?.fullName ? currentUser.fullName.split(' ')[0] : ''} ! 👋 Bienvenue sur le support en direct Loc. Comment pouvons-nous vous aider aujourd'hui ?`,
          timestamp: 'À l\'instant',
          isRead: true,
        }
      ]);
    }
  }, [targetConv, currentUser]);

  // Scroll to bottom on new message
  useEffect(() => {
    if (isOpen && !isMinimized) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [localMessages, isOpen, isMinimized]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const userText = inputText.trim();
    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      senderId: activeUserId,
      senderName: currentUser?.fullName || 'Locataire Loc',
      senderRole: activeRole,
      text: userText,
      timestamp: 'À l\'instant',
      isRead: true,
    };

    setLocalMessages(prev => [...prev, newMsg]);
    setInputText('');

    if (onSendMessage) {
      const convId = targetConv ? targetConv.id : `conv-${activeUserId}`;
      onSendMessage(convId, userText);
    }

    // Trigger Ticket creation for Admin
    if (onCreateTicket) {
      onCreateTicket({
        userId: currentUser?.id || `guest-${Date.now()}`,
        userName: currentUser?.fullName || 'Utilisateur Invité (Session Simple)',
        userPhone: currentUser?.phone || '+221 77 000 00 00',
        userRole: currentUser ? (currentUser.role as any) : 'guest',
        subject: `Demande de Chat Support (${userText.substring(0, 35)}...)`,
        lastMessage: userText,
        priority: 'normal',
      });
    }

    // Friendly instant AI assist response if appropriate
    setTimeout(() => {
      let replyText = "Votre message a été transmis aux équipes de gestion Loc. Un conseiller va vous répondre sous 15 minutes.";
      const lower = userText.toLowerCase();

      if (lower.includes('caution') || lower.includes('dossier') || lower.includes('24h') || lower.includes('validation')) {
        replyText = "Votre dossier de caution Loc est analysé en priorité (délai < 24h). Vous recevrez un SMS et un e-mail dès validation de votre garantie.";
      } else if (lower.includes('tranche') || lower.includes('payer') || lower.includes('wave') || lower.includes('orange')) {
        replyText = "Vous pouvez régler vos micro-versements directement depuis l'onglet « Synthèse du Loyer » par Wave ou Orange Money, sans aucun frais supplémentaire.";
      } else if (lower.includes('panne') || lower.includes('reparation') || lower.includes('fuite') || lower.includes('clim')) {
        replyText = "Pour une intervention rapide, vous pouvez soumettre une demande dans l'onglet « Signalements & Pannes ». Un artisan agréé Loc sera mandaté.";
      }

      setLocalMessages(prev => [
        ...prev,
        {
          id: `reply-${Date.now()}`,
          senderId: 'loc-support',
          senderName: 'Support Loc (Réponse Rapide)',
          senderRole: 'admin',
          text: replyText,
          timestamp: 'À l\'instant',
          isRead: true,
        }
      ]);
    }, 900);
  };

  const handleQuickChip = (text: string) => {
    setInputText(text);
  };

  return (
    <>
      {/* FLOATING TRIGGER BUTTON (Always visible at bottom right) */}
      <div 
        id="floating-chat-trigger"
        className="fixed bottom-20 right-4 sm:bottom-6 sm:right-6 z-50 flex items-center gap-2"
      >
        <button
          type="button"
          onClick={toggleOpen}
          className="relative w-14 h-14 rounded-full bg-linear-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-xl flex items-center justify-center transition-all duration-300 transform hover:scale-105 active:scale-95 border-2 border-white ring-4 ring-blue-500/20 group cursor-pointer"
          title="Ouvrir le chat Support Loc"
          aria-label="Ouvrir le chat Loc"
        >
          {isOpen ? (
            <X className="w-6 h-6 transition-transform group-hover:rotate-90" />
          ) : (
            <>
              <MessageSquare className="w-6 h-6 transition-transform group-hover:scale-110" />
              <span className="absolute top-0 right-0 w-4 h-4 bg-emerald-500 border-2 border-white rounded-full flex items-center justify-center text-[9px] font-black">
                1
              </span>
            </>
          )}
        </button>
      </div>

      {/* FLOATING CHAT WINDOW */}
      {isOpen && (
        <div 
          id="floating-chat-window"
          className={`fixed bottom-24 right-4 sm:bottom-24 sm:right-6 z-50 w-[92vw] sm:w-[380px] bg-white border border-slate-200 rounded-3xl shadow-2xl flex flex-col overflow-hidden transition-all duration-300 ${
            isMinimized ? 'h-16' : 'h-[520px] max-h-[80vh]'
          }`}
        >
          {/* Top Bar Header */}
          <div className="bg-linear-to-r from-slate-900 to-blue-950 text-white p-4 flex items-center justify-between shadow-xs">
            <div className="flex items-center gap-3">
              <div className="relative">
                <LogoLoc className="w-9 h-9" />
                <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-slate-900 rounded-full" />
              </div>

              <div>
                <div className="flex items-center gap-1.5">
                  <h4 className="text-xs font-black">Support Loc & Risque</h4>
                  <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
                </div>
                <p className="text-[10px] text-emerald-400 font-medium flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  En ligne • Réponse &lt; 15 min
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setIsMinimized(!isMinimized)}
                className="p-1.5 rounded-xl hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
                title={isMinimized ? "Agrandir" : "Réduire"}
              >
                {isMinimized ? <ChevronDown className="w-4 h-4" /> : <Minus className="w-4 h-4" />}
              </button>
              <button
                type="button"
                onClick={toggleOpen}
                className="p-1.5 rounded-xl hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
                title="Fermer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {!isMinimized && (
            <>
              {/* Quick Action Suggestion Chips */}
              <div className="px-3 py-2 bg-slate-50 border-b border-slate-100 flex items-center gap-1.5 overflow-x-auto no-scrollbar text-[11px]">
                {[
                  '📋 Statut de ma caution',
                  '💳 Payer une tranche',
                  '🔑 Visite & Bail',
                  '🛠️ Signaler une panne'
                ].map((chip, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleQuickChip(chip.replace(/^[^\s]+\s/, ''))}
                    className="px-2.5 py-1 rounded-full bg-white border border-slate-200 hover:border-blue-400 text-slate-700 hover:text-blue-700 font-bold whitespace-nowrap shadow-2xs transition-colors shrink-0"
                  >
                    {chip}
                  </button>
                ))}
              </div>

              {/* Messages Body */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50/50">
                {localMessages.map((msg) => {
                  const isMe = msg.senderRole === activeRole || msg.senderId === activeUserId;
                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} animate-fade-in`}
                    >
                      <div
                        className={`max-w-[85%] p-3 rounded-2xl text-xs space-y-1 ${
                          isMe
                            ? 'bg-blue-600 text-white rounded-br-xs shadow-xs'
                            : 'bg-white text-slate-800 rounded-bl-xs border border-slate-200 shadow-2xs'
                        }`}
                      >
                        <span className={`text-[9px] font-bold block ${isMe ? 'text-blue-100' : 'text-slate-500'}`}>
                          {msg.senderName}
                        </span>
                        <p className="text-xs leading-relaxed font-medium whitespace-pre-wrap">{msg.text}</p>

                        {/* Interactive Calendar / Visit Appointment Card */}
                        {msg.appointmentInvite && (
                          <CalendarInviteCard
                            invite={msg.appointmentInvite}
                            currentRole={activeRole}
                            onValidateAppointment={onValidateAppointment}
                          />
                        )}
                      </div>
                      <span className="text-[9px] text-slate-400 px-1 mt-0.5 font-mono">{msg.timestamp}</span>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>

              {/* Bottom Input Area */}
              <form onSubmit={handleSend} className="p-3 bg-white border-t border-slate-200 flex items-center gap-2">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="Posez votre question à Loc..."
                  className="flex-1 bg-slate-100 border border-slate-200 rounded-2xl px-3.5 py-2.5 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none font-medium transition-colors"
                />
                <button
                  type="submit"
                  disabled={!inputText.trim()}
                  className={`p-2.5 rounded-2xl text-white shadow-xs transition-all flex items-center justify-center shrink-0 ${
                    inputText.trim()
                      ? 'bg-blue-600 hover:bg-blue-700 cursor-pointer'
                      : 'bg-slate-300 cursor-not-allowed'
                  }`}
                  aria-label="Envoyer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </>
          )}
        </div>
      )}
    </>
  );
};
