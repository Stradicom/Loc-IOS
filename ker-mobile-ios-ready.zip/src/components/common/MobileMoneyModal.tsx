import React, { useState, useEffect } from 'react';
import { X, CheckCircle2, QrCode, ArrowRight, ShieldCheck, Smartphone, CreditCard, Sparkles, Loader2, Zap } from 'lucide-react';
import { PaymentMethod } from '../../types';
import { formatFCFA, getCurrentPeriod, getNextMonthFirstDay } from '../../utils/finance';
import confetti from 'canvas-confetti';

interface MobileMoneyModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentMonthDueTotal?: number;
  currentMonthPaidAmount?: number;
  initialPresetAmount?: number;
  onPaymentSuccess: (amount: number, method: PaymentMethod, reference: string) => void;
}

export const MobileMoneyModal: React.FC<MobileMoneyModalProps> = ({
  isOpen,
  onClose,
  currentMonthDueTotal = 133333,
  currentMonthPaidAmount = 70000,
  initialPresetAmount,
  onPaymentSuccess,
}) => {
  const safeDueTotal = currentMonthDueTotal && currentMonthDueTotal > 0 ? currentMonthDueTotal : 133333;
  const safePaidAmount = typeof currentMonthPaidAmount === 'number' && currentMonthPaidAmount >= 0 ? currentMonthPaidAmount : 0;
  const remainingDue = Math.max(0, safeDueTotal - safePaidAmount);

  // Strict Wave payment method restriction per user requirement
  const selectedMethod: PaymentMethod = 'wave';
  const [selectedAmountPreset, setSelectedAmountPreset] = useState<number | 'custom'>(() => {
    if (initialPresetAmount && initialPresetAmount > 0) return initialPresetAmount;
    return remainingDue > 0 ? Math.min(25000, remainingDue) : 10000;
  });
  const [customAmount, setCustomAmount] = useState<string>(() => {
    if (initialPresetAmount && initialPresetAmount > 0) return initialPresetAmount.toString();
    return (remainingDue > 0 ? Math.min(25000, remainingDue) : 10000).toString();
  });
  const [phoneNumber, setPhoneNumber] = useState<string>('77 890 12 34');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [generatedRef, setGeneratedRef] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      const activeSafeDue = currentMonthDueTotal && currentMonthDueTotal > 0 ? currentMonthDueTotal : 133333;
      const activeSafePaid = typeof currentMonthPaidAmount === 'number' && currentMonthPaidAmount >= 0 ? currentMonthPaidAmount : 0;
      const nextRem = Math.max(0, activeSafeDue - activeSafePaid);

      if (initialPresetAmount && initialPresetAmount > 0) {
        setSelectedAmountPreset(initialPresetAmount);
        setCustomAmount(initialPresetAmount.toString());
      } else {
        const defaultAmt = nextRem > 0 ? (nextRem >= 25000 ? 25000 : nextRem) : 10000;
        setSelectedAmountPreset(defaultAmt);
        setCustomAmount(defaultAmt.toString());
      }
      setIsSuccess(false);
      setIsProcessing(false);
    }
  }, [isOpen, initialPresetAmount, currentMonthDueTotal, currentMonthPaidAmount]);

  if (!isOpen) return null;

  const rawFinalAmount =
    selectedAmountPreset === 'custom'
      ? parseInt(customAmount || '0', 10)
      : selectedAmountPreset;
  const finalAmount = isNaN(rawFinalAmount) || rawFinalAmount < 0 ? 0 : rawFinalAmount;
  const remainingAfterPayment = Math.max(0, remainingDue - finalAmount);

  const handleSelectPreset = (amt: number) => {
    setSelectedAmountPreset(amt);
    setCustomAmount(amt.toString());
  };

  const handlePay = () => {
    if (finalAmount <= 0) return;

    setIsProcessing(true);
    const refCode = `WAV-DKR-${Math.floor(10000 + Math.random() * 90000)}`;
    setGeneratedRef(refCode);

    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {
        // Confetti fallback
      }

      setTimeout(() => {
        onPaymentSuccess(finalAmount, 'wave', refCode);
        setIsSuccess(false);
        onClose();
      }, 2000);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in text-slate-800">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {isSuccess ? (
          <div className="text-center py-8 space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto border border-emerald-200 animate-bounce">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-xl font-bold text-slate-900">Versement de Tranche Réussi !</h3>
            <p className="text-sm text-slate-600">
              Votre tranche de <span className="font-bold text-slate-900 font-mono">{formatFCFA(finalAmount)}</span> a été comptabilisée en direct. La jauge de progression s'actualise instantanément.
            </p>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs font-mono text-slate-600">
              Réf Transaction : {generatedRef}
            </div>
            <p className="text-xs text-emerald-700 font-semibold flex items-center justify-center gap-1">
              <ShieldCheck className="w-4 h-4" />
              Reçu numérique & décompte locataire actualisés
            </p>
          </div>
        ) : (
          <div className="space-y-5">
            {/* Modal Title */}
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-semibold border border-blue-200 mb-2">
                <Zap className="w-3.5 h-3.5 text-amber-500" />
                Paiement de loyer par tranches
              </div>
              <h2 className="text-xl font-bold text-slate-900">Régler une Tranche</h2>
              <p className="text-xs text-slate-500 font-medium">
                Versez à votre rythme du 1er au 30 du mois jusqu'au solde total.
              </p>
            </div>

            {/* Current Rent Status Pill (Real-time Live Sync) */}
            <div className="p-4 rounded-2xl bg-slate-900 text-white shadow-md space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Déjà versé ce mois :</span>
                  <span className="text-sm font-extrabold text-emerald-400 font-mono">
                    {formatFCFA(safePaidAmount)}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total exigible mois :</span>
                  <span className="text-sm font-extrabold text-white font-mono">
                    {formatFCFA(safeDueTotal)}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-0.5">
                <div>
                  <span className="text-[10px] font-bold text-slate-300 block">Reste actuel à payer :</span>
                  <span className="text-base font-black text-rose-400 font-mono">
                    {formatFCFA(remainingDue)}
                  </span>
                </div>

                <div className="text-right">
                  <span className="text-[10px] font-bold text-blue-300 block">Après ce versement :</span>
                  <span className={`text-xs font-mono font-black px-2.5 py-1 rounded-lg border transition-all ${
                    remainingAfterPayment === 0
                      ? 'bg-emerald-500 text-white border-emerald-400 animate-pulse'
                      : 'bg-blue-900/80 text-blue-200 border-blue-700'
                  }`}>
                    {remainingAfterPayment === 0 ? '0 FCFA (Soldé 🎉)' : formatFCFA(remainingAfterPayment)}
                  </span>
                </div>
              </div>
            </div>

            {/* Check if current month rent is already 100% paid */}
            {remainingDue <= 0 ? (
              <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-300 text-center space-y-3 shadow-xs">
                <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-200">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-black text-emerald-950">
                    Loyer de {getCurrentPeriod()} Intégralement Soldé ! 🎉
                  </h3>
                  <p className="text-xs text-emerald-800 leading-relaxed font-medium max-w-xs mx-auto">
                    Vous avez réglé la totalité de votre loyer du mois en cours (<span className="font-mono font-bold">{formatFCFA(safeDueTotal)}</span>). Votre quittance certifiée Loc est générée.
                  </p>
                </div>

                <div className="p-3 bg-white/80 rounded-xl border border-emerald-200 text-xs font-bold text-slate-700">
                  🔒 Versements par tranche bloqués jusqu'au <span className="text-blue-700 font-black">{getNextMonthFirstDay()}</span>
                </div>

                <button
                  type="button"
                  onClick={onClose}
                  className="w-full py-3 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-xs transition-all cursor-pointer"
                >
                  Fermer & Consulter mes Quittances
                </button>
              </div>
            ) : (
              <>
                {/* Tranche Presets */}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-700 block flex items-center justify-between">
                    <span>Montant de votre tranche à verser :</span>
                    <span className="text-[11px] font-mono text-blue-700 font-bold">{formatFCFA(finalAmount)}</span>
                  </label>
                  
                  <div className="grid grid-cols-2 gap-2">
                    {initialPresetAmount && initialPresetAmount > 0 && (
                      <button
                        type="button"
                        onClick={() => handleSelectPreset(initialPresetAmount)}
                        className={`col-span-2 py-2.5 px-3 rounded-xl border text-xs font-bold font-mono transition-all flex items-center justify-between cursor-pointer ${
                          selectedAmountPreset === initialPresetAmount || (selectedAmountPreset === 'custom' && parseInt(customAmount, 10) === initialPresetAmount)
                            ? 'bg-blue-600 border-blue-600 text-white shadow-xs'
                            : 'bg-blue-50 border-blue-200 text-blue-900 hover:bg-blue-100'
                        }`}
                      >
                        <span>Tranche choisie :</span>
                        <span>{formatFCFA(initialPresetAmount)}</span>
                      </button>
                    )}

                    {[10000, 25000, 50000].map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => handleSelectPreset(preset)}
                        className={`py-2.5 px-3 rounded-xl border text-xs font-bold font-mono transition-all cursor-pointer ${
                          selectedAmountPreset === preset || (selectedAmountPreset === 'custom' && parseInt(customAmount, 10) === preset)
                            ? 'bg-blue-600 border-blue-600 text-white shadow-xs'
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        {formatFCFA(preset)}
                      </button>
                    ))}

                    <button
                      type="button"
                      onClick={() => handleSelectPreset(remainingDue > 0 ? remainingDue : 10000)}
                      className={`py-2.5 px-3 rounded-xl border text-xs font-bold font-mono transition-all cursor-pointer ${
                        selectedAmountPreset === remainingDue || (selectedAmountPreset === 'custom' && parseInt(customAmount, 10) === remainingDue)
                          ? 'bg-emerald-600 border-emerald-600 text-white shadow-xs'
                          : 'bg-emerald-50 border-emerald-300 text-emerald-900 hover:bg-emerald-100'
                      }`}
                    >
                      Tout solder ({formatFCFA(remainingDue)})
                    </button>
                  </div>

                  {/* Custom Amount option */}
                  <div className="pt-1">
                    <div className="relative">
                      <input
                        type="number"
                        min="1000"
                        step="1000"
                        value={customAmount}
                        onChange={(e) => {
                          setSelectedAmountPreset('custom');
                          setCustomAmount(e.target.value);
                        }}
                        placeholder="Saisissez un montant libre..."
                        className="w-full bg-slate-50 border border-blue-400 rounded-xl pl-3 pr-16 py-2.5 text-sm text-slate-900 font-bold font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      <span className="absolute right-3 top-3 text-xs text-slate-500 font-semibold">
                        FCFA
                      </span>
                    </div>
                  </div>
                </div>

                {/* Payment Method Selector (Wave ONLY per user request) */}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-700 block">
                    Moyen de paiement Mobile Money :
                  </label>

                  <div className="w-full">
                    {/* Wave Senegal Only */}
                    <div className="p-3.5 rounded-2xl bg-sky-50 border-2 border-sky-400 text-slate-900 ring-2 ring-sky-300/40 shadow-xs flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-sky-500 text-white flex items-center justify-center font-black text-base shrink-0 shadow-xs">
                          🌊
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-extrabold text-slate-900 block">Wave Senegal</span>
                            <span className="text-[10px] bg-sky-600 text-white px-2 py-0.5 rounded-full font-bold">Exclusif Loc</span>
                          </div>
                          <span className="text-[11px] text-sky-800 font-medium">Frais réduits 1% • Validation instantanée</span>
                        </div>
                      </div>
                      <CheckCircle2 className="w-5 h-5 text-sky-600" />
                    </div>
                  </div>
                </div>

                {/* Mobile number input for Wave */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 flex items-center justify-between">
                    <span>Numéro de téléphone mobile :</span>
                    <span className="text-[11px] text-blue-700 font-mono">+221 (Sénégal)</span>
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500 text-xs font-semibold">
                      +221
                    </div>
                    <input
                      type="tel"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="77 123 45 67"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-14 pr-3 py-2 text-sm text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {/* Submit Action */}
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={handlePay}
                    disabled={isProcessing || finalAmount <= 0}
                    className="w-full py-3.5 px-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-xs flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Communication avec Wave Senegal...</span>
                      </>
                    ) : (
                      <>
                        <span>Valider le versement de {formatFCFA(finalAmount)}</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
