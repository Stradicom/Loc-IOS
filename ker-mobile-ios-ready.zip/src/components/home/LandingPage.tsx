import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Sparkles, 
  ArrowRight, 
  Calculator, 
  CheckCircle2, 
  Home, 
  KeyRound, 
  Building2, 
  Castle,
  TrendingUp, 
  Smartphone, 
  Clock, 
  BadgePercent, 
  Coins, 
  Lock, 
  Users, 
  Check, 
  Star, 
  ChevronRight, 
  MapPin, 
  Bed, 
  Bath, 
  Maximize2,
  Zap,
  PhoneCall,
  FileCheck,
  Award,
  Wallet,
  ShieldAlert
} from 'lucide-react';
import { Property } from '../../types';
import { calculateDepositPlan, calculateClassicPlan, formatFCFA } from '../../utils/finance';
import { LogoKer } from '../common/LogoKer';

interface LandingPageProps {
  properties: Property[];
  onSelectProperty: (property: Property) => void;
  onOpenAuth: (initialRole?: 'tenant' | 'landlord' | 'admin') => void;
  onOpenCalculator: () => void;
  onOpenCatalog: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  properties,
  onSelectProperty,
  onOpenAuth,
  onOpenCalculator,
  onOpenCatalog,
}) => {
  // Simulator State
  const [simulatedRent, setSimulatedRent] = useState<number>(150000);
  const [selectedNeighborhoodFilter, setSelectedNeighborhoodFilter] = useState<string>('all');

  // Calculations for simulator with exact LOC formula & classic formula
  const simulatedPlan = calculateDepositPlan(simulatedRent);
  const simulatedClassicPlan = calculateClassicPlan(simulatedRent);

  // Filter approved properties
  const approvedProperties = properties.filter(p => (p.approvalStatus === 'approved' || p.approvalStatus === undefined) && p.isAvailable !== false);
  const featuredProperties = approvedProperties.filter(p => p.featured || p.monthlyRent <= 250000).slice(0, 6);
  const neighborhoods = ['all', 'Almadies', 'Mermoz', 'Plateau', 'Ngor', 'Ouakam', 'Fann Résidence'];

  const filteredFeatured = selectedNeighborhoodFilter === 'all'
    ? featuredProperties
    : approvedProperties.filter(p => p.neighborhood.toLowerCase().includes(selectedNeighborhoodFilter.toLowerCase()));

  return (
    <div className="w-full space-y-16 sm:space-y-24 bg-white text-slate-800">
      
      {/* ================= 1. HERO SECTION (LUMINEUX) ================= */}
      <section className="relative overflow-hidden pt-6 sm:pt-12 pb-8 sm:pb-16 bg-gradient-to-b from-blue-50/50 via-white to-white border-b border-slate-100">
        <div className="max-w-5xl mx-auto text-center space-y-6 sm:space-y-8 px-4">
          
          {/* Badge Innovation */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-100/70 border border-blue-200 text-blue-800 text-xs sm:text-sm font-semibold shadow-sm">
            <Sparkles className="w-4 h-4 text-blue-600" />
            <span>Fintech Immobilière Pionnière au Sénégal</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          </div>

          {/* Main Title */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-[1.15]">
            Emménagez à Dakar avec <br className="hidden sm:inline" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
              seulement 1/3 d'apport initial.
            </span>
          </h1>

          {/* Subtitle */}
          <p className="max-w-2xl mx-auto text-sm sm:text-base lg:text-lg text-slate-600 leading-relaxed">
            Fini le blocage des 3 mois d’avance (2 mois de caution + 1 mois d’agence). 
            <strong className="text-slate-900 font-semibold"> Loc échelonne vos frais d'entrée</strong> et vous permet de régler votre loyer en micro-versements par <span className="text-blue-600 font-semibold">Wave</span> et <span className="text-orange-600 font-semibold">Orange Money</span>, avec une garantie de loyer 100% sécurisée pour les propriétaires.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 pt-2">
            <button
              onClick={() => onOpenAuth('tenant')}
              className="w-full sm:w-auto px-7 py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm sm:text-base shadow-lg shadow-blue-600/25 flex items-center justify-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <span>Trouver un logement & S'inscrire</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onOpenAuth('landlord')}
              className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 hover:text-slate-900 font-bold text-sm sm:text-base transition-all flex items-center justify-center gap-2 shadow-sm"
            >
              <KeyRound className="w-4 h-4 text-blue-600" />
              <span>Espace Propriétaire & Bailleur</span>
            </button>
          </div>

          {/* Metrics bar */}
          <div className="pt-8 sm:pt-12 grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 max-w-4xl mx-auto">
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 text-center shadow-sm">
              <span className="text-2xl sm:text-3xl font-black font-mono text-blue-600 block">1/3</span>
              <span className="text-xs text-slate-600 mt-1 block font-medium">Apport initial au lieu de 3 mois</span>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 text-center shadow-sm">
              <span className="text-2xl sm:text-3xl font-black font-mono text-emerald-600 block">150M</span>
              <span className="text-xs text-slate-600 mt-1 block font-medium">FCFA Fonds de Garantie Loc</span>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 text-center shadow-sm">
              <span className="text-2xl sm:text-3xl font-black font-mono text-indigo-600 block">99.4%</span>
              <span className="text-xs text-slate-600 mt-1 block font-medium">Taux de recouvrement ponctuel</span>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 text-center shadow-sm">
              <span className="text-2xl sm:text-3xl font-black font-mono text-slate-900 block">24h</span>
              <span className="text-xs text-slate-600 mt-1 block font-medium">Délai moyen de validation du bail</span>
            </div>
          </div>
        </div>
      </section>

      {/* ================= 2. PROPOSITIONS DES ACTIFS IMMOBILIERS (CATALOGUE EN PREMIER) ================= */}
      <section className="max-w-6xl mx-auto px-4 space-y-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-bold">
              <Home className="w-3.5 h-3.5 text-blue-600" />
              <span>Actifs Immobiliers Certifiés Loc</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
              Logements Éligibles à l'Échelonnement 1/3
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Chambres, studios et appartements vérifiés à Dakar. Réservez avec seulement 1/3 de caution.
            </p>
          </div>

          <button
            onClick={onOpenCatalog}
            className="self-start md:self-auto px-4 py-2 rounded-xl bg-blue-50 border border-blue-200 hover:bg-blue-100 text-blue-700 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm"
          >
            <span>Voir tous les {approvedProperties.length} logements disponibles</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Neighborhood Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {neighborhoods.map((n) => (
            <button
              key={n}
              onClick={() => setSelectedNeighborhoodFilter(n)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
                selectedNeighborhoodFilter === n
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border border-slate-200'
              }`}
            >
              {n === 'all' ? '✨ Tous les quartiers' : n}
            </button>
          ))}
        </div>

        {/* Property Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {filteredFeatured.map((property) => {
            const plan = calculateDepositPlan(property.monthlyRent, property.depositMonths || 2);

            return (
              <div
                key={property.id}
                onClick={() => onSelectProperty(property)}
                className="group bg-white rounded-2xl border border-slate-200/90 hover:border-blue-300 overflow-hidden shadow-sm hover:shadow-md transition-all cursor-pointer flex flex-col"
              >
                {/* Image Container */}
                <div className="relative aspect-[16/10] overflow-hidden bg-slate-100">
                  <img
                    src={property.images[0]}
                    alt={property.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                  
                  {/* Top Badges */}
                  <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
                    <span className="px-2.5 py-1 rounded-full bg-white/90 backdrop-blur-md text-slate-900 text-[11px] font-extrabold shadow-sm">
                      {property.typeLabel}
                    </span>
                    <span className="px-2.5 py-1 rounded-full bg-emerald-600 text-white text-[10px] font-bold tracking-tight shadow-sm flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      Éligible Loc • Apport : {formatFCFA(plan.initialTotalDue)}
                    </span>
                  </div>

                  {/* Location at bottom of photo */}
                  <div className="absolute bottom-2.5 left-3 text-white flex items-center gap-1 text-xs font-semibold drop-shadow-md">
                    <MapPin className="w-3.5 h-3.5 text-blue-400" />
                    <span>{property.neighborhood}, {property.city}</span>
                  </div>
                </div>

                {/* Body Content */}
                <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 line-clamp-1 group-hover:text-blue-600 transition-colors">
                      {property.title}
                    </h3>
                    <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                      {property.categoryDesc}
                    </p>
                  </div>

                  {/* Surface & Features */}
                  <div className="flex items-center gap-3 text-xs text-slate-600 pt-1 border-t border-slate-100">
                    <div className="flex items-center gap-1 font-medium">
                      <Maximize2 className="w-3.5 h-3.5 text-slate-400" />
                      <span>{property.surface} m²</span>
                    </div>
                    <div className="flex items-center gap-1 font-medium">
                      <Bed className="w-3.5 h-3.5 text-slate-400" />
                      <span>{property.rooms} ch.</span>
                    </div>
                    <div className="flex items-center gap-1 font-medium">
                      <Bath className="w-3.5 h-3.5 text-slate-400" />
                      <span>{property.bathrooms} sdb</span>
                    </div>
                  </div>

                  {/* Pricing Comparison Box */}
                  <div className="p-3 rounded-2xl bg-blue-50/90 border border-blue-200/90 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-600 font-medium">Loyer Mensuel :</span>
                      <span className="text-slate-900 font-black font-mono">{formatFCFA(property.monthlyRent)}</span>
                    </div>
                    <div className="flex items-center justify-between pt-1.5 border-t border-blue-200/70">
                      <div className="flex items-center gap-1.5 text-blue-900 font-extrabold text-xs">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>Apport initial Loc :</span>
                      </div>
                      <span className="text-xs sm:text-sm font-black font-mono text-blue-800 bg-white px-2 py-0.5 rounded-lg border border-blue-200 shadow-2xs">
                        {formatFCFA(plan.initialTotalDue)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-600">
                      <span>Sans Loc : <span className="line-through text-slate-400 font-mono">{formatFCFA(plan.standardInitialDue)}</span></span>
                      <span className="text-emerald-700 font-extrabold bg-emerald-100/90 px-1.5 py-0.5 rounded text-[10px]">
                        -{plan.savingsPercent}% à l'entrée
                      </span>
                    </div>
                  </div>

                  {/* View Details Button */}
                  <button className="w-full py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors shadow-xs">
                    <span>Consulter ce logement</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ================= 3. SIMULATEUR D'ÉCHELONNEMENT LOC (PLACÉ JUSTE APRÈS LES ACTIFS) ================= */}
      <section className="max-w-4xl mx-auto px-4">
        <div className="bg-gradient-to-b from-slate-50 to-white border-2 border-blue-100 rounded-3xl p-6 sm:p-10 shadow-lg space-y-8">
          
          <div className="text-center space-y-2 max-w-xl mx-auto">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100 border border-blue-200 text-blue-800 text-xs font-bold">
              <Calculator className="w-3.5 h-3.5 text-blue-600" />
              <span>Simulateur d'Échelonnement Loc</span>
            </div>
            <h2 className="text-[24px] font-black text-slate-900">
              Calculez votre apport d'entrée selon votre loyer
            </h2>
            <p className="text-xs sm:text-sm text-slate-600">
              Ajustez le curseur ci-dessous pour comparer instantanément le modèle traditionnel sénégalais et la formule Loc étalée.
            </p>
          </div>

          {/* Slider for Rent with Modern White Design */}
          <div className="relative rounded-3xl bg-white text-slate-900 p-6 sm:p-8 border border-slate-200/80 shadow-xl space-y-6 overflow-hidden">
            {/* Subtle Ambient Background Accents */}
            <div className="absolute -top-20 -right-20 w-60 h-60 bg-blue-100/60 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-indigo-100/60 rounded-full blur-3xl pointer-events-none" />

            <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-bold shadow-md shadow-blue-500/20">
                  <Zap className="w-5 h-5 text-amber-300" />
                </div>
                <div>
                  <label className="text-xs font-black uppercase tracking-widest text-slate-500 block">
                    Loyer Mensuel Estimé
                  </label>
                  <span className="text-[11px] text-slate-500 font-medium">Sélectionnez le type de bien ou ajustez le curseur</span>
                </div>
              </div>

              <div className="text-left sm:text-right">
                <div className="text-2xl sm:text-3xl font-black font-mono text-blue-600">
                  {simulatedRent.toLocaleString('fr-FR')} <span className="text-sm font-sans font-bold text-slate-500">FCFA / mois</span>
                </div>
              </div>
            </div>

            {/* Quick Preset Buttons with Modern White & Blue Cards */}
            <div className="relative space-y-2">
              <span className="text-[10px] uppercase font-extrabold tracking-wider text-slate-400 block">
                Préréglages par Catégorie :
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {[
                  { label: 'Chambres', sub: '50 000 F', val: 50000, icon: Bed },
                  { label: 'Studios', sub: '150 000 F', val: 150000, icon: Home },
                  { label: 'Appartement', sub: '350 000 F', val: 350000, icon: Building2 },
                  { label: 'Villa Luxe', sub: '1 000 000 F', val: 1000000, icon: Castle },
                ].map((p) => {
                  const IconComp = p.icon;
                  const isSelected = simulatedRent === p.val;
                  return (
                    <button
                      key={p.val}
                      type="button"
                      onClick={() => setSimulatedRent(p.val)}
                      className={`p-3.5 rounded-2xl text-left transition-all duration-200 cursor-pointer flex flex-col justify-between gap-2 border relative overflow-hidden group ${
                        isSelected
                          ? 'bg-blue-600 text-white border-blue-600 shadow-lg shadow-blue-600/25 scale-[1.02]'
                          : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between w-full">
                        <IconComp className={`w-4 h-4 ${isSelected ? 'text-amber-300' : 'text-blue-600'}`} />
                        {isSelected && (
                          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                        )}
                      </div>
                      <div>
                        <span className={`text-xs font-black block leading-tight ${isSelected ? 'text-white' : 'text-slate-900'}`}>{p.label}</span>
                        <span className={`text-[10px] font-mono font-bold ${isSelected ? 'text-blue-100' : 'text-slate-500'}`}>
                          ({p.sub})
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Interactive Slider Gauge */}
            <div className="relative pt-2 pb-1 space-y-3">
              <div className="relative flex items-center">
                <input
                  type="range"
                  min="50000"
                  max="1000000"
                  step="10000"
                  value={simulatedRent}
                  onChange={(e) => setSimulatedRent(Number(e.target.value))}
                  className="w-full accent-blue-600 bg-slate-200 h-3 rounded-full cursor-pointer transition-all appearance-none"
                  style={{
                    background: `linear-gradient(to right, #2563eb 0%, #4f46e5 ${((simulatedRent - 50000) / (1000000 - 50000)) * 100}%, #e2e8f0 ${((simulatedRent - 50000) / (1000000 - 50000)) * 100}%, #e2e8f0 100%)`
                  }}
                />
              </div>
              
              {/* Dynamic Numeric Graduations Synchronized with Gauge Position */}
              <div className="flex justify-between items-center text-[10px] sm:text-[11px] font-mono select-none px-0.5 gap-1 overflow-x-auto scrollbar-none">
                {[50000, 250000, 500000, 750000, 1000000].map((val) => {
                  const isExact = simulatedRent === val;
                  const isClose = Math.abs(simulatedRent - val) < 60000;
                  const isPassed = simulatedRent >= val;

                  return (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setSimulatedRent(val)}
                      className={`transition-all duration-200 cursor-pointer shrink-0 ${
                        isExact
                          ? 'text-blue-600 font-black scale-105 px-1.5 sm:px-2.5 py-0.5 rounded-xl bg-blue-50 border border-blue-200 shadow-2xs'
                          : isClose
                          ? 'text-blue-700 font-bold'
                          : isPassed
                          ? 'text-slate-800 font-semibold'
                          : 'text-slate-400 font-medium hover:text-slate-700'
                      }`}
                      title={`Définir sur ${val.toLocaleString('fr-FR')} FCFA`}
                    >
                      <span className="hidden sm:inline">{val.toLocaleString('fr-FR')} F</span>
                      <span className="inline sm:hidden">{val >= 1000000 ? '1M F' : `${val / 1000}k F`}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>



          {/* Comparison Cards: Traditionnel vs Loc */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* 1. Modèle Paiement Classique (Sans Loc) */}
            <div className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-300 text-slate-900 space-y-3 sm:space-y-4 shadow-sm">
              <div className="flex items-center justify-between gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-slate-800 text-white font-extrabold text-[9px] sm:text-[10px] uppercase whitespace-nowrap shadow-xs">
                  Paiement Classique (sans Loc)
                </span>
              </div>

              <div>
                <span className="text-[11px] sm:text-xs text-slate-500 block whitespace-nowrap font-medium">Apport au comptant (3 mois) :</span>
                <span className="text-xl sm:text-3xl font-black font-mono text-blue-600 block whitespace-nowrap">
                  {formatFCFA(simulatedClassicPlan.initialTotalDue)}
                </span>
              </div>

              <ul className="text-[10px] sm:text-xs space-y-1.5 text-slate-700 border-t border-slate-200 pt-2.5">
                <li className="flex items-center justify-between gap-1.5">
                  <span className="whitespace-nowrap truncate">• 2 mois caution légale :</span>
                  <span className="font-bold font-mono whitespace-nowrap text-blue-600">{formatFCFA(simulatedClassicPlan.legalDeposit)}</span>
                </li>
                <li className="flex items-center justify-between gap-1.5">
                  <span className="whitespace-nowrap truncate">• 1 mois commission courtier :</span>
                  <span className="font-bold font-mono whitespace-nowrap text-blue-600">{formatFCFA(simulatedClassicPlan.brokerFee)}</span>
                </li>
                <li className="flex items-center justify-between gap-1.5 text-emerald-700 font-semibold">
                  <span className="whitespace-nowrap truncate">✨ Frais de dossier plateforme :</span>
                  <span className="font-bold font-mono whitespace-nowrap text-blue-600">0 FCFA (Gratuit)</span>
                </li>
                <li className="flex items-center justify-between gap-1.5 text-slate-900 font-semibold pt-1 border-t border-slate-200">
                  <span className="whitespace-nowrap truncate">• Loyer mensuel + Gestion 10% :</span>
                  <span className="font-bold font-mono whitespace-nowrap text-blue-600">{formatFCFA(simulatedClassicPlan.monthlyTotalRent)}/mo</span>
                </li>
              </ul>
            </div>

            {/* 2. Modèle Loc FinTech */}
            <div className="p-4 sm:p-5 rounded-2xl bg-blue-50/80 border-2 border-blue-500 shadow-md space-y-3 sm:space-y-4 relative overflow-hidden">
              <div className="flex items-center justify-between gap-2">
                <span className="px-2 py-0.5 rounded-full bg-blue-600 text-white font-extrabold text-[9px] sm:text-[10px] uppercase tracking-wider shadow-sm whitespace-nowrap">
                  Formule Loc
                </span>
                <span className="text-[8px] sm:text-[10px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded-full whitespace-nowrap">
                  Économie : -{simulatedPlan.savingsPercent}% ({formatFCFA(simulatedPlan.immediateSavings)})
                </span>
              </div>

              <div>
                <span className="text-[11px] sm:text-xs text-slate-600 block whitespace-nowrap">Apport initial à l'entrée :</span>
                <span className="text-xl sm:text-3xl font-black font-mono text-blue-700 block whitespace-nowrap">
                  {formatFCFA(simulatedPlan.initialTotalDue)}
                </span>
              </div>

              <ul className="text-[10px] sm:text-xs space-y-1.5 text-slate-700 border-t border-blue-200 pt-2.5">
                <li className="flex items-center justify-between gap-1.5 text-emerald-700 font-bold">
                  <span className="whitespace-nowrap truncate">✨ Apport initial payé :</span>
                  <span className="font-mono whitespace-nowrap">{formatFCFA(simulatedPlan.initialTotalDue)}</span>
                </li>
                <li className="flex items-center justify-between gap-1.5">
                  <span className="whitespace-nowrap truncate">• Reliquat caution (6 mois) :</span>
                  <span className="font-mono font-bold whitespace-nowrap text-slate-800">+{formatFCFA(simulatedPlan.monthlyDepositInstallment)}/mo</span>
                </li>
                <li className="flex items-center justify-between gap-1.5">
                  <span className="whitespace-nowrap truncate">• Frais de gestion (10%) :</span>
                  <span className="font-mono font-bold text-indigo-700 whitespace-nowrap">+{formatFCFA(simulatedPlan.managementFeeAmount)}/mo</span>
                </li>
                <li className="flex items-center justify-between gap-1.5 font-bold text-slate-900 pt-0.5">
                  <span className="whitespace-nowrap truncate">• Total mois 1 à 6 :</span>
                  <span className="font-mono text-blue-700 whitespace-nowrap">{formatFCFA(simulatedPlan.monthlyTotalMonths1to6)}/mo</span>
                </li>
                <li className="flex items-center justify-between gap-1.5 text-emerald-800 font-semibold pt-1 border-t border-blue-200/60 text-[9px] sm:text-[11px]">
                  <span className="whitespace-nowrap truncate">• Dès 7e mois (gestion 10%) :</span>
                  <span className="font-mono text-emerald-700 font-bold whitespace-nowrap">{formatFCFA(simulatedPlan.monthlyTotalMonth7Onwards)}/mo</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Action inside simulator */}
          <div className="p-4 rounded-2xl bg-slate-100 text-center space-y-2 border border-slate-200">
            <p className="text-xs font-semibold text-slate-700">
              Vous avez déjà trouvé un logement ou souhaitez proposer votre bien avec la garantie Loc ?
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              <button
                onClick={() => onOpenAuth('tenant')}
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-sm transition-all"
              >
                Inscrivez-vous comme Locataire
              </button>
              <button
                onClick={() => onOpenAuth('landlord')}
                className="px-5 py-2.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 text-xs font-bold shadow-sm transition-all"
              >
                Inscrivez-vous comme Propriétaire
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ================= 4. VALEUR AJOUTÉE PAR PROFIL ================= */}
      <section className="max-w-6xl mx-auto px-4 space-y-8">
        <div className="text-center space-y-2 max-w-xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-bold">
            <Users className="w-3.5 h-3.5 text-blue-600" />
            <span>Un Écosystème Gagnant-Gagnant</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
            Pourquoi choisir la plateforme Loc ?
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Des garanties financières et des innovations technologiques pour chaque acteur du marché immobilier sénégalais.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Card 1: Locataires */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center font-bold">
              <Home className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">Pour les Locataires</span>
              <h3 className="text-lg font-bold text-slate-900 mt-1">Accès Facilité & Loyer Flexible</h3>
            </div>
            <ul className="text-xs space-y-2.5 text-slate-600">
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Apport 1/3 à l'entrée</strong> : emménagez sans bloquer l'équivalent de 3 mois de revenus.</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Micro-versements</strong> : payez votre loyer par tranche via Wave et Orange Money du 1er au 30.</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Quittances électroniques certifiées</strong> instantanément téléchargeables à chaque paiement.</span>
              </li>
            </ul>
            <button
              onClick={() => onOpenAuth('tenant')}
              className="w-full py-2.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
            >
              <span>Accéder à l'Espace Locataire</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Card 2: Propriétaires & Bailleurs */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold">
              <KeyRound className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">Pour les Bailleurs (Propriétaires & Agences)</span>
              <h3 className="text-lg font-bold text-slate-900 mt-1">Baux Gérés Loc • 3% Commission & 100% Loyers Garantis</h3>
            </div>
            <ul className="text-xs space-y-2.5 text-slate-600">
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Frais de gestion de 3%</strong> seulement pour les agences et propriétaires (97% nets reversés).</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Caution perçue à 100% (2 mois)</strong> dès le 1er jour sans aucune déduction, versée d'un bloc.</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Fonds de garantie 150M FCFA</strong> assurant le versement ponctuel le 1er de chaque mois avec 0% risque impayé.</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Baux numériques certifiés OHADA</strong> avec quittances dématérialisées et signature électronique.</span>
              </li>
            </ul>
            <button
              onClick={() => onOpenAuth('landlord')}
              className="w-full py-2.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
            >
              <span>Accéder à l'Espace Bailleur</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Card 3: Courtiers & Agences Apporteurs */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider">Pour les Courtiers & Apporteurs</span>
              <h3 className="text-lg font-bold text-slate-900 mt-1">Encaissement Immédiat de la Caution (50% du 3ème mois)</h3>
            </div>
            <ul className="text-xs space-y-2.5 text-slate-600">
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Honoraires de courtage (50% du 3ème mois)</strong> encaissés immédiatement dès la signature du bail.</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Zéro frais de gestion mensuels</strong> pour le courtier : perception directe de la commission sur la caution.</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Taux d'occupation multiplié par 2</strong> en éliminant la barrière des 3 mois d'avance pour vos clients.</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Gestion centralisée des mandats</strong> et candidatures pré-qualifiées par scoring IA.</span>
              </li>
            </ul>
            <button
              onClick={() => onOpenAuth('landlord')}
              className="w-full py-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
            >
              <span>Espace Courtier Partenaire</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* ================= 5. PROCESSUS EN 4 ÉTAPES ================= */}
      <section className="max-w-5xl mx-auto px-4 space-y-8">
        <div className="text-center space-y-2 max-w-xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-slate-700 text-xs font-bold">
            <Clock className="w-3.5 h-3.5 text-blue-600" />
            <span>Simplicité & Rapidité</span>
          </div>
          <h2 className="text-[25px] font-black text-slate-900">
            Comment ça marche ? Votre bail en 4 étapes
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="w-8 h-8 rounded-xl bg-blue-600 text-white font-black text-sm flex items-center justify-center shadow-sm">
              1
            </div>
            <h4 className="text-sm font-bold text-slate-900">Inscription & Choix du bien</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Créez votre compte en 1 minute et postulez au logement de votre choix sur Dakar.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="w-8 h-8 rounded-xl bg-blue-600 text-white font-black text-sm flex items-center justify-center shadow-sm">
              2
            </div>
            <h4 className="text-sm font-bold text-slate-900">Validation Solvabilité en 24h</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Notre algorithme évalue votre dossier et valide votre éligibilité à l'échelonnement.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="w-8 h-8 rounded-xl bg-blue-600 text-white font-black text-sm flex items-center justify-center shadow-sm">
              3
            </div>
            <h4 className="text-sm font-bold text-slate-900">Apport 1/3 & Signature</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Réglez uniquement 1/3 des frais d'entrée par Wave ou Orange Money et signez le bail certifié.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="w-8 h-8 rounded-xl bg-blue-600 text-white font-black text-sm flex items-center justify-center shadow-sm">
              4
            </div>
            <h4 className="text-sm font-bold text-slate-900">Remise des Clés & Suivi</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Emménagez sereinement. Le propriétaire est indemnisé à 100% et vous fractionnez vos loyers.
            </p>
          </div>
        </div>
      </section>


      {/* ================= 7. CTA BANNER & FOOTER (LUMINEUX) ================= */}
      <section className="max-w-5xl mx-auto px-4 pb-12">
        <div className="rounded-3xl bg-gradient-to-r from-blue-600 to-indigo-600 p-8 sm:p-12 text-white text-center space-y-6 shadow-xl shadow-blue-600/20">
          <h2 className="text-[32px] font-black tracking-tight">
            Prêt à transformer votre expérience locative à Dakar ?
          </h2>
          <p className="max-w-xl mx-auto text-sm sm:text-base text-blue-100">
            Rejoignez des centaines de locataires et propriétaires qui bénéficient déjà de la flexibilité et de la garantie Loc.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={() => onOpenAuth('tenant')}
              className="w-full sm:w-auto px-7 py-3.5 rounded-2xl bg-white hover:bg-slate-50 text-blue-600 font-bold text-sm shadow-md transition-all"
            >
              Créer mon compte Locataire
            </button>
            <button
              onClick={() => onOpenAuth('landlord')}
              className="w-full sm:w-auto px-7 py-3.5 rounded-2xl bg-blue-700/80 hover:bg-blue-800 border border-white/20 text-white font-bold text-sm transition-all"
            >
              Créer mon compte Propriétaire
            </button>
          </div>
        </div>

        {/* Clean Light Footer */}
        <div className="mt-12 pt-8 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <LogoKer className="w-5 h-5 shadow-xs" />
            <span className="font-black text-[#165CF7] text-sm">LOC</span>
            <span>• Fintech & Proptech Immobilière au Sénégal</span>
          </div>
          <p>© 2026 Plateforme Loc — Tous droits réservés. Dakar, Sénégal.</p>
        </div>
      </section>

    </div>
  );
};
