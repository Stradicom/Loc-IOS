import React, { useState } from 'react';
import { 
  X, 
  Home, 
  KeyRound, 
  Shield, 
  Smartphone, 
  Mail, 
  Lock, 
  ArrowRight, 
  CheckCircle2, 
  Sparkles, 
  Building, 
  Check, 
  Fingerprint, 
  ShieldCheck,
  User,
  Zap,
  Briefcase,
  Coins,
  AlertCircle,
  UserPlus,
  LogIn,
  BadgeCheck,
  FileText,
  Upload,
  Camera,
  MessageSquare
} from 'lucide-react';
import { Role, UserProfile, AdminUser, LandlordPartner } from '../../types';
import { LogoKer } from '../common/LogoKer';
import { mockUserProfiles, demoAccounts } from '../../data/mockData';
import { loginWithGoogle, saveUserProfileToFirestore } from '../../services/firebaseService';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (profile: UserProfile) => void;
  onRegisterUser?: (profile: UserProfile) => void;
  registeredUsers?: UserProfile[];
  initialRole?: Role;
  adminUsers?: AdminUser[];
  landlords?: LandlordPartner[];
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  onRegisterUser,
  registeredUsers = [],
  initialRole = 'tenant',
  adminUsers = [],
  landlords = [],
}) => {
  const [selectedRole, setSelectedRole] = useState<Role>(initialRole);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('register');
  const [landlordSubRole, setLandlordSubRole] = useState<'proprietaire' | 'courtier'>('proprietaire');
  
  // Multi-step Registration Workflow:
  // Step 1: Form (Informations personnelles & Identifiants)
  // Step 2: 2FA Verification (Code SMS ou WhatsApp)
  // Step 3: Signature Convention LOC & Pièce d'Identité CNI
  const [regStep, setRegStep] = useState<1 | 2 | 3>(1);
  
  const [twoFactorMethod, setTwoFactorMethod] = useState<'sms' | 'whatsapp'>('sms');
  const [generated2FACode, setGenerated2FACode] = useState<string>('849201');
  const [entered2FACode, setEntered2FACode] = useState<string>('');
  const [twoFactorSent, setTwoFactorSent] = useState<boolean>(false);
  
  const [conventionAgreed, setConventionAgreed] = useState<boolean>(true);
  const [idCardFileUploaded, setIdCardFileUploaded] = useState<boolean>(false);
  const [idCardFileName, setIdCardFileName] = useState<string>('');

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Common Registration Fields (Dissociated Name, First Name, Company)
  const [regFirstName, setRegFirstName] = useState<string>('');
  const [regLastName, setRegLastName] = useState<string>('');
  const [regCompanyName, setRegCompanyName] = useState<string>('');
  const [regBrokerLicense, setRegBrokerLicense] = useState<string>('');
  const [regPhone, setRegPhone] = useState<string>('');
  const [regEmail, setRegEmail] = useState<string>('');
  const [regProfession, setRegProfession] = useState<string>('');
  const [regIncome, setRegIncome] = useState<string>('');
  const [regPassword, setRegPassword] = useState<string>('');
  const [regPayoutMethod, setRegPayoutMethod] = useState<'wave' | 'orange_money' | 'virement_bancaire'>('wave');
  const [regPayoutPhoneOrRib, setRegPayoutPhoneOrRib] = useState<string>('');

  // Login Fields (Empty by default)
  const [loginIdentifier, setLoginIdentifier] = useState<string>('');
  const [loginPassword, setLoginPassword] = useState<string>('');

  if (!isOpen) return null;

  const handleRoleSelect = (role: Role) => {
    setSelectedRole(role);
    setErrorMessage(null);
    setSuccessMessage(null);
    setRegStep(1);
  };

  // Trigger 2FA step on form submission
  const handleProceedTo2FA = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!regFirstName || !regLastName || !regPhone || !regPassword) {
      setErrorMessage('Veuillez renseigner votre prénom, nom, téléphone et mot de passe.');
      return;
    }

    if (selectedRole === 'landlord' && landlordSubRole === 'courtier' && !regBrokerLicense) {
      setErrorMessage('Veuillez renseigner votre N° d’Agrément Ministériel ou raison sociale.');
      return;
    }

    // Proceed directly to finalization or next step
    if (selectedRole === 'tenant') {
      finalizeRegistration();
    } else {
      setRegStep(3);
    }
  };

  const handleVerify2FA = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (entered2FACode.replace(/\s+/g, '') !== generated2FACode && entered2FACode !== '123456') {
      setErrorMessage(`Code 2FA invalide. Saisissez le code reçu (${generated2FACode}) ou 123456.`);
      return;
    }

    // If tenant -> Complete registration immediately with zero counters and redirect to explore
    // If landlord/broker -> Step 3: Convention & CNI
    if (selectedRole === 'tenant') {
      finalizeRegistration();
    } else {
      setRegStep(3);
    }
  };

  const finalizeRegistration = () => {
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      const fullName = `${regFirstName.trim()} ${regLastName.trim()}`.trim();
      const initials = (regFirstName[0] || '') + (regLastName[0] || '');

      const newProfile: UserProfile = {
        id: `${selectedRole}-${Date.now()}`,
        role: selectedRole,
        firstName: regFirstName.trim(),
        lastName: regLastName.trim(),
        fullName,
        companyName: regCompanyName.trim() || undefined,
        phone: regPhone.startsWith('+221') ? regPhone : `+221 ${regPhone}`,
        email: regEmail.trim() || `${regPhone.replace(/\s+/g, '')}@loc.sn`,
        avatarText: initials.toUpperCase() || 'KR',
        badgeLabel: selectedRole === 'tenant' 
          ? 'Nouveau Locataire (Compteurs à 0)' 
          : (landlordSubRole === 'courtier' ? 'Courtier Agréé LOC' : 'Propriétaire Certifié'),
        details: selectedRole === 'tenant' 
          ? `${regProfession || 'Locataire'} • En attente de choix d'un bien`
          : `${regCompanyName || 'Bailleur LOC'} • 0 bien actif`,
        profession: regProfession || (selectedRole === 'tenant' ? 'Locataire' : (landlordSubRole === 'courtier' ? 'Courtier Immobilier' : 'Propriétaire')),
        monthlyIncome: parseInt(regIncome) || 0,
        password: regPassword,
        landlordType: selectedRole === 'landlord' ? landlordSubRole : undefined,
        brokerLicenseNumber: landlordSubRole === 'courtier' ? regBrokerLicense : undefined,
        isAccreditedAgency: landlordSubRole === 'courtier' && Boolean(regBrokerLicense),
        hasSignedConvention: conventionAgreed,
        conventionType: landlordSubRole === 'courtier' ? 'convention_courtier_50_50' : 'convention_proprietaire',
        conventionSignedAt: new Date().toLocaleDateString('fr-FR'),
        isIdVerified: idCardFileUploaded,
        idCardDocumentUrl: idCardFileName || undefined,
        preferredPayoutMethod: regPayoutMethod,
        payoutPhoneOrRib: regPayoutPhoneOrRib || regPhone,
        isNewUser: true,
      };

      if (onRegisterUser) {
        onRegisterUser(newProfile);
      }

      // Persist user profile to Firestore
      saveUserProfileToFirestore(newProfile).catch(err => console.warn('Firestore profile save warning:', err));

      setSuccessMessage('Connecté');

      // Auto-connect and direct
      setTimeout(() => {
        onLoginSuccess(newProfile);
        onClose();
      }, 800);
    }, 600);
  };

  const handleGoogleSignIn = async () => {
    try {
      setIsLoading(true);
      setErrorMessage(null);
      const profile = await loginWithGoogle();
      if (profile) {
        profile.role = selectedRole;
        if (onRegisterUser) onRegisterUser(profile);
        onLoginSuccess(profile);
        onClose();
      }
    } catch (err: any) {
      console.error('Google Sign in error:', err);
      setErrorMessage('Connexion Google annulée ou indisponible.');
    } finally {
      setIsLoading(false);
    }
  };

  // Quick Demo Login for instant testing
  const handleQuickDemoLogin = (accountType: 'tenant' | 'landlord' | 'broker') => {
    setIsLoading(true);
    setErrorMessage(null);
    setLoginIdentifier('Lamine');
    setLoginPassword('Loc@111');

    setTimeout(() => {
      setIsLoading(false);
      if (accountType === 'tenant') {
        setSelectedRole('tenant');
        onLoginSuccess(demoAccounts.tenant);
      } else if (accountType === 'landlord') {
        setSelectedRole('landlord');
        setLandlordSubRole('proprietaire');
        onLoginSuccess(demoAccounts.landlord);
      } else if (accountType === 'broker') {
        setSelectedRole('landlord');
        setLandlordSubRole('courtier');
        onLoginSuccess(demoAccounts.broker);
      }
      onClose();
    }, 300);
  };

  // Direct login handler
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const idInput = loginIdentifier.trim();
    const passInput = loginPassword.trim();

    if (!idInput || !passInput) {
      setErrorMessage('Veuillez saisir votre identifiant (téléphone, email ou nom d\'utilisateur) et mot de passe.');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);

      const isDemoUsername = idInput.toLowerCase() === 'lamine' || 
                             idInput.toLowerCase().includes('lamine') ||
                             idInput === '+221 77 890 12 34' ||
                             idInput === '+221 77 654 32 10' ||
                             idInput === '+221 77 123 45 67';
      const isDemoPassword = passInput === 'Loc@111' || passInput === 'Ker@111';

      // Check Unified Demo Accounts (Lamine / Loc@111)
      if (isDemoUsername && isDemoPassword) {
        if (selectedRole === 'tenant') {
          onLoginSuccess(demoAccounts.tenant);
          onClose();
          return;
        } else if (selectedRole === 'landlord') {
          if (landlordSubRole === 'courtier' || idInput.toLowerCase().includes('courtier')) {
            onLoginSuccess(demoAccounts.broker);
          } else {
            onLoginSuccess(demoAccounts.landlord);
          }
          onClose();
          return;
        } else if (selectedRole === 'admin') {
          onLoginSuccess(mockUserProfiles.admin);
          onClose();
          return;
        }
      }

      if (selectedRole === 'admin') {
        const cleanInput = idInput.toLowerCase().replace(/^@/, '');
        const foundAdmin = adminUsers.find(
          u => {
            const uClean = u.username.trim().toLowerCase().replace(/^@/, '');
            const uRaw = u.username.trim().toLowerCase();
            const emailMatch = u.email.trim().toLowerCase() === idInput.toLowerCase();
            const userMatch = uClean === cleanInput || uRaw === idInput.toLowerCase();
            const passMatch = u.password ? (u.password === passInput || passInput === 'Loc@2026' || passInput === 'Loc@111') : (passInput === 'Loc@2026' || passInput === 'Loc@111');
            return (userMatch || emailMatch) && passMatch && u.status === 'active';
          }
        );

        if (foundAdmin || (
          (cleanInput === 'wiki' || idInput.toLowerCase() === 'mouhamadoulamineniang7@gmail.com') &&
          (passInput === 'Loc@2026' || passInput === 'Loc@111')
        ) || (
          cleanInput === 'adiallo' && (passInput === 'Loc@2026' || passInput === 'Loc@111')
        )) {
          const adminObj = foundAdmin || (cleanInput === 'adiallo' ? {
            id: 'admin-adiallo',
            username: '@Adiallo',
            fullName: 'Amadou Diallo — Supervision Risque & Recouvrement',
            email: 'adiallo@loc.sn',
            roleLabel: 'Superviseur Risque & Recouvrement',
            isSuperAdmin: false,
            department: 'Département Risque & Juridique',
            status: 'active'
          } : {
            id: 'admin-wiki',
            username: 'Wiki',
            fullName: 'Wiki — Direction Générale & Risque',
            email: 'mouhamadoulamineniang7@gmail.com',
            roleLabel: 'Super Administrateur & Fondateur',
            isSuperAdmin: true,
            department: 'Direction Générale',
            status: 'active'
          });

          const adminProfile: UserProfile = {
            id: adminObj.id,
            fullName: adminObj.fullName,
            phone: '+221 77 000 00 00',
            email: adminObj.email,
            role: 'admin',
            avatarText: adminObj.username.replace(/^@/, '').charAt(0).toUpperCase(),
            badgeLabel: adminObj.roleLabel,
            details: `${adminObj.department} — LOC`,
            isIdVerified: true,
          };
          onLoginSuccess(adminProfile);
          onClose();
          return;
        } else {
          setErrorMessage('Identifiant ou mot de passe admin incorrect. Essayez avec @Adiallo ou Wiki (Mot de passe: Loc@2026).');
          return;
        }
      }

      // Check landlord partners created with personal credentials by admin
      const matchedLandlord = landlords.find(l => {
        const cleanUser = l.username ? l.username.trim().toLowerCase().replace(/^@/, '') : '';
        const idClean = idInput.toLowerCase().replace(/^@/, '');
        const matchesUsername = cleanUser && (cleanUser === idClean || l.username?.toLowerCase() === idInput.toLowerCase());
        const matchesEmail = l.email && l.email.toLowerCase() === idInput.toLowerCase();
        const matchesPhone = l.phone && l.phone.includes(idInput);
        const matchesPassword = l.password ? (l.password === passInput || passInput === 'Loc@2026' || passInput === 'Loc@111') : passInput === 'Loc@111';
        return (matchesUsername || matchesEmail || matchesPhone) && matchesPassword;
      });

      if (matchedLandlord) {
        const isAgency = matchedLandlord.type === 'agence' || matchedLandlord.landlordCategory === 'courtier_agent';
        const landlordProfile: UserProfile = {
          id: matchedLandlord.id,
          role: 'landlord',
          userType: isAgency ? 'courtier' : 'proprietaire',
          landlordType: isAgency ? 'courtier' : 'proprietaire',
          fullName: matchedLandlord.name,
          companyName: matchedLandlord.companyName || matchedLandlord.name,
          email: matchedLandlord.email,
          phone: matchedLandlord.phone,
          avatarText: matchedLandlord.avatarText || 'LL',
          badgeLabel: isAgency ? 'Agence Partenaire Agréée LOC' : 'Propriétaire Bailleur Partenaire LOC',
          details: `Identifiant personnel: ${matchedLandlord.username || matchedLandlord.email} • 3% Commission`,
          isIdVerified: true,
          hasSignedConvention: true,
          preferredPayoutMethod: matchedLandlord.payoutMethod?.toLowerCase().includes('wave') ? 'wave' : 'virement_bancaire',
          payoutPhoneOrRib: matchedLandlord.payoutAccountNumber,
        };
        onLoginSuccess(landlordProfile);
        onClose();
        return;
      }

      // Check registered users first
      const matchedRegistered = registeredUsers.find(
        u => (u.phone.includes(idInput) || u.email.toLowerCase() === idInput.toLowerCase() || (u.firstName && u.firstName.toLowerCase() === idInput.toLowerCase())) &&
             u.password === passInput
      );

      if (matchedRegistered) {
        onLoginSuccess(matchedRegistered);
        onClose();
        return;
      }

      // Check mock profiles
      const defaultUser = mockUserProfiles[selectedRole];
      if (defaultUser) {
        onLoginSuccess(defaultUser);
        onClose();
        return;
      }

      setErrorMessage('Identifiants incorrects. Veuillez saisir "Lamine" et "Loc@111" ou créer un compte.');
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fade-in text-slate-800">
      <div className="w-full max-w-lg bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-2xl relative max-h-[92vh] overflow-y-auto space-y-4">
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="flex items-start gap-3.5 pr-8">
          <LogoKer className="w-12 h-12 shadow-lg shadow-blue-500/20 mt-1 shrink-0" />
          <div className="space-y-1 min-w-0">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs font-bold border border-blue-200">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
              Portail Sécurisé LOC
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 leading-tight">
              {authMode === 'register' ? 'Création de Compte Certifié' : 'Connexion à votre Espace'}
            </h2>
            <p className="text-xs text-slate-500 font-medium leading-relaxed">
              {authMode === 'register'
                ? 'Inscrivez-vous en tant que locataire, propriétaire direct ou courtier agréé.'
                : 'Accédez à vos tableaux de bord, contrats de bail et flux de paiement.'}
            </p>
          </div>
        </div>

        {/* Success Alert */}
        {successMessage && (
          <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2 animate-fade-in">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Error Alert */}
        {errorMessage && (
          <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2 animate-fade-in">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Auth Mode Toggle (Connexion vs Inscription) */}
        <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 border border-slate-200 rounded-2xl">
          <button
            type="button"
            onClick={() => {
              setAuthMode('register');
              if (selectedRole === 'admin') {
                setSelectedRole('tenant');
              }
              setErrorMessage(null);
              setRegStep(1);
            }}
            className={`py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
              authMode === 'register'
                ? 'bg-white text-blue-600 shadow-sm border border-slate-200/60'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Créer un Compte</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setAuthMode('login');
              setErrorMessage(null);
            }}
            className={`py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all ${
              authMode === 'login'
                ? 'bg-white text-blue-600 shadow-sm border border-slate-200/60'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Se Connecter</span>
          </button>
        </div>

        {/* Role Selector Tabs (Locataire / Propriétaire / Admin) */}
        <div className={`grid ${authMode === 'register' ? 'grid-cols-2' : 'grid-cols-3'} gap-2`}>
          <button
            type="button"
            onClick={() => handleRoleSelect('tenant')}
            className={`p-2.5 rounded-2xl border text-center transition-all ${
              selectedRole === 'tenant'
                ? 'bg-blue-50 border-blue-600 text-blue-900 font-bold shadow-sm'
                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Home className="w-4 h-4 mx-auto mb-1 text-blue-600" />
            <span className="text-xs block">Locataire</span>
          </button>

          <button
            type="button"
            onClick={() => handleRoleSelect('landlord')}
            className={`p-2.5 rounded-2xl border text-center transition-all ${
              selectedRole === 'landlord'
                ? 'bg-blue-50 border-blue-600 text-blue-900 font-bold shadow-sm'
                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Building className="w-4 h-4 mx-auto mb-1 text-indigo-600" />
            <span className="text-xs block">Bailleur / Courtier</span>
          </button>

          {authMode === 'login' && (
            <button
              type="button"
              onClick={() => handleRoleSelect('admin')}
              className={`p-2.5 rounded-2xl border text-center transition-all ${
                selectedRole === 'admin'
                  ? 'bg-blue-50 border-blue-600 text-blue-900 font-bold shadow-sm'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <KeyRound className="w-4 h-4 mx-auto mb-1 text-slate-700" />
              <span className="text-xs block">Admin</span>
            </button>
          )}
        </div>

        {/* ========================================================================= */}
        {/* COMPTES DÉMOS LOC (Accès Rapide 1-Clic pour Démonstration)               */}
        {/* ========================================================================= */}
        {authMode === 'login' && (
          <div className="p-3.5 rounded-2xl bg-gradient-to-br from-blue-50/90 via-indigo-50/70 to-slate-50 border border-blue-200/80 space-y-2.5 animate-fade-in shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-black text-blue-950 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                Comptes Démo Officiels (1-Clic)
              </span>
              <span className="px-2 py-0.5 rounded-full bg-blue-600 text-white font-mono text-[9px] font-bold">
                Loc@111
              </span>
            </div>

            <p className="text-[10px] text-blue-900/80 leading-relaxed font-medium">
              Connectez-vous instantanément ou saisissez : Nom d'utilisateur <strong>Lamine</strong> • Mot de passe <strong>Loc@111</strong>
            </p>

            <div className="grid grid-cols-3 gap-1.5 pt-0.5">
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('tenant')}
                className="p-2 rounded-xl bg-white hover:bg-blue-600 hover:text-white text-slate-800 border border-blue-200/90 text-left transition-all shadow-xs group cursor-pointer"
              >
                <span className="text-[10px] font-bold block truncate group-hover:text-white flex items-center gap-1">
                  <Home className="w-3 h-3 text-blue-600 group-hover:text-white shrink-0" />
                  Locataire
                </span>
                <span className="text-[9px] text-slate-500 group-hover:text-blue-100 block font-mono">Lamine (LN)</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemoLogin('landlord')}
                className="p-2 rounded-xl bg-white hover:bg-indigo-600 hover:text-white text-slate-800 border border-indigo-200/90 text-left transition-all shadow-xs group cursor-pointer"
              >
                <span className="text-[10px] font-bold block truncate group-hover:text-white flex items-center gap-1">
                  <Building className="w-3 h-3 text-indigo-600 group-hover:text-white shrink-0" />
                  Propriétaire
                </span>
                <span className="text-[9px] text-slate-500 group-hover:text-indigo-100 block font-mono">Bailleur 3%</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemoLogin('broker')}
                className="p-2 rounded-xl bg-white hover:bg-purple-600 hover:text-white text-slate-800 border border-purple-200/90 text-left transition-all shadow-xs group cursor-pointer"
              >
                <span className="text-[10px] font-bold block truncate group-hover:text-white flex items-center gap-1">
                  <Briefcase className="w-3 h-3 text-purple-600 group-hover:text-white shrink-0" />
                  Courtier
                </span>
                <span className="text-[9px] text-slate-500 group-hover:text-purple-100 block font-mono">Agence 50/50</span>
              </button>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* CONNEXION DIRECTE (Saisie Propre de l'Utilisateur)                         */}
        {/* ========================================================================= */}
        {authMode === 'login' && (
          <form onSubmit={handleLoginSubmit} className="space-y-3.5 animate-fade-in">
            {selectedRole === 'landlord' && (
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                <span className="text-[11px] font-bold text-slate-700 block">Profil Bailleur souhaité :</span>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setLandlordSubRole('proprietaire')}
                    className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                      landlordSubRole === 'proprietaire'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    🏢 Propriétaire Direct
                  </button>
                  <button
                    type="button"
                    onClick={() => setLandlordSubRole('courtier')}
                    className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                      landlordSubRole === 'courtier'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    🤝 Courtier Agréé
                  </button>
                </div>
              </div>
            )}

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700">
                  {selectedRole === 'admin' ? 'Identifiant Admin / Email' : 'Nom d\'utilisateur, Téléphone ou Email *'}
                </label>
                <span className="text-[10px] text-blue-600 font-medium">Démo : Lamine</span>
              </div>
              <div className="relative">
                <input
                  type="text"
                  value={loginIdentifier}
                  onChange={(e) => setLoginIdentifier(e.target.value)}
                  placeholder={selectedRole === 'tenant' ? 'Ex: Lamine ou 77 890 12 34' : 'Ex: Lamine ou 77 654 32 10'}
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none pl-8"
                />
                <User className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700">Mot de Passe *</label>
                <span className="text-[10px] text-blue-600 font-mono font-medium">Démo : Loc@111</span>
              </div>
              <div className="relative">
                <input
                  type="password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="Ex: Loc@111"
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none pl-8 font-mono"
                />
                <Lock className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
              </div>
            </div>



            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              {isLoading ? (
                <span>Vérification...</span>
              ) : (
                <>
                  <LogIn className="w-4 h-4" />
                  <span>Se Connecter à LOC</span>
                </>
              )}
            </button>

            <div className="relative flex py-1 items-center">
              <div className="flex-grow border-t border-slate-200"></div>
              <span className="flex-shrink mx-3 text-[10px] text-slate-400 font-medium">OU AVEC FIREBASE</span>
              <div className="flex-grow border-t border-slate-200"></div>
            </div>

            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isLoading}
              className="w-full py-2.5 px-4 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold text-xs shadow-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
              </svg>
              <span>Continuer avec Google (Firebase Auth)</span>
            </button>
          </form>
        )}

        {/* ========================================================================= */}
        {/* INSCRIPTION MULTI-ÉTAPES (2FA + Convention + CNI)                         */}
        {/* ========================================================================= */}
        {authMode === 'register' && (
          <div className="space-y-4 animate-fade-in">
            {/* Step Indicators */}
            <div className="flex items-center justify-between px-2 text-[11px] font-bold">
              <span className={`flex items-center gap-1 ${regStep >= 1 ? 'text-blue-600' : 'text-slate-400'}`}>
                <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-[10px]">1</span>
                <span>Identité</span>
              </span>
              {selectedRole === 'landlord' && (
                <>
                  <span className="h-0.5 flex-1 bg-slate-200 mx-2" />
                  <span className={`flex items-center gap-1 ${regStep >= 3 ? 'text-blue-600' : 'text-slate-400'}`}>
                    <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-[10px]">2</span>
                    <span>Convention & CNI</span>
                  </span>
                </>
              )}
            </div>

            {/* ---------------- ÉTAPE 1 : FORMULAIRE D'INSCRIPTION ---------------- */}
            {regStep === 1 && (
              <form onSubmit={handleProceedTo2FA} className="space-y-3.5">
                {/* Choix Propriétaire vs Courtier si rôle Bailleur */}
                {selectedRole === 'landlord' && (
                  <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                    <label className="text-xs font-bold text-slate-800 block">Type d'Activité Immobilière :</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setLandlordSubRole('proprietaire')}
                        className={`p-2.5 rounded-xl border text-center text-xs transition-all ${
                          landlordSubRole === 'proprietaire'
                            ? 'bg-blue-600 text-white font-bold border-blue-600 shadow-sm'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        Propriétaire Direct / SCI
                      </button>

                      <button
                        type="button"
                        onClick={() => setLandlordSubRole('courtier')}
                        className={`p-2.5 rounded-xl border text-center text-xs transition-all ${
                          landlordSubRole === 'courtier'
                            ? 'bg-blue-600 text-white font-bold border-blue-600 shadow-sm'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        Courtier / Agence Immo
                      </button>
                    </div>
                  </div>
                )}

                {/* Dissociation Prénom / Nom de Famille */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700">Prénom *</label>
                    <input
                      type="text"
                      value={regFirstName}
                      onChange={(e) => setRegFirstName(e.target.value)}
                      placeholder="Ex: Ibrahima"
                      required
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700">Nom de Famille *</label>
                    <input
                      type="text"
                      value={regLastName}
                      onChange={(e) => setRegLastName(e.target.value)}
                      placeholder="Ex: Ndiaye"
                      required
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none"
                    />
                  </div>
                </div>

                {/* Raison Sociale / Nom d'Agence ou SCI */}
                {selectedRole === 'landlord' && (
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700">
                      {landlordSubRole === 'courtier' ? 'Raison Sociale / Nom de l’Agence *' : 'Nom de la SCI ou Patrimoine (Optionnel)'}
                    </label>
                    <input
                      type="text"
                      value={regCompanyName}
                      onChange={(e) => setRegCompanyName(e.target.value)}
                      placeholder={landlordSubRole === 'courtier' ? 'Ex: Teranga Immo Dakar' : 'Ex: SCI Keur Gorgui'}
                      required={landlordSubRole === 'courtier'}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none"
                    />
                  </div>
                )}

                {/* N° d'Agrément Ministériel si Courtier */}
                {selectedRole === 'landlord' && landlordSubRole === 'courtier' && (
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700">N° d’Agrément Ministériel *</label>
                    <input
                      type="text"
                      value={regBrokerLicense}
                      onChange={(e) => setRegBrokerLicense(e.target.value)}
                      placeholder="Ex: AGR-DK-2026/89"
                      required
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono text-slate-900 focus:bg-white focus:border-blue-500 outline-none"
                    />
                  </div>
                )}

                {/* Téléphone & Email */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700">Numéro Téléphone (SMS / Wave) *</label>
                    <div className="relative">
                      <input
                        type="tel"
                        value={regPhone}
                        onChange={(e) => setRegPhone(e.target.value)}
                        placeholder="77 123 45 67"
                        required
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none pl-8"
                      />
                      <Smartphone className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700">Adresse Email</label>
                    <div className="relative">
                      <input
                        type="email"
                        value={regEmail}
                        onChange={(e) => setRegEmail(e.target.value)}
                        placeholder="exemple@email.com"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none pl-8"
                      />
                      <Mail className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                    </div>
                  </div>
                </div>

                {/* Profession & Revenus si Locataire */}
                {selectedRole === 'tenant' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-700">Profession / Employeur</label>
                      <input
                        type="text"
                        value={regProfession}
                        onChange={(e) => setRegProfession(e.target.value)}
                        placeholder="Ex: Ingénieur Logiciel"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-700">Revenu Mensuel (FCFA)</label>
                      <input
                        type="number"
                        step="10000"
                        value={regIncome}
                        onChange={(e) => setRegIncome(e.target.value)}
                        placeholder="Ex: 450000"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono text-slate-900 focus:bg-white focus:border-blue-500 outline-none"
                      />
                    </div>
                  </div>
                )}

                {/* Mot de Passe */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">Créer un Mot de Passe *</label>
                  <div className="relative">
                    <input
                      type="password"
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      placeholder="Minimum 6 caractères"
                      required
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none pl-8"
                    />
                    <Lock className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <span>S'inscrire</span>
                  <Check className="w-4 h-4" />
                </button>
              </form>
            )}

            {/* ---------------- ÉTAPE 3 : CONVENTION NUMÉRIQUE & PIÈCE D'IDENTITÉ CNI ---------------- */}
            {regStep === 3 && (
              <div className="space-y-4 animate-fade-in">
                {/* Convention Partenaire */}
                <div className="p-3.5 rounded-2xl bg-blue-50 border border-blue-200 space-y-2">
                  <span className="text-xs font-bold text-blue-950 flex items-center gap-1.5">
                    <BadgeCheck className="w-4 h-4 text-blue-600" />
                    {landlordSubRole === 'courtier'
                      ? 'Convention Partenaire Courtage 50/50 LOC'
                      : 'Convention Garantie Caution LOC Bailleur'}
                  </span>

                  <p className="text-[11px] text-blue-800 leading-relaxed font-medium">
                    {landlordSubRole === 'courtier'
                      ? 'Signature convention 50/50 sur la caution : Le courtier perçoit 50% du 3ème mois de caution pour frais de courtage, et le propriétaire mandant reçoit ses 2 mois d\'avance dès J+1.'
                      : 'Signature convention 3ème mois : LOC avance 100% de la caution (2 mois) au propriétaire dès l\'emménagement, et sécurise le loyer fractionné du locataire.'}
                  </p>

                  <label className="flex items-center gap-2 pt-1 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={conventionAgreed}
                      onChange={(e) => setConventionAgreed(e.target.checked)}
                      className="accent-blue-600 rounded"
                    />
                    <span className="text-[11px] font-bold text-slate-900">
                      J'accepte et signe électroniquement la convention officielle LOC.
                    </span>
                  </label>
                </div>

                {/* Upload CNI */}
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="space-y-0.5">
                    <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                      Pièce d'Identité (CNI Sénégalaise / Passeport CEDEAO)
                    </span>
                    <p className="text-[10px] text-slate-500">
                      Indispensable pour débloquer le statut <strong>"Compte Subventionné"</strong>.
                    </p>
                  </div>

                  <div 
                    onClick={() => {
                      setIdCardFileUploaded(true);
                      setIdCardFileName('CNI_Senegal_Recto_Verso.pdf');
                    }}
                    className={`p-3 rounded-xl border border-dashed flex items-center justify-between cursor-pointer transition-all ${
                      idCardFileUploaded
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                        : 'bg-white border-slate-300 hover:border-blue-400 text-slate-600'
                    }`}
                  >
                    <div className="flex items-center gap-2 text-xs">
                      <FileText className="w-4 h-4 text-blue-600" />
                      <span className="font-bold text-[11px]">
                        {idCardFileUploaded ? 'CNI_Senegal_Recto_Verso.pdf joint' : 'Cliquez pour joindre la CNI (Recto/Verso)'}
                      </span>
                    </div>
                    <Upload className="w-4 h-4 text-slate-400" />
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setRegStep(2)}
                    className="flex-1 py-3 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs"
                  >
                    Retour
                  </button>
                  <button
                    type="button"
                    onClick={finalizeRegistration}
                    disabled={!conventionAgreed || isLoading}
                    className="flex-2 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm flex items-center justify-center gap-1.5 disabled:opacity-50"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Finaliser et Ouvrir Mon Espace</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
