import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  ShieldAlert,
  AlertTriangle, 
  TrendingUp, 
  Send, 
  CheckCircle2, 
  DollarSign, 
  Sliders, 
  Users, 
  Sparkles, 
  Activity, 
  MessageSquare,
  Building2,
  Scale,
  BadgeCheck,
  PhoneCall,
  RefreshCw,
  LogOut,
  UserPlus,
  Lock,
  Calendar,
  RotateCcw,
  Bell
} from 'lucide-react';
import { ArrearsCase, Property, TenantApplication, LandlordPartner, ChatConversation, AdminUser, VisitAppointment, SignalementItem, AppNotification } from '../../types';
import { formatFCFA, computeSolvencyScore } from '../../utils/finance';
import { AdminPropertyManagement } from './AdminPropertyManagement';
import { AdminApplicationsManagement } from './AdminApplicationsManagement';
import { AdminChatSpace } from './AdminChatSpace';
import { AdminLandlordsTracking } from './AdminLandlordsTracking';
import { AdminRecoverySuite } from './AdminRecoverySuite';
import { AdminTeamManagement } from './AdminTeamManagement';
import { AppointmentsManager } from '../common/AppointmentsManager';
import { AdminSignalementsManagement } from './AdminSignalementsManagement';
import { AdminFinancialFlows } from './AdminFinancialFlows';
import { AdminSettlementsManager } from './AdminSettlementsManager';

interface AdminDashboardProps {
  arrears: ArrearsCase[];
  properties: Property[];
  applications: TenantApplication[];
  landlords: LandlordPartner[];
  conversations: ChatConversation[];
  adminUsers: AdminUser[];
  currentAdmin: AdminUser | null;
  notifications?: AppNotification[];
  onToggleNotifications?: () => void;
  onResetPlatformData?: () => Promise<void> | void;
  appointments?: VisitAppointment[];
  signalements?: SignalementItem[];
  onUpdateSignalement?: (updatedSignalement: SignalementItem) => void;
  onAddSignalement?: (newSignalement: SignalementItem) => void;
  microPayments?: any[];
  receipts?: any[];
  reserveFundAmount?: number;
  onUpdateReserveFund?: (amount: number) => void;
  onTriggerReminder: (caseId: string, type: 'sms' | 'whatsapp' | 'call') => void;
  onActivateGuarantee: (caseId: string) => void;
  onOpenNewPropertyModal: () => void;
  onApproveApplication: (applicationId: string) => void;
  onRejectApplication: (applicationId: string) => void;
  onOpenLeaseModal: (application: TenantApplication) => void;
  onSendMessage: (conversationId: string, text: string) => void;
  onAddLandlord: (landlord: LandlordPartner) => void;
  onUpdateLandlord?: (landlord: LandlordPartner) => void;
  onAddPropertyForLandlord?: (property: Property) => void;
  onUpdateProperty?: (property: Property) => void;
  onAddAdminUser: (newAdmin: AdminUser) => void;
  onUpdateAdminUser?: (updatedAdmin: AdminUser) => void;
  onLogoutAdmin: () => void;
  onSelectProperty?: (property: Property) => void;
  onUpdateArrearsStatus?: (caseId: string, newStatus: ArrearsCase['status'], notes?: string) => void;
  onApproveProperty?: (propertyId: string) => void;
  onRejectProperty?: (propertyId: string) => void;
  onEditProperty?: (property: Property) => void;
  onApproveWithAppointment?: (application: TenantApplication) => void;
  onCancelLeaseValidation?: (applicationId: string) => void;
  onUpdateApplicationScore?: (applicationId: string, score: number) => void;
  onConfirmAppointment?: (appointmentId: string) => void;
  onCancelAppointment?: (appointmentId: string) => void;
  onAddAppointment?: (newAppt: VisitAppointment) => void;
  onUpdateAppointment?: (appointmentId: string, updates: Partial<VisitAppointment>) => void;
  onStartNewConversation?: (newConv: ChatConversation) => void;
  activeTab?: 'applications' | 'properties' | 'appointments' | 'signalements' | 'chat' | 'landlords' | 'settlements' | 'financial_flows' | 'recovery' | 'fund' | 'team';
  onTabChange?: (tab: 'applications' | 'properties' | 'appointments' | 'signalements' | 'chat' | 'landlords' | 'settlements' | 'financial_flows' | 'recovery' | 'fund' | 'team') => void;
  selectedConversationId?: string | null;
  onSelectConversation?: (id: string | null) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  arrears,
  properties,
  applications,
  landlords,
  conversations,
  adminUsers,
  currentAdmin,
  notifications = [],
  onToggleNotifications,
  onResetPlatformData,
  appointments = [],
  signalements = [],
  onUpdateSignalement,
  onAddSignalement,
  microPayments = [],
  receipts = [],
  reserveFundAmount = 0,
  onUpdateReserveFund,
  onTriggerReminder,
  onActivateGuarantee,
  onOpenNewPropertyModal,
  onApproveApplication,
  onRejectApplication,
  onOpenLeaseModal,
  onSendMessage,
  onStartNewConversation,
  onAddLandlord,
  onUpdateLandlord,
  onAddPropertyForLandlord,
  onUpdateProperty,
  onAddAdminUser,
  onUpdateAdminUser,
  onLogoutAdmin,
  onSelectProperty,
  onUpdateArrearsStatus,
  onApproveProperty,
  onRejectProperty,
  onEditProperty,
  onApproveWithAppointment,
  onCancelLeaseValidation,
  onUpdateApplicationScore,
  onConfirmAppointment,
  onCancelAppointment,
  onAddAppointment,
  onUpdateAppointment,
  activeTab: propActiveTab,
  onTabChange,
  selectedConversationId: propSelectedConversationId,
  onSelectConversation,
}) => {
  // Check if current user is Super Admin Wiki
  const isWikiSuperAdmin = currentAdmin?.username?.trim().toLowerCase() === 'wiki' || currentAdmin?.isSuperAdmin;

  const userPermissions = currentAdmin?.permissions || [];

  const hasPermission = (permId: string) => {
    if (isWikiSuperAdmin) return true;
    return userPermissions.includes(permId);
  };

  // Unread notifications for Admin
  const unreadAdminNotifs = notifications.filter(
    (n) => (n.role === 'admin' || n.userId === 'admin' || n.userId === 'all' || (currentAdmin && n.userId === currentAdmin.id)) && !n.isRead
  ).length;
  const pendingAppsCount = applications.filter(a => a.status === 'pending').length;
  const activeArrearsCount = arrears.filter(a => a.status !== 'regularise').length;

  // Filter allowed tabs based on permissions
  const allTabs = [
    {
      id: 'applications' as const,
      label: 'Candidatures LOC',
      icon: Sparkles,
      count: pendingAppsCount,
      allowed: isWikiSuperAdmin || hasPermission('approve_applications') || hasPermission('reject_applications') || hasPermission('manage_properties')
    },
    {
      id: 'properties' as const,
      label: 'Gestion Immobilière',
      icon: Building2,
      count: properties.filter(p => p.validationStatus === 'pending_validation').length,
      allowed: isWikiSuperAdmin || hasPermission('manage_properties') || hasPermission('approve_applications') || hasPermission('reject_applications')
    },
    {
      id: 'appointments' as const,
      label: 'Rendez-vous',
      icon: Calendar,
      count: appointments.filter(a => a.status === 'pending').length,
      allowed: isWikiSuperAdmin || hasPermission('manage_properties') || hasPermission('approve_applications')
    },
    {
      id: 'signalements' as const,
      label: 'Signalements',
      icon: ShieldAlert,
      count: signalements.filter(s => s.status === 'nouveau').length,
      allowed: true
    },
    {
      id: 'chat' as const,
      label: 'Chat Clients',
      icon: MessageSquare,
      badge: true,
      allowed: isWikiSuperAdmin || userPermissions.length > 0
    },
    {
      id: 'landlords' as const,
      label: 'Suivi Bailleurs',
      icon: Users,
      allowed: isWikiSuperAdmin || hasPermission('manage_properties') || hasPermission('manage_landlords')
    },
    {
      id: 'settlements' as const,
      label: 'Règlements & Partenaires',
      icon: DollarSign,
      allowed: isWikiSuperAdmin || hasPermission('manage_properties') || hasPermission('release_guarantee_funds')
    },
    {
      id: 'financial_flows' as const,
      label: 'Flux Financiers',
      icon: TrendingUp,
      allowed: isWikiSuperAdmin || hasPermission('release_guarantee_funds')
    },
    {
      id: 'recovery' as const,
      label: 'Recouvrement',
      icon: Scale,
      count: activeArrearsCount,
      allowed: isWikiSuperAdmin || hasPermission('legal_recovery') || hasPermission('release_guarantee_funds')
    },
    {
      id: 'fund' as const,
      label: 'Fonds & Risque',
      icon: ShieldCheck,
      allowed: isWikiSuperAdmin || hasPermission('release_guarantee_funds')
    },
    {
      id: 'team' as const,
      label: 'Équipe & Admins',
      icon: UserPlus,
      allowed: isWikiSuperAdmin // "Le tableau de bord du super Admin n'est visible que par l'utilisateur Wiki"
    },
  ];

  const availableTabs = allTabs.filter(t => t.allowed);

  const [internalTab, setInternalTab] = useState<'applications' | 'properties' | 'appointments' | 'signalements' | 'chat' | 'landlords' | 'settlements' | 'financial_flows' | 'recovery' | 'fund' | 'team'>(() => {
    try {
      const saved = localStorage.getItem('ker_admin_tab');
      if (saved === 'finance_config' || saved === 'comptabilite') return 'financial_flows';
      return (saved as any) || availableTabs[0]?.id || 'applications';
    } catch {
      return availableTabs[0]?.id || 'applications';
    }
  });

  const activeTab = propActiveTab || internalTab;

  const setActiveTab = (tab: 'applications' | 'properties' | 'appointments' | 'signalements' | 'chat' | 'landlords' | 'settlements' | 'financial_flows' | 'recovery' | 'fund' | 'team') => {
    setInternalTab(tab);
    if (onTabChange) onTabChange(tab);
    try {
      localStorage.setItem('ker_admin_tab', tab);
    } catch (e) {
      console.warn('Could not persist admin tab:', e);
    }
  };

  useEffect(() => {
    if (propActiveTab) {
      setInternalTab(propActiveTab);
    }
  }, [propActiveTab]);

  useEffect(() => {
    try {
      localStorage.setItem('ker_admin_tab', activeTab);
    } catch (e) {
      console.warn('Could not persist admin tab:', e);
    }
  }, [activeTab]);

  const [selectedChatConversationId, setSelectedChatConversationId] = useState<string | null>(propSelectedConversationId || null);

  useEffect(() => {
    if (propSelectedConversationId !== undefined) {
      setSelectedChatConversationId(propSelectedConversationId);
    }
  }, [propSelectedConversationId]);

  const handleDirectChat = (
    recipientName: string,
    recipientPhone?: string,
    messageText?: string,
    propertyTitle?: string,
    role: 'tenant' | 'landlord' = 'tenant'
  ) => {
    const cleanPhone = (recipientPhone || '').replace(/\D/g, '');
    let target = conversations.find(c => {
      const matchName = c.participantName.trim().toLowerCase() === recipientName.trim().toLowerCase();
      const matchPhone = cleanPhone && c.participantPhone && c.participantPhone.replace(/\D/g, '') === cleanPhone;
      return matchName || matchPhone;
    });

    if (!target) {
      const newConvId = `conv-${Date.now()}`;
      const firstMsgText = messageText || `Bonjour ${recipientName}, prise de contact par un administrateur LOC.`;
      const newConv: ChatConversation = {
        id: newConvId,
        participantId: `usr-${Date.now()}`,
        participantName: recipientName,
        participantRole: role,
        participantPhone: recipientPhone || '+221 77 000 00 00',
        participantAvatar: recipientName.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || (role === 'landlord' ? '🏢' : '👤'),
        participantTag: role === 'landlord' ? 'Bailleur Partenaire' : 'Locataire Actif',
        propertyTitle: propertyTitle || 'Logement LOC',
        unreadCount: 0,
        priority: 'normal',
        lastMessage: firstMsgText,
        lastMessageTime: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
        messages: [
          {
            id: `msg-${Date.now()}`,
            senderId: 'admin-1',
            senderName: 'LOC Support & Risque',
            senderRole: 'admin',
            text: firstMsgText,
            timestamp: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
            isRead: true,
          }
        ]
      };

      if (onStartNewConversation) {
        onStartNewConversation(newConv);
      }
      target = newConv;
    } else if (messageText) {
      onSendMessage(target.id, messageText);
    }

    setSelectedChatConversationId(target.id);
    setActiveTab('chat');
  };

  // Interactive Scoring Engine Playground
  const [simIncome, setSimIncome] = useState(500000);
  const [simRent, setSimRent] = useState(150000);
  const [simContract, setSimContract] = useState('cdi');
  const [simGuarantor, setSimGuarantor] = useState(true);

  const { score, level, recommendation } = computeSolvencyScore(
    simIncome,
    simRent,
    simContract,
    simGuarantor,
    true
  );

  return (
    <div className="p-3 sm:p-5 pb-24 space-y-4 text-slate-800">
      {/* Top Header Card */}
      <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white flex items-center justify-center font-black text-xl shadow-sm">
              🛡️
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-slate-900">
                  {isWikiSuperAdmin ? 'Tableau de Bord Super Admin LOC' : `Espace Opérationnel : ${currentAdmin?.roleLabel || 'Administrateur'}`}
                </h2>
                <BadgeCheck className="w-4 h-4 text-blue-600" />
                {currentAdmin && (
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                    isWikiSuperAdmin ? 'bg-amber-100 text-amber-900 border-amber-300 font-mono' : 'bg-blue-100 text-blue-800 border-blue-200'
                  }`}>
                    {isWikiSuperAdmin ? '👑 Super Admin: Wiki' : `Admin: @${currentAdmin.username}`}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 font-medium">
                {isWikiSuperAdmin 
                  ? 'Supervision Intégrale : Gestion des prérogatives, Baux, Contentieux, Bailleurs & Risque' 
                  : `Accès filtré selon vos droits : ${currentAdmin?.department || 'Opérations LOC'}`}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1">
              <Activity className="w-3.5 h-3.5" />
              Session Sécurisée
            </span>

            {onToggleNotifications && (
              <button
                onClick={onToggleNotifications}
                className="relative py-1.5 px-3 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                title="Consulter les notifications administrateur"
              >
                <Bell className="w-3.5 h-3.5 text-blue-700" />
                <span className="hidden sm:inline">Notifications</span>
                {unreadAdminNotifs > 0 && (
                  <span className="px-1.5 py-0.5 bg-red-600 text-white rounded-full text-[10px] font-mono font-black animate-pulse">
                    {unreadAdminNotifs}
                  </span>
                )}
              </button>
            )}

            <button
              onClick={onLogoutAdmin}
              className="py-1.5 px-3 rounded-xl bg-slate-100 hover:bg-red-50 text-slate-700 hover:text-red-700 border border-slate-200 hover:border-red-200 text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm"
              title="Verrouiller et déconnecter la session admin"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Verrouiller Session</span>
            </button>
          </div>
        </div>
      </div>

      {/* Dynamic Navigation Tabs Dispatched by Permissions */}
      <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-100 border border-slate-200 rounded-2xl">
        {availableTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-2 px-3 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 relative ${
                isActive
                  ? 'bg-white text-blue-700 shadow-sm border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
              {tab.count !== undefined && tab.count > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500 text-white font-black">
                  {tab.count}
                </span>
              )}
              {tab.badge && (
                <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse" />
              )}
            </button>
          );
        })}
      </div>

      {/* 1. GESTION DES CANDIDATURES INDIVIDUELLES */}
      {activeTab === 'applications' && (
        <AdminApplicationsManagement
          applications={applications}
          properties={properties}
          onApproveApplication={onApproveApplication}
          onRejectApplication={onRejectApplication}
          onCancelLeaseValidation={onCancelLeaseValidation}
          onUpdateApplicationScore={onUpdateApplicationScore}
          onOpenLeaseModal={onOpenLeaseModal}
          onOpenChatWithTenant={(tenantName, tenantPhone) => {
            handleDirectChat(tenantName, tenantPhone, `Bonjour ${tenantName}, concernant votre candidature LOC...`, undefined, 'tenant');
          }}
          onApproveWithAppointment={onApproveWithAppointment}
        />
      )}

      {/* 2. GESTION IMMOBILIÈRE */}
      {activeTab === 'properties' && (
        <AdminPropertyManagement
          properties={properties}
          applications={applications}
          microPayments={microPayments}
          receipts={receipts}
          onOpenNewPropertyModal={onOpenNewPropertyModal}
          onApproveApplication={onApproveApplication}
          onRejectApplication={onRejectApplication}
          onOpenLeaseModal={onOpenLeaseModal}
          onSelectProperty={onSelectProperty}
          onEditProperty={onEditProperty}
          onApproveProperty={onApproveProperty}
          onRejectProperty={onRejectProperty}
          onOpenChatWithClient={(clientName, clientPhone, shareText, propertyTitle) => {
            handleDirectChat(clientName, clientPhone, shareText, propertyTitle, 'tenant');
          }}
        />
      )}

      {/* 2. ESPACE GESTION DES RENDEZ-VOUS (VISITES & SIGNATURES BAUX) */}
      {activeTab === 'appointments' && (
        <div className="space-y-4 animate-fade-in">
          <AppointmentsManager
            appointments={appointments}
            properties={properties}
            userRole="admin"
            currentUserId={currentAdmin?.id}
            currentUserName={currentAdmin?.name || currentAdmin?.username}
            onConfirmAppointment={onConfirmAppointment}
            onCancelAppointment={onCancelAppointment}
            onAddAppointment={onAddAppointment}
            onUpdateAppointment={onUpdateAppointment}
          />
        </div>
      )}

      {/* ESPACE DE GESTION DES SIGNALEMENTS */}
      {activeTab === 'signalements' && (
        <AdminSignalementsManagement
          signalements={signalements}
          onUpdateSignalement={onUpdateSignalement || (() => {})}
          onAddSignalement={onAddSignalement || (() => {})}
          onOpenChat={(recipientName, recipientPhone) => {
            handleDirectChat(recipientName, recipientPhone, `[SIGNALEMENT] Prise de contact avec ${recipientName} (${recipientPhone || 'N/A'})`, undefined, 'tenant');
          }}
        />
      )}

      {/* 3. ESPACE DE CONVERSATION VIA CHAT INTÉGRÉ */}
      {activeTab === 'chat' && (
        <AdminChatSpace
          conversations={conversations}
          selectedConversationId={selectedChatConversationId}
          onSelectConversation={setSelectedChatConversationId}
          onSendMessage={onSendMessage}
          onStartNewConversation={onStartNewConversation}
          applications={applications}
          landlords={landlords}
          properties={properties}
        />
      )}

      {/* 3. ESPACE DE SUIVI DES PROPRIÉTAIRES & BAILLEURS */}
      {activeTab === 'landlords' && (
        <AdminLandlordsTracking
          landlords={landlords}
          properties={properties}
          onAddLandlord={onAddLandlord}
          onUpdateLandlord={onUpdateLandlord}
          onAddPropertyForLandlord={onAddPropertyForLandlord}
          onUpdateProperty={onUpdateProperty}
        />
      )}

      {/* 3b. GESTION DES RÈGLEMENTS DUS AUX COURTIERS, AGENCES ET PROPRIÉTAIRES */}
      {activeTab === 'settlements' && (
        <AdminSettlementsManager
          landlords={landlords}
          properties={properties}
        />
      )}

      {/* 3c. VISUALISATION DES FLUX FINANCIERS */}
      {activeTab === 'financial_flows' && (
        <AdminFinancialFlows
          properties={properties}
          landlords={landlords}
          applications={applications}
          microPayments={microPayments}
          receipts={receipts}
          arrears={arrears}
        />
      )}

      {/* 4. ESPACE DE SUIVI DE RECOUVREMENT */}
      {activeTab === 'recovery' && (
        <AdminRecoverySuite
          arrears={arrears}
          onTriggerReminder={onTriggerReminder}
          onActivateGuarantee={onActivateGuarantee}
          onUpdateArrearsStatus={onUpdateArrearsStatus}
        />
      )}

      {/* 5. GESTION DES ADMINISTRATEURS */}
      {activeTab === 'team' && (
        <AdminTeamManagement
          adminUsers={adminUsers}
          currentAdmin={currentAdmin}
          onAddAdminUser={onAddAdminUser}
          onUpdateAdminUser={onUpdateAdminUser}
        />
      )}

      {/* 6. FONDS DE GARANTIE, TRÉSORERIE & SCORING */}
      {activeTab === 'fund' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3 sm:gap-4">
            <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 space-y-2 shadow-sm relative">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Fonds Réserve Mobilisé</span>
                {isWikiSuperAdmin && (
                  <button
                    onClick={() => {
                      const val = window.prompt("Définir le Fonds de Réserve mobilisé (en FCFA) :", String(reserveFundAmount || 0));
                      if (val !== null && !isNaN(Number(val))) {
                        onUpdateReserveFund?.(Number(val));
                      }
                    }}
                    className="text-[10px] px-2 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-lg font-bold transition-all border border-amber-300 flex items-center gap-1"
                    title="Définir le fonds de réserve (Admin Wiki)"
                  >
                    <Sliders className="w-3 h-3 text-amber-700" />
                    Définir (Wiki)
                  </button>
                )}
              </div>
              <span className="text-xl sm:text-2xl font-black text-emerald-700 font-mono block">
                {formatFCFA(reserveFundAmount || 0)}
              </span>
              <span className="text-xs text-slate-500 font-medium block">
                {reserveFundAmount && reserveFundAmount > 0
                  ? 'Fonds mobilisé auprès des partenaires'
                  : '0 FCFA mobilisé pour le moment'}
              </span>
            </div>

            <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 space-y-1 shadow-sm">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Taux de Défaut Global</span>
              <span className="text-xl sm:text-2xl font-black text-blue-700 font-mono block">
                1.18%
              </span>
              <span className="text-xs text-emerald-700 block font-semibold">Seuil d'alerte : &lt; 3.5%</span>
            </div>
          </div>

          {/* Solvency Distribution */}
          <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 shadow-sm space-y-3">
            <h3 className="font-bold text-slate-900 text-sm">
              Répartition des Risques du Portefeuille LOC
            </h3>
            <div className="space-y-2.5">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-600 font-medium">Profils Risque Faible (Score 80+) :</span>
                  <span className="font-bold text-emerald-700 font-mono">82%</span>
                </div>
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full w-[82%]" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-600 font-medium">Profils Risque Modéré (Score 50-79) :</span>
                  <span className="font-bold text-amber-700 font-mono">15%</span>
                </div>
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-amber-500 h-full w-[15%]" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-600 font-medium">Dossiers sous Surveillance / Garants :</span>
                  <span className="font-bold text-red-700 font-mono">3%</span>
                </div>
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-red-500 h-full w-[3%]" />
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Scoring Engine Playground */}
          <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-blue-600" />
                Simulateur d'Algorithme de Solvabilité LOC
              </h3>
              <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200 font-mono">
                v2.4 Live
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Score Calculé</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-black text-emerald-700 font-mono">{score}/100</span>
                  <span className="text-xs font-bold text-slate-700">Risque {level}</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">{recommendation}</p>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-700 flex items-center justify-center shadow-sm">
                <ShieldCheck className="w-6 h-6" />
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <div className="flex justify-between text-slate-700 mb-1">
                  <span className="font-medium">Revenu mensuel candidat :</span>
                  <span className="font-bold text-slate-900 font-mono">{formatFCFA(simIncome)}</span>
                </div>
                <input
                  type="range"
                  min="100000"
                  max="1500000"
                  step="25000"
                  value={simIncome}
                  onChange={(e) => setSimIncome(Number(e.target.value))}
                  className="w-full accent-blue-600 bg-slate-200 h-2 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-700 mb-1">
                  <span className="font-medium">Loyer visé :</span>
                  <span className="font-bold text-slate-900 font-mono">{formatFCFA(simRent)}</span>
                </div>
                <input
                  type="range"
                  min="30000"
                  max="600000"
                  step="10000"
                  value={simRent}
                  onChange={(e) => setSimRent(Number(e.target.value))}
                  className="w-full accent-blue-600 bg-slate-200 h-2 rounded-lg cursor-pointer"
                />
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">Contrat de Travail</span>
                  <select
                    value={simContract}
                    onChange={(e) => setSimContract(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 font-medium"
                  >
                    <option value="cdi">CDI</option>
                    <option value="fonctionnaire">Fonctionnaire</option>
                    <option value="cdd">CDD</option>
                    <option value="entrepreneur">Entrepreneur</option>
                  </select>
                </div>

                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">Garant Solidaire</span>
                  <button
                    type="button"
                    onClick={() => setSimGuarantor(!simGuarantor)}
                    className={`w-full py-1.5 px-2.5 rounded-xl border text-xs font-bold transition-all ${
                      simGuarantor
                        ? 'bg-blue-50 border-blue-300 text-blue-700'
                        : 'bg-slate-50 border-slate-200 text-slate-500'
                    }`}
                  >
                    {simGuarantor ? '✓ Avec Garant' : 'Sans Garant'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
