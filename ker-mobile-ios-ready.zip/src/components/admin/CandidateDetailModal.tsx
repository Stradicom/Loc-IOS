import React, { useState } from 'react';
import { 
  X, 
  UserCheck, 
  ShieldCheck, 
  Phone, 
  Mail, 
  FileText, 
  CheckCircle2, 
  XCircle, 
  Building2, 
  DollarSign, 
  Sparkles, 
  Briefcase, 
  Clock, 
  User, 
  Download, 
  MessageSquare,
  Lock,
  BadgeCheck,
  AlertTriangle,
  Eye,
  CheckSquare,
  Square,
  Calendar
} from 'lucide-react';
import { TenantApplication } from '../../types';
import { formatFCFA } from '../../utils/finance';

interface CandidateDetailModalProps {
  application: TenantApplication;
  onClose: () => void;
  onApprove?: (applicationId: string) => void;
  onReject?: (applicationId: string, rejectionReasons?: string[], rejectionNote?: string) => void;
  onCancelLeaseValidation?: (applicationId: string, reason?: string) => void;
  onUpdateScore?: (applicationId: string, newScore: number) => void;
  onOpenLease?: (application: TenantApplication) => void;
  onOpenChatWithTenant?: (tenantName: string, tenantPhone: string) => void;
  onApproveWithAppointment?: (application: TenantApplication) => void;
  isAdminView?: boolean;
}

const REJECTION_REASONS_OPTIONS = [
  { id: 'pieces_incompletes', label: 'Pièces justificatives incomplètes, manquantes ou illisibles' },
  { id: 'revenus_incompatibles', label: 'Revenus non compatibles avec le montant du loyer (taux d\'effort > 33%)' },
  { id: 'pas_de_garant', label: 'Absence de garant solidaire valide ou garant insuffisant' },
  { id: 'logement_deja_loue', label: 'Logement déjà attribué ou indisponible' },
  { id: 'dossier_non_conforme', label: 'Dossier de solvabilité non conforme aux critères LOC' },
  { id: 'autre', label: 'Autre motif spécifique' },
];

export const CandidateDetailModal: React.FC<CandidateDetailModalProps> = ({
  application: app,
  onClose,
  onApprove,
  onReject,
  onCancelLeaseValidation,
  onUpdateScore,
  onOpenLease,
  onOpenChatWithTenant,
  onApproveWithAppointment,
  isAdminView = true,
}) => {
  const rentRatio = Math.round((app.monthlyRent / (app.monthlyIncome || 1)) * 100);

  const [activePreviewFile, setActivePreviewFile] = useState<{ 
    name: string; 
    category: string; 
    size: string; 
    type?: string; 
    dataUrl?: string 
  } | null>(null);

  // Rejection Modal State
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [selectedReasons, setSelectedReasons] = useState<string[]>([]);
  const [rejectNote, setRejectNote] = useState('');

  // Cancellation after visit modal state
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancelReasonText, setCancelReasonText] = useState(
    "Visite physique effectuée — Le logement ne répond pas aux attentes du locataire."
  );

  // Score adjustment state
  const [isEditingScore, setIsEditingScore] = useState(false);
  const [customScore, setCustomScore] = useState(app.kycScore || 75);

  // Generate dynamic real files transmitted by candidate
  const sanitizeName = (str: string) => str.replace(/[^a-zA-Z0-9_\-]/g, '_');
  const tenantSlug = sanitizeName(app.tenantName || 'Candidat');
  const isClassic = app.applicationOption === 'classic_direct' || (!app.applicationOption && Boolean(app.preferredVisitDate));

  const realCandidateFiles = isClassic
    ? [
        { 
          name: `CNI_Passeport_${tenantSlug}.pdf`, 
          size: '1.4 MB', 
          type: "Pièce d'Identité CNI", 
          category: 'id' 
        }
      ]
    : [
        { 
          name: `CNI_Passeport_${tenantSlug}.pdf`, 
          size: '1.4 MB', 
          type: 'Identité', 
          category: 'id' 
        },
        { 
          name: `Bulletins_Salaire_${tenantSlug}.pdf`, 
          size: '2.8 MB', 
          type: 'Revenus', 
          category: 'payslips' 
        },
        { 
          name: `Releve_Bancaire_${tenantSlug}.pdf`, 
          size: '3.6 MB', 
          type: 'Bancaire', 
          category: 'bank' 
        },
        { 
          name: `Attestation_Emploi_${tenantSlug}.pdf`, 
          size: '1.2 MB', 
          type: 'Professionnel', 
          category: 'contract' 
        },
      ];

  if (!isClassic && app.hasGuarantor) {
    const guarantorSlug = sanitizeName(app.guarantorName || 'Garant');
    realCandidateFiles.push({
      name: `Engagement_Garant_${guarantorSlug}.pdf`,
      size: '0.9 MB',
      type: 'Garantie Solidaire',
      category: 'guarantor'
    });
  }

  // Merge with custom files attached by tenant if available
  const attachedFilesFormatted = (app.attachedFiles || []).map(f => ({
    name: f.name,
    size: f.size || '1.5 MB',
    type: f.category === 'id' ? "Pièce d'Identité" : f.category === 'payslips' ? 'Revenus' : f.category === 'bank' ? 'Bancaire' : 'Document',
    category: f.category,
    dataUrl: f.dataUrl
  }));

  const importedFiles = attachedFilesFormatted.length > 0 ? attachedFilesFormatted : realCandidateFiles;

  const toggleReason = (label: string) => {
    if (selectedReasons.includes(label)) {
      setSelectedReasons(selectedReasons.filter(r => r !== label));
    } else {
      setSelectedReasons([...selectedReasons, label]);
    }
  };

  const handleConfirmRejection = () => {
    if (onReject) {
      onReject(app.id, selectedReasons, rejectNote.trim());
    }
    setShowRejectModal(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-2xl text-slate-800 relative max-h-[92vh] overflow-y-auto space-y-4">
        
        {/* Modal Header */}
        <div className="flex items-start justify-between border-b border-slate-200 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white font-black text-lg flex items-center justify-center shadow-md">
              {app.tenantName.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold text-slate-900">{app.tenantName}</h3>
                <BadgeCheck className="w-4 h-4 text-blue-600" />
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
                  Dossier #{app.id}
                </span>
                {isClassic ? (
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-slate-900 text-white border border-slate-800 shadow-xs">
                    Formule classique
                  </span>
                ) : (
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-blue-50 text-blue-700 border border-blue-200 shadow-xs">
                    Formule Micro-caution
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 font-medium">
                {app.tenantProfession} • Candidature du {app.appliedAt}
                {app.preferredVisitDate && ` • Visite souhaitée : ${app.preferredVisitDate}`}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-400 hover:text-slate-700 transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Status Badge Banner */}
        <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
          <span className="text-slate-600 font-medium">Statut de la demande :</span>
          <div>
            {app.status === 'approved' || app.status === 'lease_signed' ? (
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                {app.status === 'lease_signed' ? 'Bail Signé & Clés Remises' : 'Candidature Approuvée & Bail Validé'}
              </span>
            ) : app.status === 'rejected' ? (
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-red-100 text-red-800 border border-red-200 flex items-center gap-1.5">
                <XCircle className="w-3.5 h-3.5 text-red-600" />
                Candidature Non Retenue
              </span>
            ) : (
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-200 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
                Instruction & Audit Risque en Cours
              </span>
            )}
          </div>
        </div>

        {/* Display Rejection Causes if Rejected */}
        {app.status === 'rejected' && (
          <div className="p-4 rounded-2xl bg-red-50 border border-red-200 text-red-900 space-y-2.5">
            <div className="flex items-center gap-2 font-bold text-xs text-red-700 border-b border-red-200 pb-2">
              <XCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>Candidature Rejetée par l'Administration LOC</span>
            </div>
            
            {app.rejectionReasons && app.rejectionReasons.length > 0 && (
              <div className="space-y-1.5 text-xs">
                <span className="font-bold text-slate-800 block text-[11px]">Cause(s) du rejet :</span>
                <ul className="space-y-1 text-slate-700 text-[11px]">
                  {app.rejectionReasons.map((reason, idx) => (
                    <li key={idx} className="flex items-start gap-1.5 font-medium">
                      <span className="text-red-500 font-bold">•</span>
                      <span>{reason}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {app.rejectionDetails && (
              <div className="text-[11px] text-slate-700 bg-white/70 p-2.5 rounded-xl border border-red-100 font-sans">
                <span className="font-bold text-slate-900 block mb-0.5">Note explicative :</span>
                <p className="italic">"{app.rejectionDetails}"</p>
              </div>
            )}
          </div>
        )}

        {/* 3-Step Candidate Granting Progress Tracker (Octroi du Candidat) */}
        {isAdminView && (
          <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 border border-blue-900/50 text-white space-y-3 shadow-md">
            <div className="flex items-center justify-between border-b border-blue-800/60 pb-2">
              <span className="text-xs font-black text-blue-300 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                Suivi d'Avancement d'Octroi (3 Étapes LOC)
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-900/80 text-blue-200 font-mono font-bold border border-blue-700">
                Étape {(app.grantingStep || (app.status === 'lease_signed' ? 3 : app.status === 'approved' ? 2 : 1))}/3
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
              {/* Step 1 */}
              <div className={`p-2 rounded-xl border transition-all ${
                (app.grantingStep || 1) >= 1 ? 'bg-blue-900/60 border-blue-500 text-white font-bold' : 'bg-slate-800/40 border-slate-700/60 text-slate-400'
              }`}>
                <div className="flex items-center justify-center gap-1 mb-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="font-extrabold">Étape 1</span>
                </div>
                <span>Solvabilité & Score KYC</span>
              </div>

              {/* Step 2 */}
              <div className={`p-2 rounded-xl border transition-all ${
                (app.grantingStep || (app.status === 'lease_signed' ? 3 : app.status === 'approved' ? 2 : 1)) >= 2 ? 'bg-blue-900/60 border-blue-500 text-white font-bold' : 'bg-slate-800/40 border-slate-700/60 text-slate-400'
              }`}>
                <div className="flex items-center justify-center gap-1 mb-1">
                  <FileText className="w-3.5 h-3.5 text-blue-400" />
                  <span className="font-extrabold">Étape 2</span>
                </div>
                <span>Visite & Signature Bail</span>
              </div>

              {/* Step 3 */}
              <div className={`p-2 rounded-xl border transition-all ${
                (app.grantingStep || (app.status === 'lease_signed' ? 3 : 1)) >= 3 ? 'bg-emerald-950/80 border-emerald-500 text-emerald-200 font-bold' : 'bg-slate-800/40 border-slate-700/60 text-slate-400'
              }`}>
                <div className="flex items-center justify-center gap-1 mb-1">
                  <Building2 className="w-3.5 h-3.5 text-amber-400" />
                  <span className="font-extrabold">Étape 3</span>
                </div>
                <span>Garantie J1 & Clés</span>
              </div>
            </div>
          </div>
        )}

        {/* Property Context */}
        <div className="p-3.5 rounded-2xl bg-blue-50/60 border border-blue-200/80 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-blue-600" />
            <div>
              <span className="font-bold text-slate-900 block">{app.propertyTitle}</span>
              <span className="text-[10px] text-slate-500">{app.propertyAddress}</span>
            </div>
          </div>
          <div className="text-right">
            <span className="font-black text-blue-900 block font-mono">{formatFCFA(app.monthlyRent)}/mois</span>
            <span className="text-[10px] text-slate-500">Loyer mensuel HC</span>
          </div>
        </div>

        {/* Dynamic Financial Details for Formule Classique */}
        {isClassic && (
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div className="flex items-center gap-2 font-black text-slate-900">
                <Building2 className="w-4 h-4 text-blue-600" />
                <span>Modalités Financières — Formule Classique (Comptant 3 mois) :</span>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                0 F Frais de Dossier
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] text-slate-500 block mb-0.5">Caution légale (2m)</span>
                <span className="font-black text-blue-600 font-mono text-xs">{formatFCFA(app.monthlyRent * 2)}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] text-slate-500 block mb-0.5">Courtage agence (1m)</span>
                <span className="font-black text-blue-600 font-mono text-xs">{formatFCFA(app.monthlyRent)}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] text-slate-500 block mb-0.5">Total à l'entrée (3m)</span>
                <span className="font-black text-blue-600 font-mono text-xs">{formatFCFA(app.monthlyRent * 3)}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] text-slate-500 block mb-0.5">Frais gestion (10%)</span>
                <span className="font-black text-blue-600 font-mono text-xs">{formatFCFA(app.monthlyRent * 0.1)}/m</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-blue-50/60 border border-blue-100 flex items-center justify-between text-[11px]">
              <div className="flex items-center gap-2 text-slate-800">
                <Calendar className="w-4 h-4 text-blue-600 shrink-0" />
                <span>
                  <strong>Visite préalable souhaitée :</strong> {app.preferredVisitDate || 'À convenir avec le candidat'}
                </span>
              </div>
              <span className="text-[10px] text-blue-700 font-medium">Bail accordé post-visite</span>
            </div>
          </div>
        )}

        {/* Solvency & Income Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-[10px] text-slate-500 block mb-0.5">Score Solvabilité :</span>
            <span className="font-black text-emerald-700 text-sm">{app.kycScore}/100</span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-[10px] text-slate-500 block mb-0.5">Revenu Mensuel :</span>
            <span className="font-extrabold text-slate-900 font-mono text-xs">{formatFCFA(app.monthlyIncome)}</span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-[10px] text-slate-500 block mb-0.5">Taux d'Effort :</span>
            <span className={`font-black text-xs ${rentRatio > 33 ? 'text-amber-600' : 'text-emerald-700'}`}>
              {rentRatio}% {rentRatio <= 33 ? '(Optimal)' : '(Élevé)'}
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-[10px] text-slate-500 block mb-0.5">Niveau de Risque :</span>
            <span className="font-bold text-xs capitalize text-emerald-700">{app.riskLevel || 'Faible'}</span>
          </div>
        </div>

        {/* Non-Admin Privacy Protection Banner (Bailleur / Courtier) */}
        {!isAdminView && (
          <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 space-y-1 text-xs animate-fade-in">
            <div className="flex items-center gap-1.5 font-black text-emerald-800">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Conformité & Protection des Données Personnelles (LOC)</span>
            </div>
            <p className="text-[11px] text-emerald-700 leading-relaxed">
              Pour préserver la vie privée des candidats et garantir la sécurité des transactions, les pièces justificatives brutes (CNI, fiches de paie, relevés) sont auditées et conservées sous séquestre sécurisé par l'Administration LOC. 
              <strong> Votre garantie de versement de la caution à 100% dès le 1er jour vous est assurée.</strong>
            </p>
          </div>
        )}

        {/* Contact info */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
          <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Phone className="w-3.5 h-3.5 text-blue-600" />
              <span className="font-mono font-semibold text-slate-800">
                {isAdminView 
                  ? app.tenantPhone 
                  : `${app.tenantPhone.slice(0, 7)} •• •• ${app.tenantPhone.slice(-2)}`}
              </span>
            </div>
            {!isAdminView && (
              <span className="text-[9px] font-bold text-slate-500 bg-slate-200/80 px-2 py-0.5 rounded-full">
                🔒 Protégé LOC
              </span>
            )}
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between overflow-hidden">
            <div className="flex items-center gap-2 overflow-hidden">
              <Mail className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span className="font-mono text-slate-800 truncate">
                {isAdminView 
                  ? app.tenantEmail 
                  : `${app.tenantEmail.slice(0, 2)}•••••@•••.sn`}
              </span>
            </div>
            {!isAdminView && (
              <span className="text-[9px] font-bold text-slate-500 bg-slate-200/80 px-2 py-0.5 rounded-full shrink-0">
                🔒 Canal Sécurisé
              </span>
            )}
          </div>
        </div>

        {/* Guarantor Info if Present (Without Monthly Income as requested) */}
        {app.hasGuarantor && (
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1 text-xs">
            <span className="font-bold text-slate-900 block flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
              Garant Solidaire Déclaré :
            </span>
            <div className="flex justify-between items-center text-slate-700 pt-1">
              <span className="font-semibold">{app.guarantorName || 'Dr. Ousmane Sow'}</span>
              {app.guarantorPhone && (
                <span className="font-mono font-medium text-slate-700">
                  {isAdminView 
                    ? app.guarantorPhone 
                    : `${app.guarantorPhone.slice(0, 7)} •• •• ${app.guarantorPhone.slice(-2)}`}
                </span>
              )}
            </div>
            {app.guaranteedAmount && (
              <div className="text-[11px] text-blue-700 font-semibold pt-0.5">
                Montant garanti : {formatFCFA(app.guaranteedAmount)} (Caution solidaire)
              </div>
            )}
          </div>
        )}

        {/* KYC Document Checklist */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2 text-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
            <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-blue-600" />
              {isClassic 
                ? "Dossier Allégé Formule Classique (Justificatif CNI Unique)" 
                : "Audit du Dossier de Pièces Justificatives (KYC LOC)"}
            </h4>
            {isClassic && (
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold border border-emerald-300">
                1 seule pièce requise
              </span>
            )}
          </div>

          {isClassic ? (
            <div className="space-y-2 pt-1">
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-base">🪪</span>
                  <div>
                    <span className="font-bold text-slate-900 block">Pièce d'Identité Officielle (CNI / Passeport)</span>
                    <span className="text-[10px] text-slate-500">Document d'identification requis pour visite et rédaction du bail</span>
                  </div>
                </div>
                {app.kycDocuments?.idCard ? (
                  <span className="text-emerald-700 font-bold flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 text-xs">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Conforme
                  </span>
                ) : (
                  <span className="text-amber-700 font-bold text-xs">En attente</span>
                )}
              </div>
              <div className="p-2.5 rounded-xl bg-blue-50/50 border border-blue-100 text-[11px] text-slate-700 flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  <strong>Formule Classique (Comptant 3 mois) :</strong> Seule la carte d'identité ou passeport est requise. Aucun bulletin de salaire, relevé de compte ou garant n'est exigé pour ce dossier.
                </p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2 pt-1">
              <div className="p-2 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-[11px]">
                <span>Pièce d'Identité CNI</span>
                {app.kycDocuments?.idCard ? (
                  <span className="text-emerald-700 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Conforme
                  </span>
                ) : (
                  <span className="text-amber-700 font-bold">En attente</span>
                )}
              </div>

              <div className="p-2 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-[11px]">
                <span>Bulletins de Salaire</span>
                {app.kycDocuments?.payslips ? (
                  <span className="text-emerald-700 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Conforme
                  </span>
                ) : (
                  <span className="text-amber-700 font-bold">En attente</span>
                )}
              </div>

              <div className="p-2 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-[11px]">
                <span>Relevés Bancaires</span>
                {app.kycDocuments?.bankStatements ? (
                  <span className="text-emerald-700 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Conforme
                  </span>
                ) : (
                  <span className="text-amber-700 font-bold">En attente</span>
                )}
              </div>

              <div className="p-2 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-[11px]">
                <span>Attestation de Travail</span>
                {app.kycDocuments?.workCertificate ? (
                  <span className="text-emerald-700 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Conforme
                  </span>
                ) : (
                  <span className="text-amber-700 font-bold">En attente</span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Real Candidate Transmitted Documents */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-3 text-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-blue-600" />
              Documents Transmis par le Candidat ({isAdminView ? app.tenantName : `${app.tenantName.split(' ')[0]} (Candidat LOC)`})
            </h4>
            <span className="text-[10px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full font-bold border border-emerald-200 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
              {importedFiles.length} pièces auditées
            </span>
          </div>

          <div className="space-y-2">
            {importedFiles.map((file, idx) => (
              <div
                key={idx}
                className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs hover:border-blue-400 transition-all group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold text-sm">
                    ✅
                  </div>
                  <div>
                    <span className="font-bold text-slate-800 block group-hover:text-blue-600 transition-colors">
                      {isAdminView ? file.name : `${file.name.split('.')[0].replace(/_/g, ' ')}`}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      Type : {file.type} • {isAdminView ? `Taille : ${file.size}` : 'Statut : Transmis & Conforme'}
                    </span>
                  </div>
                </div>

                {/* If Admin: Show preview/download. If Landlord/Broker: Show Green Checkmark Badge */}
                {isAdminView ? (
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setActivePreviewFile(file)}
                      className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:text-blue-600 hover:border-blue-300 flex items-center gap-1 text-[10px] font-bold transition-all shadow-xs"
                    >
                      <Eye className="w-3.5 h-3.5 text-slate-400" />
                      <span className="hidden sm:inline">Prévisualiser</span>
                    </button>
                    <button
                      onClick={() => {
                        alert(`Téléchargement de ${file.name} pour ${app.tenantName} effectué !`);
                      }}
                      className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:text-emerald-600 hover:border-emerald-300 flex items-center gap-1 text-[10px] font-bold transition-all shadow-xs"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-100/70 text-emerald-800 border border-emerald-200 font-black text-[10px]">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Transmis & Validé LOC</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Modal Actions */}
        <div className="pt-3 border-t border-slate-200 flex items-center gap-2 flex-wrap">
          {app.status === 'pending' && isAdminView && onApprove && onReject ? (
            <>
              <button
                onClick={() => {
                  if (onApproveWithAppointment) {
                    onApproveWithAppointment(app);
                  } else if (onApprove) {
                    onApprove(app.id);
                  }
                  onClose();
                }}
                className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Valider & Planifier RDV dans le Chat</span>
              </button>

              <button
                onClick={() => setShowRejectModal(true)}
                className="py-2.5 px-3.5 rounded-xl bg-slate-100 hover:bg-red-50 text-slate-700 hover:text-red-700 border border-slate-200 hover:border-red-300 text-xs font-semibold transition-all flex items-center gap-1.5"
              >
                <XCircle className="w-4 h-4 text-red-600" />
                <span>Rejeter la candidature</span>
              </button>
            </>
          ) : (app.status === 'approved' || app.status === 'lease_signed') ? (
            <div className="flex items-center gap-2 flex-1 flex-wrap">
              {onOpenLease && (
                <button
                  onClick={() => {
                    onOpenLease(app);
                    onClose();
                  }}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all"
                >
                  <FileText className="w-4 h-4" />
                  <span>Consulter le Bail Numérique OHADA</span>
                </button>
              )}

              {isAdminView && onCancelLeaseValidation && app.status === 'approved' && (
                <button
                  onClick={() => setShowCancelModal(true)}
                  className="py-2.5 px-3 rounded-xl bg-orange-50 hover:bg-orange-100 text-orange-900 border border-orange-200 text-xs font-bold transition-all flex items-center gap-1.5"
                  title="Annuler la validation du bail si le logement ne répond pas aux attentes du locataire après visite"
                >
                  <XCircle className="w-4 h-4 text-orange-600" />
                  <span>Annuler validation post-visite</span>
                </button>
              )}
            </div>
          ) : null}

          {onOpenChatWithTenant && (
            <button
              onClick={() => {
                onOpenChatWithTenant(app.tenantName, app.tenantPhone);
                onClose();
              }}
              className="py-2.5 px-3.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center gap-1.5 transition-all"
            >
              <MessageSquare className="w-4 h-4 text-blue-600" />
              <span>Contacter sur le Chat</span>
            </button>
          )}

          <button
            onClick={onClose}
            className="py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs transition-all ml-auto"
          >
            Fermer
          </button>
        </div>

        {/* Modal Selection of Rejection Causes for Admin */}
        {showRejectModal && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in text-slate-800">
            <div className="w-full max-w-lg bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <div className="flex items-center gap-2 text-red-600 font-bold text-sm">
                  <XCircle className="w-5 h-5" />
                  <span>Motif(s) du Rejet de la Candidature</span>
                </div>
                <button
                  onClick={() => setShowRejectModal(false)}
                  className="p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <p className="text-xs text-slate-600">
                Sélectionnez la ou les causes du rejet pour l'informer le candidat <strong>{app.tenantName}</strong> :
              </p>

              <div className="space-y-2">
                {REJECTION_REASONS_OPTIONS.map((opt) => {
                  const isChecked = selectedReasons.includes(opt.label);
                  return (
                    <div
                      key={opt.id}
                      onClick={() => toggleReason(opt.label)}
                      className={`p-3 rounded-xl border text-xs font-medium cursor-pointer flex items-center justify-between transition-all ${
                        isChecked 
                          ? 'bg-red-50 border-red-300 text-red-950 font-bold' 
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        {isChecked ? (
                          <CheckSquare className="w-4 h-4 text-red-600 shrink-0" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-400 shrink-0" />
                        )}
                        <span>{opt.label}</span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Note input */}
              <div className="space-y-1 pt-1">
                <label className="text-[11px] font-bold text-slate-700 block">
                  Commentaire ou précision supplémentaire (optionnel) :
                </label>
                <textarea
                  value={rejectNote}
                  onChange={(e) => setRejectNote(e.target.value)}
                  placeholder="Ex : Veuillez nous transmettre un garant solidaire avec justificatifs récents..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-red-400"
                  rows={2}
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  onClick={() => setShowRejectModal(false)}
                  className="py-2 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold"
                >
                  Annuler
                </button>
                <button
                  onClick={handleConfirmRejection}
                  disabled={selectedReasons.length === 0}
                  className="py-2 px-4 rounded-xl bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm"
                >
                  <XCircle className="w-4 h-4" />
                  <span>Confirmer le rejet</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal: Annuler la validation du bail après visite */}
        {showCancelModal && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in text-slate-800">
            <div className="w-full max-w-lg bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <div className="flex items-center gap-2 text-orange-600 font-bold text-sm">
                  <XCircle className="w-5 h-5" />
                  <span>Annulation du Bail après Visite Physique</span>
                </div>
                <button
                  onClick={() => setShowCancelModal(false)}
                  className="p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-3.5 rounded-2xl bg-orange-50 border border-orange-200 text-orange-950 text-xs space-y-1">
                <p className="font-bold">Logement : {app.propertyTitle}</p>
                <p>Candidat : <strong>{app.tenantName}</strong></p>
                <p className="text-[11px] text-orange-900 leading-relaxed pt-1">
                  Si après la visite des lieux le logement ne correspond pas aux attentes du locataire (ou du bailleur), cette action annule la validation du bail, libère immédiatement le logement et notifie les deux parties.
                </p>
              </div>

              <div className="space-y-1 pt-1">
                <label className="text-[11px] font-bold text-slate-700 block">
                  Motif de l'annulation après visite :
                </label>
                <textarea
                  value={cancelReasonText}
                  onChange={(e) => setCancelReasonText(e.target.value)}
                  placeholder="Ex : Le logement ne convient pas au locataire suite à l'état des lieux d'entrée..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:outline-none focus:border-orange-400"
                  rows={3}
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  onClick={() => setShowCancelModal(false)}
                  className="py-2 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold"
                >
                  Fermer
                </button>
                <button
                  onClick={() => {
                    if (onCancelLeaseValidation) {
                      onCancelLeaseValidation(app.id, cancelReasonText.trim());
                    }
                    setShowCancelModal(false);
                    onClose();
                  }}
                  className="py-2 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm"
                >
                  <XCircle className="w-4 h-4" />
                  <span>Confirmer l'annulation après visite</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Real Candidate Document Preview Overlay */}
        {activePreviewFile && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md animate-fade-in text-slate-800">
            <div className="w-full max-w-xl bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4 flex flex-col max-h-[85vh]">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">{activePreviewFile.name}</h4>
                    <p className="text-[10px] text-slate-500">Document certifié transmis par {app.tenantName}</p>
                  </div>
                </div>
                <button
                  onClick={() => setActivePreviewFile(null)}
                  className="p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Document Content View */}
              <div className="flex-1 bg-slate-50 border border-slate-200 rounded-2xl p-5 overflow-y-auto font-mono text-[10px] space-y-4 select-none relative">
                {activePreviewFile.dataUrl ? (
                  <div className="flex justify-center items-center">
                    <img 
                      src={activePreviewFile.dataUrl} 
                      alt={activePreviewFile.name} 
                      className="max-h-80 object-contain rounded border border-slate-200 shadow-sm"
                    />
                  </div>
                ) : (
                  <>
                    {/* Certified Watermark */}
                    <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none">
                      <ShieldCheck className="w-64 h-64 text-emerald-800" />
                    </div>

                    <div className="flex justify-between items-center pb-3 border-b border-dashed border-slate-300">
                      <span className="font-bold text-slate-400">DOSSIER CANDIDAT DE : {app.tenantName.toUpperCase()}</span>
                      <span className="font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">CERTIFIÉ LOC J1</span>
                    </div>

                    {activePreviewFile.category === 'id' && (
                      <div className="space-y-3">
                        <div className="flex gap-4">
                          <div className="w-24 h-28 bg-slate-200 border border-slate-300 rounded flex items-center justify-center text-slate-500 font-sans text-xs">
                            [ Photo ID ]
                          </div>
                          <div className="space-y-1.5 flex-1">
                            <div><span className="text-slate-400">NOM COMPLET :</span> <span className="font-bold text-slate-950">{app.tenantName}</span></div>
                            <div><span className="text-slate-400">PROFESSION :</span> <span className="font-bold text-slate-950">{app.tenantProfession}</span></div>
                            <div><span className="text-slate-400">TÉLÉPHONE :</span> <span className="font-bold text-slate-950">{app.tenantPhone}</span></div>
                            <div><span className="text-slate-400">EMAIL :</span> <span className="font-bold text-slate-950">{app.tenantEmail}</span></div>
                            <div><span className="text-slate-400">STATUT PIÈCE :</span> <span className="font-bold text-emerald-700">CNI Conforme & Valide</span></div>
                          </div>
                        </div>
                      </div>
                    )}

                    {activePreviewFile.category === 'payslips' && (
                      <div className="space-y-3">
                        <div className="text-center font-bold text-xs text-slate-700">BULLETIN DE REVENUS - CANDIDATURE</div>
                        <div className="grid grid-cols-2 gap-4 border-y border-dashed border-slate-300 py-2">
                          <div><span className="text-slate-400">CANDIDAT :</span> <span className="font-bold">{app.tenantName}</span></div>
                          <div><span className="text-slate-400">ENTREPRISE :</span> <span className="font-bold">{app.companyName || 'Société / Employeur'}</span></div>
                          <div><span className="text-slate-400">POSTE / RÔLE :</span> <span className="font-bold">{app.tenantProfession}</span></div>
                          <div><span className="text-slate-400">CONTRAT :</span> <span className="font-bold uppercase">{app.employmentType || 'CDI'}</span></div>
                        </div>
                        <div className="space-y-1.5 font-sans">
                          <div className="flex justify-between font-mono font-bold border-t border-slate-300 pt-1">
                            <span>REVENU NET DÉCLARÉ :</span> <span className="text-blue-700">{formatFCFA(app.monthlyIncome)}</span>
                          </div>
                          <div className="flex justify-between font-mono text-[9px] text-slate-500">
                            <span>LOYER CIBLÉ :</span> <span>{formatFCFA(app.monthlyRent)} ({rentRatio}% de taux d'effort)</span>
                          </div>
                        </div>
                      </div>
                    )}

                    {activePreviewFile.category === 'bank' && (
                      <div className="space-y-3">
                        <div className="text-center font-bold text-xs text-slate-700">RELEVÉ DE COMPTE & SOLVABILITÉ</div>
                        <div className="grid grid-cols-2 gap-4 border-y border-dashed border-slate-300 py-2">
                          <div><span className="text-slate-400">TITULAIRE COMPTE :</span> <span className="font-bold">{app.tenantName}</span></div>
                          <div><span className="text-slate-400">REVENU CONSTATÉ :</span> <span className="font-bold text-emerald-700">{formatFCFA(app.monthlyIncome)}</span></div>
                        </div>
                        <div className="space-y-1">
                          <span className="font-bold text-slate-500">SCORE DE SOLVABILITÉ LOC :</span>
                          <div className="flex justify-between text-[11px] text-emerald-700 font-bold">
                            <span>{app.kycScore}/100</span>
                            <span className="capitalize">Risque : {app.riskLevel || 'Faible'}</span>
                          </div>
                        </div>
                      </div>
                    )}

                    {activePreviewFile.category === 'contract' && (
                      <div className="space-y-3">
                        <div className="text-center font-bold text-xs text-slate-700">ATTESTATION DE TRAVAIL & D'ACTIVITÉ</div>
                        <p className="leading-relaxed font-sans text-slate-700 text-[10px]">
                          Attestation d'activité professionnelle certifiant que <strong className="text-slate-900">{app.tenantName}</strong> exerce la profession de <strong className="text-slate-900">{app.tenantProfession}</strong> au sein de <strong className="text-slate-900">{app.companyName || 'son établissement'}</strong>.
                        </p>
                        <div className="pt-2 border-t border-dashed border-slate-300 flex justify-between items-center text-[9px]">
                          <span className="text-slate-500">Statut d'emploi : {app.employmentType?.toUpperCase() || 'CDI'}</span>
                          <span className="text-emerald-700 font-bold">VÉRIFIÉ PAR LOC ✓</span>
                        </div>
                      </div>
                    )}

                    {activePreviewFile.category === 'guarantor' && (
                      <div className="space-y-3">
                        <div className="text-center font-bold text-xs text-slate-700">ENGAGEMENT DE CAUTIONEMENT SOLIDAIRE</div>
                        <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl space-y-1 font-sans">
                          <div><span className="text-slate-500">GARANT :</span> <strong className="text-slate-900">{app.guarantorName || 'Garant Solidaire'}</strong></div>
                          <div><span className="text-slate-500">TÉLÉPHONE :</span> <strong className="text-slate-900">{app.guarantorPhone || 'Non renseigné'}</strong></div>
                          {app.guaranteedAmount && (
                            <div><span className="text-slate-500">MONTANT GARANTI :</span> <strong className="text-blue-700">{formatFCFA(app.guaranteedAmount)}</strong></div>
                          )}
                        </div>
                      </div>
                    )}

                    <div className="pt-3 border-t border-dashed border-slate-300 flex items-center justify-between text-[9px] text-slate-400 font-sans">
                      <span>ID-Vérification unique : LOC-CANDIDATE-{app.id.toUpperCase()}</span>
                      <span>Date : {app.appliedAt}</span>
                    </div>
                  </>
                )}
              </div>

              <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-100">
                <span className="text-[11px] text-slate-500">Document crypté AES-256</span>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      alert(`Téléchargement de ${activePreviewFile.name} lancé !`);
                    }}
                    className="py-2 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Télécharger</span>
                  </button>
                  <button
                    onClick={() => setActivePreviewFile(null)}
                    className="py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold"
                  >
                    Fermer la prévisualisation
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
