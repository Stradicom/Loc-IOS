import React, { useState } from 'react';
import { 
  X, 
  Send, 
  Download, 
  CheckCircle2, 
  Building2, 
  CreditCard, 
  Clock, 
  ShieldCheck, 
  FileText, 
  Sparkles,
  Share2,
  Copy,
  Check
} from 'lucide-react';
import { formatFCFA } from '../../utils/finance';

export interface CashflowTransaction {
  id: string;
  reference: string;
  title: string;
  type: 'loyer' | 'micro_caution' | 'reversement_bailleur' | 'indemnisation_fonds';
  amount: number;
  date: string;
  time: string;
  paymentMethod: string;
  status: 'valide' | 'garanti' | 'en_cours';
  clientName: string;
  clientRole: 'tenant' | 'landlord';
  clientPhone: string;
  propertyTitle: string;
  notes?: string;
}

interface TransactionDetailModalProps {
  transaction: CashflowTransaction;
  onClose: () => void;
  onShareToChat?: (clientName: string, clientPhone: string, shareText: string) => void;
}

export const TransactionDetailModal: React.FC<TransactionDetailModalProps> = ({
  transaction: tx,
  onClose,
  onShareToChat,
}) => {
  const [copied, setCopied] = useState(false);
  const [downloadNotice, setDownloadNotice] = useState(false);

  const receiptContent = `=====================================================
                    LOC PLATAFORME IMMOBILIÈRE
              REÇU OFFICIEL DE TRANSACTION CERTIFIÉE
=====================================================
Référence      : ${tx.reference}
Date & Heure   : ${tx.date} à ${tx.time}
Statut         : ${tx.status.toUpperCase()} (Garanti par le Fonds LOC)

Montant Total  : ${tx.amount.toLocaleString('fr-FR')} FCFA
Objet          : ${tx.title}
Mode Règlement : ${tx.paymentMethod}

Émetteur/Payeur: ${tx.clientName} (${tx.clientPhone})
Type Client    : ${tx.clientRole === 'tenant' ? 'Locataire' : 'Bailleur Agréé'}
Bien Associé   : ${tx.propertyTitle}

Remarques      : ${tx.notes || 'Transaction traitée et enregistrée avec succès sous la garantie LOC.'}
=====================================================
Attestation émise automatiquement par le système LOC.
Horodatage certifié OHADA & BCEAO.
=====================================================`;

  const handleCopyReceipt = () => {
    navigator.clipboard.writeText(receiptContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([receiptContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Recu_Transaction_KER_${tx.reference}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setDownloadNotice(true);
    setTimeout(() => setDownloadNotice(false), 3000);
  };

  const handleShareToTenantChat = () => {
    const shareMessage = `🧾 [REÇU DE TRANSACTION LOC]\nRéférence: ${tx.reference}\nMontant: ${formatFCFA(tx.amount)}\nObjet: ${tx.title}\nMode: ${tx.paymentMethod}\nStatut: Confirmé & Certifié\n\nMerci pour votre confiance ! L'équipe LOC.`;
    if (onShareToChat) {
      onShareToChat(tx.clientName, tx.clientPhone, shareMessage);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-lg bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-2xl text-slate-800 relative max-h-[92vh] overflow-y-auto space-y-4">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
          <div className="space-y-0.5">
            <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-700 text-[10px] font-bold border border-blue-200">
              <ShieldCheck className="w-3 h-3 text-blue-600" />
              Réf: {tx.reference}
            </div>
            <h3 className="text-base font-extrabold text-slate-900">Détails de la Transaction</h3>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-400 hover:text-slate-700 transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Notice toasts */}
        {downloadNotice && (
          <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Reçu texte/PDF téléchargé sous le nom Recu_Transaction_KER_{tx.reference}.txt !</span>
          </div>
        )}

        {/* Amount Hero Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 to-blue-950 text-white space-y-2 text-center shadow-lg relative overflow-hidden">
          <div className="absolute top-2 right-2 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-400/30 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            Certifié & Validé
          </div>

          <span className="text-[10px] uppercase font-bold tracking-wider text-slate-300 block">
            {tx.title}
          </span>
          <span className="text-2xl sm:text-3xl font-black font-mono text-emerald-400 block">
            {formatFCFA(tx.amount)}
          </span>
          <span className="text-[11px] text-slate-300 font-medium block">
            Règlement via <strong className="text-white">{tx.paymentMethod}</strong>
          </span>
        </div>

        {/* Details Grid */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
          <div className="flex justify-between items-center py-1 border-b border-slate-200">
            <span className="text-slate-500">Date & Heure :</span>
            <span className="font-semibold text-slate-900 font-mono">{tx.date} à {tx.time}</span>
          </div>

          <div className="flex justify-between items-center py-1 border-b border-slate-200">
            <span className="text-slate-500">Client / Bénéficiaire :</span>
            <span className="font-bold text-slate-900">{tx.clientName} ({tx.clientPhone})</span>
          </div>

          <div className="flex justify-between items-center py-1 border-b border-slate-200">
            <span className="text-slate-500">Qualité du Partenaire :</span>
            <span className="font-semibold text-blue-700">
              {tx.clientRole === 'tenant' ? 'Locataire' : 'Bailleur Agréé'}
            </span>
          </div>

          <div className="flex justify-between items-center py-1 border-b border-slate-200">
            <span className="text-slate-500">Bien Immobilier :</span>
            <span className="font-medium text-slate-900 truncate max-w-[200px]">{tx.propertyTitle}</span>
          </div>

          <div className="flex justify-between items-center py-1">
            <span className="text-slate-500">Garantie LOC :</span>
            <span className="font-bold text-emerald-700 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" /> Direct J1 Sécurisé
            </span>
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-2 pt-2 border-t border-slate-200">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {onShareToChat && (
              <button
                onClick={handleShareToTenantChat}
                className="py-2.5 px-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
              >
                <Share2 className="w-4 h-4" />
                <span>Partager direct dans le Chat</span>
              </button>
            )}

            <button
              onClick={handleDownloadFile}
              className="py-2.5 px-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
            >
              <Download className="w-4 h-4" />
              <span>Télécharger le Reçu (.txt)</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyReceipt}
              className="flex-1 py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs flex items-center justify-center gap-1.5 transition-all"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copié dans le presse-papier !' : 'Copier l\'attestation texte'}</span>
            </button>

            <button
              onClick={onClose}
              className="py-2 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs transition-all"
            >
              Fermer
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
