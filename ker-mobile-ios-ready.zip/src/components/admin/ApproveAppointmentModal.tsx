import React, { useState } from 'react';
import { 
  X, 
  Calendar, 
  Clock, 
  MapPin, 
  Send, 
  CheckCircle2, 
  UserCheck, 
  Building2, 
  FileText, 
  Sparkles,
  ShieldCheck
} from 'lucide-react';
import { TenantApplication } from '../../types';

interface ApproveAppointmentModalProps {
  isOpen: boolean;
  application: TenantApplication | null;
  onClose: () => void;
  onConfirmSchedule: (
    application: TenantApplication,
    appointmentInfo: {
      date: string;
      time: string;
      location: string;
      purpose: string;
      note?: string;
    }
  ) => void;
}

export const ApproveAppointmentModal: React.FC<ApproveAppointmentModalProps> = ({
  isOpen,
  application,
  onClose,
  onConfirmSchedule,
}) => {
  // Default to tomorrow's date YYYY-MM-DD
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const defaultDate = tomorrow.toISOString().split('T')[0];

  const [date, setDate] = useState(defaultDate);
  const [time, setTime] = useState('11:00');
  const [location, setLocation] = useState(application?.propertyTitle ? `Sur place : ${application.propertyTitle}, Dakar` : 'Sur place, Dakar');
  const [purpose, setPurpose] = useState('Signature du bail LOC & Remise des clés');
  const [note, setNote] = useState('Veuillez vous présenter avec votre pièce d\'identité originale et la preuve de paiement de la caution LOC.');

  if (!isOpen || !application) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!date || !time || !location) return;

    onConfirmSchedule(application, {
      date,
      time,
      location,
      purpose,
      note,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fade-in text-slate-800">
      <div className="w-full max-w-xl bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-2xl relative max-h-[94vh] overflow-y-auto space-y-5">
        {/* Close button */}
        <button
          onClick={onClose}
          type="button"
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="space-y-1.5 pr-8">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Approbation Candidat & Planification RDV</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900">
            Fixer le Rendez-vous pour {application.tenantName}
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            La candidature pour <strong className="text-slate-800">{application.propertyTitle}</strong> est approuvée. Définissez l'horaire et le lieu de rendez-vous qui seront immédiatement envoyés dans la messagerie du locataire.
          </p>
        </div>

        {/* Application summary badge */}
        <div className="p-3.5 rounded-2xl bg-blue-50/70 border border-blue-200 flex items-center justify-between text-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black">
              <UserCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="font-extrabold text-slate-900">{application.tenantName}</p>
              <p className="text-[11px] text-slate-600">{application.tenantPhone} • Score dossier: 95%</p>
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black border border-emerald-300">
            DOSSIER VALIDÉ
          </span>
        </div>

        {/* Appointment Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-blue-600" />
                <span>Date du Rendez-vous *</span>
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 font-medium outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-blue-600" />
                <span>Heure du Rendez-vous *</span>
              </label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                required
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 font-medium outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-blue-600" />
              <span>Lieu du Rendez-vous / Agence / Sur place *</span>
            </label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Ex: Agence LOC Almadies ou Sur place à la résidence"
              required
              className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 font-medium outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-blue-600" />
              <span>Motif Officiel *</span>
            </label>
            <select
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 font-medium outline-none"
            >
              <option value="Signature du bail LOC & Remise des clés">Signature du bail LOC & Remise des clés</option>
              <option value="Visite d'état des lieux & Signature du contrat">Visite d'état des lieux & Signature du contrat</option>
              <option value="Paiement du complément de caution & Clés">Paiement du complément de caution & Clés</option>
              <option value="Remise officielle des clés de l'appartement">Remise officielle des clés de l'appartement</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Instructions complémentaires pour le locataire (Transmises dans le Chat)</span>
            </label>
            <textarea
              rows={3}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Précisez les documents à apporter, instructions d'accès, etc."
              className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 font-medium outline-none resize-none"
            />
          </div>

          {/* Preview of chat message */}
          <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1 text-[11px]">
            <p className="font-extrabold text-emerald-900 flex items-center gap-1">
              <Send className="w-3.5 h-3.5 text-emerald-600" />
              Aperçu du message envoyé dans le Chat du locataire :
            </p>
            <p className="text-emerald-800 italic bg-white/80 p-2.5 rounded-xl border border-emerald-200 font-mono text-[10.5px]">
              "📅 <strong>CONVOCATION RENDEZ-VOUS LOC</strong> : Votre candidature pour {application.propertyTitle} est validée ! RDV le <strong>{date} à {time}</strong> à {location}. Motif : {purpose}."
            </p>
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-all"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold flex items-center gap-2 transition-all shadow-md shadow-emerald-600/20"
            >
              <Send className="w-4 h-4" />
              <span>Valider & Transmettre au Chat</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
