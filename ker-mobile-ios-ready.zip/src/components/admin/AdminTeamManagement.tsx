import React, { useState } from 'react';
import { 
  Users, 
  UserPlus, 
  ShieldCheck, 
  KeyRound, 
  Lock, 
  Mail, 
  User, 
  CheckCircle2, 
  AlertCircle, 
  Trash2, 
  BadgeCheck, 
  Sparkles,
  ShieldAlert,
  Clock,
  Check
} from 'lucide-react';
import { AdminUser } from '../../types';

interface AdminTeamManagementProps {
  adminUsers: AdminUser[];
  currentAdmin: AdminUser | null;
  onAddAdminUser: (newAdmin: AdminUser) => void;
  onUpdateAdminUser?: (updatedAdmin: AdminUser) => void;
  onToggleAdminStatus?: (adminId: string) => void;
  onDeleteAdminUser?: (adminId: string) => void;
}

export const AdminTeamManagement: React.FC<AdminTeamManagementProps> = ({
  adminUsers,
  currentAdmin,
  onAddAdminUser,
  onUpdateAdminUser,
  onToggleAdminStatus,
  onDeleteAdminUser,
}) => {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState<AdminUser | null>(null);

  // Add form state
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [department, setDepartment] = useState<AdminUser['department']>('Analyse Risque & Scoring');
  const [roleLabel, setRoleLabel] = useState('Analyste Risque & Scoring');
  const [selectedPermissions, setSelectedPermissions] = useState<string[]>([
    'approve_applications',
    'manage_properties'
  ]);

  // Edit form state
  const [editFullName, setEditFullName] = useState('');
  const [editUsername, setEditUsername] = useState('');
  const [editPassword, setEditPassword] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editDepartment, setEditDepartment] = useState<AdminUser['department']>('Analyse Risque & Scoring');
  const [editRoleLabel, setEditRoleLabel] = useState('');
  const [editStatus, setEditStatus] = useState<'active' | 'suspended'>('active');
  const [editPermissions, setEditPermissions] = useState<string[]>([]);

  const [formError, setFormError] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const isSuperAdminWiki = currentAdmin?.isSuperAdmin || currentAdmin?.username?.trim().toLowerCase() === 'wiki';

  const availablePermissions = [
    { id: 'approve_applications', label: 'Validation & Approbation des Candidatures' },
    { id: 'reject_applications', label: 'Rejet & Demande de Complément Dossier' },
    { id: 'release_guarantee_funds', label: 'Déblocage Caution & Indemnisation Fonds LOC' },
    { id: 'manage_properties', label: 'Gestion & Modération du Catalogue de Biens' },
    { id: 'legal_recovery', label: 'Actions de Recouvrement & Transmission Huissier' },
    { id: 'manage_admins', label: 'Gestion des Administrateurs & Droits d’Accès' },
  ];

  const handleOpenEdit = (admin: AdminUser) => {
    setEditingAdmin(admin);
    setEditFullName(admin.fullName);
    setEditUsername(admin.username);
    setEditPassword(admin.password);
    setEditEmail(admin.email);
    setEditDepartment(admin.department);
    setEditRoleLabel(admin.roleLabel);
    setEditStatus(admin.status as any || 'active');
    setEditPermissions([...admin.permissions]);
    setFormError(null);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAdmin) return;

    if (!editFullName.trim() || !editUsername.trim() || !editPassword.trim()) {
      setFormError('Veuillez renseigner le nom, l\'identifiant et le mot de passe.');
      return;
    }

    const updated: AdminUser = {
      ...editingAdmin,
      fullName: editFullName.trim(),
      username: editUsername.trim(),
      password: editPassword.trim(),
      email: editEmail.trim(),
      department: editDepartment,
      roleLabel: editRoleLabel.trim() || editDepartment,
      status: editStatus as any,
      permissions: editPermissions,
    };

    if (onUpdateAdminUser) {
      onUpdateAdminUser(updated);
    }
    setSuccessToast(`Modifications enregistrées avec succès pour ${updated.fullName} (@${updated.username}) !`);
    setTimeout(() => setSuccessToast(null), 4000);
    setEditingAdmin(null);
  };

  const handleTogglePermission = (permId: string) => {
    if (selectedPermissions.includes(permId)) {
      setSelectedPermissions(selectedPermissions.filter(p => p !== permId));
    } else {
      setSelectedPermissions([...selectedPermissions, permId]);
    }
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    // Validation
    if (!username.trim() || !password.trim() || !fullName.trim()) {
      setFormError('Veuillez renseigner le nom, l\'identifiant et le mot de passe.');
      return;
    }

    if (adminUsers.some(u => u.username.toLowerCase() === username.trim().toLowerCase())) {
      setFormError(`L'identifiant "${username}" est déjà utilisé.`);
      return;
    }

    const newAdmin: AdminUser = {
      id: `admin-${Date.now()}`,
      username: username.trim(),
      password: password.trim(),
      fullName: fullName.trim(),
      email: email.trim() || `${username.trim().toLowerCase()}@loc.sn`,
      roleLabel: roleLabel.trim() || department,
      isSuperAdmin: false,
      department,
      permissions: selectedPermissions,
      createdAt: new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' }),
      status: 'active',
      lastLogin: 'Non encore connecté'
    };

    onAddAdminUser(newAdmin);
    setSuccessToast(`Nouvel administrateur ${newAdmin.fullName} (@${newAdmin.username}) ajouté avec succès !`);
    setTimeout(() => setSuccessToast(null), 4000);

    // Reset form
    setFullName('');
    setUsername('');
    setPassword('');
    setEmail('');
    setIsAddModalOpen(false);
  };

  return (
    <div className="space-y-4 text-slate-800">
      {/* Header with add button */}
      <div className="flex items-center justify-between gap-3 flex-wrap p-4 bg-white border border-slate-200 rounded-3xl shadow-sm">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h3 className="text-base font-black text-slate-900">Gestion de l'Équipe & Administrateurs LOC</h3>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
              {adminUsers.length} Administrateurs
            </span>
          </div>
          <p className="text-xs text-slate-500 font-medium">
            Supervisez les comptes d'accès, ajoutez de nouveaux analystes et définissez les niveaux de prérogatives.
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-all ml-auto"
        >
          <UserPlus className="w-4 h-4" />
          <span>Ajouter un Administrateur</span>
        </button>
      </div>

      {/* Success alert */}
      {successToast && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2 shadow-sm animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Admin List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {adminUsers.map((admin) => (
          <div
            key={admin.id}
            className={`p-4 rounded-3xl bg-white border transition-all shadow-sm space-y-3 relative overflow-hidden ${
              admin.isSuperAdmin
                ? 'border-blue-300 ring-1 ring-blue-100'
                : 'border-slate-200 hover:border-slate-300'
            }`}
          >
            {admin.isSuperAdmin && (
              <div className="absolute top-0 right-0 px-3 py-1 bg-gradient-to-l from-blue-600 to-indigo-600 text-white text-[9px] font-black uppercase tracking-wider rounded-bl-xl shadow-sm">
                Super Admin
              </div>
            )}

            <div className="flex items-start gap-3">
              <div className={`w-11 h-11 rounded-2xl flex items-center justify-center font-black text-sm shrink-0 shadow-sm ${
                admin.isSuperAdmin 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-slate-100 border border-slate-200 text-blue-700'
              }`}>
                {admin.username.slice(0, 2).toUpperCase()}
              </div>

              <div className="space-y-0.5 pr-6">
                <div className="flex items-center gap-1.5">
                  <h4 className="text-xs font-bold text-slate-900">{admin.fullName}</h4>
                </div>
                <p className="text-[11px] text-blue-700 font-mono font-bold">@{admin.username}</p>
                <p className="text-[10px] text-slate-500">{admin.email}</p>
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5 text-xs">
              <div className="flex justify-between items-center text-[11px]">
                <span className="text-slate-500">Pôle :</span>
                <span className="font-semibold text-slate-800">{admin.department}</span>
              </div>
              <div className="flex justify-between items-center text-[11px]">
                <span className="text-slate-500">Rôle :</span>
                <span className="font-semibold text-blue-800">{admin.roleLabel}</span>
              </div>
              <div className="flex justify-between items-center text-[11px]">
                <span className="text-slate-500">Statut :</span>
                <span className={`font-bold flex items-center gap-1 ${
                  admin.status === 'active' ? 'text-emerald-700' : 'text-slate-400'
                }`}>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 inline-block" />
                  {admin.status === 'active' ? 'Actif' : 'Suspendu'}
                </span>
              </div>
            </div>

            {/* Permissions Badges */}
            <div className="space-y-1">
              <span className="text-[10px] font-bold text-slate-500 block uppercase tracking-wider">
                Droits & Prérogatives ({admin.permissions.length}) :
              </span>
              <div className="flex flex-wrap gap-1">
                {admin.permissions.map((p, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded-md text-[9px] font-medium bg-slate-100 text-slate-700 border border-slate-200"
                  >
                    {p.replace(/_/g, ' ')}
                  </span>
                ))}
              </div>
            </div>

            {/* Footer info */}
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400 font-medium">
              <span>Créé le {admin.createdAt}</span>
              
              <div className="flex items-center gap-2">
                {isSuperAdminWiki && (
                  <button
                    onClick={() => handleOpenEdit(admin)}
                    className="px-2.5 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-[10px] border border-blue-200 transition-all flex items-center gap-1"
                  >
                    <span>Éditer Profil & Droits</span>
                  </button>
                )}
                <span className="font-mono text-slate-500">{admin.lastLogin}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* MODAL: ÉDITER UN ADMIN (SUPER ADMIN WIKI ONLY) */}
      {editingAdmin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-lg bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-2xl text-slate-800 relative max-h-[92vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="space-y-0.5">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-700 text-xs font-semibold border border-blue-200">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Modification Prérogatives Super Admin
                </div>
                <h3 className="text-lg font-bold text-slate-900">Éditer Administrateur : {editingAdmin.fullName}</h3>
              </div>
              <button
                onClick={() => setEditingAdmin(null)}
                className="p-2 rounded-full bg-slate-100 text-slate-400 hover:text-slate-700"
              >
                ✕
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleEditSubmit} className="space-y-3.5">
              {/* Full Name */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Nom & Prénom</label>
                <input
                  type="text"
                  value={editFullName}
                  onChange={(e) => setEditFullName(e.target.value)}
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:border-blue-500 outline-none font-medium"
                />
              </div>

              {/* Username & Password */}
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">Identifiant Unique</label>
                  <input
                    type="text"
                    value={editUsername}
                    onChange={(e) => setEditUsername(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:border-blue-500 outline-none font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">Mot de Passe</label>
                  <input
                    type="text"
                    value={editPassword}
                    onChange={(e) => setEditPassword(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:border-blue-500 outline-none font-mono"
                  />
                </div>
              </div>

              {/* Email */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Email Professionnel</label>
                <input
                  type="email"
                  value={editEmail}
                  onChange={(e) => setEditEmail(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:border-blue-500 outline-none font-medium"
                />
              </div>

              {/* Department & Role */}
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">Pôle / Département</label>
                  <select
                    value={editDepartment}
                    onChange={(e) => {
                      const dep = e.target.value as AdminUser['department'];
                      setEditDepartment(dep);
                      setEditRoleLabel(dep);
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:border-blue-500 outline-none font-medium"
                  >
                    <option value="Analyse Risque & Scoring">Analyse Risque & Scoring</option>
                    <option value="Gestion des Baux">Gestion des Baux</option>
                    <option value="Recouvrement & Contentieux">Recouvrement & Contentieux</option>
                    <option value="Support & Onboarding">Support & Onboarding</option>
                    <option value="Direction Générale">Direction Générale</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">Titre / Fonction</label>
                  <input
                    type="text"
                    value={editRoleLabel}
                    onChange={(e) => setEditRoleLabel(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:border-blue-500 outline-none font-medium"
                  />
                </div>
              </div>

              {/* Status */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Statut du Compte</label>
                <select
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:border-blue-500 outline-none font-medium"
                >
                  <option value="active">Actif (Accès autorisé)</option>
                  <option value="suspended">Suspendu (Accès bloqué)</option>
                </select>
              </div>

              {/* Permissions Checklist */}
              <div className="space-y-1.5 pt-1">
                <label className="text-xs font-bold text-slate-700">Mettre à Jour les Autorisations & Prérogatives</label>
                <div className="space-y-1.5 p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  {availablePermissions.map((perm) => {
                    const isChecked = editPermissions.includes(perm.id);
                    return (
                      <label
                        key={perm.id}
                        onClick={() => {
                          if (isChecked) {
                            setEditPermissions(editPermissions.filter(p => p !== perm.id));
                          } else {
                            setEditPermissions([...editPermissions, perm.id]);
                          }
                        }}
                        className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer hover:text-slate-900"
                      >
                        <div className={`w-4 h-4 rounded-md flex items-center justify-center border transition-all ${
                          isChecked ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-300 bg-white'
                        }`}>
                          {isChecked && <Check className="w-3 h-3" />}
                        </div>
                        <span className="text-[11px] font-medium">{perm.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingAdmin(null)}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Sauvegarder les Modifications</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: AJOUTER UN NOUVEL ADMIN */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-lg bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-2xl text-slate-800 relative max-h-[92vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="space-y-0.5">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-700 text-xs font-semibold border border-blue-200">
                  <UserPlus className="w-3.5 h-3.5" />
                  Accréditation Équipe
                </div>
                <h3 className="text-lg font-bold text-slate-900">Ajouter un Nouvel Administrateur</h3>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-2 rounded-full bg-slate-100 text-slate-400 hover:text-slate-700"
              >
                ✕
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleAddSubmit} className="space-y-3.5">
              {/* Full Name */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Nom & Prénom</label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Ex: Amadou Diallo"
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:border-blue-500 outline-none font-medium"
                />
              </div>

              {/* Username & Password */}
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">Identifiant Unique</label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Ex: Adiallo"
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:border-blue-500 outline-none font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">Mot de Passe</label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Ex: Loc@2026"
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:border-blue-500 outline-none font-mono"
                  />
                </div>
              </div>

              {/* Email */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Email Professionnel</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="a.diallo@loc.sn"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:border-blue-500 outline-none font-medium"
                />
              </div>

              {/* Department & Role */}
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">Pôle / Département</label>
                  <select
                    value={department}
                    onChange={(e) => {
                      const dep = e.target.value as AdminUser['department'];
                      setDepartment(dep);
                      setRoleLabel(dep);
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:border-blue-500 outline-none font-medium"
                  >
                    <option value="Analyse Risque & Scoring">Analyse Risque & Scoring</option>
                    <option value="Gestion des Baux">Gestion des Baux</option>
                    <option value="Recouvrement & Contentieux">Recouvrement & Contentieux</option>
                    <option value="Support & Onboarding">Support & Onboarding</option>
                    <option value="Direction Générale">Direction Générale</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">Titre / Fonction</label>
                  <input
                    type="text"
                    value={roleLabel}
                    onChange={(e) => setRoleLabel(e.target.value)}
                    placeholder="Ex: Analyste Risque Senior"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:border-blue-500 outline-none font-medium"
                  />
                </div>
              </div>

              {/* Permissions Checklist */}
              <div className="space-y-1.5 pt-1">
                <label className="text-xs font-bold text-slate-700">Prérogatives & Autorisations</label>
                <div className="space-y-1.5 p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  {availablePermissions.map((perm) => {
                    const isChecked = selectedPermissions.includes(perm.id);
                    return (
                      <label
                        key={perm.id}
                        onClick={() => handleTogglePermission(perm.id)}
                        className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer hover:text-slate-900"
                      >
                        <div className={`w-4 h-4 rounded-md flex items-center justify-center border transition-all ${
                          isChecked ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-300 bg-white'
                        }`}>
                          {isChecked && <Check className="w-3 h-3" />}
                        </div>
                        <span className="text-[11px] font-medium">{perm.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Enregistrer l'Administrateur</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
