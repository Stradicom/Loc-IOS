import React, { useState } from 'react';
import { 
  AlertTriangle, 
  Search, 
  Filter, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  User, 
  Phone, 
  Building2, 
  Wrench, 
  Zap, 
  Key, 
  ShieldAlert, 
  FileText, 
  MessageSquare, 
  Plus, 
  X, 
  Send,
  ChevronRight,
  ShieldCheck,
  Check
} from 'lucide-react';
import { SignalementItem } from '../../types';

interface AdminSignalementsManagementProps {
  signalements: SignalementItem[];
  onUpdateSignalement: (updatedSignalement: SignalementItem) => void;
  onAddSignalement: (newSignalement: SignalementItem) => void;
  onOpenChat?: (recipientName: string, recipientPhone?: string) => void;
}

export const AdminSignalementsManagement: React.FC<AdminSignalementsManagementProps> = ({
  signalements,
  onUpdateSignalement,
  onAddSignalement,
  onOpenChat,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'nouveau' | 'en_cours' | 'resolu' | 'rejete'>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [selectedSignalement, setSelectedSignalement] = useState<SignalementItem | null>(null);
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  
  // Note / Artisan edit state
  const [adminNoteInput, setAdminNoteInput] = useState('');
  const [artisanInput, setArtisanInput] = useState('');

  // New Signalement Form state
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newAuthorName, setNewAuthorName] = useState('');
  const [newAuthorPhone, setNewAuthorPhone] = useState('');
  const [newAuthorRole, setNewAuthorRole] = useState<'tenant' | 'landlord' | 'visitor'>('tenant');
  const [newCategory, setNewCategory] = useState<'plomberie' | 'electricite' | 'serrurerie' | 'litige_bail' | 'annonce_suspecte' | 'autre'>('plomberie');
  const [newPriority, setNewPriority] = useState<'basse' | 'moyenne' | 'haute' | 'urgente'>('moyenne');
  const [newPropertyTitle, setNewPropertyTitle] = useState('');

  // Counters
  const totalCount = signalements.length;
  const newCount = signalements.filter(s => s.status === 'nouveau').length;
  const inProgressCount = signalements.filter(s => s.status === 'en_cours').length;
  const resolvedCount = signalements.filter(s => s.status === 'resolu').length;
  const urgentCount = signalements.filter(s => s.priority === 'urgente' || s.priority === 'haute').length;

  // Filtered Signalements
  const filteredSignalements = signalements.filter(sig => {
    const matchesSearch = 
      sig.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sig.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sig.authorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (sig.propertyTitle && sig.propertyTitle.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesStatus = statusFilter === 'all' ? true : sig.status === statusFilter;
    const matchesCategory = categoryFilter === 'all' ? true : sig.category === categoryFilter;

    return matchesSearch && matchesStatus && matchesCategory;
  });

  const handleOpenDetail = (sig: SignalementItem) => {
    setSelectedSignalement(sig);
    setAdminNoteInput(sig.adminNotes || '');
    setArtisanInput(sig.assignedArtisan || '');
  };

  const handleSaveDetailChanges = () => {
    if (!selectedSignalement) return;
    const updated: SignalementItem = {
      ...selectedSignalement,
      adminNotes: adminNoteInput,
      assignedArtisan: artisanInput,
    };
    onUpdateSignalement(updated);
    setSelectedSignalement(null);
  };

  const handleChangeStatus = (sig: SignalementItem, newStatus: 'nouveau' | 'en_cours' | 'resolu' | 'rejete') => {
    const updated: SignalementItem = {
      ...sig,
      status: newStatus,
    };
    onUpdateSignalement(updated);
    if (selectedSignalement && selectedSignalement.id === sig.id) {
      setSelectedSignalement(updated);
    }
  };

  const handleCreateSignalement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDesc.trim() || !newAuthorName.trim()) return;

    const newSigItem: SignalementItem = {
      id: `sig-${Date.now()}`,
      authorId: `user-${Date.now()}`,
      authorName: newAuthorName.trim(),
      authorRole: newAuthorRole,
      authorPhone: newAuthorPhone.trim() || '+221 77 000 00 00',
      propertyTitle: newPropertyTitle.trim() || 'Non spécifié',
      title: newTitle.trim(),
      description: newDesc.trim(),
      category: newCategory,
      priority: newPriority,
      status: 'nouveau',
      createdAt: new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }),
    };

    onAddSignalement(newSigItem);
    setIsNewModalOpen(false);

    // Reset Form
    setNewTitle('');
    setNewDesc('');
    setNewAuthorName('');
    setNewAuthorPhone('');
    setNewPropertyTitle('');
  };

  const getCategoryIcon = (cat: string) => {
    switch (cat) {
      case 'plomberie':
        return <Wrench className="w-4 h-4 text-sky-600" />;
      case 'electricite':
        return <Zap className="w-4 h-4 text-amber-500" />;
      case 'serrurerie':
        return <Key className="w-4 h-4 text-slate-700" />;
      case 'litige_bail':
        return <FileText className="w-4 h-4 text-purple-600" />;
      case 'annonce_suspecte':
        return <ShieldAlert className="w-4 h-4 text-rose-600" />;
      default:
        return <AlertTriangle className="w-4 h-4 text-slate-600" />;
    }
  };

  const getPriorityBadge = (prio: string) => {
    switch (prio) {
      case 'urgente':
        return <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 border border-rose-300 font-bold text-[10px] animate-pulse">🔴 URGENTE</span>;
      case 'haute':
        return <span className="px-2 py-0.5 rounded-full bg-orange-100 text-orange-800 border border-orange-300 font-bold text-[10px]">🟠 Haute</span>;
      case 'moyenne':
        return <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 border border-blue-200 font-bold text-[10px]">🔵 Moyenne</span>;
      default:
        return <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200 font-bold text-[10px]">⚪ Basse</span>;
    }
  };

  const getStatusPill = (status: string) => {
    switch (status) {
      case 'nouveau':
        return <span className="px-2.5 py-1 rounded-xl bg-amber-50 text-amber-800 border border-amber-200 font-bold text-xs flex items-center gap-1"><Clock className="w-3.5 h-3.5 text-amber-600" /> Nouveau</span>;
      case 'en_cours':
        return <span className="px-2.5 py-1 rounded-xl bg-blue-50 text-blue-800 border border-blue-200 font-bold text-xs flex items-center gap-1"><Wrench className="w-3.5 h-3.5 text-blue-600" /> En cours</span>;
      case 'resolu':
        return <span className="px-2.5 py-1 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold text-xs flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Résolu</span>;
      case 'rejete':
        return <span className="px-2.5 py-1 rounded-xl bg-slate-100 text-slate-600 border border-slate-200 font-bold text-xs flex items-center gap-1"><XCircle className="w-3.5 h-3.5 text-slate-400" /> Classé</span>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6 animate-fade-in text-slate-800">
      {/* Top Banner & Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-50 text-rose-800 border border-rose-200 text-xs font-bold mb-1">
            <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
            Espace Administrateur LOC
          </div>
          <h2 className="text-xl font-black text-slate-900">Gestion des Signalements & Incidents</h2>
          <p className="text-xs text-slate-500 font-medium">
            Supervisez les pannes techniques, litiges locatifs et signalements d'annonces en temps réel.
          </p>
        </div>

        <button
          onClick={() => setIsNewModalOpen(true)}
          className="py-2.5 px-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Créer un Signalement</span>
        </button>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div 
          onClick={() => setStatusFilter('all')}
          className={`p-4 rounded-3xl border transition-all cursor-pointer ${
            statusFilter === 'all' ? 'bg-blue-600 text-white border-blue-600 shadow-md' : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <span className={`text-[10px] uppercase font-bold tracking-wider block ${statusFilter === 'all' ? 'text-blue-100' : 'text-slate-400'}`}>
            Total Signalements
          </span>
          <span className={`text-2xl font-black font-mono ${statusFilter === 'all' ? 'text-white' : 'text-slate-900'}`}>
            {totalCount}
          </span>
        </div>

        <div 
          onClick={() => setStatusFilter('nouveau')}
          className={`p-4 rounded-3xl border transition-all cursor-pointer ${
            statusFilter === 'nouveau' ? 'bg-amber-500 text-white border-amber-500 shadow-md' : 'bg-white border-slate-200 hover:border-amber-300'
          }`}
        >
          <span className={`text-[10px] uppercase font-bold tracking-wider block ${statusFilter === 'nouveau' ? 'text-amber-100' : 'text-amber-700'}`}>
            Nouveaux / À Traiter
          </span>
          <span className={`text-2xl font-black font-mono ${statusFilter === 'nouveau' ? 'text-white' : 'text-amber-800'}`}>
            {newCount}
          </span>
        </div>

        <div 
          onClick={() => setStatusFilter('en_cours')}
          className={`p-4 rounded-3xl border transition-all cursor-pointer ${
            statusFilter === 'en_cours' ? 'bg-sky-600 text-white border-sky-600 shadow-md' : 'bg-white border-slate-200 hover:border-sky-300'
          }`}
        >
          <span className={`text-[10px] uppercase font-bold tracking-wider block ${statusFilter === 'en_cours' ? 'text-sky-100' : 'text-sky-700'}`}>
            Intervention En Cours
          </span>
          <span className={`text-2xl font-black font-mono ${statusFilter === 'en_cours' ? 'text-white' : 'text-sky-800'}`}>
            {inProgressCount}
          </span>
        </div>

        <div 
          onClick={() => setStatusFilter('resolu')}
          className={`p-4 rounded-3xl border transition-all cursor-pointer ${
            statusFilter === 'resolu' ? 'bg-emerald-600 text-white border-emerald-600 shadow-md' : 'bg-white border-slate-200 hover:border-emerald-300'
          }`}
        >
          <span className={`text-[10px] uppercase font-bold tracking-wider block ${statusFilter === 'resolu' ? 'text-emerald-100' : 'text-emerald-700'}`}>
            Incidents Résolus
          </span>
          <span className={`text-2xl font-black font-mono ${statusFilter === 'resolu' ? 'text-white' : 'text-emerald-800'}`}>
            {resolvedCount}
          </span>
        </div>
      </div>

      {/* Filters & Search Toolbar */}
      <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher un incident, locataire, bailleur, logement..."
              className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Category Selector */}
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400" />
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="py-2.5 px-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">Toutes catégories</option>
              <option value="plomberie">🔧 Plomberie</option>
              <option value="electricite">⚡ Électricité</option>
              <option value="serrurerie">🔑 Serrurerie</option>
              <option value="litige_bail">📜 Litige / Bail</option>
              <option value="annonce_suspecte">🛡️ Annonce Suspecte</option>
              <option value="autre">📦 Autre</option>
            </select>
          </div>
        </div>

        {/* Status Tab Pills */}
        <div className="flex items-center gap-2 pt-1 overflow-x-auto pb-1">
          {[
            { id: 'all', label: 'Tous' },
            { id: 'nouveau', label: 'Nouveaux' },
            { id: 'en_cours', label: 'En cours' },
            { id: 'resolu', label: 'Résolus' },
            { id: 'rejete', label: 'Classés' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id as any)}
              className={`py-1.5 px-3 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                statusFilter === tab.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Signalements List */}
      <div className="space-y-3">
        {filteredSignalements.length === 0 ? (
          <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-3">
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
            <h4 className="text-base font-bold text-slate-800">Aucun signalement trouvé</h4>
            <p className="text-xs text-slate-500">
              Aucun incident ne correspond à vos filtres actuels. Tous les voyants sont au vert.
            </p>
          </div>
        ) : (
          filteredSignalements.map((sig) => (
            <div
              key={sig.id}
              className="bg-white border border-slate-200 hover:border-slate-300 rounded-3xl p-5 shadow-xs transition-all space-y-4"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 rounded-2xl bg-slate-100 border border-slate-200">
                    {getCategoryIcon(sig.category)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black uppercase text-slate-500 font-mono">
                        {sig.category.replace('_', ' ')}
                      </span>
                      {getPriorityBadge(sig.priority)}
                    </div>
                    <h3 className="text-sm font-bold text-slate-900">{sig.title}</h3>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-center">
                  {getStatusPill(sig.status)}
                  <span className="text-[11px] font-mono text-slate-400">{sig.createdAt}</span>
                </div>
              </div>

              {/* Description & Property */}
              <div className="space-y-2">
                <p className="text-xs text-slate-700 leading-relaxed font-medium">
                  {sig.description}
                </p>

                {sig.propertyTitle && (
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 font-semibold">
                    <Building2 className="w-3.5 h-3.5 text-blue-600" />
                    <span>Concerne : <strong>{sig.propertyTitle}</strong></span>
                  </div>
                )}
              </div>

              {/* Author Info & Actions */}
              <div className="pt-3 border-t border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div className="flex items-center gap-3 text-xs">
                  <div className="flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    <span className="font-bold text-slate-900">{sig.authorName}</span>
                    <span className="text-[10px] px-2 py-0.2 rounded-full bg-slate-100 font-semibold text-slate-600 capitalize">
                      {sig.authorRole === 'tenant' ? 'Locataire' : sig.authorRole === 'landlord' ? 'Bailleur' : 'Visiteur'}
                    </span>
                  </div>
                  
                  {sig.authorPhone && (
                    <a
                      href={`tel:${sig.authorPhone.replace(/\s+/g, '')}`}
                      className="text-slate-500 hover:text-blue-600 font-mono text-[11px] flex items-center gap-1"
                    >
                      <Phone className="w-3 h-3" />
                      {sig.authorPhone}
                    </a>
                  )}
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {sig.status === 'nouveau' && (
                    <button
                      onClick={() => handleChangeStatus(sig, 'en_cours')}
                      className="py-1.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1 shadow-xs transition-all cursor-pointer"
                    >
                      <Wrench className="w-3.5 h-3.5" />
                      <span>Prendre en charge</span>
                    </button>
                  )}

                  {sig.status === 'en_cours' && (
                    <button
                      onClick={() => handleChangeStatus(sig, 'resolu')}
                      className="py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1 shadow-xs transition-all cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Marquer Résolu</span>
                    </button>
                  )}

                  <button
                    onClick={() => handleOpenDetail(sig)}
                    className="py-1.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center gap-1 transition-all cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5 text-slate-600" />
                    <span>Détails & Suivi</span>
                  </button>

                  {onOpenChat && sig.authorName && (
                    <button
                      onClick={() => onOpenChat(sig.authorName, sig.authorPhone)}
                      className="py-1.5 px-3 rounded-xl bg-white border border-slate-200 hover:border-blue-300 text-slate-700 font-bold text-xs flex items-center gap-1 transition-all cursor-pointer"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-blue-600" />
                      <span>Chat Direct</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Detail / Admin Note & Artisan Assignment Modal */}
      {selectedSignalement && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in text-slate-800">
          <div className="w-full max-w-lg bg-white border border-slate-200 rounded-3xl p-6 shadow-2xl relative space-y-4 max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setSelectedSignalement(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-400 hover:text-slate-800 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2">
              {getCategoryIcon(selectedSignalement.category)}
              <h3 className="text-base font-bold text-slate-900">Traitement du Signalement</h3>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900">{selectedSignalement.title}</span>
                {getPriorityBadge(selectedSignalement.priority)}
              </div>
              <p className="text-slate-600 leading-relaxed">{selectedSignalement.description}</p>
              <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between text-[11px] text-slate-500">
                <span>Signalé par : <strong>{selectedSignalement.authorName}</strong></span>
                <span>Date : <strong>{selectedSignalement.createdAt}</strong></span>
              </div>
            </div>

            {/* Change Status Controls */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 block">Statut du dossier :</label>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { id: 'nouveau', label: 'Nouveau', cls: 'bg-amber-100 text-amber-800' },
                  { id: 'en_cours', label: 'En cours', cls: 'bg-blue-100 text-blue-800' },
                  { id: 'resolu', label: 'Résolu', cls: 'bg-emerald-100 text-emerald-800' },
                  { id: 'rejete', label: 'Classé', cls: 'bg-slate-200 text-slate-700' },
                ].map((st) => (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => handleChangeStatus(selectedSignalement, st.id as any)}
                    className={`py-2 px-2 rounded-xl text-xs font-bold transition-all text-center cursor-pointer ${
                      selectedSignalement.status === st.id
                        ? `${st.cls} ring-2 ring-slate-900 shadow-xs`
                        : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Assigned Artisan */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 block">Artisan / Prestataire agréé LOC :</label>
              <input
                type="text"
                value={artisanInput}
                onChange={(e) => setArtisanInput(e.target.value)}
                placeholder="Ex : Plomberie Express Dakar (077 123 45 67)"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Admin Internal Notes */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 block">Notes internes & suivi admin :</label>
              <textarea
                rows={3}
                value={adminNoteInput}
                onChange={(e) => setAdminNoteInput(e.target.value)}
                placeholder="Rédigez les remarques ou étapes de résolution..."
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setSelectedSignalement(null)}
                className="py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={handleSaveDetailChanges}
                className="py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs cursor-pointer"
              >
                Enregistrer les Modifications
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create Signalement Modal */}
      {isNewModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in text-slate-800">
          <div className="w-full max-w-lg bg-white border border-slate-200 rounded-3xl p-6 shadow-2xl relative space-y-4 max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setIsNewModalOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-400 hover:text-slate-800 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2">
              <Plus className="w-5 h-5 text-blue-600" />
              <h3 className="text-base font-bold text-slate-900">Enregistrer un Nouveau Signalement</h3>
            </div>

            <form onSubmit={handleCreateSignalement} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">Nom de l'auteur :</label>
                  <input
                    type="text"
                    required
                    value={newAuthorName}
                    onChange={(e) => setNewAuthorName(e.target.value)}
                    placeholder="Ex : Ousmane Ba"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">Téléphone :</label>
                  <input
                    type="tel"
                    value={newAuthorPhone}
                    onChange={(e) => setNewAuthorPhone(e.target.value)}
                    placeholder="+221 77 123 45 67"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">Rôle de l'auteur :</label>
                  <select
                    value={newAuthorRole}
                    onChange={(e) => setNewAuthorRole(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="tenant">Locataire</option>
                    <option value="landlord">Bailleur</option>
                    <option value="visitor">Visiteur / Public</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">Catégorie :</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="plomberie">Plomberie</option>
                    <option value="electricite">Électricité</option>
                    <option value="serrurerie">Serrurerie</option>
                    <option value="litige_bail">Litige / Bail</option>
                    <option value="annonce_suspecte">Annonce Suspecte</option>
                    <option value="autre">Autre</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">Niveau d'urgence :</label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="basse">Basse</option>
                    <option value="moyenne">Moyenne</option>
                    <option value="haute">Haute</option>
                    <option value="urgente">Urrente (🔴)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">Logement concerné :</label>
                  <input
                    type="text"
                    value={newPropertyTitle}
                    onChange={(e) => setNewPropertyTitle(e.target.value)}
                    placeholder="Ex : Studio F2 Mermoz"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">Titre du signalement :</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Ex : Coupure d'eau générale dans le bâtiment"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block">Description détaillée :</label>
                <textarea
                  rows={3}
                  required
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Décrivez précisément la situation..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsNewModalOpen(false)}
                  className="py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs cursor-pointer"
                >
                  Créer le Signalement
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
