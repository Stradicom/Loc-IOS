import React, { useState, useMemo } from 'react';
import { 
  Users, 
  Search, 
  Filter, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  FileText, 
  ShieldCheck, 
  Sparkles, 
  Eye, 
  MessageSquare, 
  Calendar, 
  RotateCcw, 
  AlertTriangle, 
  Building2, 
  Phone, 
  Mail, 
  UserCheck, 
  Sliders, 
  ChevronRight, 
  BadgeCheck, 
  ArrowRight,
  RefreshCw,
  TrendingUp,
  X,
  Check,
  Award
} from 'lucide-react';
import { TenantApplication, Property, Role, ProfessionCategory } from '../../types';
import { formatFCFA, computeSolvencyScore } from '../../utils/finance';
import { CandidateDetailModal } from './CandidateDetailModal';

interface AdminApplicationsManagementProps {
  applications: TenantApplication[];
  properties: Property[];
  onApproveApplication: (applicationId: string) => void;
  onRejectApplication: (applicationId: string, reasons?: string[], note?: string) => void;
  onCancelLeaseValidation?: (applicationId: string, reason?: string) => void;
  onUpdateApplicationScore?: (applicationId: string, newScore: number) => void;
  onOpenLeaseModal?: (application: TenantApplication) => void;
  onOpenChatWithTenant?: (tenantName: string, tenantPhone: string) => void;
  onApproveWithAppointment?: (application: TenantApplication) => void;
}

export const AdminApplicationsManagement: React.FC<AdminApplicationsManagementProps> = ({
  applications,
  properties,
  onApproveApplication,
  onRejectApplication,
  onCancelLeaseValidation,
  onUpdateApplicationScore,
  onOpenLeaseModal,
  onOpenChatWithTenant,
  onApproveWithAppointment,
}) => {
  // Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'lease_signed' | 'cancelled' | 'rejected'>('all');
  const [formulaFilter, setFormulaFilter] = useState<'all' | 'ker_financing' | 'classic_direct'>('all');
  const [professionFilter, setProfessionFilter] = useState<string>('all');
  const [selectedCandidateForDetail, setSelectedCandidateForDetail] = useState<TenantApplication | null>(null);

  // Cancellation Modal State
  const [candidateToCancel, setCandidateToCancel] = useState<TenantApplication | null>(null);
  const [cancellationReason, setCancellationReason] = useState<string>(
    "Visite physique effectuée — Le logement ne répond pas aux attentes du locataire (agencement, luminosité ou localisation)."
  );

  // Score Adjustment Modal State
  const [candidateToAdjustScore, setCandidateToAdjustScore] = useState<TenantApplication | null>(null);
  const [adjustedScoreValue, setAdjustedScoreValue] = useState<number>(75);

  // Calculate Metrics
  const isAppClassic = (a: TenantApplication) => a.applicationOption === 'classic_direct' || (!a.applicationOption && Boolean(a.preferredVisitDate));
  const totalCount = applications.length;
  const kerApplicationsCount = applications.filter(a => !isAppClassic(a)).length;
  const classicApplicationsCount = applications.filter(a => isAppClassic(a)).length;
  const pendingCount = applications.filter(a => a.status === 'pending').length;
  const approvedCount = applications.filter(a => a.status === 'approved' || a.status === 'lease_signed').length;
  const cancelledCount = applications.filter(a => a.status === 'cancelled').length;
  const rejectedCount = applications.filter(a => a.status === 'rejected').length;

  const avgScore = totalCount > 0 
    ? Math.round(applications.reduce((acc, curr) => acc + (curr.kycScore || 50), 0) / totalCount)
    : 0;

  // Filtered Applications List
  const filteredApplications = useMemo(() => {
    return applications.filter((app) => {
      // Search
      const q = searchQuery.toLowerCase().trim();
      const matchesQuery = !q || (
        app.tenantName.toLowerCase().includes(q) ||
        app.tenantPhone.toLowerCase().includes(q) ||
        app.propertyTitle.toLowerCase().includes(q) ||
        app.tenantProfession.toLowerCase().includes(q) ||
        app.id.toLowerCase().includes(q)
      );

      // Formula Filter (Micro-caution vs Classique)
      let matchesFormula = true;
      if (formulaFilter === 'ker_financing') {
        matchesFormula = !isAppClassic(app);
      } else if (formulaFilter === 'classic_direct') {
        matchesFormula = isAppClassic(app);
      }

      // Status
      let matchesStatus = true;
      if (statusFilter === 'all') matchesStatus = true;
      else if (statusFilter === 'approved') matchesStatus = app.status === 'approved';
      else matchesStatus = app.status === statusFilter;

      // Profession
      let matchesProfession = true;
      if (professionFilter !== 'all') {
        matchesProfession = app.professionCategory === professionFilter;
      }

      return matchesQuery && matchesFormula && matchesStatus && matchesProfession;
    });
  }, [applications, searchQuery, formulaFilter, statusFilter, professionFilter]);

  const handleConfirmCancelLease = () => {
    if (!candidateToCancel) return;
    if (onCancelLeaseValidation) {
      onCancelLeaseValidation(candidateToCancel.id, cancellationReason.trim());
    }
    setCandidateToCancel(null);
  };

  const handleSaveScoreAdjustment = () => {
    if (!candidateToAdjustScore) return;
    if (onUpdateApplicationScore) {
      onUpdateApplicationScore(candidateToAdjustScore.id, adjustedScoreValue);
    }
    setCandidateToAdjustScore(null);
  };

  const getStatusPill = (status: TenantApplication['status']) => {
    switch (status) {
      case 'approved':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Caution Validée J1
          </span>
        );
      case 'lease_signed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
            <FileText className="w-3.5 h-3.5 text-blue-600" />
            Bail Signé & Actif
          </span>
        );
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-orange-100 text-orange-900 border border-orange-200">
            <RotateCcw className="w-3.5 h-3.5 text-orange-600" />
            Annulé post-visite
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            Rejeté
          </span>
        );
      case 'pending':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
            <Clock className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
            Audit en cours
          </span>
        );
    }
  };

  return (
    <div className="space-y-6 animate-fade-in text-slate-800" id="admin-applications-management">
      
      {/* Header & Main Overview Banner */}
      <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-xs space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[11px] font-bold border border-blue-200">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
              Pôle Audit & Gestion des Candidatures Individuelles LOC
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900">
              Gestion des Candidatures Individuelles
            </h2>
            <p className="text-xs text-slate-500 max-w-2xl">
              Supervisez l'intégralité des dossiers locataires déposés sur les logements LOC : audit de solvabilité, déblocage de garantie caution 6 mois, signature de bail et annulation après visite.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-blue-50 border border-blue-200 text-center">
              <span className="text-[10px] text-slate-500 font-bold uppercase block">Score Moyen KYC</span>
              <span className="text-xl font-black text-blue-700 font-mono">{avgScore}/100</span>
            </div>
          </div>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
          <div 
            onClick={() => setStatusFilter('all')}
            className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
              statusFilter === 'all' ? 'bg-slate-900 text-white border-slate-900 shadow-sm' : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <span className="text-[10px] block opacity-75 font-bold uppercase">Total Reçues</span>
            <span className="text-lg font-black font-mono mt-1 block">{totalCount}</span>
          </div>

          <div 
            onClick={() => setStatusFilter('pending')}
            className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
              statusFilter === 'pending' ? 'bg-amber-500 text-white border-amber-600 shadow-sm' : 'bg-amber-50/70 border-amber-200 text-amber-900 hover:bg-amber-100/60'
            }`}
          >
            <span className="text-[10px] block opacity-85 font-bold uppercase flex items-center gap-1">
              <Clock className="w-3 h-3" /> En attente
            </span>
            <span className="text-lg font-black font-mono mt-1 block">{pendingCount}</span>
          </div>

          <div 
            onClick={() => setStatusFilter('approved')}
            className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
              statusFilter === 'approved' ? 'bg-emerald-600 text-white border-emerald-700 shadow-sm' : 'bg-emerald-50/70 border-emerald-200 text-emerald-900 hover:bg-emerald-100/60'
            }`}
          >
            <span className="text-[10px] block opacity-85 font-bold uppercase flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> Validées LOC
            </span>
            <span className="text-lg font-black font-mono mt-1 block">{approvedCount}</span>
          </div>

          <div 
            onClick={() => setStatusFilter('cancelled')}
            className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
              statusFilter === 'cancelled' ? 'bg-orange-600 text-white border-orange-700 shadow-sm' : 'bg-orange-50/70 border-orange-200 text-orange-900 hover:bg-orange-100/60'
            }`}
          >
            <span className="text-[10px] block opacity-85 font-bold uppercase flex items-center gap-1">
              <RotateCcw className="w-3 h-3" /> Annulées post-visite
            </span>
            <span className="text-lg font-black font-mono mt-1 block">{cancelledCount}</span>
          </div>

          <div 
            onClick={() => setStatusFilter('rejected')}
            className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
              statusFilter === 'rejected' ? 'bg-rose-600 text-white border-rose-700 shadow-sm' : 'bg-rose-50/70 border-rose-200 text-rose-900 hover:bg-rose-100/60'
            }`}
          >
            <span className="text-[10px] block opacity-85 font-bold uppercase flex items-center gap-1">
              <XCircle className="w-3 h-3" /> Non Retenues
            </span>
            <span className="text-lg font-black font-mono mt-1 block">{rejectedCount}</span>
          </div>
        </div>

        {/* Formula Filter Tabs: LOC vs Classique */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-2 rounded-2xl bg-slate-100 border border-slate-200">
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              type="button"
              onClick={() => setFormulaFilter('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 ${
                formulaFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <Users className="w-3.5 h-3.5 text-slate-500" />
              <span>Toutes les candidatures</span>
              <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-slate-200 text-slate-700 font-bold">
                {totalCount}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setFormulaFilter('ker_financing')}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 ${
                formulaFilter === 'ker_financing'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-blue-700 hover:text-blue-900 hover:bg-blue-50/70'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Candidatures Formule Micro-caution</span>
              <span className={`ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-mono font-bold ${
                formulaFilter === 'ker_financing' ? 'bg-blue-700 text-white' : 'bg-blue-100 text-blue-800'
              }`}>
                {kerApplicationsCount}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setFormulaFilter('classic_direct')}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 ${
                formulaFilter === 'classic_direct'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <Building2 className="w-3.5 h-3.5 text-blue-400" />
              <span>Candidatures Formule classique</span>
              <span className={`ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-mono font-bold ${
                formulaFilter === 'classic_direct' ? 'bg-slate-800 text-slate-200' : 'bg-slate-200 text-slate-800'
              }`}>
                {classicApplicationsCount}
              </span>
            </button>
          </div>

          <div className="text-[11px] text-slate-500 font-medium px-2 shrink-0">
            {formulaFilter === 'ker_financing' && '⚡ Filtre actif : Dossiers avec micro-caution LOC & garantie 6m'}
            {formulaFilter === 'classic_direct' && '🏛️ Filtre actif : Dossiers avec paiement direct 3 mois comptant & visite physique'}
            {formulaFilter === 'all' && 'Vue globale : LOC + Classique'}
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="flex flex-col md:flex-row gap-3 pt-1">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher par candidat, téléphone, logement, réf dossier..."
              className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Profession Category Selector */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-bold whitespace-nowrap">Catégorie :</span>
            <select
              value={professionFilter}
              onChange={(e) => setProfessionFilter(e.target.value)}
              className="py-2.5 px-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">Toutes les professions</option>
              <option value="salarie">Salariés (CDI/CDD)</option>
              <option value="fonctionnaire">Fonctionnaires d'État</option>
              <option value="entrepreneur">Entrepreneurs & Dirigeants</option>
              <option value="commercant">Commerçants & Marchands</option>
              <option value="independant">Indépendants & Freelances</option>
              <option value="etudiant">Étudiants (avec Garant)</option>
              <option value="autre">Autres profils</option>
            </select>
          </div>
        </div>
      </div>

      {/* Applications Table / Cards List */}
      <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-xs">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-blue-600" />
            <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider">
              {formulaFilter === 'ker_financing'
                ? `Candidatures Formule Micro-caution (${filteredApplications.length})`
                : formulaFilter === 'classic_direct'
                ? `Candidatures Formule classique (${filteredApplications.length})`
                : `Toutes les Candidatures (${filteredApplications.length})`}
            </h3>
          </div>
          <span className="text-[11px] text-slate-500 font-medium">
            Statut : <strong className="text-slate-800">{statusFilter.toUpperCase()}</strong>
          </span>
        </div>

        {filteredApplications.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <Building2 className="w-10 h-10 text-slate-300 mx-auto" />
            <h4 className="text-sm font-bold text-slate-800">Aucune candidature trouvée</h4>
            <p className="text-xs text-slate-500">
              Aucun dossier ne correspond à vos critères de recherche actuels.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setStatusFilter('all');
                setFormulaFilter('all');
                setProfessionFilter('all');
              }}
              className="px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-bold hover:bg-blue-700"
            >
              Réinitialiser les filtres
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 overflow-x-auto">
            {filteredApplications.map((app) => {
              const isClassic = isAppClassic(app);
              const rentRatio = Math.round((app.monthlyRent / (app.monthlyIncome || 1)) * 100);
              const isApprovedOnly = app.status === 'approved';
              const isCancelled = app.status === 'cancelled';

              return (
                <div 
                  key={app.id}
                  className={`p-4 sm:p-5 transition-all flex flex-col lg:flex-row lg:items-center justify-between gap-4 ${
                    isClassic ? 'hover:bg-slate-50/90 bg-white' : 'hover:bg-blue-50/30'
                  }`}
                >
                  {/* Column 1: Candidate Info, Formula Badge & Visit Tag */}
                  <div className="flex items-start gap-3.5 min-w-[300px]">
                    <div className={`w-11 h-11 rounded-2xl text-white font-black text-sm flex items-center justify-center shadow-xs shrink-0 ${
                      isClassic 
                        ? 'bg-slate-900 border border-slate-700' 
                        : 'bg-gradient-to-br from-blue-600 to-indigo-700'
                    }`}>
                      {app.tenantName.slice(0, 2).toUpperCase()}
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-extrabold text-slate-900 text-sm">{app.tenantName}</span>
                        <span className="text-[10px] font-mono text-slate-400">#{app.id}</span>
                        {getStatusPill(app.status)}
                      </div>

                      {/* Formula Badge Tag (Clear distinction LOC vs Classique) */}
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {isClassic ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-slate-900 text-white shadow-xs">
                            <Building2 className="w-3 h-3 text-blue-400" />
                            Formule classique
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-blue-50 text-blue-700 border border-blue-200 shadow-xs">
                            <Sparkles className="w-3 h-3 text-blue-600" />
                            Formule Micro-caution
                          </span>
                        )}

                        {/* If Classic and has visit date, show prominent tag */}
                        {isClassic && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-800 border border-blue-200">
                            <Calendar className="w-3 h-3 text-blue-600" />
                            <span>Visite : {app.preferredVisitDate || 'À planifier'}</span>
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-xs text-slate-600 flex-wrap">
                        <span className="font-medium">{app.tenantProfession}</span>
                        <span>•</span>
                        <span className="font-mono text-slate-700 font-bold">{formatFCFA(app.monthlyIncome)}/mois</span>
                        <span>•</span>
                        <span className={`font-mono text-[11px] font-bold ${
                          rentRatio <= 33 ? 'text-emerald-700' : rentRatio <= 45 ? 'text-amber-700' : 'text-rose-700'
                        }`}>
                          Effort : {rentRatio}%
                        </span>
                      </div>

                      <div className="flex items-center gap-3 text-[11px] text-slate-500 pt-0.5">
                        <span className="flex items-center gap-1">
                          <Phone className="w-3 h-3 text-slate-400" />
                          {app.tenantPhone}
                        </span>
                        <span>•</span>
                        <span>Déposé le {app.appliedAt}</span>
                      </div>
                    </div>
                  </div>

                  {/* Column 2: Target Housing & Formula Details */}
                  <div className={`space-y-1 p-3 rounded-2xl border min-w-[250px] text-xs ${
                    isClassic ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-50/80 border-slate-200/70'
                  }`}>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-slate-400 uppercase">Logement Cible</span>
                      <span className="font-mono font-bold text-blue-700">{formatFCFA(app.monthlyRent)}/m</span>
                    </div>
                    <span className="font-bold text-slate-900 block line-clamp-1">{app.propertyTitle}</span>
                    <span className="text-[11px] text-slate-500 block line-clamp-1">{app.propertyAddress}</span>

                    {/* Specific Details based on formula */}
                    {isClassic ? (
                      <div className="pt-1.5 border-t border-slate-200/80 space-y-1 text-[10px]">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-500">Règlement à l'entrée :</span>
                          <span className="font-mono font-bold text-blue-600">
                            {formatFCFA(app.monthlyRent * 3)} comptant
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-500">Pièces exigées :</span>
                          <span className="font-bold text-emerald-700">CNI uniquement (sans garant)</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-500">Validation bail :</span>
                          <span className="font-bold text-slate-700">Après visite physique des lieux</span>
                        </div>
                      </div>
                    ) : (
                      <div className="pt-1.5 border-t border-slate-200/60 space-y-1 text-[10px]">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-500">Garant Solidaire :</span>
                          <span className={`font-bold ${app.hasGuarantor ? 'text-emerald-700' : 'text-amber-700'}`}>
                            {app.hasGuarantor ? (app.guarantorName || 'Garant Déclaré') : 'Sans garant'}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-500">Garantie LOC J+1 :</span>
                          <span className="font-bold text-indigo-700 font-mono">
                            {formatFCFA(app.monthlyRent * 2)} (Caution avancée)
                          </span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Column 3: Solvency Score or Classic Inspection */}
                  <div className="flex items-center gap-3">
                    {isClassic ? (
                      <div className="p-3 rounded-2xl bg-white border border-slate-200 text-center min-w-[120px] shadow-xs">
                        <span className="text-[9px] text-slate-500 font-bold uppercase block">Procédure Classique</span>
                        <span className="text-xs font-black text-blue-600 block mt-0.5">Visite Obligatoire</span>
                        <span className="text-[10px] font-bold text-emerald-700 block mt-0.5">0 F Frais Dossier</span>
                        <span className="text-[9px] text-slate-400 block mt-0.5">Pièce CNI</span>
                      </div>
                    ) : (
                      <div className="p-3 rounded-2xl bg-blue-50/60 border border-blue-200 text-center min-w-[110px]">
                        <span className="text-[9px] text-slate-500 font-bold uppercase block">Score Solvabilité</span>
                        <span className="text-base font-black text-blue-800 font-mono">{app.kycScore}/100</span>
                        <button
                          type="button"
                          onClick={() => {
                            setCandidateToAdjustScore(app);
                            setAdjustedScoreValue(app.kycScore || 75);
                          }}
                          className="text-[9px] font-bold text-blue-600 hover:text-blue-800 underline mt-0.5 block mx-auto cursor-pointer"
                        >
                          Ajuster score
                        </button>
                      </div>
                    )}

                    {/* Column 4: Quick Action Buttons */}
                    <div className="flex flex-col gap-1.5 min-w-[170px]">
                      {/* View Dossier */}
                      <button
                        type="button"
                        onClick={() => setSelectedCandidateForDetail(app)}
                        className="py-1.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs"
                      >
                        <Eye className="w-3.5 h-3.5 text-slate-600" />
                        <span>{isClassic ? 'Dossier Classique' : 'Examiner Dossier'}</span>
                      </button>

                      {/* If pending: Approve or Reject */}
                      {app.status === 'pending' && (
                        <div className="flex gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              if (onApproveWithAppointment) {
                                onApproveWithAppointment(app);
                              } else {
                                onApproveApplication(app.id);
                              }
                            }}
                            className="flex-1 py-1.5 px-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] flex items-center justify-center gap-1 shadow-xs transition-all"
                          >
                            <Check className="w-3 h-3" />
                            <span>{isClassic ? 'Confirmer' : 'Valider'}</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => onRejectApplication(app.id, [isClassic ? "Demande de visite annulée ou logement indisponible" : "Dossier non retenu par le comité de risque LOC"])}
                            className="py-1.5 px-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-[11px] flex items-center justify-center"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      )}

                      {/* If Approved (not yet signed): Cancel Validation after visit */}
                      {isApprovedOnly && (
                        <button
                          type="button"
                          onClick={() => setCandidateToCancel(app)}
                          className="py-1.5 px-3 rounded-xl bg-orange-50 hover:bg-orange-100 text-orange-800 border border-orange-200 font-bold text-[10px] flex items-center justify-center gap-1 transition-all"
                          title="Annuler la validation du bail après visite si le logement ne répond pas aux attentes du locataire"
                        >
                          <RotateCcw className="w-3 h-3 text-orange-600" />
                          <span>Annuler après visite</span>
                        </button>
                      )}

                      {/* Chat with candidate */}
                      {onOpenChatWithTenant && (
                        <button
                          type="button"
                          onClick={() => onOpenChatWithTenant(app.tenantName, app.tenantPhone)}
                          className="py-1 px-2.5 rounded-xl bg-white border border-slate-200 hover:border-blue-300 text-slate-700 font-semibold text-[10px] flex items-center justify-center gap-1"
                        >
                          <MessageSquare className="w-3 h-3 text-blue-600" />
                          <span>Message Direct</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* MODAL 1: CANCELLATION OF LEASE VALIDATION AFTER VISIT (DEMANDE UTILISATEUR) */}
      {/* ========================================================================= */}
      {candidateToCancel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in text-slate-800">
          <div className="w-full max-w-lg bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4 relative">
            <button
              onClick={() => setCandidateToCancel(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-400 hover:text-slate-800"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2.5 text-orange-600 font-bold text-base border-b border-slate-100 pb-3">
              <RotateCcw className="w-5 h-5" />
              <span>Annuler la validation du bail après visite</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-orange-50 border border-orange-200 text-orange-950 text-xs space-y-1.5">
              <span className="font-bold block">Logement : {candidateToCancel.propertyTitle}</span>
              <span className="block">Locataire : <strong>{candidateToCancel.tenantName}</strong> ({candidateToCancel.tenantPhone})</span>
              <p className="text-[11px] text-orange-900 pt-1 leading-relaxed">
                Cette action annule l'agrément accordé à ce candidat suite à la visite physique (non-conformité ou attentes non satisfaites), libère immédiatement le logement dans le catalogue pour d'autres candidats, et invite le locataire à choisir un autre bien.
              </p>
            </div>

            <div className="space-y-1 text-xs">
              <label className="font-bold text-slate-700 block">
                Motif de l'annulation après visite (communiqué au locataire et bailleur) :
              </label>
              <textarea
                value={cancellationReason}
                onChange={(e) => setCancellationReason(e.target.value)}
                rows={3}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-orange-500"
                placeholder="Indiquez le motif précis de l'annulation..."
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setCandidateToCancel(null)}
                className="py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold"
              >
                Retour
              </button>
              <button
                type="button"
                onClick={handleConfirmCancelLease}
                className="py-2.5 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Confirmer l'annulation du bail</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: DIRECT SOLVENCY SCORE ADJUSTER (AJUSTER DIRECTEMENT LE SCORE)    */}
      {/* ========================================================================= */}
      {candidateToAdjustScore && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in text-slate-800">
          <div className="w-full max-w-sm bg-white border border-slate-200 rounded-3xl p-5 shadow-2xl space-y-4 relative">
            <button
              onClick={() => setCandidateToAdjustScore(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-400 hover:text-slate-800"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2 text-blue-700 font-bold text-sm border-b border-slate-100 pb-2">
              <Sliders className="w-4 h-4" />
              <span>Ajuster le Score de Solvabilité</span>
            </div>

            <div className="space-y-2 text-xs">
              <p className="text-slate-600">
                Ajustez directement la note de solvabilité de <strong>{candidateToAdjustScore.tenantName}</strong> :
              </p>

              <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 text-center space-y-2">
                <span className="text-3xl font-black text-blue-700 font-mono">{adjustedScoreValue}/100</span>
                <input
                  type="range"
                  min="10"
                  max="100"
                  step="5"
                  value={adjustedScoreValue}
                  onChange={(e) => setAdjustedScoreValue(parseInt(e.target.value, 10))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-bold">
                  <span>Risque Élevé (10)</span>
                  <span>Modéré (50)</span>
                  <span>Excellent (100)</span>
                </div>
              </div>
            </div>

            <div className="flex gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setCandidateToAdjustScore(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={handleSaveScoreAdjustment}
                className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs"
              >
                Enregistrer le score
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: FULL CANDIDATE DETAIL MODAL                                      */}
      {/* ========================================================================= */}
      {selectedCandidateForDetail && (
        <CandidateDetailModal
          application={selectedCandidateForDetail}
          onClose={() => setSelectedCandidateForDetail(null)}
          onApprove={(appId) => {
            onApproveApplication(appId);
            setSelectedCandidateForDetail(null);
          }}
          onReject={(appId, reasons, note) => {
            onRejectApplication(appId, reasons, note);
            setSelectedCandidateForDetail(null);
          }}
          onOpenLease={onOpenLeaseModal}
          onOpenChatWithTenant={onOpenChatWithTenant}
          onApproveWithAppointment={onApproveWithAppointment}
          isAdminView={true}
        />
      )}

    </div>
  );
};
