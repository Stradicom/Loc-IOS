import React, { useState, useEffect } from 'react';
import { 
  DollarSign, 
  Sliders, 
  ShieldCheck, 
  TrendingUp, 
  CheckCircle2, 
  Percent, 
  Building2, 
  Users, 
  Wallet, 
  Scale, 
  HelpCircle, 
  Save, 
  RefreshCw, 
  Sparkles, 
  ArrowRight, 
  BadgeCheck, 
  AlertCircle,
  FileSpreadsheet
} from 'lucide-react';
import { formatFCFA } from '../../utils/finance';

export interface FinancialConfig {
  cautionGuaranteeMonths: number; // Default: 2 months
  tenantSpreadMonths: number; // Default: 6 months
  tenantServiceFeePercent: number; // Default: 10%
  landlordCommissionPercent: number; // Default: 3.0%
  applicationFeeAmount: number; // Default: 10000 FCFA
  brokerRetrocessionPercent: number; // Default: 50% of the 3rd month
  reserveFundRatePercent: number; // Default: 5.0%
  payoutDelayHours: number; // Default: 24 (J+1)
}

const DEFAULT_CONFIG: FinancialConfig = {
  cautionGuaranteeMonths: 2,
  tenantSpreadMonths: 6,
  tenantServiceFeePercent: 10,
  landlordCommissionPercent: 3.0,
  applicationFeeAmount: 10000,
  brokerRetrocessionPercent: 50,
  reserveFundRatePercent: 5.0,
  payoutDelayHours: 24,
};

interface AdminFinancialFlowsConfigProps {
  onConfigSaved?: (config: FinancialConfig) => void;
}

export const AdminFinancialFlowsConfig: React.FC<AdminFinancialFlowsConfigProps> = ({
  onConfigSaved,
}) => {
  const [config, setConfig] = useState<FinancialConfig>(() => {
    try {
      const saved = localStorage.getItem('ker_financial_flows_config');
      return saved ? JSON.parse(saved) : DEFAULT_CONFIG;
    } catch {
      return DEFAULT_CONFIG;
    }
  });

  const [simRent, setSimRent] = useState<number>(200000);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);

  const handleSave = () => {
    try {
      localStorage.setItem('ker_financial_flows_config', JSON.stringify(config));
    } catch (e) {
      console.warn('Could not save financial config:', e);
    }
    setSaveSuccess(true);
    onConfigSaved?.(config);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleReset = () => {
    setConfig(DEFAULT_CONFIG);
  };

  // Calculations based on the active simulated rent & config
  const depositGross = simRent * config.cautionGuaranteeMonths; // Ex: 200k * 2 = 400k
  const serviceFeeAmount = Math.round(depositGross * (config.tenantServiceFeePercent / 100)); // Ex: 40k
  const tenantEntryTotal = simRent + Math.round((depositGross + serviceFeeAmount) / config.tenantSpreadMonths) + config.applicationFeeAmount;
  const tenantMonthlySpread = Math.round((depositGross + serviceFeeAmount) / config.tenantSpreadMonths);
  const tenantFullMonthly = simRent + tenantMonthlySpread;

  // Landlord
  const landlordMonthlyCommission = Math.round(simRent * (config.landlordCommissionPercent / 100));
  const landlordNetPayout = simRent - landlordMonthlyCommission;

  // Broker
  const brokerRetrocessionAmount = Math.round(simRent * (config.brokerRetrocessionPercent / 100));

  // LOC Platform Gross Margin per lease
  const kerGrossMargin = serviceFeeAmount + (landlordMonthlyCommission * 12) + config.applicationFeeAmount;
  const kerReserveAllocation = Math.round(depositGross * (config.reserveFundRatePercent / 100));

  return (
    <div className="space-y-5 animate-fade-in text-slate-800">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white flex items-center justify-center font-bold text-xl shadow-sm">
              ⚙️
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-slate-900">
                  Cartographie & Configuration des Flux Financiers LOC
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200 font-mono">
                  Moteur Économique Live
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Paramétrez en temps réel les taux de commission, l'étalement de caution, les frais de gestion et les rétrocessions courtiers.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleReset}
              className="py-2 px-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Valeurs par Défaut</span>
            </button>

            <button
              onClick={handleSave}
              className="py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-black transition-all flex items-center gap-1.5 shadow-sm cursor-pointer hover:scale-105"
            >
              <Save className="w-4 h-4" />
              <span>Enregistrer & Appliquer</span>
            </button>
          </div>
        </div>

        {saveSuccess && (
          <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center gap-2 font-bold animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Configuration financière mise à jour avec succès ! Les paramètres sont actifs sur toute la plateforme.</span>
          </div>
        )}
      </div>

      {/* VISUAL ARCHITECTURE OF FINANCIAL FLOWS */}
      <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
        <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-blue-600" />
          <span>Architecture Dynamique des Flux Financiers</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {/* Card 1: Locataire */}
          <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200 space-y-2 relative">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-blue-700 tracking-wider">Entrée Locataire</span>
              <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-black">1</span>
            </div>
            <p className="text-xs font-bold text-slate-900">Locataire & Candidat</p>
            <ul className="text-[11px] text-slate-600 space-y-1 pt-1 font-medium">
              <li>• Loyer du 1er mois : 100%</li>
              <li>• Caution étalée : {config.cautionGuaranteeMonths} mois / {config.tenantSpreadMonths} mois</li>
              <li>• Frais de service LOC : {config.tenantServiceFeePercent}%</li>
              <li>• Frais de dossier : {formatFCFA(config.applicationFeeAmount)}</li>
            </ul>
          </div>

          {/* Card 2: Trésorerie LOC */}
          <div className="p-4 rounded-2xl bg-indigo-50/70 border border-indigo-200 space-y-2 relative">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-indigo-700 tracking-wider">Hub LOC & Fonds</span>
              <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-black">2</span>
            </div>
            <p className="text-xs font-bold text-slate-900">Trésorerie & Garantie</p>
            <ul className="text-[11px] text-slate-600 space-y-1 pt-1 font-medium">
              <li>• Avance Caution ({config.cautionGuaranteeMonths} mois) versée à J+1</li>
              <li>• Rétention Commission : {config.landlordCommissionPercent}% / mois</li>
              <li>• Dotation Réserve Risque : {config.reserveFundRatePercent}%</li>
              <li>• Gestion Micro-versements Wave/OM</li>
            </ul>
          </div>

          {/* Card 3: Propriétaire / Bailleur */}
          <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-2 relative">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-emerald-700 tracking-wider">Sortie Bailleur</span>
              <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-black">3</span>
            </div>
            <p className="text-xs font-bold text-slate-900">Propriétaire / SCI</p>
            <ul className="text-[11px] text-slate-600 space-y-1 pt-1 font-medium">
              <li>• Caution {config.cautionGuaranteeMonths} mois reçue intégrale à J+1</li>
              <li>• Loyer mensuel net : {(100 - config.landlordCommissionPercent).toFixed(1)}%</li>
              <li>• Virement garanti le 1er du mois</li>
              <li>• Zéro impayé garanti par le Fonds</li>
            </ul>
          </div>

          {/* Card 4: Courtier / Agence */}
          <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-2 relative">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-amber-700 tracking-wider">Partenaire Courtier</span>
              <span className="w-6 h-6 rounded-full bg-amber-600 text-white flex items-center justify-center text-xs font-black">4</span>
            </div>
            <p className="text-xs font-bold text-slate-900">Courtiers & Agences</p>
            <ul className="text-[11px] text-slate-600 space-y-1 pt-1 font-medium">
              <li>• Honoraires de mise en location</li>
              <li>• Rétrocession : {config.brokerRetrocessionPercent}% sur 3ème mois</li>
              <li>• Virement automatisé le 5 du mois</li>
              <li>• Accès tableau de bord dédié</li>
            </ul>
          </div>
        </div>
      </div>

      {/* CONFIGURATION OPTIONS GRID & LIVE SIMULATOR */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left column: Configuration Controls (7 cols) */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-sm space-y-5">
          <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-blue-600" />
            <span>Paramètres Économiques & Barèmes</span>
          </h3>

          <div className="space-y-4 text-xs">
            {/* 1. Caution LOC & Étalement */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-blue-600" />
                  Caution LOC Garantie & Durée d'Amortissement
                </span>
                <span className="font-mono font-bold text-blue-700 bg-blue-100 px-2 py-0.5 rounded-md">
                  {config.cautionGuaranteeMonths} mois caution / {config.tenantSpreadMonths} mois étalement
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="text-[11px] text-slate-500 font-medium block mb-1">
                    Mois de caution garantis au bailleur :
                  </label>
                  <select
                    value={config.cautionGuaranteeMonths}
                    onChange={(e) => setConfig({ ...config, cautionGuaranteeMonths: Number(e.target.value) })}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none"
                  >
                    <option value={1}>1 Mois de Caution</option>
                    <option value={2}>2 Mois de Caution (Standard LOC)</option>
                    <option value={3}>3 Mois de Caution (Prestige)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] text-slate-500 font-medium block mb-1">
                    Durée d'étalement pour le locataire :
                  </label>
                  <select
                    value={config.tenantSpreadMonths}
                    onChange={(e) => setConfig({ ...config, tenantSpreadMonths: Number(e.target.value) })}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none"
                  >
                    <option value={3}>3 Mois</option>
                    <option value={6}>6 Mois (Standard LOC)</option>
                    <option value={9}>9 Mois</option>
                    <option value={12}>12 Mois</option>
                  </select>
                </div>
              </div>
            </div>

            {/* 2. Pourcentage Commission Propriétaire */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-900 block">
                    Commission de Gestion LOC sur Propriétaires
                  </span>
                  <span className="text-[11px] text-slate-500 font-normal">
                    Prélevée mensuellement sur les loyers gérés (Garantie de paiement 100%)
                  </span>
                </div>
                <span className="text-base font-black font-mono text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded-lg">
                  {config.landlordCommissionPercent}%
                </span>
              </div>

              <input
                type="range"
                min="0.0"
                max="15.0"
                step="0.5"
                value={config.landlordCommissionPercent}
                onChange={(e) => setConfig({ ...config, landlordCommissionPercent: Number(e.target.value) })}
                className="w-full accent-emerald-600 bg-slate-200 h-2 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>0.0% (Direct)</span>
                <span>3.0% (Mandat LOC)</span>
                <span>5.0% (Intermédiaire)</span>
                <span>15.0% (Max)</span>
              </div>
            </div>

            {/* 3. Frais de Service Locataire sur Caution */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-900 block">
                    Frais de Service Locataire sur Caution Étalée
                  </span>
                  <span className="text-[11px] text-slate-500 font-normal">
                    Rémunère l'avance de trésorerie LOC et la garantie immédiate
                  </span>
                </div>
                <span className="text-base font-black font-mono text-blue-700 bg-blue-100 px-2.5 py-0.5 rounded-lg">
                  {config.tenantServiceFeePercent}%
                </span>
              </div>

              <input
                type="range"
                min="5"
                max="20"
                step="1"
                value={config.tenantServiceFeePercent}
                onChange={(e) => setConfig({ ...config, tenantServiceFeePercent: Number(e.target.value) })}
                className="w-full accent-blue-600 bg-slate-200 h-2 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>5% (Solidaire)</span>
                <span>10% (Standard LOC)</span>
                <span>15%</span>
                <span>20% (Court terme)</span>
              </div>
            </div>

            {/* 4. Frais de Dossier & Solvabilité */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-900 block">
                    Frais de Dossier & Audit de Solvabilité
                  </span>
                  <span className="text-[11px] text-slate-500 font-normal">
                    Frais unique payé lors de la signature du bail et certification LOC
                  </span>
                </div>
                <span className="text-sm font-black font-mono text-indigo-700 bg-indigo-100 px-2.5 py-0.5 rounded-lg">
                  {formatFCFA(config.applicationFeeAmount)}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                {[
                  { label: 'Gratuit (0 FCFA)', val: 0 },
                  { label: '5 000 FCFA', val: 5000 },
                  { label: '10 000 FCFA (Standard)', val: 10000 },
                  { label: '20 000 FCFA', val: 20000 },
                ].map((item) => (
                  <button
                    key={item.val}
                    type="button"
                    onClick={() => setConfig({ ...config, applicationFeeAmount: item.val })}
                    className={`py-1.5 px-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                      config.applicationFeeAmount === item.val
                        ? 'bg-indigo-50 border-indigo-400 text-indigo-700'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* 5. Rétrocession Courtiers & Dotation Réserve */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="font-bold text-slate-900 block text-xs">
                  Rétrocession Courtiers Partenaires
                </span>
                <span className="text-xs font-mono font-black text-amber-700 block">
                  {config.brokerRetrocessionPercent}% sur 3ème mois
                </span>
                <input
                  type="range"
                  min="20"
                  max="100"
                  step="5"
                  value={config.brokerRetrocessionPercent}
                  onChange={(e) => setConfig({ ...config, brokerRetrocessionPercent: Number(e.target.value) })}
                  className="w-full accent-amber-600 bg-slate-200 h-2 rounded-lg cursor-pointer"
                />
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="font-bold text-slate-900 block text-xs">
                  Dotation Fonds de Réserve
                </span>
                <span className="text-xs font-mono font-black text-emerald-700 block">
                  {config.reserveFundRatePercent}% du montant garanti
                </span>
                <input
                  type="range"
                  min="2.0"
                  max="10.0"
                  step="0.5"
                  value={config.reserveFundRatePercent}
                  onChange={(e) => setConfig({ ...config, reserveFundRatePercent: Number(e.target.value) })}
                  className="w-full accent-emerald-600 bg-slate-200 h-2 rounded-lg cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right column: Live Economic Impact Simulator (5 cols) */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-600" />
              <span>Simulateur d'Impact Économique</span>
            </h3>
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 font-mono">
              Projection Instantanée
            </span>
          </div>

          {/* Simulated rent selector */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-600 font-medium">Loyer Mensuel Test :</span>
              <span className="font-mono font-black text-blue-700 text-sm">{formatFCFA(simRent)}</span>
            </div>
            <input
              type="range"
              min="50000"
              max="1000000"
              step="25000"
              value={simRent}
              onChange={(e) => setSimRent(Number(e.target.value))}
              className="w-full accent-blue-600 bg-slate-200 h-2 rounded-lg cursor-pointer"
            />
          </div>

          {/* Breakdown cards */}
          <div className="space-y-2.5 text-xs">
            {/* Impact Locataire */}
            <div className="p-3.5 rounded-2xl bg-blue-50 border border-blue-200 space-y-1.5">
              <span className="text-[10px] uppercase font-bold text-blue-800 tracking-wider block">
                Impact Candidat Locataire
              </span>
              <div className="flex justify-between items-center text-slate-700">
                <span>Total déboursé à l'entrée :</span>
                <span className="font-mono font-black text-slate-900">{formatFCFA(tenantEntryTotal)}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700">
                <span>Mensualité (Loyer + Caution amortie) :</span>
                <span className="font-mono font-bold text-blue-700">{formatFCFA(tenantFullMonthly)} / mois</span>
              </div>
              <div className="flex justify-between items-center text-[11px] text-slate-500">
                <span>Économie d'effort initial LOC :</span>
                <span className="font-bold text-emerald-700 font-mono">-{formatFCFA((simRent * 3) - tenantEntryTotal)}</span>
              </div>
            </div>

            {/* Impact Propriétaire */}
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1.5">
              <span className="text-[10px] uppercase font-bold text-emerald-800 tracking-wider block">
                Impact Propriétaire / Bailleur
              </span>
              <div className="flex justify-between items-center text-slate-700">
                <span>Caution perçue à J+1 (Garantie LOC) :</span>
                <span className="font-mono font-black text-emerald-800">{formatFCFA(depositGross)}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700">
                <span>Loyer net viré chaque mois ({(100 - config.landlordCommissionPercent).toFixed(1)}%) :</span>
                <span className="font-mono font-bold text-emerald-700">{formatFCFA(landlordNetPayout)} / mois</span>
              </div>
              <div className="flex justify-between items-center text-[11px] text-slate-500">
                <span>Commission gestion LOC ({config.landlordCommissionPercent}%) :</span>
                <span className="font-mono font-bold text-slate-700">-{formatFCFA(landlordMonthlyCommission)} / mois</span>
              </div>
            </div>

            {/* Impact LOC & Courtier */}
            <div className="p-3.5 rounded-2xl bg-indigo-50 border border-indigo-200 space-y-1.5">
              <span className="text-[10px] uppercase font-bold text-indigo-800 tracking-wider block">
                Marge LOC & Rémunération Partenaires
              </span>
              <div className="flex justify-between items-center text-slate-700">
                <span>Marge brute LOC (par bail/an) :</span>
                <span className="font-mono font-black text-indigo-900">{formatFCFA(kerGrossMargin)}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700">
                <span>Rétrocession Courtier ({config.brokerRetrocessionPercent}%) :</span>
                <span className="font-mono font-bold text-amber-700">{formatFCFA(brokerRetrocessionAmount)}</span>
              </div>
              <div className="flex justify-between items-center text-[11px] text-slate-500">
                <span>Provision Réserve de Risque ({config.reserveFundRatePercent}%) :</span>
                <span className="font-mono font-bold text-slate-700">{formatFCFA(kerReserveAllocation)}</span>
              </div>
            </div>
          </div>

          <button
            onClick={handleSave}
            className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-black transition-all flex items-center justify-center gap-2 shadow-sm cursor-pointer hover:scale-[1.02]"
          >
            <Save className="w-4 h-4" />
            <span>Valider & Enregistrer cette Configuration</span>
          </button>
        </div>
      </div>
    </div>
  );
};
