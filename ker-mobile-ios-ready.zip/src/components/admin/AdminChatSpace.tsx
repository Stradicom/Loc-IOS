import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Send, 
  Search, 
  Phone, 
  MessageSquare, 
  CheckCheck, 
  Clock, 
  Paperclip, 
  FileText, 
  Sparkles, 
  UserCheck, 
  Building2, 
  ShieldCheck, 
  AlertTriangle,
  Smile,
  BadgeCheck,
  ChevronRight,
  MoreVertical,
  CheckCircle2,
  Plus,
  UserPlus,
  X,
  User,
  Check
} from 'lucide-react';
import { ChatConversation, ChatMessage, SupportTicket, TenantApplication, LandlordPartner, Property } from '../../types';
import { initialTickets } from '../../data/mockData';
import { sortConversationsByDate, insertNewConversationAtTop, formatConversationBadge } from '../../utils/chatUtils';

export interface PersonSuggestion {
  id: string;
  name: string;
  phone?: string;
  role: 'tenant' | 'landlord';
  propertyTitle?: string;
  tag: string;
  avatarText: string;
}

interface AdminChatSpaceProps {
  conversations: ChatConversation[];
  tickets?: SupportTicket[];
  selectedConversationId?: string | null;
  onSelectConversation?: (id: string) => void;
  onSendMessage: (conversationId: string, text: string) => void;
  onUpdateTicketStatus?: (ticketId: string, newStatus: SupportTicket['status']) => void;
  onStartNewConversation?: (newConv: ChatConversation) => void;
  applications?: TenantApplication[];
  landlords?: LandlordPartner[];
  properties?: Property[];
}

export const AdminChatSpace: React.FC<AdminChatSpaceProps> = ({
  conversations: initialConversationsList,
  tickets: initialTicketsList = initialTickets,
  selectedConversationId: propSelectedConversationId,
  onSelectConversation,
  onSendMessage,
  onUpdateTicketStatus,
  onStartNewConversation,
  applications = [],
  landlords = [],
  properties = [],
}) => {
  const [activeTab, setActiveTab] = useState<'conversations' | 'tickets'>('conversations');
  const [ticketsList, setTicketsList] = useState<SupportTicket[]>(initialTicketsList);
  const [selectedTicketId, setSelectedTicketId] = useState<string>(initialTicketsList[0]?.id || '');
  const [ticketReplyText, setTicketReplyText] = useState('');

  const [conversations, setConversations] = useState<ChatConversation[]>(() =>
    sortConversationsByDate(initialConversationsList)
  );
  const [selectedConversationId, setSelectedConversationId] = useState<string>(
    propSelectedConversationId || initialConversationsList[0]?.id || ''
  );
  const [activeFilter, setActiveFilter] = useState<'all' | 'tenant' | 'landlord' | 'urgent'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  // New Chat Modal state
  const [isNewChatModalOpen, setIsNewChatModalOpen] = useState(false);
  const [newChatName, setNewChatName] = useState('');
  const [newChatRole, setNewChatRole] = useState<'tenant' | 'landlord'>('tenant');
  const [newChatMessage, setNewChatMessage] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [selectedSuggestion, setSelectedSuggestion] = useState<PersonSuggestion | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Sync with prop when external conversation is assigned (e.g. from Gestion Immobilière)
  useEffect(() => {
    if (propSelectedConversationId) {
      setSelectedConversationId(propSelectedConversationId);
      // Ensure the conversation is not hidden by the active filter
      const target = initialConversationsList.find(c => c.id === propSelectedConversationId);
      if (target) {
        if (activeFilter === 'tenant' && target.participantRole !== 'tenant') setActiveFilter('all');
        if (activeFilter === 'landlord' && target.participantRole !== 'landlord') setActiveFilter('all');
        if (activeFilter === 'urgent' && target.priority !== 'urgent' && target.priority !== 'recouvrement') setActiveFilter('all');
      }
    }
  }, [propSelectedConversationId, initialConversationsList]);

  // Sync when prop updates and preserve date & time sorting
  useEffect(() => {
    setConversations(sortConversationsByDate(initialConversationsList));
  }, [initialConversationsList]);

  useEffect(() => {
    if (initialTicketsList && initialTicketsList.length > 0) {
      setTicketsList(initialTicketsList);
    }
  }, [initialTicketsList]);

  // Build list of suggested candidates, tenants, and landlords
  const suggestions = useMemo<PersonSuggestion[]>(() => {
    const list: PersonSuggestion[] = [];
    const seen = new Set<string>();

    // 1. Add candidates and active tenants from applications
    (applications || []).forEach((app) => {
      const key = `${(app.tenantName || '').trim().toLowerCase()}_tenant`;
      if (!seen.has(key) && app.tenantName) {
        seen.add(key);
        const isRented = app.status === 'lease_signed';
        list.push({
          id: `tenant-${app.id}`,
          name: app.tenantName,
          phone: app.tenantPhone,
          role: 'tenant',
          propertyTitle: app.propertyTitle,
          tag: isRented ? 'Locataire Actif' : `Candidat (${app.status === 'approved' ? 'Validé' : 'Dossier en cours'})`,
          avatarText: (app.tenantName || 'L').split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2),
        });
      }
    });

    // 2. Add landlords from landlords partner list
    (landlords || []).forEach((l) => {
      const key = `${(l.name || '').trim().toLowerCase()}_landlord`;
      if (!seen.has(key) && l.name) {
        seen.add(key);
        list.push({
          id: `landlord-${l.id}`,
          name: l.name,
          phone: l.phone,
          role: 'landlord',
          propertyTitle: l.companyName ? `Agence : ${l.companyName}` : undefined,
          tag: l.companyName ? `Agence : ${l.companyName}` : 'Bailleur Partenaire',
          avatarText: (l.name || 'B').split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2),
        });
      }
    });

    // 3. Add landlords from properties list
    (properties || []).forEach((p) => {
      if (p.landlordName) {
        const key = `${p.landlordName.trim().toLowerCase()}_landlord`;
        if (!seen.has(key)) {
          seen.add(key);
          list.push({
            id: `prop-landlord-${p.id}`,
            name: p.landlordName,
            phone: p.landlordPhone,
            role: 'landlord',
            propertyTitle: p.title,
            tag: `Bailleur (${p.neighborhood})`,
            avatarText: (p.landlordName || 'B').split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2),
          });
        }
      }
    });

    // 4. Add participants from existing conversations
    (conversations || []).forEach((c) => {
      const key = `${(c.participantName || '').trim().toLowerCase()}_${c.participantRole}`;
      if (!seen.has(key) && c.participantName) {
        seen.add(key);
        list.push({
          id: `conv-p-${c.id}`,
          name: c.participantName,
          phone: c.participantPhone,
          role: c.participantRole === 'landlord' ? 'landlord' : 'tenant',
          propertyTitle: c.propertyTitle,
          tag: c.participantTag || (c.participantRole === 'landlord' ? 'Bailleur' : 'Locataire'),
          avatarText: c.participantAvatar || (c.participantName || 'KC').slice(0, 2).toUpperCase(),
        });
      }
    });

    return list;
  }, [applications, landlords, properties, conversations]);

  // Filter suggestions by name input and/or role
  const filteredSuggestions = useMemo(() => {
    const q = newChatName.trim().toLowerCase();
    return suggestions.filter((s) => {
      // Must match role if specified
      if (s.role !== newChatRole) return false;
      if (!q) return true;
      return (
        s.name.toLowerCase().includes(q) ||
        (s.phone && s.phone.includes(q)) ||
        (s.propertyTitle && s.propertyTitle.toLowerCase().includes(q))
      );
    });
  }, [suggestions, newChatName, newChatRole]);

  // Always class conversations strictly by date and time (most recent first)
  const sortedConversations = useMemo(() => {
    return sortConversationsByDate(conversations);
  }, [conversations]);

  // Selected conversation
  const currentConversation = useMemo(() => {
    return conversations.find(c => c.id === selectedConversationId) || sortedConversations[0] || conversations[0];
  }, [conversations, selectedConversationId, sortedConversations]);

  // Auto scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentConversation?.messages, isTyping]);

  // Filtered conversations (preserves chronological ranking)
  const filteredConversations = useMemo(() => {
    return sortedConversations.filter((c) => {
      const matchesSearch = c.participantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            c.participantPhone.includes(searchQuery) ||
                            (c.propertyTitle && c.propertyTitle.toLowerCase().includes(searchQuery.toLowerCase()));
      
      if (activeFilter === 'tenant') return matchesSearch && c.participantRole === 'tenant';
      if (activeFilter === 'landlord') return matchesSearch && c.participantRole === 'landlord';
      if (activeFilter === 'urgent') return matchesSearch && (c.priority === 'urgent' || c.priority === 'recouvrement');
      return matchesSearch;
    });
  }, [sortedConversations, searchQuery, activeFilter]);

  const handleCreateNewChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChatName.trim()) return;

    // Check if a conversation already exists with this recipient
    const existingConv = conversations.find(c => {
      const matchName = c.participantName.trim().toLowerCase() === newChatName.trim().toLowerCase();
      const matchPhone = selectedSuggestion?.phone && c.participantPhone && 
        c.participantPhone.replace(/\D/g, '') === selectedSuggestion.phone.replace(/\D/g, '');
      return matchName || matchPhone;
    });

    const initialText = newChatMessage.trim() || 'Bonjour, un administrateur LOC a ouvert cette discussion avec vous.';
    const now = Date.now();
    const timeStr = new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

    if (existingConv) {
      setSelectedConversationId(existingConv.id);
      if (onSelectConversation) onSelectConversation(existingConv.id);
      
      let updatedTarget: ChatConversation;
      if (newChatMessage.trim()) {
        const newMessage: ChatMessage = {
          id: `msg-${now}`,
          senderId: 'admin-1',
          senderName: 'LOC Support & Risque',
          senderRole: 'admin',
          text: newChatMessage.trim(),
          timestamp: timeStr,
          isRead: true,
        };
        updatedTarget = {
          ...existingConv,
          lastMessage: newChatMessage.trim(),
          lastMessageTime: timeStr,
          updatedAt: now,
          messages: [...existingConv.messages, newMessage],
        };
        onSendMessage(existingConv.id, newChatMessage.trim());
      } else {
        updatedTarget = {
          ...existingConv,
          updatedAt: now,
        };
      }
      
      // Placer la discussion tout en haut et classer les autres par date et heure
      setConversations(insertNewConversationAtTop(updatedTarget, conversations));
      if (onStartNewConversation) onStartNewConversation(updatedTarget);

      setIsNewChatModalOpen(false);
      setNewChatName('');
      setNewChatMessage('');
      setSelectedSuggestion(null);
      setShowSuggestions(false);
      return;
    }

    const convId = `conv-${now}`;
    const newConv: ChatConversation = {
      id: convId,
      participantId: selectedSuggestion?.id || `usr-${now}`,
      participantName: newChatName.trim(),
      participantRole: newChatRole,
      participantPhone: selectedSuggestion?.phone || '+221 77 000 00 00',
      participantAvatar: newChatRole === 'landlord' ? '🏢' : '👤',
      participantTag: selectedSuggestion?.tag || (newChatRole === 'landlord' ? 'Bailleur Partenaire' : 'Locataire / Candidat'),
      propertyTitle: selectedSuggestion?.propertyTitle || (newChatRole === 'landlord' ? 'Patrimoine Locatif LOC' : 'Dossier Logement LOC'),
      unreadCount: 0,
      priority: 'normal',
      lastMessage: initialText,
      lastMessageTime: timeStr,
      updatedAt: now,
      createdAt: now,
      messages: [
        {
          id: `msg-${now}`,
          senderId: 'admin-1',
          senderName: 'LOC Support & Risque',
          senderRole: 'admin',
          text: initialText,
          timestamp: timeStr,
          isRead: true,
        },
      ],
    };

    // Mettre la nouvelle discussion tout en haut et classer les autres par date et heure
    const updatedConversations = insertNewConversationAtTop(newConv, conversations);
    setConversations(updatedConversations);
    setSelectedConversationId(convId);
    if (onSelectConversation) {
      onSelectConversation(convId);
    }
    if (onStartNewConversation) {
      onStartNewConversation(newConv);
    }
    setIsNewChatModalOpen(false);
    setNewChatName('');
    setNewChatMessage('');
    setSelectedSuggestion(null);
    setShowSuggestions(false);
  };

  const handleSend = (textToSend?: string) => {
    const content = textToSend || inputText;
    if (!content.trim() || !currentConversation) return;

    const now = Date.now();
    const timeStr = new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

    const newMessage: ChatMessage = {
      id: `msg-${now}`,
      senderId: 'admin-1',
      senderName: 'LOC Support & Risque',
      senderRole: 'admin',
      text: content.trim(),
      timestamp: timeStr,
      isRead: true,
    };

    const updatedConv: ChatConversation = {
      ...currentConversation,
      lastMessage: content.trim(),
      lastMessageTime: timeStr,
      updatedAt: now,
      messages: [...currentConversation.messages, newMessage],
    };

    // Mettre la discussion active tout en haut et classer les autres par date et heure
    const updatedConversations = insertNewConversationAtTop(updatedConv, conversations);

    setConversations(updatedConversations);
    onSendMessage(currentConversation.id, content.trim());
    setInputText('');
    // Réponses automatiques désactivées dans l'espace admin (Règle Métier LOC)
  };

  // Quick message presets
  const quickTemplates = [
    {
      title: 'Relance Loyer Amiable',
      text: 'Bonjour, petit rappel amical concernant votre échéance de loyer ce mois. Vous pouvez effectuer votre micro-versement simplement par Wave ou Orange Money depuis votre espace.',
    },
    {
      title: 'Validation Caution LOC',
      text: 'Félicitations ! Votre demande d\'étalement de caution sur 6 mois a été validée avec succès par le comité de risque LOC.',
    },
    {
      title: 'Versement Garanti Bailleur J1',
      text: 'Bonjour cher partenaire, 100% de la caution du nouveau locataire a été versée avec succès sur votre compte Wave / Bancaire.',
    },
    {
      title: 'Accord Échéancier Apurement',
      text: 'Votre proposition d\'échéancier en 2 tranches a été validée. La première échéance est attendue sous 48h.',
    },
  ];

  return (
    <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm flex flex-col md:flex-row h-[680px] text-slate-800">
      {/* LEFT COLUMN: CONVERSATION LIST */}
      <div className="w-full md:w-80 lg:w-96 border-b md:border-b-0 md:border-r border-slate-200 flex flex-col bg-slate-50 shrink-0">
        {/* Header & Search */}
        <div className="p-3.5 border-b border-slate-200 space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-blue-600" />
              <h3 className="text-sm font-bold text-slate-900">Centre de Conversations</h3>
            </div>
            <button
              onClick={() => setIsNewChatModalOpen(true)}
              className="px-2.5 py-1 rounded-xl text-[11px] font-bold bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-1 shadow-sm transition-all"
              title="Démarrer une nouvelle discussion avec un locataire ou bailleur"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Nouveau</span>
            </button>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Chercher un locataire, bailleur, numéro..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 no-scrollbar">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all whitespace-nowrap ${
                activeFilter === 'all'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
              }`}
            >
              Tous ({conversations.length})
            </button>
            <button
              onClick={() => setActiveFilter('tenant')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all whitespace-nowrap ${
                activeFilter === 'tenant'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
              }`}
            >
              Locataires
            </button>
            <button
              onClick={() => setActiveFilter('landlord')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all whitespace-nowrap ${
                activeFilter === 'landlord'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
              }`}
            >
              Bailleurs
            </button>
            <button
              onClick={() => setActiveFilter('urgent')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all whitespace-nowrap ${
                activeFilter === 'urgent'
                  ? 'bg-red-600 text-white'
                  : 'bg-white text-red-600 hover:text-red-700 border border-slate-200'
              }`}
            >
              Urgents / Impayés
            </button>
          </div>

          {/* Chronological Sorting Indicator */}
          <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1.5 px-0.5 font-medium border-t border-slate-100 mt-1">
            <span>{filteredConversations.length} discussion{filteredConversations.length > 1 ? 's' : ''}</span>
            <span className="flex items-center gap-1 text-blue-600 font-semibold">
              <Clock className="w-2.5 h-2.5" />
              Plus récent en haut
            </span>
          </div>
        </div>

        {/* Conversation List Items */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-200/80 p-1.5 space-y-1">
          {filteredConversations.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-xs">
              Aucune conversation trouvée.
            </div>
          ) : (
            filteredConversations.map((conv, index) => {
              const isSelected = conv.id === currentConversation?.id;
              const timeBadge = formatConversationBadge(conv);
              return (
                <button
                  key={conv.id}
                  id={`chat-conv-item-${conv.id}`}
                  onClick={() => {
                    setSelectedConversationId(conv.id);
                    if (onSelectConversation) onSelectConversation(conv.id);
                  }}
                  className={`w-full text-left p-3 rounded-2xl transition-all flex items-start gap-3 ${
                    isSelected
                      ? 'bg-blue-50/80 border border-blue-200 shadow-sm'
                      : 'hover:bg-white border border-transparent'
                  }`}
                >
                  <div className="relative shrink-0">
                    <div
                      className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-xs shadow-xs overflow-hidden ${
                        conv.participantRole === 'landlord'
                          ? 'bg-blue-100 text-blue-700 border border-blue-200'
                          : conv.priority === 'recouvrement' || conv.priority === 'urgent'
                          ? 'bg-red-100 text-red-700 border border-red-200'
                          : 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                      }`}
                    >
                      {conv.participantAvatar && (conv.participantAvatar.startsWith('http') || conv.participantAvatar.startsWith('data:') || conv.participantAvatar.startsWith('blob:')) && !conv.participantAvatar.includes('unsplash.com') ? (
                        <img src={conv.participantAvatar} alt={conv.participantName} className="w-full h-full object-cover" />
                      ) : (
                        <span>{conv.participantAvatar && !conv.participantAvatar.startsWith('http') ? conv.participantAvatar : (conv.participantName || 'KC').split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}</span>
                      )}
                    </div>
                    {conv.unreadCount > 0 && (
                      <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-blue-600 text-white text-[10px] font-black flex items-center justify-center shadow">
                        {conv.unreadCount}
                      </span>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <h4 className="text-xs font-bold text-slate-900 truncate flex items-center gap-1">
                        {conv.participantName}
                        {conv.participantRole === 'landlord' && (
                          <BadgeCheck className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                        )}
                      </h4>
                      <span
                        className={`text-[10px] shrink-0 font-mono px-1.5 py-0.5 rounded-md flex items-center gap-1 ${
                          timeBadge.isToday
                            ? 'text-blue-700 bg-blue-50 font-bold border border-blue-200/60'
                            : 'text-slate-500 bg-slate-100'
                        }`}
                        title={`Dernier message: ${conv.lastMessageTime}`}
                      >
                        <Clock className="w-2.5 h-2.5 opacity-70" />
                        {timeBadge.label}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-500 truncate mt-0.5">
                      {conv.lastMessage}
                    </p>

                    <div className="flex items-center justify-between mt-1.5">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-200/70 text-slate-700 font-medium">
                          {conv.participantRole === 'landlord' ? '🏢 Bailleur' : '👤 Locataire'}
                        </span>
                        {conv.priority === 'recouvrement' && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-red-100 text-red-800 font-bold border border-red-200">
                            Recouvrement
                          </span>
                        )}
                      </div>
                      {index === 0 && (
                        <span className="text-[8px] font-bold px-1.5 py-0.2 rounded bg-blue-100 text-blue-800 uppercase tracking-wider">
                          Récent
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* RIGHT COLUMN: ACTIVE CHAT VIEW */}
      {currentConversation ? (
        <div className="flex-1 flex flex-col bg-white min-w-0">
          {/* Active Chat Header */}
          <div className="p-3.5 px-4 bg-white border-b border-slate-200 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-3">
              <div
                className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-xs overflow-hidden ${
                  currentConversation.participantRole === 'landlord'
                    ? 'bg-blue-100 text-blue-700 border border-blue-200'
                    : 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                }`}
              >
                {currentConversation.participantAvatar && (currentConversation.participantAvatar.startsWith('http') || currentConversation.participantAvatar.startsWith('data:') || currentConversation.participantAvatar.startsWith('blob:')) && !currentConversation.participantAvatar.includes('unsplash.com') ? (
                  <img src={currentConversation.participantAvatar} alt={currentConversation.participantName} className="w-full h-full object-cover" />
                ) : (
                  <span>{currentConversation.participantAvatar && !currentConversation.participantAvatar.startsWith('http') ? currentConversation.participantAvatar : (currentConversation.participantName || 'KC').split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}</span>
                )}
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="text-sm font-bold text-slate-900">{currentConversation.participantName}</h3>
                  <span className="text-[10px] px-2 py-0.2 rounded-full bg-slate-100 text-slate-600 font-medium">
                    {currentConversation.participantRole === 'landlord' ? 'Bailleur Agréé' : 'Locataire'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 font-medium">{currentConversation.participantPhone} • {currentConversation.propertyTitle}</p>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <a
                href={`tel:${currentConversation.participantPhone.replace(/\s+/g, '')}`}
                className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-all flex items-center gap-1 text-xs font-semibold"
                title="Appeler"
              >
                <Phone className="w-3.5 h-3.5 text-emerald-600" />
                <span className="hidden sm:inline">Appel</span>
              </a>

              <a
                href={`https://wa.me/${currentConversation.participantPhone.replace(/[^0-9]/g, '')}`}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white transition-all flex items-center gap-1 text-xs font-bold shadow-sm"
                title="WhatsApp Direct"
              >
                <Send className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">WhatsApp</span>
              </a>
            </div>
          </div>

          {/* Quick Template Selector Carousel */}
          <div className="p-2 px-3 bg-slate-50 border-b border-slate-200 flex items-center gap-1.5 overflow-x-auto no-scrollbar shrink-0">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1 shrink-0">
              <Sparkles className="w-3 h-3 text-blue-600" />
              Réponses Rapides :
            </span>
            {quickTemplates.map((tpl, i) => (
              <button
                key={i}
                onClick={() => handleSend(tpl.text)}
                className="px-2.5 py-1 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-[11px] font-medium whitespace-nowrap transition-all shrink-0 hover:border-blue-500"
              >
                {tpl.title}
              </button>
            ))}
          </div>

          {/* Messages Feed */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50/50">
            <div className="text-center my-2">
              <span className="px-3 py-1 rounded-full text-[10px] font-semibold bg-white text-slate-500 border border-slate-200">
                Canal de messagerie chiffré LOC • Dossier certifié
              </span>
            </div>

            {currentConversation.messages.map((msg) => {
              const isAdmin = msg.senderRole === 'admin';
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isAdmin ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[85%] sm:max-w-[75%] p-3.5 rounded-2xl space-y-1.5 shadow-sm ${
                      isAdmin
                        ? 'bg-blue-600 text-white rounded-br-none'
                        : 'bg-white border border-slate-200 text-slate-800 rounded-bl-none'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-3 text-[10px] opacity-80 border-b border-white/10 pb-1">
                      <span className="font-bold">{msg.senderName}</span>
                      <span className="font-mono">{msg.timestamp}</span>
                    </div>

                    <p className="text-xs leading-relaxed whitespace-pre-wrap">{msg.text}</p>

                    {/* Attachments if any */}
                    {msg.attachments && msg.attachments.length > 0 && (
                      <div className="pt-1 space-y-1">
                        {msg.attachments.map((att, idx) => (
                          <div
                            key={idx}
                            className="p-2 rounded-xl bg-black/10 border border-white/10 flex items-center justify-between gap-2 text-xs"
                          >
                            <div className="flex items-center gap-1.5 truncate">
                              <FileText className="w-3.5 h-3.5 shrink-0 text-blue-200" />
                              <span className="truncate text-[11px] font-medium">{att.title}</span>
                            </div>
                            <span className="text-[10px] font-bold underline cursor-pointer shrink-0">
                              Voir
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-1 text-[9px] text-slate-400 mt-1 px-1">
                    <span>{msg.timestamp}</span>
                    {isAdmin && <CheckCheck className="w-3 h-3 text-blue-600" />}
                  </div>
                </div>
              );
            })}

            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex items-center gap-2 p-2 rounded-xl bg-white border border-slate-200 w-fit text-slate-500 text-xs shadow-sm">
                <div className="flex gap-1">
                  <span className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce" />
                  <span className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <span className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce [animation-delay:0.4s]" />
                </div>
                <span className="text-[11px]">{currentConversation.participantName} est en train d'écrire...</span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Message Input Bar */}
          <div className="p-3 bg-white border-t border-slate-200 shrink-0">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex items-center gap-2"
            >
              <div className="flex-1 relative">
                <input
                  type="text"
                  placeholder="Écrire un message officiel LOC..."
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2.5 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 pr-10 shadow-sm"
                />
              </div>

              <button
                type="submit"
                disabled={!inputText.trim()}
                className="p-2.5 rounded-2xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold transition-all shadow-sm flex items-center justify-center shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex items-center justify-center text-slate-400 text-xs p-8">
          Sélectionnez une conversation pour afficher l'historique des échanges.
        </div>
      )}

      {/* MODAL: NOUVELLE DISCUSSION */}
      {isNewChatModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-5 max-w-md w-full space-y-4 shadow-2xl animate-scale-in">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-blue-50 text-blue-700">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Nouvelle Discussion</h4>
                  <p className="text-[11px] text-slate-500">Sélectionnez un candidat ou bailleur pour échanger directement</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsNewChatModalOpen(false);
                  setShowSuggestions(false);
                }}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateNewChat} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Rôle du destinataire</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setNewChatRole('tenant');
                      setSelectedSuggestion(null);
                    }}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      newChatRole === 'tenant'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    👤 Locataire / Candidat
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setNewChatRole('landlord');
                      setSelectedSuggestion(null);
                    }}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      newChatRole === 'landlord'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    🏢 Bailleur / Agence
                  </button>
                </div>
              </div>

              {/* NOM COMPLET AVEC AUTO-SUGGESTION */}
              <div className="relative">
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nom du {newChatRole === 'tenant' ? 'candidat ou locataire' : 'bailleur'} *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    placeholder={newChatRole === 'tenant' ? "Rechercher ou saisir un candidat / locataire..." : "Rechercher ou saisir un bailleur / agence..."}
                    value={newChatName}
                    onFocus={() => setShowSuggestions(true)}
                    onChange={(e) => {
                      setNewChatName(e.target.value);
                      setShowSuggestions(true);
                      if (selectedSuggestion && e.target.value !== selectedSuggestion.name) {
                        setSelectedSuggestion(null);
                      }
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-blue-500 pr-8"
                  />
                  {newChatName && (
                    <button
                      type="button"
                      onClick={() => {
                        setNewChatName('');
                        setSelectedSuggestion(null);
                        setShowSuggestions(true);
                      }}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs font-bold"
                    >
                      ✕
                    </button>
                  )}
                </div>

                {/* DROPDOWN DE SUGGESTIONS */}
                {showSuggestions && (
                  <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-slate-200 rounded-2xl shadow-xl max-h-56 overflow-y-auto z-50 p-1 divide-y divide-slate-100">
                    <div className="px-2.5 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between bg-slate-50/70 rounded-lg">
                      <span>Suggestions {newChatRole === 'tenant' ? 'Candidats & Locataires' : 'Bailleurs & Partenaires'}</span>
                      <span className="text-blue-600 font-bold">{filteredSuggestions.length} trouvé(s)</span>
                    </div>
                    {filteredSuggestions.length === 0 ? (
                      <div className="px-3 py-3 text-xs text-slate-500 text-center">
                        Aucun {newChatRole === 'tenant' ? 'candidat' : 'bailleur'} trouvé. Vous pouvez saisir un nom libre.
                      </div>
                    ) : (
                      filteredSuggestions.map((sug) => (
                        <button
                          key={sug.id}
                          type="button"
                          onClick={() => {
                            setNewChatName(sug.name);
                            setNewChatRole(sug.role);
                            setSelectedSuggestion(sug);
                            setShowSuggestions(false);
                          }}
                          className="w-full text-left px-3 py-2 hover:bg-blue-50 rounded-xl transition-colors flex items-center justify-between gap-2 group cursor-pointer"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 ${
                              sug.role === 'landlord' ? 'bg-indigo-100 text-indigo-700' : 'bg-blue-100 text-blue-700'
                            }`}>
                              {sug.avatarText}
                            </div>
                            <div className="min-w-0">
                              <div className="text-xs font-bold text-slate-900 truncate group-hover:text-blue-600">
                                {sug.name}
                              </div>
                              <div className="text-[11px] text-slate-500 truncate flex items-center gap-1.5">
                                {sug.phone && <span>{sug.phone}</span>}
                                {sug.propertyTitle && (
                                  <>
                                    <span>•</span>
                                    <span className="truncate">{sug.propertyTitle}</span>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-lg shrink-0 ${
                            sug.role === 'landlord' ? 'bg-indigo-50 text-indigo-700 border border-indigo-200' : 'bg-blue-50 text-blue-700 border border-blue-200'
                          }`}>
                            {sug.tag}
                          </span>
                        </button>
                      ))
                    )}
                  </div>
                )}

                {/* Badge visuel contextuel si un profil a été sélectionné */}
                {selectedSuggestion && (
                  <div className="mt-2 p-2.5 bg-blue-50/80 border border-blue-200/80 rounded-xl flex items-center justify-between text-xs animate-fade-in">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-6 h-6 rounded-lg bg-blue-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0">
                        <Check className="w-3.5 h-3.5" />
                      </div>
                      <div className="min-w-0">
                        <div className="font-bold text-blue-950 truncate">
                          {selectedSuggestion.name}
                          <span className="text-blue-700 font-normal ml-1.5 text-[11px]">{selectedSuggestion.phone}</span>
                        </div>
                        {selectedSuggestion.propertyTitle && (
                          <div className="text-[10px] text-blue-700/80 truncate">
                            Bien : {selectedSuggestion.propertyTitle}
                          </div>
                        )}
                      </div>
                    </div>
                    <span className="text-[10px] font-bold bg-white text-blue-700 border border-blue-200 px-2 py-0.5 rounded-md shrink-0 shadow-2xs">
                      {selectedSuggestion.tag}
                    </span>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Premier message officiel</label>
                <textarea
                  rows={2}
                  placeholder="Écrivez votre message d'ouverture (ou laissez vide pour le message d'accueil standard)..."
                  value={newChatMessage}
                  onChange={(e) => setNewChatMessage(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-blue-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setIsNewChatModalOpen(false);
                    setShowSuggestions(false);
                  }}
                  className="px-3 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={!newChatName.trim()}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white shadow-sm flex items-center gap-1.5 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Démarrer l'échange</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
