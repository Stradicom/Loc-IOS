import React, { useState, useEffect } from 'react';
import { 
  AlertTriangle, 
  ShieldCheck, 
  Send, 
  Phone, 
  MessageSquare, 
  CheckCircle2, 
  Clock, 
  DollarSign, 
  FileText, 
  Scale, 
  Sparkles, 
  ChevronRight, 
  Filter, 
  Search, 
  ArrowRight,
  TrendingDown,
  Activity,
  Calendar,
  Layers,
  X,
  Printer,
  Download,
  BadgeAlert
} from 'lucide-react';
import { ArrearsCase } from '../../types';
import { formatFCFA } from '../../utils/finance';

interface AdminRecoverySuiteProps {
  arrears: ArrearsCase[];
  onTriggerReminder: (caseId: string, type: 'sms' | 'whatsapp' | 'call') => void;
  onActivateGuarantee: (caseId: string) => void;
  onUpdateArrearsStatus?: (caseId: string, newStatus: ArrearsCase['status'], notes?: string) => void;
}

export const AdminRecoverySuite: React.FC<AdminRecoverySuiteProps> = ({
  arrears: initialArrearsList,
  onTriggerReminder,
  onActivateGuarantee,
  onUpdateArrearsStatus,
}) => {
  const [arrears, setArrears] = useState<ArrearsCase[]>(initialArrearsList);

  useEffect(() => {
    setArrears(initialArrearsList);
  }, [initialArrearsList]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPhase, setSelectedPhase] = useState<'all' | '1' | '2' | '3' | '4' | 'regularise'>('all');
  const [selectedCase, setSelectedCase] = useState<ArrearsCase | null>(null);

  // Action Modals State
  const [activeActionModal, setActiveActionModal] = useState<{
    type: 'whatsapp' | 'sms' | 'installment' | 'formal_notice' | 'bailiff' | 'settle';
    caseItem: ArrearsCase;
  } | null>(null);

  const [customMessage, setCustomMessage] = useState('');
  const [installmentTranches, setInstallmentTranches] = useState(2);
  const [alertSuccess, setAlertSuccess] = useState<string | null>(null);

  // Metrics
  const totalArrearsAmount = arrears.filter(c => c.status !== 'regularise').reduce((sum, c) => sum + c.dueAmount, 0);
  const recoveredAmountThisMonth = arrears.filter(c => c.status === 'regularise').reduce((sum, c) => sum + c.dueAmount, 0);
  const totalCasesCount = arrears.length;
  const regularizedCount = arrears.filter(c => c.status === 'regularise').length;
  const recoverySuccessRate = totalCasesCount > 0 ? (regularizedCount / totalCasesCount) * 100 : 0;
  const guaranteeEngagedAmount = arrears.filter(c => c.status === 'garantie_activee').reduce((sum, c) => sum + c.dueAmount, 0);
  const activeCasesCount = arrears.filter(c => c.status !== 'regularise').length;

  // Filtered cases
  const filteredCases = arrears.filter((c) => {
    const matchesSearch = c.tenantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          c.tenantPhone.includes(searchQuery) ||
                          c.propertyTitle.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (selectedPhase === 'all') return matchesSearch;
    if (selectedPhase === 'regularise') return matchesSearch && c.status === 'regularise';
    if (selectedPhase === '1') return matchesSearch && (c.phase === 1 || c.status === 'relance_douce');
    if (selectedPhase === '2') return matchesSearch && (c.phase === 2 || c.status === 'relance_ferme' || c.status === 'echeancier_accorde');
    if (selectedPhase === '3') return matchesSearch && (c.phase === 3 || c.status === 'garantie_activee');
    if (selectedPhase === '4') return matchesSearch && (c.phase === 4 || c.status === 'contentieux_huissier');
    return matchesSearch;
  });

  const handleOpenActionModal = (type: 'whatsapp' | 'sms' | 'installment' | 'formal_notice' | 'bailiff' | 'settle', caseItem: ArrearsCase) => {
    let defaultMsg = '';
    if (type === 'sms' || type === 'whatsapp') {
      if (caseItem.daysLate <= 5) {
        defaultMsg = `Bonjour ${caseItem.tenantName}. Rappel courtois : votre loyer de ${formatFCFA(caseItem.dueAmount)} pour "${caseItem.propertyTitle}" présente un retard de ${caseItem.daysLate}j. Règlement simple via Wave ou OM sur LOC.`;
      } else {
        defaultMsg = `URGENT LOC : M./Mme ${caseItem.tenantName}, votre loyer (${formatFCFA(caseItem.dueAmount)}) accuse ${caseItem.daysLate}j de retard. Merci de régulariser sous 24h ou de valider un échéancier pour suspendre la procédure.`;
      }
    }
    setCustomMessage(defaultMsg);
    setActiveActionModal({ type, caseItem });
  };

  const handleConfirmAction = () => {
    if (!activeActionModal) return;
    const { type, caseItem } = activeActionModal;

    if (type === 'sms' || type === 'whatsapp') {
      onTriggerReminder(caseItem.id, type);
      setAlertSuccess(`Message de relance envoyé avec succès à ${caseItem.tenantName} !`);
    } else if (type === 'installment') {
      const trancheAmt = Math.round(caseItem.dueAmount / installmentTranches);
      const updatedList = arrears.map(c => {
        if (c.id === caseItem.id) {
          return {
            ...c,
            status: 'echeancier_accorde' as const,
            phase: 2 as const,
            notes: `Échéancier LOC accordé : ${installmentTranches} tranches de ${formatFCFA(trancheAmt)}.`,
            installmentsPlan: {
              totalTranches: installmentTranches,
              amountPerTranche: trancheAmt,
              paidTranches: 0,
            }
          };
        }
        return c;
      });
      setArrears(updatedList);
      if (onUpdateArrearsStatus) onUpdateArrearsStatus(caseItem.id, 'echeancier_accorde', `Échéancier en ${installmentTranches} fois`);
      setAlertSuccess(`Échéancier de ${installmentTranches} tranches validé pour ${caseItem.tenantName} !`);
    } else if (type === 'formal_notice') {
      const updatedList = arrears.map(c => {
        if (c.id === caseItem.id) {
          return {
            ...c,
            status: 'relance_ferme' as const,
            phase: 3 as const,
            notes: `Mise en demeure certifiée générée et transmise par lettre recommandée & SMS légal.`,
          };
        }
        return c;
      });
      setArrears(updatedList);
      setAlertSuccess(`Mise en demeure certifiée émise à l'encontre de ${caseItem.tenantName} !`);
    } else if (type === 'bailiff') {
      const updatedList = arrears.map(c => {
        if (c.id === caseItem.id) {
          return {
            ...c,
            status: 'contentieux_huissier' as const,
            phase: 4 as const,
            notes: `Dossier judiciaire transmis à l'Étude de Me Ndiaye (Huissier de Justice Dakar). Commandement de payer en cours.`,
          };
        }
        return c;
      });
      setArrears(updatedList);
      if (onUpdateArrearsStatus) onUpdateArrearsStatus(caseItem.id, 'contentieux_huissier');
      setAlertSuccess(`Dossier transmis avec succès à l'Étude d'Huissier partenaire (Dakar) !`);
    } else if (type === 'settle') {
      const updatedList = arrears.map(c => {
        if (c.id === caseItem.id) {
          return {
            ...c,
            status: 'regularise' as const,
            dueAmount: 0,
            daysLate: 0,
            notes: `Dossier intégralement soldé et régularisé par Wave / Mobile Money.`,
          };
        }
        return c;
      });
      setArrears(updatedList);
      if (onUpdateArrearsStatus) onUpdateArrearsStatus(caseItem.id, 'regularise');
      setAlertSuccess(`Paiement enregistré ! Le dossier de ${caseItem.tenantName} est désormais 100% régularisé.`);
    }

    setActiveActionModal(null);
    setTimeout(() => setAlertSuccess(null), 4000);
  };

  return (
    <div className="space-y-4 text-slate-800">
      {/* 4-Stage Pipeline Tracker */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Scale className="w-5 h-5 text-red-600" />
            <h3 className="text-sm font-bold text-slate-900">Pipeline de Recouvrement Graduel LOC</h3>
          </div>
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 font-mono">
            {recoverySuccessRate}% de Résolution Amiable
          </span>
        </div>

        {/* 4 Stages Visual Stepper */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 pt-1">
          <div className="p-3 rounded-2xl bg-blue-50 border border-blue-200 space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-blue-900">Phase 1 : Amiable</span>
              <span className="text-[10px] text-blue-700 font-mono font-bold">J+1 à J+5</span>
            </div>
            <p className="text-[11px] text-slate-600">SMS & WhatsApp automatiques de courtoisie avec lien Wave.</p>
          </div>

          <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-amber-900">Phase 2 : Négociation</span>
              <span className="text-[10px] text-amber-700 font-mono font-bold">J+6 à J+15</span>
            </div>
            <p className="text-[11px] text-slate-600">Appel superviseur & proposition d'échéancier en 2-3 micro-tranches.</p>
          </div>

          <div className="p-3 rounded-2xl bg-purple-50 border border-purple-200 space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-purple-900">Phase 3 : Garantie</span>
              <span className="text-[10px] text-purple-700 font-mono font-bold">J+16 à J+30</span>
            </div>
            <p className="text-[11px] text-slate-600">Mise en demeure & indemnisation bailleur via le Fonds 150M FCFA.</p>
          </div>

          <div className="p-3 rounded-2xl bg-red-50 border border-red-200 space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-red-900">Phase 4 : Contentieux</span>
              <span className="text-[10px] text-red-700 font-mono font-bold">J+31+</span>
            </div>
            <p className="text-[11px] text-slate-600">Transmission à l'Étude d'Huissier (Commandement de payer).</p>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 space-y-1 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Encours Total Impayé</span>
          <span className="text-lg sm:text-xl font-black text-red-600 font-mono block">
            {formatFCFA(totalArrearsAmount)}
          </span>
          <span className="text-[10px] text-slate-500 block font-medium">{activeCasesCount} dossiers actifs</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 space-y-1 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Recouvré ce Mois</span>
          <span className="text-lg sm:text-xl font-black text-emerald-700 font-mono block">
            {formatFCFA(recoveredAmountThisMonth)}
          </span>
          <span className="text-[10px] text-emerald-700 block font-semibold">
            {regularizedCount > 0 ? `${regularizedCount} dossier(s) régularisé(s)` : '0 FCFA recouvré'}
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 space-y-1 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Taux de Recouvrement</span>
          <span className="text-lg sm:text-xl font-black text-blue-700 font-mono block">
            {totalCasesCount > 0 ? `${recoverySuccessRate.toFixed(1)}%` : '0%'}
          </span>
          <span className="text-[10px] text-slate-500 block font-medium">
            {totalCasesCount > 0 ? 'Sur dossiers gérés' : 'Aucun dossier à recouvrer'}
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 space-y-1 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Garantie LOC Engagée</span>
          <span className="text-lg sm:text-xl font-black text-purple-700 font-mono block">
            {formatFCFA(guaranteeEngagedAmount)}
          </span>
          <span className="text-[10px] text-purple-800 block font-semibold">
            {arrears.filter(c => c.status === 'garantie_activee').length > 0
              ? `${arrears.filter(c => c.status === 'garantie_activee').length} dossier(s) indemnisé(s)`
              : '0 FCFA engagé'}
          </span>
        </div>
      </div>

      {alertSuccess && (
        <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center justify-between shadow-sm">
          <span className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            {alertSuccess}
          </span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="p-3.5 bg-white border border-slate-200 rounded-2xl flex items-center justify-between gap-3 flex-wrap shadow-sm">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Chercher locataire, téléphone, logement..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 font-medium"
          />
        </div>

        {/* Phase Filter Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setSelectedPhase('all')}
            className={`px-2.5 py-1 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
              selectedPhase === 'all' ? 'bg-blue-600 text-white' : 'bg-slate-50 text-slate-600 hover:text-slate-900 border border-slate-200'
            }`}
          >
            Tous ({arrears.length})
          </button>
          <button
            onClick={() => setSelectedPhase('1')}
            className={`px-2.5 py-1 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
              selectedPhase === '1' ? 'bg-blue-600 text-white' : 'bg-slate-50 text-slate-600 hover:text-slate-900 border border-slate-200'
            }`}
          >
            Phase 1 (J+1 à J+5)
          </button>
          <button
            onClick={() => setSelectedPhase('2')}
            className={`px-2.5 py-1 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
              selectedPhase === '2' ? 'bg-amber-600 text-white' : 'bg-slate-50 text-slate-600 hover:text-slate-900 border border-slate-200'
            }`}
          >
            Phase 2 (J+6 à J+15)
          </button>
          <button
            onClick={() => setSelectedPhase('3')}
            className={`px-2.5 py-1 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
              selectedPhase === '3' ? 'bg-purple-600 text-white' : 'bg-slate-50 text-slate-600 hover:text-slate-900 border border-slate-200'
            }`}
          >
            Phase 3 (Garantie)
          </button>
          <button
            onClick={() => setSelectedPhase('4')}
            className={`px-2.5 py-1 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
              selectedPhase === '4' ? 'bg-red-600 text-white' : 'bg-slate-50 text-slate-600 hover:text-slate-900 border border-slate-200'
            }`}
          >
            Phase 4 (Huissier)
          </button>
          <button
            onClick={() => setSelectedPhase('regularise')}
            className={`px-2.5 py-1 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
              selectedPhase === 'regularise' ? 'bg-emerald-600 text-white' : 'bg-slate-50 text-slate-600 hover:text-slate-900 border border-slate-200'
            }`}
          >
            Régularisés
          </button>
        </div>
      </div>

      {/* Arrears Cases List */}
      <div className="space-y-3">
        {filteredCases.length === 0 ? (
          <div className="p-8 text-center bg-white border border-slate-200 rounded-3xl text-slate-400 text-xs">
            Aucun dossier d'impayé correspondant aux critères de recherche.
          </div>
        ) : (
          filteredCases.map((c) => {
            const isSettled = c.status === 'regularise';
            return (
              <div
                key={c.id}
                className={`bg-white border rounded-3xl p-4 sm:p-5 shadow-sm space-y-3.5 transition-all ${
                  isSettled
                    ? 'border-emerald-200 opacity-80'
                    : c.daysLate > 20
                    ? 'border-red-300 shadow-red-100/50'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                {/* Header info */}
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-slate-900">{c.tenantName}</h4>
                      {isSettled ? (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200 font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          Régularisé
                        </span>
                      ) : (
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${
                            c.daysLate > 15
                              ? 'bg-red-100 text-red-800 border-red-200'
                              : 'bg-amber-100 text-amber-800 border-amber-200'
                          }`}
                        >
                          +{c.daysLate} jours de retard
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-blue-700 font-medium">{c.propertyTitle}</p>
                    <p className="text-[11px] text-slate-500 font-medium">
                      Bailleur : {c.landlordName || 'Mamadou Diop'} • Dernier contact : {c.lastReminderDate} ({c.remindersCount} relances)
                    </p>
                  </div>

                  <div className="text-right">
                    <span
                      className={`text-base sm:text-lg font-black font-mono block ${
                        isSettled ? 'text-emerald-700' : 'text-red-600'
                      }`}
                    >
                      {isSettled ? '0 FCFA' : formatFCFA(c.dueAmount)}
                    </span>
                    <span className="text-[10px] text-slate-400 block font-medium">
                      {isSettled ? 'Solde régularisé' : 'Impayé exigible'}
                    </span>
                  </div>
                </div>

                {/* Notes and Installment Plan Summary if exists */}
                {c.notes && (
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-700 flex items-start gap-2">
                    <BadgeAlert className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                    <span>{c.notes}</span>
                  </div>
                )}

                {/* Complete Action Buttons Grid */}
                {!isSettled && (
                  <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                      Actions Immédiates de Recouvrement
                    </span>

                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-1.5">
                      {/* SMS Doux */}
                      <button
                        onClick={() => handleOpenActionModal('sms', c)}
                        className="p-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-800 text-xs font-semibold flex items-center justify-center gap-1 transition-all"
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-blue-600" />
                        <span>SMS Légal</span>
                      </button>

                      {/* WhatsApp */}
                      <button
                        onClick={() => handleOpenActionModal('whatsapp', c)}
                        className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center justify-center gap-1 transition-all"
                      >
                        <Send className="w-3.5 h-3.5 text-emerald-600" />
                        <span>WhatsApp</span>
                      </button>

                      {/* Échéancier LOC */}
                      <button
                        onClick={() => handleOpenActionModal('installment', c)}
                        className="p-2 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-800 text-xs font-bold flex items-center justify-center gap-1 transition-all"
                      >
                        <Calendar className="w-3.5 h-3.5 text-amber-600" />
                        <span>Échéancier</span>
                      </button>

                      {/* Mise en demeure */}
                      <button
                        onClick={() => handleOpenActionModal('formal_notice', c)}
                        className="p-2 rounded-xl bg-purple-50 hover:bg-purple-100 border border-purple-200 text-purple-800 text-xs font-bold flex items-center justify-center gap-1 transition-all"
                      >
                        <FileText className="w-3.5 h-3.5 text-purple-600" />
                        <span>Mise en Demeure</span>
                      </button>

                      {/* Huissier */}
                      <button
                        onClick={() => handleOpenActionModal('bailiff', c)}
                        className="p-2 rounded-xl bg-red-50 hover:bg-red-100 border border-red-200 text-red-800 text-xs font-bold flex items-center justify-center gap-1 transition-all"
                      >
                        <Scale className="w-3.5 h-3.5 text-red-600" />
                        <span>Huissier</span>
                      </button>

                      {/* Enregistrer Paiement */}
                      <button
                        onClick={() => handleOpenActionModal('settle', c)}
                        className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-1 shadow-sm transition-all"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Régulariser</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* ACTION MODAL */}
      {activeActionModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 w-full max-w-lg shadow-2xl space-y-4 animate-scale-up">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                  {activeActionModal.type === 'sms' || activeActionModal.type === 'whatsapp' ? (
                    <Send className="w-4 h-4" />
                  ) : activeActionModal.type === 'installment' ? (
                    <Calendar className="w-4 h-4 text-amber-600" />
                  ) : activeActionModal.type === 'formal_notice' ? (
                    <FileText className="w-4 h-4 text-purple-600" />
                  ) : activeActionModal.type === 'bailiff' ? (
                    <Scale className="w-4 h-4 text-red-600" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  )}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    {activeActionModal.type === 'sms' && 'Envoi SMS de Relance'}
                    {activeActionModal.type === 'whatsapp' && 'Envoi WhatsApp Officiel'}
                    {activeActionModal.type === 'installment' && 'Accord d\'Échéancier Apurement'}
                    {activeActionModal.type === 'formal_notice' && 'Émission de Mise en Demeure'}
                    {activeActionModal.type === 'bailiff' && 'Transmission Contentieux Huissier'}
                    {activeActionModal.type === 'settle' && 'Enregistrer Règlement / Régularisation'}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">Dossier de {activeActionModal.caseItem.tenantName} ({formatFCFA(activeActionModal.caseItem.dueAmount)})</p>
                </div>
              </div>
              <button
                onClick={() => setActiveActionModal(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content depending on type */}
            {(activeActionModal.type === 'sms' || activeActionModal.type === 'whatsapp') && (
              <div className="space-y-3 text-xs">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Destinataire</label>
                  <input
                    type="text"
                    disabled
                    value={`${activeActionModal.caseItem.tenantName} (${activeActionModal.caseItem.tenantPhone})`}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-700 font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Texte du Message Officiel</label>
                  <textarea
                    rows={4}
                    value={customMessage}
                    onChange={(e) => setCustomMessage(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-xl p-3 text-slate-900 focus:outline-none focus:border-blue-500 leading-relaxed font-medium"
                  />
                </div>

                <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 text-[11px] flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
                  <span>Le message inclut le lien de paiement direct Wave/Orange Money sécurisé de LOC.</span>
                </div>
              </div>
            )}

            {activeActionModal.type === 'installment' && (
              <div className="space-y-3 text-xs">
                <p className="text-slate-700">
                  Afin d'éviter le contentieux et de permettre au locataire de régulariser sa dette de <span className="font-bold text-red-600 font-mono">{formatFCFA(activeActionModal.caseItem.dueAmount)}</span>, LOC autorise un plan d'apurement en micro-tranches.
                </p>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Nombre de Tranches</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setInstallmentTranches(2)}
                      className={`p-3 rounded-2xl border text-center transition-all ${
                        installmentTranches === 2
                          ? 'bg-amber-50 border-amber-500 text-amber-900 font-bold shadow-sm'
                          : 'bg-slate-50 border-slate-200 text-slate-600'
                      }`}
                    >
                      <span className="block text-xs">2 Tranches</span>
                      <span className="font-mono text-sm font-black text-amber-700">
                        {formatFCFA(Math.round(activeActionModal.caseItem.dueAmount / 2))} / tranche
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setInstallmentTranches(3)}
                      className={`p-3 rounded-2xl border text-center transition-all ${
                        installmentTranches === 3
                          ? 'bg-amber-50 border-amber-500 text-amber-900 font-bold shadow-sm'
                          : 'bg-slate-50 border-slate-200 text-slate-600'
                      }`}
                    >
                      <span className="block text-xs">3 Tranches</span>
                      <span className="font-mono text-sm font-black text-amber-700">
                        {formatFCFA(Math.round(activeActionModal.caseItem.dueAmount / 3))} / tranche
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeActionModal.type === 'formal_notice' && (
              <div className="space-y-3 text-xs">
                <div className="p-3 bg-purple-50 border border-purple-200 rounded-2xl space-y-1.5">
                  <span className="font-bold text-purple-900 block">Acte de Mise en Demeure Pré-Contentieuse</span>
                  <p className="text-[11px] text-purple-800">
                    Conformément aux dispositions de la législation sénégalaise sur le bail à usage d'habitation et à l'Acte Uniforme OHADA, cet acte somme le locataire de régler sa dette sous huitaine (8 jours ouvrés).
                  </p>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-700 space-y-1 font-mono">
                  <div>• Réf Dossier : LOC-MED-2026-{activeActionModal.caseItem.id}</div>
                  <div>• Débiteur : {activeActionModal.caseItem.tenantName}</div>
                  <div>• Montant principal : {formatFCFA(activeActionModal.caseItem.dueAmount)}</div>
                  <div>• Délai légal : 8 jours francs</div>
                </div>
              </div>
            )}

            {activeActionModal.type === 'bailiff' && (
              <div className="space-y-3 text-xs">
                <div className="p-3 bg-red-50 border border-red-200 rounded-2xl space-y-1.5">
                  <span className="font-bold text-red-900 block">Transmission à l'Étude d'Huissier Partenaire</span>
                  <p className="text-[11px] text-red-800">
                    Étude de Me Babacar Ndiaye, Huissier de Justice près le Tribunal de Grande Instance Hors Classe de Dakar. Mandat pour délivrance d'un Commandement de Payer aux fins de saisie et/ou résiliation de plein droit.
                  </p>
                </div>
              </div>
            )}

            {activeActionModal.type === 'settle' && (
              <div className="space-y-3 text-xs">
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-1">
                  <span className="font-bold text-emerald-900 block">Confirmation d'Encaissement</span>
                  <p className="text-[11px] text-emerald-800">
                    Cette action clôture le dossier d'impayé et émet automatiquement la quittance de loyer libératoire pour le locataire.
                  </p>
                </div>

                <div className="flex justify-between items-center p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-600 font-medium">Montant recouvré :</span>
                  <span className="font-black text-emerald-700 font-mono text-sm">
                    {formatFCFA(activeActionModal.caseItem.dueAmount)}
                  </span>
                </div>
              </div>
            )}

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setActiveActionModal(null)}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={handleConfirmAction}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm"
              >
                Confirmer l'Action
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
