import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Users, 
  Search, 
  Filter, 
  Plus, 
  CheckCircle2, 
  BadgeCheck, 
  Phone, 
  Mail, 
  Send, 
  FileText, 
  Wallet, 
  TrendingUp, 
  Star, 
  ShieldCheck,
  ChevronRight,
  Eye,
  Sliders,
  DollarSign,
  Download,
  ExternalLink,
  X,
  Pencil,
  Printer,
  Home,
  MapPin,
  Sparkles,
  Share2,
  Copy,
  Check,
  KeyRound
} from 'lucide-react';
import { LandlordPartner, Property } from '../../types';
import { formatFCFA } from '../../utils/finance';

interface AdminLandlordsTrackingProps {
  landlords: LandlordPartner[];
  properties: Property[];
  onAddLandlord: (landlord: LandlordPartner) => void;
  onUpdateLandlord?: (landlord: LandlordPartner) => void;
  onAddPropertyForLandlord?: (property: Property) => void;
  onUpdateProperty?: (property: Property) => void;
  onOpenChatWithLandlord?: (landlord: LandlordPartner) => void;
}

export const AdminLandlordsTracking: React.FC<AdminLandlordsTrackingProps> = ({
  landlords: initialLandlordsList,
  properties,
  onAddLandlord,
  onUpdateLandlord,
  onAddPropertyForLandlord,
  onUpdateProperty,
  onOpenChatWithLandlord,
}) => {
  const [landlords, setLandlords] = useState<LandlordPartner[]>(initialLandlordsList);

  useEffect(() => {
    setLandlords(initialLandlordsList);
  }, [initialLandlordsList]);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<'all' | 'agence' | 'sci' | 'particulier'>('all');
  const [selectedLandlord, setSelectedLandlord] = useState<LandlordPartner | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingLandlord, setEditingLandlord] = useState<LandlordPartner | null>(null);
  
  // Property creation for specific landlord
  const [isAddPropertyModalOpen, setIsAddPropertyModalOpen] = useState(false);
  const [landlordForNewProperty, setLandlordForNewProperty] = useState<LandlordPartner | null>(null);

  // Property editing state
  const [isEditPropertyModalOpen, setIsEditPropertyModalOpen] = useState(false);
  const [editingProperty, setEditingProperty] = useState<Property | null>(null);

  // Statement viewing/download modal
  const [statementLandlord, setStatementLandlord] = useState<LandlordPartner | null>(null);
  const [statementSuccess, setStatementSuccess] = useState<string | null>(null);

  // Form state for adding new landlord
  const [newName, setNewName] = useState('');
  const [newCompany, setNewCompany] = useState('');
  const [newType, setNewType] = useState<'agence' | 'particulier' | 'sci'>('agence');
  const [newPhone, setNewPhone] = useState('+221 77 ');
  const [newEmail, setNewEmail] = useState('');
  const [newPayoutMethod, setNewPayoutMethod] = useState<'Wave Business' | 'Virement CBAO' | 'Virement BOA' | 'Orange Money'>('Wave Business');
  const [newPayoutAccount, setNewPayoutAccount] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('Loc@2026');
  const [createCredentials, setCreateCredentials] = useState(true);
  const [copiedCredentialsId, setCopiedCredentialsId] = useState<string | null>(null);

  // Auto-suggest username when name or company changes
  const handleNameChange = (nameVal: string) => {
    setNewName(nameVal);
    if (!newUsername || newUsername.startsWith('@')) {
      const slug = nameVal.trim().toLowerCase().replace(/[^a-z0-9]/g, '.').replace(/\.+/g, '.').replace(/^\.|\.$/g, '');
      if (slug) setNewUsername(slug);
    }
  };

  // Form state for adding a property directly to a landlord
  const [propTitle, setPropTitle] = useState('');
  const [propType, setPropType] = useState<'studio' | 'appartement' | 'villa' | 'chambre'>('appartement');
  const [propRent, setPropRent] = useState(250000);
  const [propNeighborhood, setPropNeighborhood] = useState('Almadies');
  const [propAddress, setPropAddress] = useState('');
  const [propSurface, setPropSurface] = useState(85);
  const [propBedrooms, setPropBedrooms] = useState(2);
  const [propBathrooms, setPropBathrooms] = useState(2);

  // Get properties associated with a landlord without injecting fake entries
  const getLandlordProperties = (landlord: LandlordPartner): Property[] => {
    return properties.filter(
      p => p.landlordId === landlord.id ||
           p.landlordName?.toLowerCase() === landlord.name.toLowerCase() ||
           (landlord.companyName && p.landlordName?.toLowerCase().includes(landlord.companyName.toLowerCase()))
    );
  };

  // Metrics
  const totalLandlords = landlords.length;
  const totalPropertiesManaged = landlords.reduce((sum, l) => sum + l.totalProperties, 0);
  const totalMonthlyVolume = landlords.reduce((sum, l) => sum + l.totalMonthlyVolume, 0);
  const totalCommissionKer = landlords.reduce((sum, l) => sum + l.commissionEarnedKer, 0);

  // Filtered landlords
  const filteredLandlords = landlords.filter((l) => {
    const lProps = getLandlordProperties(l);
    const hasMatchingProp = lProps.some(p => 
      p.refNumber?.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
      p.id.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
      p.title.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const matchesSearch = l.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (l.companyName && l.companyName.toLowerCase().includes(searchQuery.toLowerCase())) ||
                          l.phone.includes(searchQuery) ||
                          l.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (l.username && l.username.toLowerCase().includes(searchQuery.toLowerCase())) ||
                          hasMatchingProp;
    const matchesType = selectedType === 'all' || l.type === selectedType;
    return matchesSearch && matchesType;
  });

  const handleCreateLandlord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newPhone.trim()) return;

    const initials = newName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() || 'LL';
    const finalUsername = newUsername.trim() || newName.toLowerCase().replace(/[^a-z0-9]/g, '.');
    const finalPassword = newPassword.trim() || 'Loc@2026';

    // Initialisation d'une fiche partenaire avec accès personnels créés par l'admin
    const newPartner: LandlordPartner = {
      id: `landlord-${Date.now()}`,
      name: newName.trim(),
      companyName: newCompany.trim() || undefined,
      type: newType,
      phone: newPhone.trim(),
      email: newEmail.trim() || `${newName.toLowerCase().replace(/\s+/g, '.')}@partenaire.sn`,
      avatarText: initials,
      totalProperties: 0,
      occupiedProperties: 0,
      totalMonthlyVolume: 0,
      commissionEarnedKer: 0,
      payoutMethod: newPayoutMethod,
      payoutAccountNumber: newPayoutAccount.trim() || newPhone.trim(),
      payoutCycle: 'Le 1er du mois (Automatique)',
      verified: true,
      rating: 5.0,
      memberSince: 'Septembre 2026',
      status: 'active',
      username: finalUsername,
      password: finalPassword,
      loginAccessCreated: createCredentials,
    };

    const updated = [newPartner, ...landlords];
    setLandlords(updated);
    onAddLandlord(newPartner);
    setIsAddModalOpen(false);
    
    // Reset form
    setNewName('');
    setNewCompany('');
    setNewPhone('+221 77 ');
    setNewEmail('');
    setNewPayoutAccount('');
    setNewUsername('');
    setNewPassword('Loc@2026');

    setStatementSuccess(`Bailleur "${newPartner.name}" créé avec succès ! Identifiants d'accès : ${finalUsername} / ${finalPassword}`);
    setTimeout(() => setStatementSuccess(null), 5000);
  };

  const handleOpenEdit = (landlord: LandlordPartner) => {
    setEditingLandlord({ ...landlord });
    setIsEditModalOpen(true);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingLandlord) return;

    const updated = landlords.map(l => l.id === editingLandlord.id ? editingLandlord : l);
    setLandlords(updated);
    if (selectedLandlord?.id === editingLandlord.id) {
      setSelectedLandlord(editingLandlord);
    }
    if (onUpdateLandlord) {
      onUpdateLandlord(editingLandlord);
    }
    setIsEditModalOpen(false);
    setStatementSuccess(`Dossier de ${editingLandlord.name} mis à jour avec succès.`);
    setTimeout(() => setStatementSuccess(null), 3000);
  };

  const handleOpenAddProperty = (landlord: LandlordPartner) => {
    setLandlordForNewProperty(landlord);
    setPropTitle(`Appartement F3 Standing - ${landlord.name.split(' ')[0]}`);
    setPropRent(250000);
    setPropNeighborhood('Almadies');
    setPropAddress('Route des Almadies, Dakar');
    setPropSurface(85);
    setPropBedrooms(2);
    setPropBathrooms(2);
    setIsAddPropertyModalOpen(true);
  };

  const handleCreatePropertyForLandlord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!landlordForNewProperty || !propTitle.trim()) return;

    const refNum = `LOC-2026-${Math.floor(3000 + Math.random() * 6900)}`;
    const newProp: Property = {
      id: `prop-ll-${Date.now()}`,
      refNumber: refNum,
      title: propTitle.trim(),
      type: propType,
      typeLabel: propType === 'appartement' ? 'Appartement' : propType === 'studio' ? 'Studio' : propType === 'villa' ? 'Villa' : 'Chambre',
      categoryDesc: `${propType.toUpperCase()} Standing sous gestion LOC`,
      city: 'Dakar',
      neighborhood: propNeighborhood,
      address: propAddress || `${propNeighborhood}, Dakar`,
      monthlyRent: propRent,
      depositMonths: 2,
      brokerFeeMonths: 1,
      totalPackageMonths: 3,
      chargesIncluded: true,
      surface: propSurface,
      rooms: propBedrooms,
      bathrooms: propBathrooms,
      furnished: false,
      images: [
        'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1000&q=80',
        'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1000&q=80'
      ],
      description: `Logement de standing géré pour le compte de ${landlordForNewProperty.name}. Éligible garantie LOC et étalement de caution.`,
      amenities: ['Climatisation', 'Groupe Électrogène', 'Gardiennage 24/7', 'Réservoir d\'eau', 'Parking'],
      landlordId: landlordForNewProperty.id,
      landlordName: landlordForNewProperty.name,
      landlordPhone: landlordForNewProperty.phone,
      verifiedLandlord: true,
      isAvailable: true,
      approvalStatus: 'approved',
      createdAt: 'Aujourd\'hui',
    };

    // Update landlord stats with 3% platform commission
    const updatedLandlord: LandlordPartner = {
      ...landlordForNewProperty,
      totalProperties: landlordForNewProperty.totalProperties + 1,
      totalMonthlyVolume: landlordForNewProperty.totalMonthlyVolume + propRent,
      commissionEarnedKer: Math.round((landlordForNewProperty.totalMonthlyVolume + propRent) * 0.03),
    };

    const updatedList = landlords.map(l => l.id === updatedLandlord.id ? updatedLandlord : l);
    setLandlords(updatedList);
    if (selectedLandlord?.id === updatedLandlord.id) {
      setSelectedLandlord(updatedLandlord);
    }
    if (onUpdateLandlord) {
      onUpdateLandlord(updatedLandlord);
    }
    if (onAddPropertyForLandlord) {
      onAddPropertyForLandlord(newProp);
    }

    setIsAddPropertyModalOpen(false);
    setStatementSuccess(`Nouveau bien "${propTitle}" rattaché avec succès à ${landlordForNewProperty.name} !`);
    setTimeout(() => setStatementSuccess(null), 3500);
  };

  // Property editing handlers
  const handleOpenEditProperty = (prop: Property) => {
    setEditingProperty({ ...prop });
    setIsEditPropertyModalOpen(true);
  };

  const handleSavePropertyEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProperty) return;

    if (onUpdateProperty) {
      onUpdateProperty(editingProperty);
    }

    // Refresh landlord stats if landlord is selected
    if (selectedLandlord) {
      const landlordProps = properties.map(p => p.id === editingProperty.id ? editingProperty : p)
        .filter(p => p.landlordId === selectedLandlord.id || p.landlordName?.toLowerCase() === selectedLandlord.name.toLowerCase());
      const newVolume = landlordProps.reduce((sum, p) => sum + p.monthlyRent, 0);
      const updatedLandlord: LandlordPartner = {
        ...selectedLandlord,
        totalMonthlyVolume: newVolume,
        commissionEarnedKer: Math.round(newVolume * 0.03),
      };
      setLandlords(prev => prev.map(l => l.id === updatedLandlord.id ? updatedLandlord : l));
      setSelectedLandlord(updatedLandlord);
      if (onUpdateLandlord) {
        onUpdateLandlord(updatedLandlord);
      }
    }

    setIsEditPropertyModalOpen(false);
    setStatementSuccess(`Bien immobilier "${editingProperty.title}" modifié avec succès !`);
    setTimeout(() => setStatementSuccess(null), 3500);
  };

  return (
    <div className="space-y-4 text-slate-800 animate-fade-in">
      {/* KPI Top Banner */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 space-y-1 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Bailleurs & Agences</span>
          <span className="text-lg sm:text-xl font-black text-slate-900 font-mono block">
            {totalLandlords} Partenaires
          </span>
          <span className="text-[10px] text-emerald-700 block font-semibold">100% Agréés & Vérifiés</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 space-y-1 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Parc Sous Mandat</span>
          <span className="text-lg sm:text-xl font-black text-blue-700 font-mono block">
            {totalPropertiesManaged} Logements
          </span>
          <span className="text-[10px] text-slate-500 block font-medium">Taux d'occupation : 88%</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 space-y-1 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Volume Mensuel Géré</span>
          <span className="text-lg sm:text-xl font-black text-emerald-700 font-mono block">
            {formatFCFA(totalMonthlyVolume)}
          </span>
          <span className="text-[10px] text-slate-500 block font-medium">Reversements sécurisés</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 space-y-1 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Commissions LOC Baux</span>
          <span className="text-lg sm:text-xl font-black text-indigo-700 font-mono block">
            {formatFCFA(totalCommissionKer)}
          </span>
          <span className="text-[10px] text-indigo-800 block font-semibold">3% sur baux gérés propriétaires</span>
        </div>
      </div>

      {statementSuccess && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center justify-between shadow-sm animate-fade-in">
          <span className="flex items-center gap-2 font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            {statementSuccess}
          </span>
        </div>
      )}

      {/* Action and Filter Bar */}
      <div className="p-3.5 bg-white border border-slate-200 rounded-2xl flex items-center justify-between gap-3 flex-wrap shadow-sm">
        <div className="flex items-center gap-2 flex-1 min-w-[220px]">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Rechercher par nom, agence, téléphone, email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 font-medium"
            />
          </div>

          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value as any)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-700 focus:outline-none font-medium"
          >
            <option value="all">Toutes structures</option>
            <option value="agence">Agences Immobilières</option>
            <option value="sci">Sociétés Civiles (SCI)</option>
            <option value="particulier">Bailleurs Particuliers</option>
          </select>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="py-2 px-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer hover:scale-105"
        >
          <Plus className="w-4 h-4" />
          <span>Nouveau Bailleur / Agence</span>
        </button>
      </div>

      {/* Landlords Directory Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {filteredLandlords.map((landlord) => {
          const landlordProps = getLandlordProperties(landlord);

          return (
            <div
              key={landlord.id}
              className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 shadow-sm space-y-4 hover:border-slate-300 transition-all"
            >
              {/* Header */}
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-700 border border-blue-200 flex items-center justify-center font-black text-sm shadow-sm">
                    {landlord.avatarText}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h3 className="text-sm font-bold text-slate-900">{landlord.name}</h3>
                      {landlord.verified && (
                        <BadgeCheck className="w-4 h-4 text-blue-600" title="Bailleur Agréé LOC" />
                      )}
                    </div>
                    <p className="text-xs text-slate-500 font-medium">{landlord.companyName || 'Bailleur Privé'}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleOpenEdit(landlord)}
                    className="p-1.5 rounded-xl bg-slate-100 hover:bg-blue-50 text-slate-600 hover:text-blue-700 transition-all"
                    title="Modifier le dossier bailleur"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                  </button>

                  <div className="flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200 text-amber-800 text-xs font-bold font-mono">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                    {landlord.rating}
                  </div>
                </div>
              </div>

              {/* Metrics Breakdown */}
              <div className="grid grid-cols-3 gap-2 p-3 rounded-2xl bg-slate-50 border border-slate-200 text-center text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 block">Biens Gérés</span>
                  <span className="font-extrabold text-slate-900 font-mono">{landlord.totalProperties}</span>
                  <span className="text-[9px] text-emerald-700 block font-semibold">{landlord.occupiedProperties} occupés</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Volume Mensuel</span>
                  <span className="font-extrabold text-emerald-700 font-mono">{formatFCFA(landlord.totalMonthlyVolume)}</span>
                  <span className="text-[9px] text-slate-500 block">100% garanti</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Mode de Virement</span>
                  <span className="font-semibold text-blue-800 truncate block text-[11px]">
                    {landlord.payoutMethod}
                  </span>
                  <span className="text-[9px] text-slate-400 block">Le 1er du mois</span>
                </div>
              </div>

              {/* Quick Biens Gérés Preview */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-slate-700 flex items-center gap-1">
                    <Home className="w-3 h-3 text-blue-600" />
                    Biens rattachés ({landlordProps.length}) :
                  </span>
                  <button
                    onClick={() => handleOpenAddProperty(landlord)}
                    className="text-blue-600 hover:text-blue-800 font-bold flex items-center gap-0.5 text-[10px] cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Ajouter un bien</span>
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {landlordProps.slice(0, 2).map((p) => (
                    <span key={p.id} className="text-[10px] px-2 py-0.5 rounded-lg bg-slate-100 text-slate-700 border border-slate-200 truncate max-w-[200px]">
                      {p.title} ({formatFCFA(p.monthlyRent)})
                    </span>
                  ))}
                  {landlordProps.length > 2 && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded-lg bg-blue-50 text-blue-700 font-bold">
                      +{landlordProps.length - 2} autres
                    </span>
                  )}
                </div>
              </div>

              {/* Credentials badge */}
              <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-200 text-[11px]">
                <div className="flex items-center gap-1.5 font-mono text-slate-700 truncate">
                  <KeyRound className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span className="text-slate-500">Accès:</span>
                  <span className="font-bold text-slate-900">{landlord.username || landlord.email.split('@')[0]}</span>
                  <span className="text-slate-400">/</span>
                  <span className="text-slate-600">{landlord.password || 'Loc@2026'}</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const u = landlord.username || landlord.email.split('@')[0];
                    const p = landlord.password || 'Loc@2026';
                    navigator.clipboard?.writeText(`Identifiant LOC : ${u}\nMot de passe : ${p}\nLien : https://loc.sn`);
                    setCopiedCredentialsId(landlord.id);
                    setTimeout(() => setCopiedCredentialsId(null), 2500);
                  }}
                  className="px-2 py-1 rounded-lg bg-white hover:bg-blue-50 border border-slate-200 text-blue-700 font-bold text-[10px] flex items-center gap-1 transition-all cursor-pointer shrink-0"
                >
                  {copiedCredentialsId === landlord.id ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-600" />
                      <span className="text-emerald-700">Copié !</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3 text-slate-400" />
                      <span>Copier</span>
                    </>
                  )}
                </button>
              </div>

              {/* Action Bar */}
              <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-xs gap-2">
                <span className="text-[11px] text-slate-500 truncate font-mono">
                  {landlord.phone}
                </span>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => setStatementLandlord(landlord)}
                    className="py-1.5 px-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold flex items-center gap-1 transition-all cursor-pointer"
                    title="Consulter et Télécharger le Relevé de Gestion"
                  >
                    <FileText className="w-3.5 h-3.5 text-blue-600" />
                    <span>Relevé</span>
                  </button>

                  <button
                    onClick={() => setSelectedLandlord(landlord)}
                    className="py-1.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold flex items-center gap-1 shadow-sm transition-all cursor-pointer hover:scale-105"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Dossier & Biens</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* MODAL 1: ADD NEW LANDLORD */}
      {/* ========================================================================= */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 w-full max-w-lg shadow-2xl space-y-4 animate-scale-up">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Nouveau Partenaire Bailleur</h3>
                  <p className="text-xs text-slate-500 font-medium">Intégration d'une agence ou d'un propriétaire agréé</p>
                </div>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateLandlord} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Nom du Responsable *</label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: Babacar Thiam"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-blue-500 font-medium"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Raison Sociale / Agence</label>
                  <input
                    type="text"
                    placeholder="Ex: Thiam Immobilier SARL"
                    value={newCompany}
                    onChange={(e) => setNewCompany(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-blue-500 font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Type de Structure</label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none font-medium"
                  >
                    <option value="agence">Agence Immobilière Agréée</option>
                    <option value="sci">Société Civile (SCI)</option>
                    <option value="particulier">Bailleur Particulier</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Téléphone Principal *</label>
                  <input
                    type="text"
                    required
                    placeholder="+221 77 000 00 00"
                    value={newPhone}
                    onChange={(e) => setNewPhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-mono focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Email Professionnel</label>
                <input
                  type="email"
                  placeholder="contact@agence.sn"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-blue-500 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Mode de Reversement</label>
                  <select
                    value={newPayoutMethod}
                    onChange={(e) => setNewPayoutMethod(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 focus:outline-none font-medium"
                  >
                    <option value="Wave Business">Wave Business</option>
                    <option value="Virement CBAO">Virement CBAO</option>
                    <option value="Virement BOA">Virement BOA</option>
                    <option value="Orange Money">Orange Money</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Coordonnées / N° Compte</label>
                  <input
                    type="text"
                    placeholder="N° Mobile Money ou IBAN"
                    value={newPayoutAccount}
                    onChange={(e) => setNewPayoutAccount(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-mono focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              {/* SECTION: ACCÈS PERSONNELS CRÉÉS PAR L'ADMIN */}
              <div className="p-3.5 rounded-2xl bg-blue-50/60 border border-blue-200 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <KeyRound className="w-4 h-4 text-blue-600" />
                    <span className="text-xs font-bold text-slate-900">Identifiants & Accès Personnels</span>
                  </div>
                  <span className="text-[10px] bg-blue-600 text-white font-bold px-2 py-0.5 rounded-full">
                    Défini par l'Admin
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-700 block mb-1">Identifiant / Nom d'utilisateur *</label>
                    <input
                      type="text"
                      required
                      placeholder="ex: teranga.immo ou m.diop"
                      value={newUsername}
                      onChange={(e) => setNewUsername(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono font-medium focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-700 block mb-1">Mot de passe personnel *</label>
                    <input
                      type="text"
                      required
                      placeholder="ex: Loc@2026"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono font-bold focus:outline-none focus:border-blue-500"
                    />
                  </div>
                </div>
                <p className="text-[11px] text-slate-600 leading-tight">
                  Ces accès permettront au bailleur/agence de se connecter directement à son tableau de bord LOC et de suivre ses reversements.
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-sm cursor-pointer hover:scale-105"
                >
                  Enregistrer Partenaire
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: EDIT LANDLORD PROFILE */}
      {/* ========================================================================= */}
      {isEditModalOpen && editingLandlord && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 w-full max-w-lg shadow-2xl space-y-4 animate-scale-up">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                  <Pencil className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Modifier le Dossier Bailleur</h3>
                  <p className="text-xs text-slate-500 font-medium">Mise à jour des coordonnées et paramètres de virement</p>
                </div>
              </div>
              <button
                onClick={() => setIsEditModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Nom / Responsable *</label>
                  <input
                    type="text"
                    required
                    value={editingLandlord.name}
                    onChange={(e) => setEditingLandlord({ ...editingLandlord, name: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-medium"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Raison Sociale / Agence</label>
                  <input
                    type="text"
                    value={editingLandlord.companyName || ''}
                    onChange={(e) => setEditingLandlord({ ...editingLandlord, companyName: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Téléphone *</label>
                  <input
                    type="text"
                    required
                    value={editingLandlord.phone}
                    onChange={(e) => setEditingLandlord({ ...editingLandlord, phone: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Email</label>
                  <input
                    type="email"
                    value={editingLandlord.email}
                    onChange={(e) => setEditingLandlord({ ...editingLandlord, email: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Canal de Virement</label>
                  <select
                    value={editingLandlord.payoutMethod}
                    onChange={(e) => setEditingLandlord({ ...editingLandlord, payoutMethod: e.target.value as any })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-medium"
                  >
                    <option value="Wave Business">Wave Business</option>
                    <option value="Virement CBAO">Virement CBAO</option>
                    <option value="Virement BOA">Virement BOA</option>
                    <option value="Orange Money">Orange Money</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">N° Compte / IBAN</label>
                  <input
                    type="text"
                    value={editingLandlord.payoutAccountNumber}
                    onChange={(e) => setEditingLandlord({ ...editingLandlord, payoutAccountNumber: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-mono"
                  />
                </div>
              </div>

              {/* Accès Personnels du Bailleur */}
              <div className="p-3.5 rounded-2xl bg-blue-50/60 border border-blue-200 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <KeyRound className="w-4 h-4 text-blue-600" />
                    <span className="text-xs font-bold text-slate-900">Identifiants & Accès Personnels</span>
                  </div>
                  <span className="text-[10px] bg-blue-600 text-white font-bold px-2 py-0.5 rounded-full">
                    Géré par l'Admin
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-700 block mb-1">Identifiant / Nom d'utilisateur</label>
                    <input
                      type="text"
                      placeholder="ex: teranga.immo"
                      value={editingLandlord.username || ''}
                      onChange={(e) => setEditingLandlord({ ...editingLandlord, username: e.target.value })}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono font-medium focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-700 block mb-1">Mot de passe personnel</label>
                    <input
                      type="text"
                      placeholder="ex: Loc@2026"
                      value={editingLandlord.password || ''}
                      onChange={(e) => setEditingLandlord({ ...editingLandlord, password: e.target.value })}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono font-bold focus:outline-none focus:border-blue-500"
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-sm cursor-pointer hover:scale-105"
                >
                  Sauvegarder les Modifications
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: ADD PROPERTY DIRECTLY FOR A LANDLORD */}
      {/* ========================================================================= */}
      {isAddPropertyModalOpen && landlordForNewProperty && (
        <div className="fixed inset-0 z-[80] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 w-full max-w-lg shadow-2xl space-y-4 animate-scale-up max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                  <Home className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Rattacher un Bien Immobilier</h3>
                  <p className="text-xs text-slate-500 font-medium">Bailleur : <strong>{landlordForNewProperty.name}</strong></p>
                </div>
              </div>
              <button
                onClick={() => setIsAddPropertyModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePropertyForLandlord} className="space-y-3 text-xs">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Titre de l'Annonce / Logement *</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Appartement F3 Standing Vue Mer"
                  value={propTitle}
                  onChange={(e) => setPropTitle(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-medium focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Type de Bien</label>
                  <select
                    value={propType}
                    onChange={(e) => setPropType(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-medium"
                  >
                    <option value="appartement">Appartement</option>
                    <option value="studio">Studio</option>
                    <option value="villa">Villa</option>
                    <option value="chambre">Chambre</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Loyer Mensuel (FCFA) *</label>
                  <input
                    type="number"
                    required
                    min={30000}
                    step={5000}
                    value={propRent}
                    onChange={(e) => setPropRent(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-mono font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Quartier</label>
                  <select
                    value={propNeighborhood}
                    onChange={(e) => setPropNeighborhood(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-medium"
                  >
                    <option value="Almadies">Almadies</option>
                    <option value="Mermoz">Mermoz</option>
                    <option value="Ngor">Ngor</option>
                    <option value="Ouakam">Ouakam</option>
                    <option value="Plateau">Plateau</option>
                    <option value="Point E">Point E</option>
                    <option value="Yoff">Yoff</option>
                    <option value="Fann Résidence">Fann Résidence</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Adresse Précise</label>
                  <input
                    type="text"
                    placeholder="Ex: Rue 14, près de la pharmacie"
                    value={propAddress}
                    onChange={(e) => setPropAddress(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Surface (m²)</label>
                  <input
                    type="number"
                    value={propSurface}
                    onChange={(e) => setPropSurface(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-slate-900 font-medium"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Chambres</label>
                  <input
                    type="number"
                    value={propBedrooms}
                    onChange={(e) => setPropBedrooms(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-slate-900 font-medium"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Salles de bain</label>
                  <input
                    type="number"
                    value={propBathrooms}
                    onChange={(e) => setPropBathrooms(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-slate-900 font-medium"
                  />
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-blue-50 border border-blue-200 text-blue-900 text-[11px] flex items-center gap-2 font-medium">
                <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Ce bien bénéficiera automatiquement de la caution LOC garantie ({formatFCFA(propRent * 2)}) débloquée à la signature.</span>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddPropertyModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-sm cursor-pointer hover:scale-105"
                >
                  Ajouter le Bien au Mandat
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3B: EDIT PROPERTY UNDER MANAGEMENT */}
      {/* ========================================================================= */}
      {isEditPropertyModalOpen && editingProperty && (
        <div className="fixed inset-0 z-[80] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 w-full max-w-lg shadow-2xl space-y-4 animate-scale-up max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                  <Pencil className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Modifier le Bien sous Mandat</h3>
                  <p className="text-xs text-slate-500 font-medium">Réf : <strong>{editingProperty.id}</strong></p>
                </div>
              </div>
              <button
                onClick={() => setIsEditPropertyModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSavePropertyEdit} className="space-y-3 text-xs">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Titre de l'Annonce / Logement *</label>
                <input
                  type="text"
                  required
                  value={editingProperty.title}
                  onChange={(e) => setEditingProperty({ ...editingProperty, title: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-medium focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Type de Bien</label>
                  <select
                    value={editingProperty.type}
                    onChange={(e) => setEditingProperty({ ...editingProperty, type: e.target.value as any, typeLabel: e.target.value === 'appartement' ? 'Appartement' : e.target.value === 'studio' ? 'Studio' : e.target.value === 'villa' ? 'Villa' : 'Chambre' })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-medium"
                  >
                    <option value="appartement">Appartement</option>
                    <option value="studio">Studio</option>
                    <option value="villa">Villa</option>
                    <option value="chambre">Chambre</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Loyer Mensuel (FCFA) *</label>
                  <input
                    type="number"
                    required
                    min={30000}
                    step={5000}
                    value={editingProperty.monthlyRent}
                    onChange={(e) => setEditingProperty({ ...editingProperty, monthlyRent: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-mono font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Quartier</label>
                  <select
                    value={editingProperty.neighborhood}
                    onChange={(e) => setEditingProperty({ ...editingProperty, neighborhood: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-medium"
                  >
                    <option value="Almadies">Almadies</option>
                    <option value="Mermoz">Mermoz</option>
                    <option value="Ngor">Ngor</option>
                    <option value="Ouakam">Ouakam</option>
                    <option value="Plateau">Plateau</option>
                    <option value="Point E">Point E</option>
                    <option value="Yoff">Yoff</option>
                    <option value="Fann Résidence">Fann Résidence</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Adresse Précise</label>
                  <input
                    type="text"
                    value={editingProperty.address}
                    onChange={(e) => setEditingProperty({ ...editingProperty, address: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Surface (m²)</label>
                  <input
                    type="number"
                    value={editingProperty.surface}
                    onChange={(e) => setEditingProperty({ ...editingProperty, surface: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-slate-900 font-medium"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Chambres</label>
                  <input
                    type="number"
                    value={editingProperty.rooms || 1}
                    onChange={(e) => setEditingProperty({ ...editingProperty, rooms: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-slate-900 font-medium"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Salles de bain</label>
                  <input
                    type="number"
                    value={editingProperty.bathrooms || 1}
                    onChange={(e) => setEditingProperty({ ...editingProperty, bathrooms: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-slate-900 font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Disponibilité</label>
                  <select
                    value={editingProperty.isAvailable ? 'available' : 'rented'}
                    onChange={(e) => setEditingProperty({ ...editingProperty, isAvailable: e.target.value === 'available' })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-medium"
                  >
                    <option value="available">Disponible à la location</option>
                    <option value="rented">Loué / Occupé</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Meublé</label>
                  <select
                    value={editingProperty.furnished ? 'yes' : 'no'}
                    onChange={(e) => setEditingProperty({ ...editingProperty, furnished: e.target.value === 'yes' })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-medium"
                  >
                    <option value="no">Non meublé</option>
                    <option value="yes">Meublé</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditPropertyModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-sm cursor-pointer hover:scale-105"
                >
                  Sauvegarder les Modifications
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: LANDLORD DETAIL DRAWER WITH MANAGED PROPERTIES */}
      {/* ========================================================================= */}
      {selectedLandlord && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 w-full max-w-2xl shadow-2xl space-y-4 animate-scale-up max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-700 border border-blue-200 flex items-center justify-center font-black text-sm">
                  {selectedLandlord.avatarText}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-base font-bold text-slate-900">{selectedLandlord.name}</h3>
                    <BadgeCheck className="w-4 h-4 text-blue-600" />
                  </div>
                  <p className="text-xs text-slate-500 font-medium">{selectedLandlord.companyName || 'Bailleur Privé'}</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    handleOpenEdit(selectedLandlord);
                  }}
                  className="p-2 rounded-xl bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 transition-all font-bold text-xs flex items-center gap-1 cursor-pointer"
                >
                  <Pencil className="w-3.5 h-3.5" />
                  <span>Modifier Dossier</span>
                </button>

                <button
                  onClick={() => setSelectedLandlord(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Quick Contact and Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-[10px] text-slate-400 block">Biens Gérés</span>
                <span className="font-extrabold text-slate-900 text-sm">{selectedLandlord.totalProperties}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-[10px] text-slate-400 block">Occupés</span>
                <span className="font-extrabold text-emerald-700 text-sm">{selectedLandlord.occupiedProperties}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-[10px] text-slate-400 block">Flux Mensuel</span>
                <span className="font-extrabold text-blue-700 text-xs font-mono">{formatFCFA(selectedLandlord.totalMonthlyVolume)}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-[10px] text-slate-400 block">Note Agréée</span>
                <span className="font-extrabold text-amber-600 text-sm">★ {selectedLandlord.rating}</span>
              </div>
            </div>

            {/* SECTION: BIENS GÉRÉS POUR CE BAILLEUR */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <Home className="w-4 h-4 text-blue-600" />
                  <span>Biens Immobiliers Sous Mandat de Gestion ({getLandlordProperties(selectedLandlord).length})</span>
                </h4>
                <button
                  onClick={() => {
                    handleOpenAddProperty(selectedLandlord);
                  }}
                  className="py-1 px-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1 shadow-sm transition-all cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Ajouter un Bien</span>
                </button>
              </div>

              <div className="space-y-2">
                {getLandlordProperties(selectedLandlord).length === 0 ? (
                  <div className="p-6 rounded-2xl bg-slate-50 border border-dashed border-slate-200 text-center space-y-2">
                    <p className="text-xs text-slate-500 font-medium">Aucun bien immobilier sous mandat actuellement pour ce partenaire.</p>
                    <button
                      onClick={() => handleOpenAddProperty(selectedLandlord)}
                      className="py-1.5 px-3 rounded-xl bg-blue-50 text-blue-700 hover:bg-blue-100 text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Rattacher un premier bien</span>
                    </button>
                  </div>
                ) : (
                  getLandlordProperties(selectedLandlord).map((prop) => (
                    <div
                      key={prop.id}
                      className="p-3 rounded-2xl bg-slate-50 hover:bg-slate-100/80 border border-slate-200 flex items-center justify-between gap-3 text-xs transition-colors"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold shrink-0">
                          <Building2 className="w-5 h-5" />
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900 truncate">{prop.title}</span>
                            <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                              prop.isAvailable ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'
                            }`}>
                              {prop.isAvailable ? 'Disponible' : 'Loué'}
                            </span>
                          </div>
                          <span className="text-[11px] text-slate-500 flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-slate-400" />
                            {prop.neighborhood} • {prop.surface} m² • {prop.rooms || 1} p.
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        <div className="text-right">
                          <span className="font-mono font-black text-emerald-700 block text-xs sm:text-sm">
                            {formatFCFA(prop.monthlyRent)} / mois
                          </span>
                          <span className="text-[10px] text-slate-500 font-medium">
                            Net viré : {formatFCFA(Math.round(prop.monthlyRent * 0.90))}
                          </span>
                        </div>

                        <button
                          onClick={() => handleOpenEditProperty(prop)}
                          className="p-2 rounded-xl bg-white hover:bg-blue-50 text-slate-600 hover:text-blue-700 border border-slate-200 hover:border-blue-200 transition-all font-bold text-xs flex items-center gap-1 cursor-pointer"
                          title="Modifier les détails de ce bien immobilier"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">Modifier</span>
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Partner Details & Mandat LOC */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
              <span className="text-xs font-bold text-slate-800 block">Mandat de Gestion LOC & Reversement Net</span>
              <div className="grid grid-cols-2 gap-2 text-[11px] bg-white p-2.5 rounded-xl border border-slate-200">
                <div>
                  <span className="text-slate-500 block">Commission Gestion LOC (3%) :</span>
                  <span className="font-bold font-mono text-indigo-700">-{formatFCFA(Math.round(selectedLandlord.totalMonthlyVolume * 0.03))}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Net Reversé au Bailleur (97%) :</span>
                  <span className="font-bold font-mono text-emerald-700">{formatFCFA(Math.round(selectedLandlord.totalMonthlyVolume * 0.97))}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
                <div>
                  <span className="text-slate-500 block">Méthode de virement :</span>
                  <span className="font-semibold text-slate-900">{selectedLandlord.payoutMethod}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">N° de compte :</span>
                  <span className="font-mono text-blue-700 font-bold">{selectedLandlord.payoutAccountNumber}</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={() => {
                  setStatementLandlord(selectedLandlord);
                  setSelectedLandlord(null);
                }}
                className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              >
                <FileText className="w-4 h-4 text-blue-600" />
                <span>Consulter / Relevé PDF</span>
              </button>

              <a
                href={`tel:${selectedLandlord.phone.replace(/\s+/g, '')}`}
                className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
              >
                <Phone className="w-4 h-4" />
                <span>Appeler ({selectedLandlord.phone})</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 5: RELEVÉ DE COMPTE CERTIFIÉ BAILLEUR LOC (CONSULTER & TÉLÉCHARGER) */}
      {/* ========================================================================= */}
      {statementLandlord && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 w-full max-w-2xl shadow-2xl space-y-4 animate-scale-up max-h-[90vh] overflow-y-auto">
            {/* Header with Print buttons */}
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black">
                  🏠
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Relevé de Compte Mensuel - Gestion LOC</h3>
                  <p className="text-[10px] text-slate-500 font-mono">RÉF : REL-2026-09-{statementLandlord.id.slice(-6).toUpperCase()}</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="py-1.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5 text-blue-600" />
                  <span>Imprimer / Télécharger PDF</span>
                </button>
                <button
                  onClick={() => setStatementLandlord(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Official Document Body */}
            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4 text-xs">
              {/* Landlord & Period Info */}
              <div className="grid grid-cols-2 gap-4 pb-3 border-b border-slate-200">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Bénéficiaire :</span>
                  <span className="font-bold text-slate-900 block text-sm">{statementLandlord.name}</span>
                  <span className="text-slate-600">{statementLandlord.companyName || 'Bailleur Particulier'}</span>
                  <span className="text-slate-500 block font-mono">{statementLandlord.phone}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Période de Gestion :</span>
                  <span className="font-bold text-slate-900 block">Septembre / Octobre 2026</span>
                  <span className="text-slate-500 block">Échéance : 01 Octobre 2026</span>
                  <span className="text-emerald-700 font-bold block">Compte : {statementLandlord.payoutMethod}</span>
                </div>
              </div>

              {/* Financial Summary Cards */}
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="p-3 bg-white rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-400 block">Loyers Bruts Collectés</span>
                  <span className="font-black font-mono text-slate-900 text-sm">{formatFCFA(statementLandlord.totalMonthlyVolume)}</span>
                </div>
                <div className="p-3 bg-white rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-400 block">Frais LOC (3%)</span>
                  <span className="font-black font-mono text-indigo-700 text-sm">-{formatFCFA(Math.round(statementLandlord.totalMonthlyVolume * 0.03))}</span>
                </div>
                <div className="p-3 bg-white rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-400 block">Net Transféré (97%)</span>
                  <span className="font-black font-mono text-emerald-700 text-sm">{formatFCFA(Math.round(statementLandlord.totalMonthlyVolume * 0.97))}</span>
                </div>
              </div>

              {/* Detailed Breakdown per Property */}
              <div className="space-y-1.5 pt-2">
                <span className="text-xs font-bold text-slate-900 block">Détail par Logement Sous Mandat :</span>
                <table className="w-full text-left text-xs bg-white rounded-xl border border-slate-200 overflow-hidden">
                  <thead className="bg-slate-100 text-slate-600 text-[10px] uppercase font-bold">
                    <tr>
                      <th className="p-2">Bien</th>
                      <th className="p-2">Loyer Brut</th>
                      <th className="p-2">Frais LOC 3%</th>
                      <th className="p-2 text-right">Net Viré (97%)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {getLandlordProperties(statementLandlord).map((prop) => (
                      <tr key={prop.id}>
                        <td className="p-2 font-medium text-slate-900">{prop.title} ({prop.neighborhood})</td>
                        <td className="p-2 font-mono text-slate-700">{formatFCFA(prop.monthlyRent)}</td>
                        <td className="p-2 font-mono text-indigo-700">-{formatFCFA(Math.round(prop.monthlyRent * 0.03))}</td>
                        <td className="p-2 font-mono font-bold text-emerald-700 text-right">{formatFCFA(Math.round(prop.monthlyRent * 0.97))}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Footer certification badge */}
              <div className="pt-2 flex items-center justify-between text-[10px] text-slate-500">
                <span className="flex items-center gap-1 font-semibold text-emerald-700">
                  <BadgeCheck className="w-4 h-4 text-emerald-600" />
                  Relevé certifié conforme - Plateforme LOC Sénégal
                </span>
                <span className="font-mono">Cachet Électronique LOC-SECURE-9921</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                onClick={() => setStatementLandlord(null)}
                className="py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs cursor-pointer"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
