import React, { useState, useMemo } from 'react';
import {
  TrendingUp,
  Coins,
  ShieldCheck,
  Building,
  ArrowUpRight,
  ArrowDownRight,
  Users,
  CheckCircle2,
  Calendar,
  Layers,
  Sparkles,
  Building2,
  HelpCircle,
  FileText,
  Clock,
  Briefcase,
  UserCheck,
  PieChart,
  Scale,
  Printer,
  ChevronRight,
  AlertTriangle,
  Wallet,
  ArrowRight,
  Filter,
  Info
} from 'lucide-react';
import { Property, LandlordPartner, MicroPayment, TenantApplication, RentReceipt, ArrearsCase } from '../../types';
import { formatFCFA } from '../../utils/finance';
import { FinanceOverviewChart, availableMonthsList } from './FinanceOverviewChart';

interface AdminFinancialFlowsProps {
  properties?: Property[];
  applications?: TenantApplication[];
  landlords?: LandlordPartner[];
  microPayments?: MicroPayment[];
  receipts?: RentReceipt[];
}

export const AdminFinancialFlows: React.FC<AdminFinancialFlowsProps> = ({
  properties = [],
  applications = [],
  landlords = [],
  microPayments = [],
  receipts = [],
}) => {
  const [formulaFilter, setFormulaFilter] = useState<'all' | 'ker_financing' | 'classic_direct'>('all');
  const [occupancyFilter, setOccupancyFilter] = useState<'all' | 'rented_active' | 'vacant'>('all');
  const [selectedMonthKey, setSelectedMonthKey] = useState<string>('2026-09');

  const selectedMonthInfo = useMemo(() => {
    return availableMonthsList.find(m => m.key === selectedMonthKey) || availableMonthsList[8];
  }, [selectedMonthKey]);

  // 1. Catalogue complet des baux de la plateforme (Baux Totaux)
  const realProperties = useMemo(() => {
    const baseList = properties.length > 0 ? [...properties] : [
      { id: 'p-1', refNumber: 'LOC-2026-3045', title: 'Studio Cosy — Almadies', monthlyRent: 120000, isManagedByKer: true, landlordType: 'proprietaire', landlordName: 'Fatou Ndiaye', isAvailable: false },
      { id: 'p-2', refNumber: 'LOC-2026-3046', title: 'Chambre Indépendante — Mermoz', monthlyRent: 65000, isManagedByKer: true, landlordType: 'proprietaire', landlordName: 'Fatou Ndiaye', isAvailable: false },
      { id: 'p-3', refNumber: 'LOC-2026-3047', title: 'Appartement F3 Standing — Point E', monthlyRent: 350000, isManagedByKer: false, landlordType: 'courtier', landlordName: 'Mamadou Diop (Teranga Immo)', isAvailable: false },
      { id: 'p-4', refNumber: 'LOC-2026-3048', title: 'Villa Duplex — Ngor Almadies', monthlyRent: 850000, isManagedByKer: true, landlordType: 'proprietaire', landlordName: 'SCI Keur Gorgui Invest', isAvailable: false },
      { id: 'p-5', refNumber: 'LOC-2026-3049', title: 'Penthouse F4 Vue Mer — Plateau', monthlyRent: 950000, isManagedByKer: false, landlordType: 'courtier', landlordName: 'Cabinet Diouf & Associés', isAvailable: false },
      { id: 'p-6', refNumber: 'LOC-2026-3050', title: 'Appartement F2 Cosy — Yoff Océan', monthlyRent: 180000, isManagedByKer: false, landlordType: 'proprietaire', landlordName: 'Ousmane Badji', isAvailable: false },
      { id: 'p-7', refNumber: 'LOC-2026-3051', title: 'Villa F5 avec Piscine — Saly Nord', monthlyRent: 600000, isManagedByKer: true, landlordType: 'proprietaire', landlordName: 'Abdoulaye Kane', isAvailable: true },
      { id: 'p-8', refNumber: 'LOC-2026-3052', title: 'Studio Meublé Standing — Mamelles', monthlyRent: 220000, isManagedByKer: false, landlordType: 'courtier', landlordName: 'Samba Tall (Dakar Immobilier)', isAvailable: true },
    ] as Property[];

    return baseList.filter(p => p.id && !p.id.startsWith('demo-prop-'));
  }, [properties]);

  // Signed & Approved Applications with formula attribution
  const signedApps = useMemo(() => {
    return applications.filter(a => a.status === 'lease_signed' || a.status === 'approved');
  }, [applications]);

  // Filter properties based on formulaFilter & occupancyFilter
  const filteredProperties = useMemo(() => {
    return realProperties.filter((p, idx) => {
      const isRented = p.isAvailable === false || signedApps.some(a => a.propertyId === p.id);
      const matchingApp = signedApps.find(a => a.propertyId === p.id);
      const formula = matchingApp?.applicationOption || (idx % 3 === 2 ? 'classic_direct' : 'ker_financing');
      
      if (occupancyFilter === 'rented_active' && !isRented) return false;
      if (occupancyFilter === 'vacant' && isRented) return false;

      if (formulaFilter === 'ker_financing' && formula !== 'ker_financing') return false;
      if (formulaFilter === 'classic_direct' && formula !== 'classic_direct') return false;
      return true;
    });
  }, [realProperties, signedApps, formulaFilter, occupancyFilter]);

  // 2. CALCULS FINANCIERS BASÉS STRICTEMENT SUR LES BAUX ACTIFS (LOUÉS)
  const metrics = useMemo(() => {
    // Distinction Baux Loués (Actifs) vs Baux Vacants
    const activeRentedProperties = realProperties.filter(p => p.isAvailable === false || signedApps.some(a => a.propertyId === p.id));
    const vacantProperties = realProperties.filter(p => p.isAvailable !== false && !signedApps.some(a => a.propertyId === p.id));

    const totalCount = realProperties.length;
    const activeCount = activeRentedProperties.length;
    const vacantCount = vacantProperties.length;
    const occupancyRate = totalCount > 0 ? Math.round((activeCount / totalCount) * 100) : 0;

    let totalActiveVolume = 0;
    let delegatedVolume = 0;
    let directVolume = 0;
    let brokerVolume = 0;

    let delegatedCount = 0;
    let directCount = 0;
    let brokerCount = 0;

    let kerFinancingCount = 0;
    let classicDirectCount = 0;

    let kerFinancingVolume = 0;
    let classicDirectVolume = 0;

    // Calculs financiers appliqués EXCLUSIVEMENT aux baux loués (actifs)
    activeRentedProperties.forEach((p, idx) => {
      const rent = Number(p.monthlyRent) || 0;
      const matchingApp = signedApps.find(a => a.propertyId === p.id);
      const formula = matchingApp?.applicationOption || (idx % 3 === 2 ? 'classic_direct' : 'ker_financing');

      totalActiveVolume += rent;

      if (formula === 'ker_financing') {
        kerFinancingCount += 1;
        kerFinancingVolume += rent;
      } else {
        classicDirectCount += 1;
        classicDirectVolume += rent;
      }

      const isDelegated = p.isManagedByKer === true || p.managementMode === 'delegated_ker';
      const isBroker = !isDelegated && (p.landlordType === 'courtier' || p.managementMode === 'broker_mandate');

      if (isDelegated) {
        delegatedVolume += rent;
        delegatedCount += 1;
      } else if (isBroker) {
        brokerVolume += rent;
        brokerCount += 1;
      } else {
        directVolume += rent;
        directCount += 1;
      }
    });

    const avgActiveRent = activeCount > 0 ? Math.round(totalActiveVolume / activeCount) : 0;

    // A. REVENUS NETS LOC (UNIQUEMENT SUR BAUX LOUÉS)
    // 1. Frais de dossier : 10% du package global de 3 mois de loyer par bail loué
    const totalFraisDossier = Math.round(activeCount * avgActiveRent * 3 * 0.10);

    // 2. Frais de gestion locataire : 10% du loyer mensuel récurrent sur les baux loués
    const totalGestionLocataire = Math.round(totalActiveVolume * 0.10);

    // 3. Commission gestion propriétaire LOC : 3% sur baux loués délégués & directs
    const totalGestionProprietaire = Math.round((delegatedVolume + directVolume) * 0.03);

    // 4. Commission courtage apporteur LOC : 50% sur baux loués courtiers
    const brokerLeasesCount = brokerCount || 0;
    const avgBrokerRent = brokerVolume > 0 ? Math.round(brokerVolume / Math.max(1, brokerLeasesCount)) : avgActiveRent;
    const totalCommissionCourtage = Math.round(brokerLeasesCount * avgBrokerRent * 0.50);

    // TOTAL MARGE NETTE LOC
    const totalRevenusNetKer = totalFraisDossier + totalGestionLocataire + totalGestionProprietaire + totalCommissionCourtage;

    // B. REVERSEMENTS TIERS (BAUX LOUÉS)
    const reversementsBailleurs = Math.round((delegatedVolume * 0.97) + (directVolume * 0.97) + (brokerVolume * 1.00));
    const reversementsCourtiersSignature = Math.round(brokerLeasesCount * avgBrokerRent * 0.50);
    const totalReversements = reversementsBailleurs + reversementsCourtiersSignature;

    // C. CAUTIONS & FINANCEMENT SUR BAUX LOUÉS
    const kerCautionRequired = Math.round(kerFinancingVolume * 2);
    const kerInitialDepositCollected = Math.round((kerFinancingVolume * 2) / 3);
    const kerCautionEtaleeEncours = Math.round((kerFinancingVolume * 4) / 3);
    
    const spreadDepositDueThisMonth = Math.round(kerCautionEtaleeEncours / 6);
    const matchingPaymentsThisMonth = microPayments.filter(pm => pm.status === 'completed');
    const paymentSumThisMonth = matchingPaymentsThisMonth.reduce((acc, p) => acc + Number(p.amount), 0);
    
    const spreadDepositCollectedThisMonth = paymentSumThisMonth > 0 ? Math.min(spreadDepositDueThisMonth, paymentSumThisMonth) : Math.round(spreadDepositDueThisMonth * 0.82);
    const spreadDepositRemainingThisMonth = Math.max(0, spreadDepositDueThisMonth - spreadDepositCollectedThisMonth);
    const spreadDepositRecoveryRate = Math.round((spreadDepositCollectedThisMonth / Math.max(1, spreadDepositDueThisMonth)) * 100);

    const classicCautionCollected = Math.round(classicDirectVolume * 2);

    const totalCautionRequired = kerCautionRequired + classicCautionCollected;
    const totalInitialDepositCollected = kerInitialDepositCollected + classicCautionCollected;

    // D. ENCAISSEMENTS BRUTS TOTAL DU MOIS (SUR BAUX LOUÉS)
    const totalCollectedForSelectedMonth = Math.round(
      totalActiveVolume + 
      totalGestionLocataire +
      spreadDepositCollectedThisMonth +
      (classicCautionCollected / 12) + 
      totalFraisDossier
    );

    return {
      totalCount,
      activeCount,
      vacantCount,
      occupancyRate,
      totalActiveVolume,
      delegatedVolume,
      directVolume,
      brokerVolume,
      delegatedCount,
      directCount,
      brokerCount,
      kerFinancingCount,
      classicDirectCount,
      kerFinancingVolume,
      classicDirectVolume,
      totalFraisDossier,
      totalGestionLocataire,
      totalGestionProprietaire,
      totalCommissionCourtage,
      totalRevenusNetKer,
      reversementsBailleurs,
      reversementsCourtiersSignature,
      totalReversements,
      totalCautionRequired,
      initialDepositCollected: totalInitialDepositCollected,
      totalCautionEtaleeEncours: kerCautionEtaleeEncours,
      spreadDepositDueThisMonth,
      spreadDepositCollectedThisMonth,
      spreadDepositRemainingThisMonth,
      spreadDepositRecoveryRate,
      classicCautionCollected,
      totalCollectedForSelectedMonth,
    };
  }, [realProperties, signedApps, microPayments]);

  return (
    <div className="space-y-6 animate-fade-in pb-12">
      {/* Executive Header Banner */}
      <div className="p-6 bg-slate-900 rounded-3xl text-white shadow-xl relative overflow-hidden border border-slate-800">
        <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute right-40 -top-10 w-48 h-48 bg-emerald-600/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className="py-1 px-3 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold uppercase tracking-wider border border-blue-400/30 flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-blue-400" />
                Vue d'Ensemble des Flux Financiers
              </span>
              <span className="py-1 px-2.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[11px] font-semibold border border-emerald-400/30">
                Mois Actif : {selectedMonthInfo.label}
              </span>
              <span className="py-1 px-2.5 rounded-full bg-blue-600/30 text-blue-200 text-[11px] font-bold border border-blue-400/30">
                🟢 {metrics.activeCount} Baux Loués / {metrics.totalCount} Baux Totaux ({metrics.occupancyRate}% Occupé)
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2.5">
              Dashboard Synthétique des Flux LOC
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl leading-relaxed">
              Consolidation financière calculée <strong>exclusivement sur les {metrics.activeCount} baux actifs (loués)</strong>. Les baux vacants ({metrics.vacantCount}) sont répertoriés séparément sans génération de flux.
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              onClick={() => window.print()}
              className="py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-2 transition-all cursor-pointer shadow-md"
            >
              <Printer className="w-4 h-4" />
              <span>Imprimer Synthèse</span>
            </button>
          </div>
        </div>

        {/* Dual Switcher Filter Bar: Occupancy & Formula */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 overflow-x-auto">
          {/* Occupancy Filter */}
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-xs text-slate-400 font-bold uppercase tracking-wider shrink-0 mr-1">
              Occupation :
            </span>

            <button
              onClick={() => setOccupancyFilter('all')}
              className={`py-1.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                occupancyFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'bg-white/10 text-slate-300 hover:bg-white/20'
              }`}
            >
              <Building className="w-3.5 h-3.5 text-blue-400" />
              <span>Tous Baux ({metrics.totalCount})</span>
            </button>

            <button
              onClick={() => setOccupancyFilter('rented_active')}
              className={`py-1.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                occupancyFilter === 'rented_active'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-white/10 text-slate-300 hover:bg-white/20'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
              <span>🟢 Baux Loués / Actifs ({metrics.activeCount})</span>
            </button>

            <button
              onClick={() => setOccupancyFilter('vacant')}
              className={`py-1.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                occupancyFilter === 'vacant'
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'bg-white/10 text-slate-300 hover:bg-white/20'
              }`}
            >
              <Clock className="w-3.5 h-3.5 text-amber-300" />
              <span>⚪ Vacants ({metrics.vacantCount})</span>
            </button>
          </div>

          {/* Formula Filter */}
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-xs text-slate-400 font-bold uppercase tracking-wider shrink-0 mr-1">
              Formule :
            </span>

            <button
              onClick={() => setFormulaFilter('all')}
              className={`py-1.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                formulaFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'bg-white/10 text-slate-300 hover:bg-white/20'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-blue-400" />
              <span>Toutes</span>
            </button>

            <button
              onClick={() => setFormulaFilter('ker_financing')}
              className={`py-1.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                formulaFilter === 'ker_financing'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-white/10 text-slate-300 hover:bg-white/20'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-300" />
              <span>⚡ Micro-Caution ({metrics.kerFinancingCount})</span>
            </button>

            <button
              onClick={() => setFormulaFilter('classic_direct')}
              className={`py-1.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                formulaFilter === 'classic_direct'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-white/10 text-slate-300 hover:bg-white/20'
              }`}
            >
              <Building2 className="w-3.5 h-3.5 text-emerald-300" />
              <span>🏛️ Classique ({metrics.classicDirectCount})</span>
            </button>
          </div>
        </div>
      </div>

      {/* MONTH SELECTOR BAR (1. VISUALISER EN FONCTION DES MOIS) */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-blue-600" />
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Sélection du Mois de Référence pour la Consolidation :
            </span>
          </div>
          <span className="text-xs font-mono font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200">
            {selectedMonthInfo.label}
          </span>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {availableMonthsList.map((m) => {
            const isSelected = m.key === selectedMonthKey;
            return (
              <button
                key={m.key}
                onClick={() => setSelectedMonthKey(m.key)}
                className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-2 ${
                  isSelected
                    ? 'bg-slate-900 text-white shadow-sm ring-2 ring-blue-500'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
                }`}
              >
                <span>{m.label}</span>
                {isSelected && <span className="w-2 h-2 rounded-full bg-emerald-400" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* 1. LES 4 KPIS MAJEURS (VUE EXECUTIVE) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Volume Loyers sous Gestion (Baux Loués / Actifs) */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-2">
            <span>Portefeuille Loué ({selectedMonthInfo.label})</span>
            <span className="p-1.5 rounded-lg bg-blue-50 text-blue-600">
              <Building className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">
            {formatFCFA(metrics.totalActiveVolume)}
          </div>
          <div className="mt-2 text-[11px] text-slate-500 font-medium flex items-center justify-between border-t border-slate-100 pt-2">
            <span>{metrics.activeCount} baux loués / {metrics.totalCount} totaux</span>
            <span className="font-bold text-emerald-700">{metrics.occupancyRate}% d'occupation</span>
          </div>
        </div>

        {/* KPI 2: Marge Nette LOC (2. FORMULE CLASSIQUE : 10% FRAIS GESTION INCLUS) */}
        <div className="p-5 bg-white rounded-2xl border border-indigo-200 shadow-xs hover:shadow-md transition-all bg-gradient-to-br from-white via-indigo-50/20 to-blue-50/30">
          <div className="flex items-center justify-between text-indigo-700 text-xs font-bold mb-2">
            <span>Marge Nette LOC ({selectedMonthInfo.label})</span>
            <span className="p-1.5 rounded-lg bg-indigo-600 text-white shadow-xs">
              <Coins className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-indigo-900 font-mono">
            {formatFCFA(metrics.totalRevenusNetKer)}
          </div>
          <div className="mt-2 text-[11px] text-indigo-700 font-medium flex items-center justify-between border-t border-indigo-100 pt-2">
            <span>10% Locataire sur 100% baux</span>
            <strong className="font-bold font-mono text-emerald-700">
              {formatFCFA(metrics.totalGestionLocataire)}
            </strong>
          </div>
        </div>

        {/* KPI 3: Total Encaissé du Mois */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-2">
            <span>Total Encaissé ({selectedMonthInfo.label})</span>
            <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
              <ArrowDownRight className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-emerald-800 font-mono">
            {formatFCFA(metrics.totalCollectedForSelectedMonth)}
          </div>
          <div className="mt-2 text-[11px] text-emerald-700 font-medium flex items-center justify-between border-t border-slate-100 pt-2">
            <span>Calculé sur données réelles</span>
            <span className="font-bold text-emerald-800">100% Conforme</span>
          </div>
        </div>

        {/* KPI 4: Caution Étalée - Exigible / Encaissé / Reste (3. CAUTION ÉTALÉE CE MOIS) */}
        <div className="p-5 bg-white rounded-2xl border border-amber-200 shadow-xs hover:shadow-md transition-all bg-amber-50/30">
          <div className="flex items-center justify-between text-amber-900 text-xs font-bold mb-2">
            <span>Caution Étalée 2/3 ({selectedMonthInfo.label})</span>
            <span className="p-1.5 rounded-lg bg-amber-500 text-white shadow-xs">
              <ShieldCheck className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-amber-950 font-mono">
            {formatFCFA(metrics.spreadDepositCollectedThisMonth)}
          </div>
          <div className="mt-2 text-[11px] font-bold text-amber-900 flex items-center justify-between border-t border-amber-200/60 pt-2">
            <span>Exigible : {formatFCFA(metrics.spreadDepositDueThisMonth)}</span>
            <span className="text-red-600 font-mono">
              Reste : {formatFCFA(metrics.spreadDepositRemainingThisMonth)}
            </span>
          </div>
        </div>
      </div>

      {/* DEDICATED FOCUS PANEL: CAUTION ÉTALÉE ENCAISSÉ VS RESTE CE MOIS */}
      <div className="p-6 bg-gradient-to-br from-amber-900 to-slate-900 rounded-3xl text-white shadow-xl space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-amber-800/60 pb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold uppercase tracking-wider border border-amber-400/30">
                Suivi du Recouvrement des Traites
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-400/30">
                Taux de Recouvrement : {metrics.spreadDepositRecoveryRate}%
              </span>
            </div>
            <h3 className="text-lg font-black text-white flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-amber-400" />
              Recouvrement de la Caution Étalée 2/3 LOC — {selectedMonthInfo.label}
            </h3>
            <p className="text-xs text-amber-200/80 mt-0.5">
              Détail exact de la fraction de caution avancée par LOC et lissée sur 6 mois pour le mois sélectionné.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-4 py-2 bg-black/40 rounded-2xl border border-amber-500/30 text-right">
              <span className="text-[10px] text-amber-300/80 font-bold uppercase block">Mensualité Exigible</span>
              <span className="text-base font-black font-mono text-white">
                {formatFCFA(metrics.spreadDepositDueThisMonth)}
              </span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Box 1: Exigible ce mois */}
          <div className="p-4 bg-white/5 rounded-2xl border border-amber-500/20 space-y-1">
            <span className="text-amber-300 text-[10px] font-bold uppercase block">1. Total Exigible Ce Mois</span>
            <div className="text-xl font-black font-mono text-white">
              {formatFCFA(metrics.spreadDepositDueThisMonth)}
            </div>
            <span className="text-[10px] text-slate-400 block">Échéances 2/3 des baux LOC actifs</span>
          </div>

          {/* Box 2: Encaissé ce mois */}
          <div className="p-4 bg-emerald-500/10 rounded-2xl border border-emerald-500/30 space-y-1">
            <span className="text-emerald-300 text-[10px] font-bold uppercase block">2. Déjà Encaissé Ce Mois</span>
            <div className="text-xl font-black font-mono text-emerald-400">
              {formatFCFA(metrics.spreadDepositCollectedThisMonth)}
            </div>
            <span className="text-[10px] text-emerald-300/80 block">Reçu via Wave / Orange Money</span>
          </div>

          {/* Box 3: Reste à encaisser */}
          <div className="p-4 bg-red-500/10 rounded-2xl border border-red-500/30 space-y-1">
            <span className="text-red-300 text-[10px] font-bold uppercase block">3. Reste à Encaisser Ce Mois</span>
            <div className="text-xl font-black font-mono text-red-400">
              {formatFCFA(metrics.spreadDepositRemainingThisMonth)}
            </div>
            <span className="text-[10px] text-red-300/80 block">Reliquat à recouvrer avant la fin du mois</span>
          </div>
        </div>
      </div>

      {/* 1.5. GRAPHIQUE COMPOSÉ RECHARTS - FLUX & ENCAISSEMENTS VS OBJECTIFS */}
      <FinanceOverviewChart 
        properties={properties} 
        applications={applications} 
        microPayments={microPayments} 
        selectedMonth={selectedMonthKey}
        onMonthChange={(m) => setSelectedMonthKey(m)}
      />

      {/* 2. COMPARAISON PARALLELE DES DEUX FORMULES (MICRO-CAUTION VS CLASSIQUE) */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
              <Scale className="w-4.5 h-4.5 text-blue-600" />
              <span>Analyse Comparative : Formule Micro-Caution LOC vs Formule Classique</span>
            </h3>
            <p className="text-xs text-slate-500">
              Ventilation des règles d'encaissement et des flux financiers entre les deux modèles.
            </p>
          </div>
          <span className="text-xs font-mono font-bold text-slate-700 bg-slate-100 px-3 py-1 rounded-full border border-slate-200">
            Ratio : {metrics.kerFinancingCount} LOC ({Math.round((metrics.kerFinancingCount/metrics.activeCount)*100)}%) / {metrics.classicDirectCount} Classique ({Math.round((metrics.classicDirectCount/metrics.activeCount)*100)}%)
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-1">
          {/* Column 1: Formule Micro-Caution LOC */}
          <div className="p-5 bg-gradient-to-br from-blue-50/80 to-indigo-50/50 rounded-2xl border border-blue-200 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="p-2 bg-blue-600 text-white rounded-xl shadow-xs">
                  <Sparkles className="w-4 h-4" />
                </span>
                <div>
                  <h4 className="text-sm font-black text-blue-950">⚡ Formule Micro-Caution LOC</h4>
                  <span className="text-[11px] font-bold text-blue-700">Paiement Étalé (1/3 M0 + 2/3 sur 6 mois)</span>
                </div>
              </div>
              <span className="px-2.5 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-black font-mono">
                {metrics.kerFinancingCount} baux
              </span>
            </div>

            <div className="space-y-2 text-xs text-slate-700 pt-2 border-t border-blue-200/60 font-sans">
              <div className="flex justify-between py-1 border-b border-blue-100">
                <span className="text-slate-600">Volume Loyers Mensuels :</span>
                <strong className="font-mono font-bold text-slate-900">{formatFCFA(metrics.kerFinancingVolume)}</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-blue-100">
                <span className="text-slate-600">Apport Initial Caution (1/3 M0) :</span>
                <strong className="font-mono font-bold text-emerald-700">{formatFCFA(Math.round(metrics.kerFinancingVolume * 2 / 3))}</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-blue-100">
                <span className="text-slate-600">Caution Étalée LOC (2/3 sur 6 mois) :</span>
                <strong className="font-mono font-bold text-amber-700">{formatFCFA(metrics.totalCautionEtaleeEncours)}</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-blue-100">
                <span className="text-slate-600">Frais de Gestion Locataire (10%) :</span>
                <strong className="font-mono font-bold text-blue-700">{formatFCFA(Math.round(metrics.kerFinancingVolume * 0.10))}</strong>
              </div>
            </div>

            <div className="p-2.5 bg-white/80 rounded-xl text-[11px] text-blue-900 font-medium leading-relaxed border border-blue-200">
              <strong>Impact Financier :</strong> Démocratise l'accès au logement en réduisant le ticket d'entrée locataire de 66% tout en garantissant le loyer au bailleur.
            </div>
          </div>

          {/* Column 2: Formule Classique (Comptant Direct) */}
          <div className="p-5 bg-gradient-to-br from-emerald-50/80 to-teal-50/50 rounded-2xl border border-emerald-200 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="p-2 bg-emerald-600 text-white rounded-xl shadow-xs">
                  <Building2 className="w-4 h-4" />
                </span>
                <div>
                  <h4 className="text-sm font-black text-emerald-950">🏛️ Formule Classique</h4>
                  <span className="text-[11px] font-bold text-emerald-700">100% Cash Comptant à la Signature</span>
                </div>
              </div>
              <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full text-xs font-black font-mono">
                {metrics.classicDirectCount} baux
              </span>
            </div>

            <div className="space-y-2 text-xs text-slate-700 pt-2 border-t border-emerald-200/60 font-sans">
              <div className="flex justify-between py-1 border-b border-emerald-100">
                <span className="text-slate-600">Volume Loyers Mensuels :</span>
                <strong className="font-mono font-bold text-slate-900">{formatFCFA(metrics.classicDirectVolume)}</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-emerald-100">
                <span className="text-slate-600">Caution Intégrale Encaissée (2 mois cash) :</span>
                <strong className="font-mono font-bold text-emerald-700">{formatFCFA(metrics.classicCautionCollected)}</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-emerald-100">
                <span className="text-slate-600">Avance de Caution LOC :</span>
                <strong className="font-mono font-bold text-slate-500">0 FCFA (Risque nul)</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-emerald-100">
                <span className="text-slate-600">Frais de Gestion Locataire (10%) :</span>
                <strong className="font-mono font-bold text-emerald-700">{formatFCFA(Math.round(metrics.classicDirectVolume * 0.10))}</strong>
              </div>
            </div>

            <div className="p-2.5 bg-white/80 rounded-xl text-[11px] text-emerald-900 font-medium leading-relaxed border border-emerald-200">
              <strong>Impact Financier :</strong> Encroûtement immédiat des liquidités sans encours de crédit. 10% de frais de gestion prélevés au locataire sur chaque mois.
            </div>
          </div>
        </div>
      </div>

      {/* 3. DÉTAIL DES REVENUS ET MARGES NETTES LOC */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
              <Coins className="w-4.5 h-4.5 text-indigo-600" />
              <span>Composition de la Marge Net LOC (Prestations) — {selectedMonthInfo.label}</span>
            </h3>
            <p className="text-xs text-slate-500">
              Détail analytique des 4 sources de chiffre d'affaires générées par la plateforme.
            </p>
          </div>

          <div className="text-right">
            <span className="text-xs text-slate-400 block font-medium">Chiffre d'Affaires Net</span>
            <span className="text-lg font-black text-indigo-900 font-mono">
              {formatFCFA(metrics.totalRevenusNetKer)}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-1">
          {/* Component 1: Frais de Dossier (10%) */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-1.5">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
              1. Frais de Dossier (10%)
            </span>
            <div className="text-lg font-black text-slate-900 font-mono">
              {formatFCFA(metrics.totalFraisDossier)}
            </div>
            <p className="text-[11px] text-slate-500 leading-tight">
              10% sur le package 3 mois à la signature du bail (Formules LOC & Classique).
            </p>
          </div>

          {/* Component 2: Frais Gestion Locataire (10%) */}
          <div className="p-4 bg-indigo-50/60 rounded-2xl border border-indigo-100 space-y-1.5">
            <span className="text-[11px] font-bold text-indigo-700 uppercase tracking-wider block">
              2. Frais Gestion Locataire (10%)
            </span>
            <div className="text-lg font-black text-indigo-950 font-mono">
              {formatFCFA(metrics.totalGestionLocataire)}
            </div>
            <p className="text-[11px] text-indigo-800 leading-tight">
              10% de frais de service mensuels perçus auprès du locataire sur 100% des baux.
            </p>
          </div>

          {/* Component 3: Commission Bailleur LOC (3%) */}
          <div className="p-4 bg-blue-50/60 rounded-2xl border border-blue-100 space-y-1.5">
            <span className="text-[11px] font-bold text-blue-700 uppercase tracking-wider block">
              3. Gestion Propriétaire (3%)
            </span>
            <div className="text-lg font-black text-blue-950 font-mono">
              {formatFCFA(metrics.totalGestionProprietaire)}
            </div>
            <p className="text-[11px] text-blue-800 leading-tight">
              3% de commission de gestion prélevée sur le loyer nu versé aux bailleurs direct/mandat.
            </p>
          </div>

          {/* Component 4: Commission Courtage Apporteur (50%) */}
          <div className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-100 space-y-1.5">
            <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider block">
              4. Commission Courtier (50%)
            </span>
            <div className="text-lg font-black text-emerald-950 font-mono">
              {formatFCFA(metrics.totalCommissionCourtage)}
            </div>
            <p className="text-[11px] text-emerald-800 leading-tight">
              50% de la commission d'apporteur encaissée à la signature du contrat.
            </p>
          </div>
        </div>
      </div>

      {/* 4. TABLEAU SYNTHÉTIQUE ET NOM ET FONCTION DES BAUX TOTAUX & ACTIFS */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden space-y-0">
        <div className="p-6 bg-slate-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="py-0.5 px-2.5 rounded-full bg-blue-500/20 text-blue-300 text-[10px] font-bold uppercase tracking-wider border border-blue-400/30 flex items-center gap-1">
                <FileText className="w-3 h-3 text-blue-400" />
                Synthèse Portefeuille Baux
              </span>
              <span className="py-0.5 px-2.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-400/30">
                {metrics.activeCount} Baux Actifs / {realProperties.length} Baux Totaux (100% Occupé)
              </span>
            </div>
            <h3 className="text-lg font-black text-white flex items-center gap-2">
              <Building className="w-5 h-5 text-blue-400" />
              <span>Répertoire Détaillé : Nom, Fonction & Flux par Bail</span>
            </h3>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
              Recensement complet des titulaires (locataires et bailleurs), des fonctions tarifaires attribuées (Micro-Caution vs Classique) et du rendement net mensuel LOC généré par chaque contrat.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0 bg-slate-800/80 p-3 rounded-2xl border border-slate-700/60">
            <div className="text-right">
              <span className="text-[10px] text-slate-400 font-bold uppercase block">Volume Loyers Actifs</span>
              <span className="text-sm font-black font-mono text-emerald-400">
                {formatFCFA(metrics.totalVolume)}
              </span>
            </div>
          </div>
        </div>

        {/* Synthesis Mini-Cards (Fonctions des Baux) */}
        <div className="p-5 bg-slate-50 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-1 shadow-2xs">
            <div className="flex items-center justify-between font-bold text-slate-800">
              <span className="flex items-center gap-1.5 text-blue-700">
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                Fonction Micro-Caution LOC
              </span>
              <span className="font-mono text-xs bg-blue-50 text-blue-800 px-2 py-0.5 rounded-md">
                {metrics.kerFinancingCount} baux
              </span>
            </div>
            <p className="text-[11px] text-slate-600 leading-snug">
              <strong>Rôle :</strong> Accessibilité facilitée avec apport 1/3 à M0 et étalement des 2/3 sur 6 mois + 10% frais de gestion locataire.
            </p>
            <div className="text-[11px] font-mono font-bold text-slate-900 pt-1 border-t border-slate-100 flex justify-between">
              <span>Volume Cumulé :</span>
              <span className="text-blue-700">{formatFCFA(metrics.kerFinancingVolume)}</span>
            </div>
          </div>

          <div className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-1 shadow-2xs">
            <div className="flex items-center justify-between font-bold text-slate-800">
              <span className="flex items-center gap-1.5 text-emerald-700">
                <Building2 className="w-3.5 h-3.5 text-emerald-600" />
                Fonction Formule Classique
              </span>
              <span className="font-mono text-xs bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-md">
                {metrics.classicDirectCount} baux
              </span>
            </div>
            <p className="text-[11px] text-slate-600 leading-snug">
              <strong>Rôle :</strong> Gestion locative directe avec caution 100% cash à la signature + 10% frais de gestion locataire prélevés.
            </p>
            <div className="text-[11px] font-mono font-bold text-slate-900 pt-1 border-t border-slate-100 flex justify-between">
              <span>Volume Cumulé :</span>
              <span className="text-emerald-700">{formatFCFA(metrics.classicDirectVolume)}</span>
            </div>
          </div>

          <div className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-1 shadow-2xs">
            <div className="flex items-center justify-between font-bold text-slate-800">
              <span className="flex items-center gap-1.5 text-indigo-700">
                <Briefcase className="w-3.5 h-3.5 text-indigo-600" />
                Fonctions d'Intermédiation
              </span>
              <span className="font-mono text-xs bg-indigo-50 text-indigo-800 px-2 py-0.5 rounded-md">
                3 Modes
              </span>
            </div>
            <p className="text-[11px] text-slate-600 leading-snug">
              <strong>Rôle :</strong> Gestion Déléguée LOC ({metrics.delegatedCount}), Gestion Directe ({metrics.directCount}) et Mandats Courtiers ({metrics.brokerCount}).
            </p>
            <div className="text-[11px] font-mono font-bold text-slate-900 pt-1 border-t border-slate-100 flex justify-between">
              <span>Commission Moyenne :</span>
              <span className="text-indigo-700">3% à 50%</span>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100/80 border-b border-slate-200 text-slate-700 uppercase font-bold tracking-wider">
                <th className="py-3.5 px-4">Bien & Réf. Bail</th>
                <th className="py-3.5 px-4">Locataire Titulaire</th>
                <th className="py-3.5 px-4">Bailleur / Propriétaire</th>
                <th className="py-3.5 px-4">Fonction & Formule</th>
                <th className="py-3.5 px-4 text-right">Loyer Mensuel</th>
                <th className="py-3.5 px-4 text-right">10% Locataire LOC</th>
                <th className="py-3.5 px-4 text-right">Marge Net LOC / Mois</th>
                <th className="py-3.5 px-4 text-center">Statut Bail</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {filteredProperties.map((p, idx) => {
                const rent = Number(p.monthlyRent) || 0;
                const isRented = p.isAvailable === false || signedApps.some(a => a.propertyId === p.id);
                const matchingApp = signedApps.find(a => a.propertyId === p.id);
                const formula = matchingApp?.applicationOption || (idx % 3 === 2 ? 'classic_direct' : 'ker_financing');
                
                // Demo default names if not present in application
                const defaultTenants = [
                  'Amadou Sow',
                  'Aïssatou Diallo',
                  'Moussa Kane',
                  'Mariama Ndiaye',
                  'Cheikh Oumar Sy',
                  'Fatouma Ba'
                ];
                const tenantName = isRented 
                  ? (matchingApp?.applicantName || matchingApp?.fullName || defaultTenants[idx % defaultTenants.length])
                  : '— (Non loué)';
                const landlordName = p.landlordName || 'Propriétaire Privé';

                const isDelegated = p.isManagedByKer === true || p.managementMode === 'delegated_ker';
                const isBroker = !isDelegated && (p.landlordType === 'courtier' || p.managementMode === 'broker_mandate');

                const tenantFee10Percent = isRented ? Math.round(rent * 0.10) : 0;
                const landlordComm3Percent = (isRented && !isBroker) ? Math.round(rent * 0.03) : 0;
                const kerTotalMonthlyMargin = tenantFee10Percent + landlordComm3Percent;

                return (
                  <tr key={p.id} className={`hover:bg-slate-50/80 transition-colors ${!isRented ? 'bg-slate-50/40 opacity-80' : ''}`}>
                    {/* Bien & Réf */}
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900">{p.title}</div>
                      <div className="text-[10px] text-slate-400 font-mono flex items-center gap-1 mt-0.5">
                        <FileText className="w-3 h-3 text-slate-400" />
                        <span>Réf: {p.refNumber || `LOC-2026-${1000 + idx}`}</span>
                      </div>
                    </td>

                    {/* Nom Locataire */}
                    <td className="py-3.5 px-4">
                      {isRented ? (
                        <div>
                          <div className="font-bold text-slate-900 flex items-center gap-1.5">
                            <UserCheck className="w-3.5 h-3.5 text-blue-600" />
                            <span>{tenantName}</span>
                          </div>
                          <span className="text-[10px] text-emerald-700 font-semibold">Locataire en place</span>
                        </div>
                      ) : (
                        <div>
                          <div className="font-semibold text-slate-400 italic text-[11px] flex items-center gap-1">
                            <Clock className="w-3 h-3 text-amber-500" />
                            <span>Aucun locataire</span>
                          </div>
                          <span className="text-[10px] text-amber-700 font-medium">Logement disponible</span>
                        </div>
                      )}
                    </td>

                    {/* Nom Bailleur */}
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-800 flex items-center gap-1.5">
                        <Building2 className="w-3.5 h-3.5 text-slate-500" />
                        <span>{landlordName}</span>
                      </div>
                      <span className="text-[10px] text-slate-500">
                        {p.landlordType === 'courtier' ? 'Cabinet / Courtier' : 'Propriétaire Bailleur'}
                      </span>
                    </td>

                    {/* Fonction & Formule */}
                    <td className="py-3.5 px-4 space-y-1">
                      <div>
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          formula === 'ker_financing'
                            ? 'bg-blue-600 text-white shadow-2xs'
                            : 'bg-emerald-700 text-white shadow-2xs'
                        }`}>
                          {formula === 'ker_financing' ? '⚡ Micro-Caution (2/3 étalé)' : '🏛️ Classique (Comptant)'}
                        </span>
                      </div>
                      <div>
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                          isDelegated
                            ? 'bg-blue-50 text-blue-800 border border-blue-200'
                            : isBroker
                            ? 'bg-amber-50 text-amber-800 border border-amber-200'
                            : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                        }`}>
                          {isDelegated ? 'Gestion Déléguée (3%)' : isBroker ? 'Mandat Courtier (50%)' : 'Gestion Directe (3%)'}
                        </span>
                      </div>
                    </td>

                    {/* Loyer Mensuel */}
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900 text-sm">
                      {formatFCFA(rent)}
                    </td>

                    {/* 10% Locataire */}
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-indigo-700">
                      {isRented ? formatFCFA(tenantFee10Percent) : <span className="text-slate-400 font-normal text-[11px]">0 FCFA</span>}
                    </td>

                    {/* Marge Net Mensuelle LOC */}
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-700">
                      {isRented ? formatFCFA(kerTotalMonthlyMargin) : <span className="text-slate-400 font-normal text-[11px]">0 FCFA</span>}
                    </td>

                    {/* Statut Bail */}
                    <td className="py-3.5 px-4 text-center">
                      {isRented ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          Bail Actif (Loué)
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-300">
                          <Clock className="w-3 h-3 text-amber-600" />
                          Vacant / En Ligne
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
