import React, { useState } from 'react';
import { 
  CreditCard, 
  Wallet, 
  CheckCircle2, 
  Clock, 
  Send, 
  Search, 
  Filter, 
  Building2, 
  Users, 
  Download, 
  BadgeCheck, 
  ShieldCheck, 
  AlertCircle, 
  ArrowUpRight, 
  RefreshCw, 
  Eye, 
  FileText, 
  TrendingUp, 
  Zap, 
  X,
  Printer
} from 'lucide-react';
import { LandlordPartner, Property } from '../../types';
import { formatFCFA } from '../../utils/finance';

export interface SettlementItem {
  id: string;
  reference: string;
  beneficiaryName: string;
  beneficiaryType: 'landlord' | 'broker' | 'agency';
  companyName?: string;
  phone: string;
  amount: number;
  grossAmount: number;
  commissionKer: number;
  description: string;
  propertyTitle: string;
  payoutMethod: 'Wave Business' | 'Orange Money' | 'Virement CBAO' | 'Virement BOA' | 'Virement Ecobank';
  payoutAccount: string;
  dueDate: string;
  status: 'pending' | 'processing' | 'completed' | 'rejected';
  completedAt?: string;
  transactionRef?: string;
}

interface AdminSettlementsManagerProps {
  landlords: LandlordPartner[];
  properties: Property[];
  onTriggerBatchPayout?: (totalAmount: number) => void;
}

const INITIAL_SETTLEMENTS: SettlementItem[] = [
  {
    id: 'stl-1',
    reference: 'PAY-2026-09-001',
    beneficiaryName: 'Mamadou Diop',
    beneficiaryType: 'agency',
    companyName: 'Teranga Immo SARL',
    phone: '+221 77 654 32 10',
    amount: 855000,
    grossAmount: 950000,
    commissionKer: 95000,
    description: 'Reversement Net Loyers de Septembre (6 biens sous gestion)',
    propertyTitle: 'Résidence Teranga F4 & Studios Almadies',
    payoutMethod: 'Wave Business',
    payoutAccount: '+221 77 654 32 10',
    dueDate: '05 Sept 2026',
    status: 'pending',
  },
  {
    id: 'stl-2',
    reference: 'PAY-2026-09-002',
    beneficiaryName: 'Cabinet Diouf & Associés',
    beneficiaryType: 'agency',
    companyName: 'Cabinet Diouf Immobilier',
    phone: '+221 78 123 45 67',
    amount: 3600000,
    grossAmount: 4000000,
    commissionKer: 400000,
    description: 'Reversement Net Loyers & Cautions J1 (14 lots)',
    propertyTitle: 'Immeuble Horizon Mermoz & Fann',
    payoutMethod: 'Virement BOA',
    payoutAccount: 'SN08 0100 1524 0001 2345 6789 12',
    dueDate: '05 Sept 2026',
    status: 'pending',
  },
  {
    id: 'stl-3',
    reference: 'PAY-2026-09-003',
    beneficiaryName: 'Babacar Ndiaye (Courtier)',
    beneficiaryType: 'broker',
    companyName: 'Courtier Indépendant Agréé',
    phone: '+221 76 987 65 43',
    amount: 175000,
    grossAmount: 175000,
    commissionKer: 0,
    description: 'Rétrocession 50% Honoraires Apporteur (Bail F3 Plateau)',
    propertyTitle: 'Appartement Haut Standing Plateau',
    payoutMethod: 'Wave Business',
    payoutAccount: '+221 76 987 65 43',
    dueDate: '01 Sept 2026',
    status: 'pending',
  },
  {
    id: 'stl-4',
    reference: 'PAY-2026-09-004',
    beneficiaryName: 'Ousmane Sow',
    beneficiaryType: 'landlord',
    phone: '+221 77 888 99 00',
    amount: 242500,
    grossAmount: 250000,
    commissionKer: 7500,
    description: 'Loyer Net Garanti LOC (Commission 3% déduite)',
    propertyTitle: 'Appartement F3 Moderne Ouakam',
    payoutMethod: 'Wave Business',
    payoutAccount: '+221 77 888 99 00',
    dueDate: '01 Sept 2026',
    status: 'pending',
  },
  {
    id: 'stl-5',
    reference: 'PAY-2026-09-005',
    beneficiaryName: 'Aïssatou Ba (Courtière)',
    beneficiaryType: 'broker',
    phone: '+221 77 444 33 22',
    amount: 100000,
    grossAmount: 100000,
    commissionKer: 0,
    description: 'Rétrocession Honoraires Mise en Location Studio Ngor',
    propertyTitle: 'Studio Meublé Ngor Almadies',
    payoutMethod: 'Orange Money',
    payoutAccount: '+221 77 444 33 22',
    dueDate: '01 Sept 2026',
    status: 'completed',
    completedAt: '01 Sept 2026 à 09:15',
    transactionRef: 'OM-TXN-99824',
  },
  {
    id: 'stl-6',
    reference: 'PAY-2026-09-006',
    beneficiaryName: 'SCI Keur Gorgui Invest',
    beneficiaryType: 'landlord',
    companyName: 'SCI Keur Gorgui',
    phone: '+221 33 820 00 00',
    amount: 6208000,
    grossAmount: 6400000,
    commissionKer: 192000,
    description: 'Reversement Net Portefeuille 22 Lots Résidentiels',
    propertyTitle: 'Parc Résidentiel Keur Gorgui & Point E',
    payoutMethod: 'Virement CBAO',
    payoutAccount: 'SN01 0200 4589 0012 3456 7890 44',
    dueDate: '05 Sept 2026',
    status: 'pending',
  },
];

export const AdminSettlementsManager: React.FC<AdminSettlementsManagerProps> = ({
  landlords,
  properties,
  onTriggerBatchPayout,
}) => {
  const [settlements, setSettlements] = useState<SettlementItem[]>(() => {
    try {
      const saved = localStorage.getItem('ker_settlements_list');
      return saved ? JSON.parse(saved) : INITIAL_SETTLEMENTS;
    } catch {
      return INITIAL_SETTLEMENTS;
    }
  });

  const [activeFilter, setActiveFilter] = useState<'all' | 'landlord' | 'agency' | 'broker'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedReceipt, setSelectedReceipt] = useState<SettlementItem | null>(null);
  const [executingId, setExecutingId] = useState<string | null>(null);
  const [batchSuccessMessage, setBatchSuccessMessage] = useState<string | null>(null);

  React.useEffect(() => {
    const syncSettlements = () => {
      try {
        const saved = localStorage.getItem('ker_settlements_list');
        if (saved) {
          setSettlements(JSON.parse(saved));
        }
      } catch (e) {
        console.warn(e);
      }
    };
    window.addEventListener('ker_settlement_updated', syncSettlements);
    window.addEventListener('storage', syncSettlements);
    return () => {
      window.removeEventListener('ker_settlement_updated', syncSettlements);
      window.removeEventListener('storage', syncSettlements);
    };
  }, []);

  const saveSettlements = (updated: SettlementItem[]) => {
    setSettlements(updated);
    try {
      localStorage.setItem('ker_settlements_list', JSON.stringify(updated));
      window.dispatchEvent(new Event('ker_settlement_updated'));
    } catch (e) {
      console.warn('Could not save settlements:', e);
    }
  };

  const pendingSettlements = settlements.filter(s => s.status === 'pending');
  const totalPendingAmount = pendingSettlements.reduce((sum, s) => sum + s.amount, 0);
  const totalCompletedAmount = settlements.filter(s => s.status === 'completed').reduce((sum, s) => sum + s.amount, 0);

  const filteredSettlements = settlements.filter(s => {
    const matchesFilter = activeFilter === 'all' || s.beneficiaryType === activeFilter;
    const matchesSearch = s.beneficiaryName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (s.companyName && s.companyName.toLowerCase().includes(searchQuery.toLowerCase())) ||
                          s.reference.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          s.propertyTitle.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const handleExecuteSinglePayout = (item: SettlementItem) => {
    setExecutingId(item.id);
    setTimeout(() => {
      const updated = settlements.map(s => {
        if (s.id === item.id) {
          const now = new Date();
          const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
          return {
            ...s,
            status: 'completed' as const,
            completedAt: `Aujourd'hui à ${timeStr}`,
            transactionRef: `${s.payoutMethod.includes('Wave') ? 'WV' : s.payoutMethod.includes('Orange') ? 'OM' : 'VIR'}-${Math.floor(100000 + Math.random() * 900000)}`,
          };
        }
        return s;
      });
      saveSettlements(updated);
      try {
        localStorage.setItem('ker_landlord_payout_state', 'completed');
      } catch (e) {
        console.warn(e);
      }
      setExecutingId(null);
    }, 900);
  };

  const handleExecuteBatchPayout = () => {
    if (pendingSettlements.length === 0) return;
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    const updated = settlements.map(s => {
      if (s.status === 'pending') {
        return {
          ...s,
          status: 'completed' as const,
          completedAt: `Aujourd'hui à ${timeStr}`,
          transactionRef: `BATCH-${Math.floor(100000 + Math.random() * 900000)}`,
        };
      }
      return s;
    });

    saveSettlements(updated);
    if (onTriggerBatchPayout) {
      onTriggerBatchPayout(totalPendingAmount);
    }
    setBatchSuccessMessage(`Virement groupé de ${formatFCFA(totalPendingAmount)} exécuté avec succès pour ${pendingSettlements.length} bénéficiaires !`);
    setTimeout(() => setBatchSuccessMessage(null), 4000);
  };

  return (
    <div className="space-y-4 animate-fade-in text-slate-800">
      {/* Top Banner & KPI Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-4 rounded-3xl bg-white border border-slate-200 space-y-1 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Règlements Dus</span>
          <span className="text-xl font-black text-amber-700 font-mono block">
            {formatFCFA(totalPendingAmount)}
          </span>
          <span className="text-[10px] text-amber-800 block font-semibold">
            {pendingSettlements.length} virements en attente
          </span>
        </div>

        <div className="p-4 rounded-3xl bg-white border border-slate-200 space-y-1 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Déjà Viré ce Mois</span>
          <span className="text-xl font-black text-emerald-700 font-mono block">
            {formatFCFA(totalCompletedAmount)}
          </span>
          <span className="text-[10px] text-emerald-700 block font-semibold flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            100% exécuté sans litige
          </span>
        </div>

        <div className="p-4 rounded-3xl bg-white border border-slate-200 space-y-1 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Bénéficiaires Actifs</span>
          <span className="text-xl font-black text-blue-700 font-mono block">
            {settlements.length} Partenaires
          </span>
          <span className="text-[10px] text-slate-500 block font-medium">Bailleurs, Agences, Courtiers</span>
        </div>

        <div className="p-4 rounded-3xl bg-white border border-slate-200 space-y-1 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Délai Garanti LOC</span>
          <span className="text-xl font-black text-indigo-700 font-mono block">
            24h / J+1
          </span>
          <span className="text-[10px] text-indigo-800 block font-semibold">Virements Wave & Interbancaires</span>
        </div>
      </div>

      {batchSuccessMessage && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center gap-2 font-bold shadow-sm animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{batchSuccessMessage}</span>
        </div>
      )}

      {/* Action Bar with Batch Payout & Search */}
      <div className="p-4 bg-white border border-slate-200 rounded-3xl shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setActiveFilter('all')}
              className={`py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeFilter === 'all'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              Tous ({settlements.length})
            </button>
            <button
              onClick={() => setActiveFilter('landlord')}
              className={`py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeFilter === 'landlord'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              Propriétaires ({settlements.filter(s => s.beneficiaryType === 'landlord').length})
            </button>
            <button
              onClick={() => setActiveFilter('agency')}
              className={`py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeFilter === 'agency'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              Agences Immobilières ({settlements.filter(s => s.beneficiaryType === 'agency').length})
            </button>
            <button
              onClick={() => setActiveFilter('broker')}
              className={`py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeFilter === 'broker'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              Courtiers Partenaires ({settlements.filter(s => s.beneficiaryType === 'broker').length})
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExecuteBatchPayout}
              disabled={pendingSettlements.length === 0}
              className={`py-2 px-4 rounded-xl text-xs font-black flex items-center gap-2 shadow-sm transition-all cursor-pointer ${
                pendingSettlements.length > 0
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white hover:scale-105'
                  : 'bg-slate-100 text-slate-400 cursor-not-allowed'
              }`}
            >
              <Zap className="w-4 h-4 text-amber-300" />
              <span>Déclencher Tous les Virements ({formatFCFA(totalPendingAmount)})</span>
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Rechercher un règlement par bénéficiaire, société, référence ou bien..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 font-medium"
          />
        </div>
      </div>

      {/* Settlements Table */}
      <div className="bg-white border border-slate-200 rounded-3xl shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">
            Règlements & Rétrocessions Dus ({filteredSettlements.length})
          </h3>
          <span className="text-xs text-slate-500 font-medium">
            Règlements garantis par le Fonds LOC
          </span>
        </div>

        <div className="divide-y divide-slate-100 text-xs">
          {filteredSettlements.map((item) => {
            const isCompleted = item.status === 'completed';
            const isExecuting = executingId === item.id;

            return (
              <div
                key={item.id}
                className="p-4 hover:bg-slate-50/80 transition-all flex flex-col md:flex-row md:items-center justify-between gap-3"
              >
                {/* Beneficiary Info */}
                <div className="flex items-start gap-3 min-w-0 md:w-1/3">
                  <div className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-sm shrink-0 shadow-xs ${
                    item.beneficiaryType === 'agency'
                      ? 'bg-indigo-100 text-indigo-700 border border-indigo-200'
                      : item.beneficiaryType === 'broker'
                      ? 'bg-amber-100 text-amber-700 border border-amber-200'
                      : 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                  }`}>
                    {item.beneficiaryType === 'agency' ? '🏢' : item.beneficiaryType === 'broker' ? '🤝' : '🏠'}
                  </div>

                  <div className="space-y-0.5 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-bold text-slate-900 truncate">{item.beneficiaryName}</span>
                      <span className={`px-2 py-0.2 rounded-full text-[9px] font-bold uppercase border ${
                        item.beneficiaryType === 'agency'
                          ? 'bg-indigo-50 text-indigo-800 border-indigo-200'
                          : item.beneficiaryType === 'broker'
                          ? 'bg-amber-50 text-amber-800 border-amber-200'
                          : 'bg-emerald-50 text-emerald-800 border-emerald-200'
                      }`}>
                        {item.beneficiaryType === 'agency' ? 'Agence' : item.beneficiaryType === 'broker' ? 'Courtier' : 'Bailleur'}
                      </span>
                    </div>
                    {item.companyName && (
                      <p className="text-[11px] text-slate-500 font-medium">{item.companyName}</p>
                    )}
                    <p className="text-[10px] text-slate-400 truncate">{item.propertyTitle}</p>
                  </div>
                </div>

                {/* Amount & Description */}
                <div className="space-y-0.5 md:w-1/3">
                  <div className="flex items-baseline gap-2">
                    <span className="text-base font-black font-mono text-slate-900">
                      {formatFCFA(item.amount)}
                    </span>
                    {item.commissionKer > 0 && (
                      <span className="text-[10px] text-slate-400 font-mono">
                        (Brut {formatFCFA(item.grossAmount)} - Com LOC {formatFCFA(item.commissionKer)})
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-600 font-medium truncate">{item.description}</p>
                  <div className="flex items-center gap-2 text-[10px] text-slate-500">
                    <span className="font-bold text-blue-700">{item.payoutMethod}</span>
                    <span>• {item.payoutAccount}</span>
                  </div>
                </div>

                {/* Status & Actions */}
                <div className="flex items-center justify-between md:justify-end gap-2 md:w-1/3 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-slate-100">
                  <div className="text-right md:mr-2">
                    {isCompleted ? (
                      <div>
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          Viré avec succès
                        </span>
                        <span className="text-[10px] text-slate-400 block font-mono mt-0.5">
                          {item.completedAt}
                        </span>
                      </div>
                    ) : (
                      <div>
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                          <Clock className="w-3 h-3 text-amber-600" />
                          En attente
                        </span>
                        <span className="text-[10px] text-slate-400 block font-mono mt-0.5">
                          Échéance : {item.dueDate}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5">
                    {!isCompleted ? (
                      <button
                        onClick={() => handleExecuteSinglePayout(item)}
                        disabled={isExecuting}
                        className="py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1 shadow-sm transition-all cursor-pointer hover:scale-105"
                      >
                        {isExecuting ? (
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Send className="w-3.5 h-3.5" />
                        )}
                        <span>Exécuter Virement</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => setSelectedReceipt(item)}
                        className="py-1.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1 transition-all cursor-pointer"
                      >
                        <FileText className="w-3.5 h-3.5 text-blue-600" />
                        <span>Avis / Reçu</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SETTLEMENT RECEIPT MODAL */}
      {selectedReceipt && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 w-full max-w-lg shadow-2xl space-y-4 animate-scale-up">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Avis Officiel de Virement LOC</h3>
                  <p className="text-[10px] text-slate-500 font-mono">{selectedReceipt.reference}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedReceipt(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3 text-xs">
              <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                <span className="text-slate-500">Bénéficiaire :</span>
                <span className="font-bold text-slate-900">{selectedReceipt.beneficiaryName}</span>
              </div>
              <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                <span className="text-slate-500">Montant Net Transféré :</span>
                <span className="font-black font-mono text-emerald-700 text-sm">{formatFCFA(selectedReceipt.amount)}</span>
              </div>
              <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                <span className="text-slate-500">Canal de Règlement :</span>
                <span className="font-bold text-blue-700">{selectedReceipt.payoutMethod}</span>
              </div>
              <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                <span className="text-slate-500">Compte / Numéro :</span>
                <span className="font-mono font-bold text-slate-800">{selectedReceipt.payoutAccount}</span>
              </div>
              <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                <span className="text-slate-500">Réf Transaction Bancaire :</span>
                <span className="font-mono font-bold text-indigo-700">{selectedReceipt.transactionRef || 'WV-882319'}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Date d'Exécution :</span>
                <span className="font-semibold text-slate-800">{selectedReceipt.completedAt || '01 Septembre 2026'}</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                onClick={() => {
                  window.print();
                }}
                className="py-2 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Imprimer l'Avis</span>
              </button>
              <button
                onClick={() => setSelectedReceipt(null)}
                className="py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs cursor-pointer"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
