import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Building2, 
  Wallet, 
  Users, 
  CheckCircle2, 
  ShieldCheck, 
  TrendingUp, 
  Clock, 
  ArrowUpRight, 
  FileText,
  BadgeCheck,
  Search,
  Filter,
  Eye,
  Pencil,
  Sliders,
  DollarSign,
  AlertCircle,
  Share2,
  Download,
  CreditCard,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Trash2,
  Tag,
  Zap,
  RefreshCw,
  Send,
  UserCheck,
  MessageSquare,
  History,
  Sparkles,
  Smartphone,
  Check,
  Receipt,
  Layers,
  ArrowDownRight,
  Calendar
} from 'lucide-react';
import { Property, TenantApplication } from '../../types';
import { formatFCFA, getCurrentPeriod, getNextMonthFirstDay } from '../../utils/finance';
import { ApplicationsList } from '../landlord/ApplicationsList';
import { TransactionDetailModal, CashflowTransaction } from './TransactionDetailModal';

interface AdminPropertyManagementProps {
  properties: Property[];
  applications: TenantApplication[];
  microPayments?: any[];
  receipts?: any[];
  onOpenNewPropertyModal: () => void;
  onApproveApplication: (applicationId: string) => void;
  onRejectApplication: (applicationId: string) => void;
  onOpenLeaseModal: (application: TenantApplication) => void;
  onSelectProperty?: (property: Property) => void;
  onEditProperty?: (property: Property) => void;
  onOpenChatWithClient?: (clientName: string, clientPhone: string, shareText?: string, propertyTitle?: string) => void;
  onApproveProperty?: (propertyId: string) => void;
  onRejectProperty?: (propertyId: string) => void;
  onTogglePropertyAvailability?: (propertyId: string, isAvailable: boolean) => void;
  onDeleteProperty?: (propertyId: string) => void;
}

export const AdminPropertyManagement: React.FC<AdminPropertyManagementProps> = ({
  properties,
  applications,
  microPayments = [],
  receipts = [],
  onOpenNewPropertyModal,
  onApproveApplication,
  onRejectApplication,
  onOpenLeaseModal,
  onSelectProperty,
  onEditProperty,
  onOpenChatWithClient,
  onApproveProperty,
  onRejectProperty,
  onTogglePropertyAvailability,
  onDeleteProperty,
}) => {
  const [subTab, setSubTab] = useState<'properties' | 'tenants' | 'approval' | 'applications' | 'cashflow'>(() => {
    try {
      const saved = localStorage.getItem('ker_admin_property_subtab');
      return (saved as any) || 'properties';
    } catch {
      return 'properties';
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('ker_admin_property_subtab', subTab);
    } catch (e) {
      console.warn('Could not persist admin property subtab:', e);
    }
  }, [subTab]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedNeighborhood, setSelectedNeighborhood] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [availabilityFilter, setAvailabilityFilter] = useState<'all' | 'available' | 'rented'>('all');
  const [selectedTransaction, setSelectedTransaction] = useState<CashflowTransaction | null>(null);

  // Landlord Automated Payouts State
  const [autoPayouts, setAutoPayouts] = useState<Array<{
    id: string;
    landlordName: string;
    companyName?: string;
    avatarText: string;
    avatarBg: string;
    amount: number;
    propertiesCount: number;
    payoutMethod: string;
    account: string;
    status: 'pending' | 'completed';
    lastPayoutDate: string;
    transactionRef?: string;
  }>>(() => {
    try {
      const saved = localStorage.getItem('ker_admin_auto_payouts');
      return saved ? JSON.parse(saved) : [
        {
          id: 'pay-ll-1',
          landlordName: 'Mamadou Diop',
          companyName: 'Teranga Immo',
          avatarText: 'MD',
          avatarBg: 'bg-blue-100 text-blue-700',
          amount: 920000,
          propertiesCount: 6,
          payoutMethod: 'Wave Business',
          account: '+221 77 654 32 10',
          status: 'pending',
          lastPayoutDate: 'Échéance : 01 Sept 2026',
        },
        {
          id: 'pay-ll-2',
          landlordName: 'Cabinet Diouf & Associés',
          avatarText: 'CD',
          avatarBg: 'bg-indigo-100 text-indigo-700',
          amount: 3850000,
          propertiesCount: 14,
          payoutMethod: 'Virement BOA',
          account: 'SN08 0100 1524 0001 2345 6789 12',
          status: 'pending',
          lastPayoutDate: 'Échéance : 01 Sept 2026',
        },
        {
          id: 'pay-ll-3',
          landlordName: 'SCI Keur Gorgui Invest',
          avatarText: 'KG',
          avatarBg: 'bg-purple-100 text-purple-700',
          amount: 6400000,
          propertiesCount: 22,
          payoutMethod: 'Wave Business',
          account: '+221 77 123 45 67',
          status: 'pending',
          lastPayoutDate: 'Échéance : 01 Sept 2026',
        },
      ];
    } catch {
      return [];
    }
  });

  const [executingPayoutId, setExecutingPayoutId] = useState<string | null>(null);
  const [payoutToast, setPayoutToast] = useState<string | null>(null);
  const [tenantSearchQuery, setTenantSearchQuery] = useState('');
  const [expandedTranchesPropId, setExpandedTranchesPropId] = useState<string | null>(null);
  const [reminderSentMap, setReminderSentMap] = useState<Record<string, boolean>>({});
  const [tenantStatusFilter, setTenantStatusFilter] = useState<'all' | 'in_progress' | 'completed'>('all');
  const [viewingReceiptData, setViewingReceiptData] = useState<{
    propTitle: string;
    tenantName: string;
    period: string;
    amountPaid: number;
    totalDue: number;
    tranchesCount: number;
    refNumber: string;
    date: string;
  } | null>(null);

  const handleExecuteSinglePayout = (payoutId: string) => {
    setExecutingPayoutId(payoutId);
    setTimeout(() => {
      const updated = autoPayouts.map(p => {
        if (p.id === payoutId) {
          const now = new Date();
          const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
          return {
            ...p,
            status: 'completed' as const,
            lastPayoutDate: `Viré aujourd'hui à ${timeStr}`,
            transactionRef: `REV-${Math.floor(100000 + Math.random() * 900000)}`,
          };
        }
        return p;
      });
      setAutoPayouts(updated);
      try {
        localStorage.setItem('ker_admin_auto_payouts', JSON.stringify(updated));
      } catch (e) {
        console.warn(e);
      }
      setExecutingPayoutId(null);
      setPayoutToast('Reversement automatisé exécuté avec succès vers le compte du bailleur !');
      setTimeout(() => setPayoutToast(null), 3500);
    }, 800);
  };

  const handleExecuteBatchPayouts = () => {
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const updated = autoPayouts.map(p => ({
      ...p,
      status: 'completed' as const,
      lastPayoutDate: `Viré aujourd'hui à ${timeStr}`,
      transactionRef: `BATCH-REV-${Math.floor(100000 + Math.random() * 900000)}`,
    }));
    setAutoPayouts(updated);
    try {
      localStorage.setItem('ker_admin_auto_payouts', JSON.stringify(updated));
    } catch (e) {
      console.warn(e);
    }
    setPayoutToast('Tous les reversements automatisés ont été virés instantanément !');
    setTimeout(() => setPayoutToast(null), 4000);
  };

  // Managed rents: Sum monthlyRent ONLY for properties with signed lease or approved guarantee
  const activePropertyIds = applications
    .filter(a => a.status === 'lease_signed' || a.status === 'approved')
    .map(a => a.propertyId);

  const managedMonthlyRents = properties
    .filter(p => !p.isAvailable || activePropertyIds.includes(p.id))
    .reduce((sum, p) => sum + p.monthlyRent, 0);

  // Estimated platform potential (all properties on platform)
  const estimatedTotalRents = properties
    .filter(p => p.approvalStatus !== 'rejected')
    .reduce((sum, p) => sum + p.monthlyRent, 0);

  const pendingApplicationsCount = applications.filter(a => a.status === 'pending').length;
  const pendingApprovalProperties = properties.filter(p => p.approvalStatus === 'pending');

  // Real operational cashflow transactions derived from microPayments/receipts
  const realTransactions: CashflowTransaction[] = microPayments.map((pm, idx) => ({
    id: pm.id || `tx-${idx}`,
    reference: `TXN-${pm.id?.slice(-8) || idx}`,
    title: `Versement Micro-tranche ${pm.method || 'Wave/OM'}`,
    type: 'loyer',
    amount: pm.amount || 0,
    date: pm.date || 'Aujourd\'hui',
    time: pm.time || '10:00',
    paymentMethod: pm.method || 'Wave',
    status: pm.status === 'validated' ? 'valide' : 'en_cours',
    clientName: pm.tenantName || 'Locataire LOC',
    clientRole: 'tenant',
    clientPhone: pm.tenantPhone || '+221 77 000 00 00',
    propertyTitle: pm.propertyTitle || 'Bien Immobilier',
    notes: 'Transaction enregistrée en temps réel sur la plateforme.'
  }));

  // Filter properties
  const filteredProperties = properties.filter((p) => {
    const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.neighborhood.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.landlordName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesNeighborhood = selectedNeighborhood === 'all' || p.neighborhood.toLowerCase() === selectedNeighborhood.toLowerCase();
    const matchesType = selectedType === 'all' || p.type === selectedType;
    const matchesAvailability = availabilityFilter === 'all' || (availabilityFilter === 'available' ? p.isAvailable : !p.isAvailable);
    return matchesSearch && matchesNeighborhood && matchesType && matchesAvailability;
  });

  return (
    <div className="space-y-4 text-slate-800">
      {/* Transaction Detail Modal */}
      {selectedTransaction && (
        <TransactionDetailModal
          transaction={selectedTransaction}
          onClose={() => setSelectedTransaction(null)}
          onShareToChat={(clientName, clientPhone, shareText) => {
            if (onOpenChatWithClient) {
              onOpenChatWithClient(clientName, clientPhone, shareText);
            }
            setSelectedTransaction(null);
          }}
        />
      )}
      {/* Overview Metric Cards */}
      <div className="space-y-3">
        {/* Overview Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
          <div className="p-3.5 rounded-2xl bg-white border border-slate-200 space-y-1 shadow-sm">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Parc Immobilier</span>
            <span className="text-lg sm:text-xl font-black text-slate-900 font-mono block">
              {properties.length} Biens
            </span>
            <span className="text-[10px] text-emerald-700 block font-semibold">
              {properties.filter(p => !p.isAvailable).length} Loués • {properties.filter(p => p.isAvailable).length} Disponibles
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-white border border-slate-200 space-y-1 shadow-sm">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Loyers Mensuels Gérés</span>
            <span className="text-lg sm:text-xl font-black text-blue-700 font-mono block">
              {formatFCFA(managedMonthlyRents)}
            </span>
            <span className="text-[10px] text-slate-500 block font-medium truncate">
              {activePropertyIds.length > 0 ? 'Baux/cautions approuvés' : '0 FCFA (Aucun contrat signé)'}
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-white border border-slate-200 space-y-1 shadow-sm">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Potentiel Parc (Est.)</span>
            <span className="text-lg sm:text-xl font-black text-indigo-700 font-mono block">
              {formatFCFA(estimatedTotalRents)}
            </span>
            <span className="text-[10px] text-slate-500 block font-medium">Valeur estimée globale</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-white border border-slate-200 space-y-1 shadow-sm">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Candidatures</span>
            <span className="text-lg sm:text-xl font-black text-amber-700 font-mono block">
              {applications.length}
            </span>
            <span className="text-[10px] text-amber-800 block font-semibold">{pendingApplicationsCount} à instruire</span>
          </div>
        </div>
      </div>

      {/* Sub navigation buttons */}
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 border border-slate-200 rounded-2xl flex-wrap">
          <button
            onClick={() => setSubTab('properties')}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 ${
              subTab === 'properties'
                ? 'bg-white text-blue-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Catalogue ({properties.length})</span>
          </button>

          <button
            onClick={() => setSubTab('tenants')}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 ${
              subTab === 'tenants'
                ? 'bg-white text-emerald-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Biens Loués & Locataires ({properties.filter(p => !p.isAvailable).length})</span>
          </button>

          <button
            onClick={() => setSubTab('approval')}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 relative ${
              subTab === 'approval'
                ? 'bg-white text-amber-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Approbation Biens</span>
            {pendingApprovalProperties.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500 text-white font-black animate-pulse">
                {pendingApprovalProperties.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setSubTab('applications')}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 relative ${
              subTab === 'applications'
                ? 'bg-white text-blue-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Candidatures</span>
            {pendingApplicationsCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500 text-white font-black">
                {pendingApplicationsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setSubTab('cashflow')}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 ${
              subTab === 'cashflow'
                ? 'bg-white text-blue-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Wallet className="w-3.5 h-3.5" />
            <span>Flux & Reversements ({realTransactions.length})</span>
          </button>
        </div>

        <button
          onClick={onOpenNewPropertyModal}
          className="py-2 px-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all ml-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Ajouter un Bien</span>
        </button>
      </div>

      {/* VIEW 1: PROPERTIES CATALOG */}
      {subTab === 'properties' && (
        <div className="space-y-3">
          {/* Search and Filters Bar */}
          <div className="p-3 bg-white border border-slate-200 rounded-2xl flex items-center gap-2 flex-wrap shadow-sm">
            <div className="flex-1 min-w-[200px] relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Rechercher par titre, quartier, bailleur..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="flex items-center gap-2">
              <select
                value={availabilityFilter}
                onChange={(e) => setAvailabilityFilter(e.target.value as any)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-700 font-bold focus:outline-none"
              >
                <option value="all">Tous statuts (Dispo & Loués)</option>
                <option value="available">🟢 Biens Disponibles ({properties.filter(p => p.isAvailable).length})</option>
                <option value="rented">💙 Biens Loués (Bail Actif) ({properties.filter(p => !p.isAvailable).length})</option>
              </select>

              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-700 focus:outline-none"
              >
                <option value="all">Tous types</option>
                <option value="chambre">Chambre</option>
                <option value="studio">Studio</option>
                <option value="appartement">Appartement</option>
                <option value="villa">Villa</option>
              </select>

              <select
                value={selectedNeighborhood}
                onChange={(e) => setSelectedNeighborhood(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-700 focus:outline-none"
              >
                <option value="all">Tous quartiers</option>
                <option value="Almadies">Almadies</option>
                <option value="Mermoz">Mermoz</option>
                <option value="Plateau">Plateau</option>
                <option value="Fann Résidence">Fann</option>
                <option value="Yoff">Yoff</option>
                <option value="Ouakam">Ouakam</option>
              </select>
            </div>
          </div>

          {/* Properties Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filteredProperties.map((prop) => (
              <div
                key={prop.id}
                className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3 hover:border-slate-300 transition-all shadow-sm"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-3">
                    <img
                      src={prop.images[0]}
                      alt={prop.title}
                      className="w-16 h-16 rounded-xl object-cover border border-slate-200 shrink-0"
                    />
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1.5">
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200 uppercase">
                          {prop.typeLabel}
                        </span>
                        <span className="text-[10px] text-slate-500">
                          {prop.surface} m² • {prop.rooms} pièce(s)
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-slate-900 line-clamp-1">{prop.title}</h4>
                      <p className="text-[11px] text-slate-500 line-clamp-1 font-medium">{prop.address}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {onTogglePropertyAvailability && (
                      <button
                        onClick={() => onTogglePropertyAvailability(prop.id, !prop.isAvailable)}
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold border transition-all cursor-pointer ${
                          prop.isAvailable
                            ? 'bg-emerald-100 text-emerald-800 border-emerald-200 hover:bg-emerald-200'
                            : 'bg-amber-100 text-amber-800 border-amber-200 hover:bg-amber-200'
                        }`}
                        title="Cliquer pour changer la disponibilité"
                      >
                        {prop.isAvailable ? '🟢 Disponible' : '🟠 Loué'}
                      </button>
                    )}
                    {!onTogglePropertyAvailability && (
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                        prop.isAvailable ? 'bg-emerald-100 text-emerald-800 border-emerald-200' : 'bg-amber-100 text-amber-800 border-amber-200'
                      }`}>
                        {prop.isAvailable ? 'Disponible' : 'Loué'}
                      </span>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-center text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Loyer Mensuel</span>
                    <span className="font-extrabold text-slate-900 font-mono">{formatFCFA(prop.monthlyRent)}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Package Caution</span>
                    <span className="font-extrabold text-blue-700 font-mono">{prop.totalPackageMonths} mois</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Bailleur</span>
                    <span className="font-semibold text-slate-700 truncate block text-[11px]">
                      {prop.landlordName.split(' ')[0]}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-xs">
                  <span className="text-[10px] text-slate-500 font-mono">
                    Réf: {prop.refNumber || prop.id}
                  </span>
                  <div className="flex items-center gap-1.5">
                    {prop.approvalStatus === 'pending' && onApproveProperty && (
                      <button
                        onClick={() => onApproveProperty(prop.id)}
                        className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold flex items-center gap-1 transition-all"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Valider</span>
                      </button>
                    )}
                    {onEditProperty && (
                      <button
                        onClick={() => onEditProperty(prop)}
                        className="px-2 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs flex items-center gap-1 font-semibold transition-all border border-amber-200"
                        title="Modifier la fiche du bien"
                      >
                        <Pencil className="w-3.5 h-3.5 text-amber-600" />
                        <span>Éditer</span>
                      </button>
                    )}
                    {onSelectProperty && (
                      <button
                        onClick={() => onSelectProperty(prop)}
                        className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs flex items-center gap-1 font-semibold transition-all"
                        title="Voir la fiche détaillée"
                      >
                        <Eye className="w-3.5 h-3.5 text-blue-600" />
                        <span>Fiche</span>
                      </button>
                    )}
                    {onDeleteProperty && (
                      <button
                        onClick={() => {
                          if (window.confirm(`Êtes-vous sûr de vouloir supprimer le bien "${prop.title}" (${prop.refNumber || prop.id}) ?`)) {
                            onDeleteProperty(prop.id);
                          }
                        }}
                        className="p-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 text-xs flex items-center gap-1 font-semibold transition-all border border-red-200"
                        title="Supprimer le bien du catalogue"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-red-600" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* VIEW: TENANTS & RENTED PROPERTIES MANAGEMENT (Rent Progression & Leases) */}
      {subTab === 'tenants' && (() => {
        const currentPeriod = getCurrentPeriod();
        const rentedProperties = properties.filter(p => !p.isAvailable);

        // Calculate global collection stats
        let totalDueAll = 0;
        let totalCollectedAll = 0;

        rentedProperties.forEach((prop, idx) => {
          const isDemoProp = prop.id === 'prop-5' || prop.monthlyRent === 100000;
          const depositInstallment = Math.round((prop.monthlyRent * 2) / 6);
          const totalDue = isDemoProp ? 133333 : prop.monthlyRent + (prop.depositMonths ? depositInstallment : 0);
          
          let amountPaid = 0;
          if (isDemoProp) {
            const completed = microPayments.filter(m => m.status === 'completed' && (m.forMonth === currentPeriod || !m.forMonth));
            amountPaid = completed.reduce((acc, p) => acc + (p.amount || 0), 0);
          } else {
            amountPaid = idx % 2 === 0 ? prop.monthlyRent : Math.round(prop.monthlyRent * 0.6);
          }

          totalDueAll += totalDue;
          totalCollectedAll += amountPaid;
        });

        const globalRecoveryRate = totalDueAll > 0 ? Math.min(100, Math.round((totalCollectedAll / totalDueAll) * 100)) : 0;

        // Filter rented properties
        const displayedRentedProps = rentedProperties.filter((prop, idx) => {
          const query = tenantSearchQuery.toLowerCase().trim();
          const app = applications.find(a => a.propertyId === prop.id) || {
            tenantName: idx % 2 === 0 ? 'Seydou Sall' : 'Awa Fall',
            tenantPhone: idx % 2 === 0 ? '+221 77 452 11 00' : '+221 78 890 33 22',
          };

          const isDemoProp = prop.id === 'prop-5' || prop.monthlyRent === 100000;
          const depositInstallment = Math.round((prop.monthlyRent * 2) / 6);
          const totalDue = isDemoProp ? 133333 : prop.monthlyRent + (prop.depositMonths ? depositInstallment : 0);
          let amountPaid = 0;
          if (isDemoProp) {
            const completed = microPayments.filter(m => m.status === 'completed' && (m.forMonth === currentPeriod || !m.forMonth));
            amountPaid = completed.reduce((acc, p) => acc + (p.amount || 0), 0);
          } else {
            amountPaid = idx % 2 === 0 ? prop.monthlyRent : Math.round(prop.monthlyRent * 0.6);
          }
          const isFullyPaid = amountPaid >= totalDue;

          if (tenantStatusFilter === 'in_progress' && isFullyPaid) return false;
          if (tenantStatusFilter === 'completed' && !isFullyPaid) return false;

          if (!query) return true;
          return (
            prop.title.toLowerCase().includes(query) ||
            prop.neighborhood.toLowerCase().includes(query) ||
            (prop.refNumber && prop.refNumber.toLowerCase().includes(query)) ||
            prop.id.toLowerCase().includes(query) ||
            (app.tenantName && app.tenantName.toLowerCase().includes(query)) ||
            (app.tenantPhone && app.tenantPhone.toLowerCase().includes(query))
          );
        });

        return (
          <div className="space-y-5">
            {/* Header & Global Collection Dashboard */}
            <div className="p-5 rounded-3xl bg-linear-to-br from-slate-900 to-slate-800 text-white shadow-md border border-slate-700/60 space-y-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Période en cours : {currentPeriod}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30 flex items-center gap-1">
                      <Zap className="w-3 h-3 text-blue-400" />
                      Paiements par tranches actifs
                    </span>
                  </div>
                  <h3 className="text-base font-black text-white flex items-center gap-2">
                    <UserCheck className="w-5 h-5 text-emerald-400" />
                    <span>Suivi des Biens Loués & Progression des Loyers Locataires</span>
                  </h3>
                  <p className="text-xs text-slate-300 font-medium">
                    Visualisez en direct l'encaissement des loyers par micro-versements (Wave, Orange Money) et les soldes restants.
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <div className="text-right pr-3 border-r border-slate-700">
                    <span className="text-[10px] text-slate-400 font-bold uppercase block">Recouvrement</span>
                    <span className="text-lg font-black text-emerald-400 font-mono">{globalRecoveryRate}%</span>
                  </div>
                  <span className="px-3.5 py-2 rounded-2xl text-xs font-black bg-emerald-500 text-slate-950 font-mono shadow-sm">
                    {rentedProperties.length} Baux Gérés
                  </span>
                </div>
              </div>

              {/* 4 Summary KPIs */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 pt-2 border-t border-slate-700/80 text-xs">
                <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/60">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">Total Loyers Exigibles</span>
                  <span className="text-sm font-black text-white font-mono mt-0.5 block">{formatFCFA(totalDueAll)}</span>
                  <span className="text-[10px] text-slate-400 mt-0.5 block">{currentPeriod}</span>
                </div>

                <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/60">
                  <span className="text-[10px] font-bold text-emerald-400 uppercase block">Total Déjà Encaissé</span>
                  <span className="text-sm font-black text-emerald-400 font-mono mt-0.5 block">{formatFCFA(totalCollectedAll)}</span>
                  <span className="text-[10px] text-emerald-300/80 mt-0.5 block">Via Micro-versements</span>
                </div>

                <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/60">
                  <span className="text-[10px] font-bold text-amber-400 uppercase block">Solde Restant à Collecter</span>
                  <span className="text-sm font-black text-amber-400 font-mono mt-0.5 block">{formatFCFA(Math.max(0, totalDueAll - totalCollectedAll))}</span>
                  <span className="text-[10px] text-amber-300/80 mt-0.5 block">Échéance fin de mois</span>
                </div>

                <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/60">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-bold text-blue-400 uppercase">Taux d'Encaissement</span>
                    <span className="text-xs font-black text-blue-300 font-mono">{globalRecoveryRate}%</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-2 overflow-hidden">
                    <div 
                      className="bg-linear-to-r from-blue-500 to-emerald-400 h-full rounded-full transition-all duration-500"
                      style={{ width: `${globalRecoveryRate}%` }}
                    />
                  </div>
                  <span className="text-[9px] text-slate-400 mt-1 block">Zéro retard enregistré</span>
                </div>
              </div>
            </div>

            {/* Search and Filters Bar */}
            <div className="bg-white border border-slate-200 rounded-2xl p-3 shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Rechercher bien loué, quartier, réf, locataire, téléphone..."
                  value={tenantSearchQuery}
                  onChange={(e) => setTenantSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 focus:outline-none focus:border-emerald-500 font-medium"
                />
              </div>

              {/* Status Filter Buttons */}
              <div className="flex items-center gap-1.5 shrink-0 overflow-x-auto pb-1 sm:pb-0">
                <button
                  onClick={() => setTenantStatusFilter('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    tenantStatusFilter === 'all'
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  Tous ({rentedProperties.length})
                </button>
                <button
                  onClick={() => setTenantStatusFilter('in_progress')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    tenantStatusFilter === 'in_progress'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-blue-50 text-blue-800 hover:bg-blue-100 border border-blue-200'
                  }`}
                >
                  <Zap className="w-3 h-3 text-amber-300" />
                  <span>En cours de fractionnement</span>
                </button>
                <button
                  onClick={() => setTenantStatusFilter('completed')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    tenantStatusFilter === 'completed'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200'
                  }`}
                >
                  <CheckCircle2 className="w-3 h-3" />
                  <span>100% Soldés</span>
                </button>
              </div>
            </div>

            {/* List of Rented Properties with Tenant Rent Progress */}
            {displayedRentedProps.length === 0 ? (
              <div className="p-8 text-center bg-white border border-slate-200 rounded-3xl space-y-2">
                <AlertCircle className="w-8 h-8 text-slate-400 mx-auto" />
                <h4 className="text-sm font-bold text-slate-700">Aucun bien ne correspond aux filtres sélectionnés</h4>
                <p className="text-xs text-slate-500">Modifiez votre recherche ou réinitialisez les filtres.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                {displayedRentedProps.map((prop, idx) => {
                  const isDemoProp = prop.id === 'prop-5' || prop.monthlyRent === 100000;
                  const depositInstallment = Math.round((prop.monthlyRent * 2) / 6);
                  const totalDue = isDemoProp ? 133333 : prop.monthlyRent + (prop.depositMonths ? depositInstallment : 0);
                  
                  // App details
                  const app = applications.find(a => a.propertyId === prop.id) || {
                    tenantName: idx % 2 === 0 ? 'Seydou Sall' : 'Awa Fall',
                    tenantPhone: idx % 2 === 0 ? '+221 77 452 11 00' : '+221 78 890 33 22',
                    monthlyIncome: prop.monthlyRent * 3.5,
                    employmentStatus: idx % 2 === 0 ? 'CDI - Cadre Télécoms' : 'Fonctionnaire d\'État',
                    solvencyScore: 96,
                  };

                  // Retrieve specific micro-payments
                  let propPayments: any[] = [];
                  let amountPaid = 0;

                  if (isDemoProp) {
                    propPayments = microPayments.filter(m => m.status === 'completed' && (m.forMonth === currentPeriod || !m.forMonth));
                    amountPaid = propPayments.reduce((acc, p) => acc + (p.amount || 0), 0);
                  } else {
                    // Pre-seeded fallback tranches for display realism
                    if (idx % 2 === 0) {
                      amountPaid = prop.monthlyRent;
                      propPayments = [
                        { id: `demo-p-${prop.id}-1`, amount: prop.monthlyRent / 2, method: 'Wave', date: '01 Sept. 2026', time: '08:30', status: 'completed' },
                        { id: `demo-p-${prop.id}-2`, amount: prop.monthlyRent / 2, method: 'Orange Money', date: '02 Sept. 2026', time: '11:15', status: 'completed' },
                      ];
                    } else {
                      amountPaid = Math.round(prop.monthlyRent * 0.6);
                      propPayments = [
                        { id: `demo-p-${prop.id}-1`, amount: amountPaid, method: 'Wave', date: '01 Sept. 2026', time: '14:20', status: 'completed' },
                      ];
                    }
                  }

                  const progressPct = Math.min(100, Math.round((amountPaid / totalDue) * 100));
                  const remainingDue = Math.max(0, totalDue - amountPaid);
                  const isFullyPaid = progressPct >= 100;
                  const isExpanded = expandedTranchesPropId === prop.id;
                  const reminderSent = reminderSentMap[prop.id];

                  return (
                    <div 
                      key={prop.id} 
                      className={`bg-white border rounded-3xl p-5 space-y-4 shadow-xs transition-all hover:shadow-md ${
                        isFullyPaid ? 'border-emerald-200' : 'border-blue-200'
                      }`}
                    >
                      {/* Property Header */}
                      <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <img
                            src={prop.images[0]}
                            alt={prop.title}
                            className="w-14 h-14 rounded-2xl object-cover border border-slate-200 shrink-0 shadow-xs"
                          />
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-emerald-100 text-emerald-900 border border-emerald-200 uppercase">
                                Bail Actif (Occupé)
                              </span>
                              <span className="text-[10px] text-slate-400 font-mono font-semibold">
                                {prop.refNumber || prop.id}
                              </span>
                            </div>
                            <h4 className="text-sm font-bold text-slate-900 line-clamp-1 mt-0.5">{prop.title}</h4>
                            <p className="text-xs text-slate-500 font-medium">{prop.neighborhood} • Propriétaire : {prop.landlordName || 'Teranga Immo'}</p>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <span className="text-[10px] text-slate-400 uppercase font-bold block">Loyer Mensuel</span>
                          <span className="text-sm font-black text-blue-700 font-mono">{formatFCFA(prop.monthlyRent)}</span>
                        </div>
                      </div>

                      {/* Tenant Identity Block */}
                      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 space-y-2.5">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs shadow-xs shrink-0">
                              {app.tenantName?.[0] || 'L'}
                            </div>
                            <div className="min-w-0">
                              <h5 className="text-xs font-bold text-slate-900 truncate">{app.tenantName || 'Locataire Enregistré'}</h5>
                              <span className="text-[10px] text-slate-500 font-mono">{app.tenantPhone || '+221 77 000 00 00'}</span>
                            </div>
                          </div>

                          <span className="px-2.5 py-1 rounded-xl bg-emerald-100 text-emerald-800 text-[10px] font-black border border-emerald-200 flex items-center gap-1 shrink-0">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            Solvable ({app.solvencyScore || 96}%)
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-[11px] pt-1.5 border-t border-slate-200/60">
                          <div>
                            <span className="text-slate-400 block text-[9px] uppercase font-semibold">Statut Pro</span>
                            <strong className="text-slate-800 font-medium truncate block">{app.employmentStatus || 'CDI'}</strong>
                          </div>
                          <div>
                            <span className="text-slate-400 block text-[9px] uppercase font-semibold">Revenus Certifiés</span>
                            <strong className="text-slate-900 font-mono">{formatFCFA(app.monthlyIncome || prop.monthlyRent * 3.5)}</strong>
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 text-xs">
                          <span className="text-[10px] text-slate-600 font-medium flex items-center gap-1">
                            <FileText className="w-3.5 h-3.5 text-blue-600" />
                            Bail Numérique OHADA signé
                          </span>
                          <button
                            onClick={() => alert(`Contrat de bail certifié LOC conforme OHADA pour le logement ${prop.title}.\nLocataire: ${app.tenantName}\nDate d'effet: 01 Septembre 2026\nCaution gérée via LOC.`)}
                            className="px-2.5 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-[10px] transition-all border border-blue-200 cursor-pointer"
                          >
                            Voir Contrat PDF
                          </button>
                        </div>
                      </div>

                      {/* --- PROGRESSION DU LOYER (CORE FEATURE) --- */}
                      <div className={`p-4 rounded-2xl border transition-all ${
                        isFullyPaid 
                          ? 'bg-emerald-50/70 border-emerald-200' 
                          : 'bg-blue-50/70 border-blue-200'
                      }`}>
                        {/* Progress Header */}
                        <div className="flex items-center justify-between gap-2 mb-2">
                          <div className="flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-blue-700" />
                            <span className="text-xs font-bold text-slate-900">
                              Loyer {currentPeriod}
                            </span>
                          </div>

                          {isFullyPaid ? (
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-200 text-emerald-900 border border-emerald-300 flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                              100% Soldé
                            </span>
                          ) : (
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-blue-200 text-blue-900 border border-blue-300 flex items-center gap-1">
                              <Zap className="w-3 h-3 text-amber-500 animate-pulse" />
                              En cours ({progressPct}%)
                            </span>
                          )}
                        </div>

                        {/* Progress Bar with Gradient */}
                        <div className="space-y-1.5 mb-3">
                          <div className="w-full bg-slate-200 rounded-full h-3 overflow-hidden p-0.5 shadow-inner">
                            <div 
                              className={`h-full rounded-full transition-all duration-500 ${
                                isFullyPaid
                                  ? 'bg-linear-to-r from-emerald-500 to-emerald-600'
                                  : 'bg-linear-to-r from-blue-500 to-indigo-600'
                              }`}
                              style={{ width: `${progressPct}%` }}
                            />
                          </div>

                          <div className="flex items-center justify-between text-[10px] text-slate-500 font-medium">
                            <span>0 FCFA</span>
                            <span className="font-bold text-slate-700">{progressPct}% complété</span>
                            <span>{formatFCFA(totalDue)}</span>
                          </div>
                        </div>

                        {/* 3-Column Financial Breakdown */}
                        <div className="grid grid-cols-3 gap-2 p-2.5 rounded-xl bg-white/90 border border-slate-200/80 text-center shadow-2xs">
                          <div className="border-r border-slate-100 pr-1">
                            <span className="text-[9px] uppercase font-bold text-slate-400 block">Déjà Versé</span>
                            <span className="text-xs font-black text-emerald-700 font-mono block">
                              {formatFCFA(amountPaid)}
                            </span>
                            <span className="text-[9px] text-emerald-600 font-semibold">
                              {propPayments.length} tranche(s)
                            </span>
                          </div>

                          <div className="border-r border-slate-100 px-1">
                            <span className="text-[9px] uppercase font-bold text-slate-400 block">Total Exigible</span>
                            <span className="text-xs font-black text-slate-900 font-mono block">
                              {formatFCFA(totalDue)}
                            </span>
                            <span className="text-[9px] text-slate-500">
                              Loyer + Caution
                            </span>
                          </div>

                          <div className="pl-1">
                            <span className="text-[9px] uppercase font-bold text-slate-400 block">Reste à Payer</span>
                            <span className={`text-xs font-black font-mono block ${
                              remainingDue === 0 ? 'text-emerald-700' : 'text-amber-700'
                            }`}>
                              {formatFCFA(remainingDue)}
                            </span>
                            <span className="text-[9px] text-slate-500">
                              {remainingDue === 0 ? 'Soldé' : 'Avant le 30'}
                            </span>
                          </div>
                        </div>

                        {/* Expandable Tranches History */}
                        <div className="mt-3 pt-2.5 border-t border-slate-200/80">
                          <button
                            type="button"
                            onClick={() => setExpandedTranchesPropId(isExpanded ? null : prop.id)}
                            className="w-full flex items-center justify-between text-xs font-bold text-slate-700 hover:text-slate-900 transition-colors cursor-pointer py-1"
                          >
                            <span className="flex items-center gap-1.5">
                              <History className="w-3.5 h-3.5 text-blue-600" />
                              <span>Détail des micro-versements reçus ({propPayments.length})</span>
                            </span>
                            {isExpanded ? (
                              <ChevronUp className="w-4 h-4 text-slate-400" />
                            ) : (
                              <ChevronDown className="w-4 h-4 text-slate-400" />
                            )}
                          </button>

                          {isExpanded && (
                            <div className="mt-2 space-y-1.5 pt-1">
                              {propPayments.length === 0 ? (
                                <p className="text-[11px] text-slate-500 italic text-center py-2">
                                  Aucun versement enregistré pour ce mois.
                                </p>
                              ) : (
                                propPayments.map((p: any, pIdx: number) => {
                                  const isWave = (p.method || '').toLowerCase().includes('wave');
                                  const isOM = (p.method || '').toLowerCase().includes('orange');

                                  return (
                                    <div 
                                      key={p.id || pIdx} 
                                      className="flex items-center justify-between p-2 rounded-xl bg-white border border-slate-200/80 text-xs shadow-2xs"
                                    >
                                      <div className="flex items-center gap-2">
                                        <div className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] font-black text-white shrink-0 ${
                                          isWave ? 'bg-sky-500' : isOM ? 'bg-orange-500' : 'bg-blue-600'
                                        }`}>
                                          {isWave ? 'W' : isOM ? 'OM' : 'K'}
                                        </div>
                                        <div>
                                          <div className="font-bold text-slate-800 text-[11px]">
                                            Tranche #{pIdx + 1} • {p.method || 'Mobile Money'}
                                          </div>
                                          <span className="text-[10px] text-slate-400 font-mono">
                                            {p.date || '02 Sept. 2026'} {p.time ? `à ${p.time}` : ''}
                                          </span>
                                        </div>
                                      </div>

                                      <div className="text-right">
                                        <span className="text-xs font-black text-emerald-700 font-mono block">
                                          +{formatFCFA(p.amount)}
                                        </span>
                                        <span className="text-[9px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.2 rounded-md border border-emerald-200">
                                          Validé
                                        </span>
                                      </div>
                                    </div>
                                  );
                                })
                              )}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center justify-between gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => {
                            setViewingReceiptData({
                              propTitle: prop.title,
                              tenantName: app.tenantName || 'Locataire Enregistré',
                              period: currentPeriod,
                              amountPaid: amountPaid,
                              totalDue: totalDue,
                              tranchesCount: propPayments.length,
                              refNumber: `QUIT-${prop.id.toUpperCase()}-202609`,
                              date: '02 Septembre 2026'
                            });
                          }}
                          className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                        >
                          <Receipt className="w-3.5 h-3.5 text-slate-600" />
                          <span>Quittance LOC</span>
                        </button>

                        <div className="flex items-center gap-1.5">
                          {/* Send Reminder / Acknowledgement button */}
                          <button
                            type="button"
                            onClick={() => {
                              const relanceMsg = isFullyPaid
                                ? `[QUITTANCE / REÇU LOC] Bonjour ${app.tenantName}, nous vous confirmons la bonne réception intégrale de votre loyer de ${currentPeriod} (${formatFCFA(amountPaid)}) pour le logement "${prop.title}". Votre solde est à 100% régularisé. Merci pour votre sérieux et votre ponctualité !`
                                : `[RELANCE SOLDE LOC] Bonjour ${app.tenantName}, rappel amical concernant votre loyer de ${currentPeriod} pour le logement "${prop.title}". Montant exigible : ${formatFCFA(totalDue)}, déjà versé : ${formatFCFA(amountPaid)}. Reste à régler : ${formatFCFA(remainingDue)}. Vous pouvez effectuer votre micro-versement par Wave ou Orange Money depuis votre espace.`;

                              setReminderSentMap(prev => ({ ...prev, [prop.id]: true }));
                              setTimeout(() => {
                                setReminderSentMap(prev => ({ ...prev, [prop.id]: false }));
                              }, 4000);

                              if (onOpenChatWithClient) {
                                onOpenChatWithClient(
                                  app.tenantName || 'Locataire',
                                  app.tenantPhone || '+221 77 000 00 00',
                                  relanceMsg,
                                  prop.title
                                );
                              }
                            }}
                            className={`px-3 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer border ${
                              reminderSent
                                ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                                : 'bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200'
                            }`}
                          >
                            {reminderSent ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-emerald-600" />
                                <span>{isFullyPaid ? 'Quittance Envoyée (Chat)' : 'Relance Envoyée (Chat)'}</span>
                              </>
                            ) : (
                              <>
                                <Send className="w-3.5 h-3.5 text-blue-600" />
                                <span>{isFullyPaid ? 'Envoyer Reçu' : 'Relancer Solde'}</span>
                              </>
                            )}
                          </button>

                          {/* Contact Tenant Chat button */}
                          <button
                            type="button"
                            onClick={() => {
                              if (onOpenChatWithClient) {
                                onOpenChatWithClient(
                                  app.tenantName || 'Locataire', 
                                  app.tenantPhone || '+221 77 000 00 00', 
                                  `Bonjour ${app.tenantName}, point sur le loyer de ${currentPeriod} (${formatFCFA(amountPaid)} versés sur ${formatFCFA(totalDue)}) pour le logement "${prop.title}".`,
                                  prop.title
                                );
                              }
                            }}
                            className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                          >
                            <MessageSquare className="w-3.5 h-3.5 text-blue-400" />
                            <span>Contacter</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Official LOC Receipt Modal */}
            {viewingReceiptData && (
              <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
                <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-slate-200 relative animate-in fade-in zoom-in-95">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-black text-sm shadow-xs">
                        K
                      </div>
                      <div>
                        <h4 className="text-sm font-black text-slate-900">Quittance Numérique Certifiée</h4>
                        <span className="text-[10px] text-slate-400 font-mono">{viewingReceiptData.refNumber}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => setViewingReceiptData(null)}
                      className="w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center text-xs font-bold transition-all cursor-pointer"
                    >
                      ✕
                    </button>
                  </div>

                  <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-2 text-xs">
                    <div className="flex justify-between text-slate-600">
                      <span>Locataire :</span>
                      <strong className="text-slate-900">{viewingReceiptData.tenantName}</strong>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>Logement :</span>
                      <strong className="text-slate-900">{viewingReceiptData.propTitle}</strong>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>Période :</span>
                      <strong className="text-slate-900">{viewingReceiptData.period}</strong>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>Nombre de tranches :</span>
                      <strong className="text-slate-900">{viewingReceiptData.tranchesCount} micro-versement(s)</strong>
                    </div>
                    <div className="pt-2 border-t border-emerald-200/80 flex justify-between text-sm">
                      <span className="font-bold text-emerald-950">Montant Encaissé :</span>
                      <strong className="font-black text-emerald-700 font-mono">{formatFCFA(viewingReceiptData.amountPaid)}</strong>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-500 text-center italic">
                    Document légal certifié conforme OHADA et horodaté par la plateforme LOC le {viewingReceiptData.date}.
                  </p>

                  <div className="flex gap-2 pt-2">
                    <button
                      onClick={() => {
                        alert(`Téléchargement de la quittance ${viewingReceiptData.refNumber} au format PDF certifié...`);
                        setViewingReceiptData(null);
                      }}
                      className="flex-1 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition-all shadow-xs cursor-pointer text-center"
                    >
                      Télécharger PDF Certifié
                    </button>
                    <button
                      onClick={() => setViewingReceiptData(null)}
                      className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-all cursor-pointer"
                    >
                      Fermer
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      })()}
      {subTab === 'approval' && (
        <div className="space-y-4">
          <div className="p-4 rounded-3xl bg-amber-50 border border-amber-200 flex items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-amber-900">Approbation Préalable des Biens Immobiliers</h3>
              <p className="text-xs text-amber-700 font-medium">
                Validation obligatoire par l'administration LOC avant parution sur le catalogue officiel.
              </p>
            </div>
            <span className="px-3 py-1 rounded-full text-xs font-black bg-amber-200 text-amber-900 font-mono shrink-0">
              {pendingApprovalProperties.length} en attente
            </span>
          </div>

          {pendingApprovalProperties.length === 0 ? (
            <div className="p-8 text-center bg-white border border-slate-200 rounded-3xl space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
              <h4 className="font-bold text-slate-800 text-sm">Toutes les annonces sont vérifiées</h4>
              <p className="text-xs text-slate-500">Aucun bien immobilier en attente d'approbation pour le moment.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pendingApprovalProperties.map((p) => (
                <div key={p.id} className="p-4 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-3">
                  <div className="flex gap-3">
                    <img src={p.images[0]} alt={p.title} className="w-24 h-20 rounded-2xl object-cover shrink-0 border border-slate-200" />
                    <div className="space-y-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                          ⏳ Attente Validation
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono font-bold">
                          {p.refNumber || p.id}
                        </span>
                      </div>
                      <h4 className="font-extrabold text-slate-900 text-xs truncate">{p.title}</h4>
                      <p className="text-xs text-slate-500 font-medium">{p.neighborhood}, Dakar • {p.typeLabel}</p>
                      <p className="text-xs font-mono font-black text-blue-700">{formatFCFA(p.monthlyRent)}/mois</p>
                    </div>
                  </div>

                  <div className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-2xl space-y-1 border border-slate-100">
                    <p><strong>Bailleur / Mandataire:</strong> {p.landlordName} ({p.landlordPhone})</p>
                    <p className="line-clamp-2 text-[11px] text-slate-500">{p.description}</p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    {onSelectProperty && (
                      <button
                        onClick={() => onSelectProperty(p)}
                        className="py-2 px-3 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-800 font-bold text-xs border border-blue-200 flex items-center justify-center gap-1.5 transition-all"
                        title="Consulter la fiche complète du bien avant approbation"
                      >
                        <Eye className="w-3.5 h-3.5 text-blue-600" />
                        <span>Consulter Fiche</span>
                      </button>
                    )}
                    <button
                      onClick={() => onApproveProperty && onApproveProperty(p.id)}
                      className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-sm"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      Approuver & Publier
                    </button>
                    <button
                      onClick={() => onRejectProperty && onRejectProperty(p.id)}
                      className="py-2 px-3 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs border border-red-200 flex items-center justify-center gap-1 transition-all"
                    >
                      Rejeter
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* VIEW 2: APPLICATIONS & LEASES */}
      {subTab === 'applications' && (
        <div className="space-y-3">
          <div className="p-3 bg-blue-50 border border-blue-200 rounded-2xl flex items-center justify-between text-xs text-blue-900">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
              L'approbation d'une candidature génère automatiquement le bail certifié conforme OHADA avec étalement de caution.
            </span>
          </div>

          <ApplicationsList
            applications={applications}
            onApprove={onApproveApplication}
            onReject={onRejectApplication}
            onOpenLease={onOpenLeaseModal}
            isAdminView={true}
          />
        </div>
      )}

      {/* VIEW 3: CASHFLOWS & PAYOUTS */}
      {subTab === 'cashflow' && (
        <div className="space-y-4">
          {/* Operational Transactions List */}
          <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Historique des Flux & Versements de Caution</h3>
                <p className="text-xs text-slate-500 font-medium">Cliquez sur une transaction pour afficher les détails, télécharger le reçu ou le partager sur le Chat client</p>
              </div>
              <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-200 font-mono">
                {realTransactions.length} Transactions
              </span>
            </div>

            <div className="space-y-2">
              {realTransactions.length === 0 ? (
                <div className="p-8 text-center bg-slate-50 border border-slate-200 rounded-2xl space-y-2">
                  <Wallet className="w-8 h-8 text-slate-300 mx-auto" />
                  <p className="text-xs font-bold text-slate-700">Aucune transaction enregistrée</p>
                  <p className="text-[11px] text-slate-500">Les versements de micro-tranches, cautions et loyers apparaîtront ici en temps réel.</p>
                </div>
              ) : (
                realTransactions.map((tx) => (
                  <div
                    key={tx.id}
                    onClick={() => setSelectedTransaction(tx)}
                    className="p-3.5 rounded-2xl bg-slate-50 hover:bg-blue-50/60 border border-slate-200 hover:border-blue-300 transition-all cursor-pointer flex items-center justify-between gap-3 text-xs group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold shrink-0 ${
                        tx.type === 'reversement_bailleur' || tx.type === 'indemnisation_fonds'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : 'bg-blue-100 text-blue-800 border border-blue-200'
                      }`}>
                        <CreditCard className="w-4 h-4" />
                      </div>

                      <div className="space-y-0.5 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-slate-900 group-hover:text-blue-700 transition-colors truncate">
                            {tx.title}
                          </span>
                          <span className="text-[10px] px-2 py-0.2 rounded bg-white text-slate-600 font-mono border border-slate-200 shrink-0">
                            {tx.reference}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 truncate font-medium">
                          {tx.clientName} • {tx.paymentMethod} • {tx.propertyTitle}
                        </p>
                      </div>
                    </div>

                    <div className="text-right shrink-0 flex items-center gap-2">
                      <div>
                        <span className="font-mono font-black text-slate-900 block text-xs sm:text-sm">
                          {formatFCFA(tx.amount)}
                        </span>
                        <span className="text-[10px] text-slate-400 block font-mono">
                          {tx.date} à {tx.time}
                        </span>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-all" />
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* REVERSEMENTS BAILLEURS AUTOMATISÉS INTERACTIFS */}
          <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-3">
            {payoutToast && (
              <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-center gap-2 animate-fade-in shadow-xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{payoutToast}</span>
              </div>
            )}

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <span>Tableau des Reversements Bailleurs Automatisés</span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                    Interactif
                  </span>
                </h3>
                <p className="text-xs text-slate-500 font-medium">Cycle de reversement Wave / Virement bancaire au 1er & 5 du mois</p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleExecuteBatchPayouts}
                  className="py-1.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer hover:scale-105"
                >
                  <Zap className="w-3.5 h-3.5 text-amber-300" />
                  <span>Déclencher Tous les Reversements</span>
                </button>
              </div>
            </div>

            <div className="space-y-2.5">
              {autoPayouts.map((payout) => {
                const isExecuting = executingPayoutId === payout.id;
                const isCompleted = payout.status === 'completed';

                return (
                  <div
                    key={payout.id}
                    className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 hover:border-slate-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-2xl ${payout.avatarBg} flex items-center justify-center font-bold text-sm shrink-0 shadow-xs`}>
                        {payout.avatarText}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-bold text-slate-900">{payout.landlordName}</span>
                          {payout.companyName && (
                            <span className="text-[10px] text-slate-500 font-medium">({payout.companyName})</span>
                          )}
                        </div>
                        <span className="text-[11px] text-slate-500 font-medium block">
                          {payout.payoutMethod} • {payout.propertiesCount} biens sous gestion • {payout.account}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-200/60">
                      <div className="text-left sm:text-right">
                        <span className="font-mono font-black text-emerald-700 block text-sm">
                          {formatFCFA(payout.amount)}
                        </span>
                        <span className="text-[10px] text-slate-400 block font-medium">
                          {payout.lastPayoutDate}
                        </span>
                      </div>

                      <div>
                        {isCompleted ? (
                          <div className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-100 text-emerald-800 font-bold text-[11px] border border-emerald-200">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Viré</span>
                          </div>
                        ) : (
                          <button
                            onClick={() => handleExecuteSinglePayout(payout.id)}
                            disabled={isExecuting}
                            className="py-1.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer hover:scale-105"
                          >
                            {isExecuting ? (
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <Send className="w-3.5 h-3.5" />
                            )}
                            <span>Exécuter Virement</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
