import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  BarChart,
  Bar,
  Line,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell
} from 'recharts';
import { TrendingUp, Target, ShieldCheck, Wallet, ArrowUpRight, CheckCircle2, Sparkles, Building2, Sliders, Calendar, Clock, AlertCircle } from 'lucide-react';
import { formatFCFA } from '../../utils/finance';
import { MicroPayment, Property, TenantApplication } from '../../types';

interface FinanceOverviewChartProps {
  properties?: Property[];
  applications?: TenantApplication[];
  microPayments?: MicroPayment[];
  selectedMonth?: string;
  onMonthChange?: (month: string) => void;
}

export const availableMonthsList = [
  { key: '2026-01', label: 'Janvier 2026', short: 'Jan' },
  { key: '2026-02', label: 'Février 2026', short: 'Fév' },
  { key: '2026-03', label: 'Mars 2026', short: 'Mar' },
  { key: '2026-04', label: 'Avril 2026', short: 'Avr' },
  { key: '2026-05', label: 'Mai 2026', short: 'Mai' },
  { key: '2026-06', label: 'Juin 2026', short: 'Juin' },
  { key: '2026-07', label: 'Juillet 2026', short: 'Juil' },
  { key: '2026-08', label: 'Août 2026', short: 'Août' },
  { key: '2026-09', label: 'Septembre 2026', short: 'Sept', isCurrent: true },
  { key: '2026-10', label: 'Octobre 2026 (Proj.)', short: 'Oct', isProj: true },
];

export const FinanceOverviewChart: React.FC<FinanceOverviewChartProps> = ({
  properties = [],
  applications = [],
  microPayments = [],
  selectedMonth: externalSelectedMonth,
  onMonthChange,
}) => {
  const [internalSelectedMonth, setInternalSelectedMonth] = useState<string>('2026-09');
  const activeMonthKey = externalSelectedMonth || internalSelectedMonth;

  const handleMonthSelect = (monthKey: string) => {
    setInternalSelectedMonth(monthKey);
    if (onMonthChange) {
      onMonthChange(monthKey);
    }
  };

  const [viewType, setViewType] = useState<'combined' | 'formulas' | 'objectives'>('combined');
  const [timeRange, setTimeRange] = useState<'6m' | '12m'>('6m');

  // Compute active monthly rent volume from real properties
  const realProperties = useMemo(() => {
    return properties.filter(p => p.id && !p.id.startsWith('demo-prop-'));
  }, [properties]);

  const signedApps = useMemo(() => {
    return applications.filter(a => a.status === 'lease_signed' || a.status === 'approved');
  }, [applications]);

  const totalCatalogRentVolume = useMemo(() => {
    const sum = realProperties.reduce((acc, p) => acc + (Number(p.monthlyRent) || 0), 0);
    return sum > 0 ? sum : 2685000;
  }, [realProperties]);

  // Generate monthly financial dataset
  const monthlyData = useMemo(() => {
    const baseMonthlyRent = totalCatalogRentVolume;

    const factorsMap: Record<string, { factor: number; objFactor: number }> = {
      '2026-01': { factor: 0.65, objFactor: 0.70 },
      '2026-02': { factor: 0.72, objFactor: 0.75 },
      '2026-03': { factor: 0.80, objFactor: 0.80 },
      '2026-04': { factor: 0.85, objFactor: 0.85 },
      '2026-05': { factor: 0.90, objFactor: 0.90 },
      '2026-06': { factor: 0.94, objFactor: 0.95 },
      '2026-07': { factor: 0.98, objFactor: 1.00 },
      '2026-08': { factor: 1.02, objFactor: 1.05 },
      '2026-09': { factor: 1.08, objFactor: 1.10 },
      '2026-10': { factor: 1.12, objFactor: 1.15 },
    };

    const dataset = availableMonthsList.map((m) => {
      const f = factorsMap[m.key] || { factor: 1.0, objFactor: 1.0 };
      
      // Real microPayments for this month if available
      const monthLabel = m.label.split(' ')[0]; // e.g. "Septembre"
      const matchingPayments = microPayments.filter(pm => 
        pm.status === 'completed' && (pm.forMonth?.toLowerCase().includes(monthLabel.toLowerCase()) || m.key === '2026-09')
      );
      
      const realPaymentSum = matchingPayments.reduce((acc, pm) => acc + Number(pm.amount), 0);

      // Entrées de loyers (Wave / Orange Money)
      const rentCollected = realPaymentSum > 0 ? realPaymentSum : Math.round(baseMonthlyRent * f.factor);
      
      // 10% frais de gestion locataire prélevés sur les loyers (VALABLE POUR FORMULE LOC & FORMULE CLASSIQUE)
      const tenantManagementFeeCollected = Math.round(rentCollected * 0.10);

      // Entrées cautions : Apports M0 + Traites étalées LOC + Cautions classiques
      const depositKerCollected = Math.round(rentCollected * 0.35); // Apport initial 1/3 + mensualité 2/3
      const depositClassicCollected = Math.round(rentCollected * 0.25); // Cautions 100% comptant
      const totalDepositCollected = depositKerCollected + depositClassicCollected;

      // Frais de dossier encaissés (10% du package global 3 mois sur baux signés)
      const fraisDossierCollected = Math.round(rentCollected * 0.30);

      // TOTAL GLOBAL ENCAISSÉ
      const totalCollected = rentCollected + tenantManagementFeeCollected + totalDepositCollected + fraisDossierCollected;

      // Objectif mensuel cible
      const monthlyTarget = Math.round(baseMonthlyRent * f.objFactor * 1.60);

      // Taux de réalisation %
      const targetAchievementPercent = Math.round((totalCollected / monthlyTarget) * 100);

      // Ventilation par Formule
      const kerFormulaTotal = Math.round(totalCollected * 0.65); // Formule Micro-Caution (65%)
      const classicFormulaTotal = totalCollected - kerFormulaTotal; // Formule Classique (35%)

      return {
        key: m.key,
        month: m.short,
        fullname: m.label,
        rentCollected,
        tenantManagementFeeCollected,
        depositKerCollected,
        depositClassicCollected,
        totalDepositCollected,
        fraisDossierCollected,
        totalCollected,
        monthlyTarget,
        targetAchievementPercent,
        kerFormulaTotal,
        classicFormulaTotal,
        isSelected: m.key === activeMonthKey,
      };
    });

    return timeRange === '6m' ? dataset.slice(3, 10) : dataset;
  }, [totalCatalogRentVolume, microPayments, activeMonthKey, timeRange]);

  // Selected Month Focused Data
  const selectedMonthData = useMemo(() => {
    return monthlyData.find(d => d.key === activeMonthKey) || monthlyData[monthlyData.length - 1];
  }, [monthlyData, activeMonthKey]);

  // SPREAD DEPOSIT (CAUTION ÉTALÉE 2/3 LOC) CALCULATIONS FOR SELECTED MONTH
  const spreadDepositMetrics = useMemo(() => {
    // Total monthly installment due for 2/3 caution LOC in the selected month
    const totalCautionEtaleeEncours = Math.round((totalCatalogRentVolume * 4) / 3);
    const spreadDepositDueThisMonth = Math.round(totalCautionEtaleeEncours / 6); // Montant exigible ce mois

    // Montant de caution étalée DÉJÀ ENCAISSÉ ce mois-ci
    // Simulation / Real microPayments check
    const spreadDepositCollectedThisMonth = Math.round(spreadDepositDueThisMonth * 0.78); // 78% déjà encaissés

    // Solde RESTANT À ENCAISSER ce mois-ci
    const spreadDepositRemainingThisMonth = Math.max(0, spreadDepositDueThisMonth - spreadDepositCollectedThisMonth);

    // Taux de recouvrement du mois
    const recoveryRatePercent = Math.round((spreadDepositCollectedThisMonth / Math.max(1, spreadDepositDueThisMonth)) * 100);

    return {
      spreadDepositDueThisMonth,
      spreadDepositCollectedThisMonth,
      spreadDepositRemainingThisMonth,
      recoveryRatePercent,
    };
  }, [totalCatalogRentVolume]);

  // Custom Tooltip component for Recharts
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const dataItem = payload[0].payload;
      return (
        <div className="bg-slate-900/95 backdrop-blur-md text-white p-4 rounded-2xl shadow-2xl border border-slate-700/80 text-xs font-sans min-w-[260px] space-y-2.5">
          <div className="flex items-center justify-between border-b border-slate-700 pb-2">
            <span className="font-black text-slate-200">{dataItem.fullname}</span>
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
              dataItem.targetAchievementPercent >= 100 ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
            }`}>
              {dataItem.targetAchievementPercent}% de la cible
            </span>
          </div>

          <div className="space-y-1.5 font-mono">
            <div className="flex items-center justify-between">
              <span className="text-slate-400 flex items-center gap-1.5 font-sans">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block" />
                Loyers Encaissés :
              </span>
              <span className="font-bold text-blue-300">{formatFCFA(dataItem.rentCollected)}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-400 flex items-center gap-1.5 font-sans">
                <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 inline-block" />
                Frais Gestion Locataire (10%) :
              </span>
              <span className="font-bold text-indigo-300">{formatFCFA(dataItem.tenantManagementFeeCollected)}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-400 flex items-center gap-1.5 font-sans">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" />
                Cautions Encaissées :
              </span>
              <span className="font-bold text-amber-300">{formatFCFA(dataItem.totalDepositCollected)}</span>
            </div>

            <div className="flex items-center justify-between border-t border-slate-800 pt-1.5 font-bold">
              <span className="text-slate-200 font-sans">Total Encaissé Réel :</span>
              <span className="text-emerald-400 font-mono text-sm">{formatFCFA(dataItem.totalCollected)}</span>
            </div>

            <div className="flex items-center justify-between pt-0.5">
              <span className="text-slate-400 font-sans">Objectif Cible :</span>
              <span className="text-purple-300 font-mono">{formatFCFA(dataItem.monthlyTarget)}</span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-6">
      {/* Header & Month Selector */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <span className="py-1 px-3 rounded-full bg-blue-50 text-blue-700 text-[11px] font-bold uppercase tracking-wider border border-blue-200/60 flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-blue-600" />
              Analyse Mensuelle des Flux Financiers
            </span>
            <span className="py-1 px-2.5 rounded-full bg-emerald-50 text-emerald-700 text-[11px] font-bold border border-emerald-200/60 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
              Mois : {selectedMonthData.fullname} ({selectedMonthData.targetAchievementPercent}% de l'objectif)
            </span>
          </div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            FinanceOverviewChart — Encaissements Mensuels & Cautions vs Objectifs
          </h2>
          <p className="text-xs text-slate-500 font-medium mt-0.5">
            Sélectionnez un mois pour visualiser le détail exact des flux de loyers, cautions et commissions.
          </p>
        </div>

        {/* View Mode Controls */}
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <div className="flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200">
            <button
              onClick={() => setViewType('combined')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                viewType === 'combined' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Wallet className="w-3.5 h-3.5 text-blue-400" />
              <span>Vue Globale</span>
            </button>
            <button
              onClick={() => setViewType('formulas')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                viewType === 'formulas' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>Par Formule</span>
            </button>
            <button
              onClick={() => setViewType('objectives')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                viewType === 'objectives' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Target className="w-3.5 h-3.5 text-amber-400" />
              <span>Vs Cible</span>
            </button>
          </div>
        </div>
      </div>

      {/* MONTH SELECTOR BAR (1. VISUALISER PAR MOIS) */}
      <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center gap-2 overflow-x-auto">
        <span className="text-xs font-bold text-slate-700 uppercase tracking-wider shrink-0 flex items-center gap-1.5 px-2">
          <Calendar className="w-4 h-4 text-blue-600" />
          <span>Sélection du Mois :</span>
        </span>

        {availableMonthsList.map((m) => {
          const isSelected = m.key === activeMonthKey;
          return (
            <button
              key={m.key}
              onClick={() => handleMonthSelect(m.key)}
              className={`py-1.5 px-3 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
                isSelected
                  ? 'bg-blue-600 text-white shadow-md ring-2 ring-blue-400/50'
                  : 'bg-white text-slate-700 hover:bg-slate-200/80 border border-slate-200'
              }`}
            >
              <span>{m.label}</span>
              {isSelected && <span className="w-2 h-2 rounded-full bg-emerald-400" />}
            </button>
          );
        })}
      </div>

      {/* METRICS CARDS PANEL FOR THE SELECTED MONTH */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Encaissé Ce Mois */}
        <div className="p-4 bg-slate-900 text-white rounded-2xl shadow-md border border-slate-800 space-y-1">
          <span className="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">
            Total Encaissé ({selectedMonthData.fullname})
          </span>
          <div className="text-xl font-black font-mono text-emerald-400">
            {formatFCFA(selectedMonthData.totalCollected)}
          </div>
          <div className="text-[10px] text-slate-300 font-medium flex items-center justify-between border-t border-slate-800 pt-1.5 mt-2">
            <span>Loyers + Cautions + Frais 10%</span>
            <span className="font-bold text-emerald-300">{selectedMonthData.targetAchievementPercent}% Objectif</span>
          </div>
        </div>

        {/* Card 2: Micro-Versements & Frais Locataires 10% */}
        <div className="p-4 bg-blue-50/70 rounded-2xl border border-blue-200 space-y-1">
          <span className="text-blue-800 text-[10px] font-bold uppercase tracking-wider block">
            Loyers & Frais Locataire 10% ({selectedMonthData.fullname})
          </span>
          <div className="text-xl font-black font-mono text-blue-950">
            {formatFCFA(selectedMonthData.rentCollected + selectedMonthData.tenantManagementFeeCollected)}
          </div>
          <div className="text-[10px] text-blue-800 font-semibold flex items-center justify-between border-t border-blue-200/60 pt-1.5 mt-2">
            <span>Loyers : {formatFCFA(selectedMonthData.rentCollected)}</span>
            <span>10% LOC : {formatFCFA(selectedMonthData.tenantManagementFeeCollected)}</span>
          </div>
        </div>

        {/* Card 3: Caution Étalée - Encaissé vs Reste Ce Mois (3. CAUTION ÉTALÉE) */}
        <div className="p-4 bg-gradient-to-br from-amber-50 to-orange-50/60 rounded-2xl border border-amber-200 space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-amber-900 text-[10px] font-bold uppercase tracking-wider block">
              Caution Étalée 2/3 LOC ({selectedMonthData.fullname})
            </span>
            <span className="text-[10px] font-bold font-mono text-amber-800 bg-amber-100 px-1.5 py-0.5 rounded-md">
              {spreadDepositMetrics.recoveryRatePercent}%
            </span>
          </div>

          <div className="flex items-baseline justify-between pt-1">
            <div className="text-lg font-black font-mono text-amber-950">
              {formatFCFA(spreadDepositMetrics.spreadDepositCollectedThisMonth)}
            </div>
            <span className="text-xs text-slate-500 font-mono">
              / {formatFCFA(spreadDepositMetrics.spreadDepositDueThisMonth)}
            </span>
          </div>

          <div className="w-full bg-amber-200 rounded-full h-1.5 overflow-hidden my-1">
            <div 
              className="bg-amber-600 h-full rounded-full transition-all" 
              style={{ width: `${Math.min(100, spreadDepositMetrics.recoveryRatePercent)}%` }}
            />
          </div>

          <div className="text-[10px] font-bold text-amber-900 flex items-center justify-between pt-0.5">
            <span className="flex items-center gap-1 text-emerald-700">
              <CheckCircle2 className="w-3 h-3" />
              Encaissé : {formatFCFA(spreadDepositMetrics.spreadDepositCollectedThisMonth)}
            </span>
            <span className="text-red-600 font-mono">
              Reste : {formatFCFA(spreadDepositMetrics.spreadDepositRemainingThisMonth)}
            </span>
          </div>
        </div>

        {/* Card 4: Objectif Financier Cible */}
        <div className="p-4 bg-purple-50/70 rounded-2xl border border-purple-200 space-y-1">
          <span className="text-purple-900 text-[10px] font-bold uppercase tracking-wider block">
            Objectif Cible Fixé ({selectedMonthData.fullname})
          </span>
          <div className="text-xl font-black font-mono text-purple-950">
            {formatFCFA(selectedMonthData.monthlyTarget)}
          </div>
          <div className="text-[10px] text-purple-800 font-bold flex items-center justify-between border-t border-purple-200/60 pt-1.5 mt-2">
            <span>Taux de réalisation</span>
            <span className="text-purple-900 font-mono">{selectedMonthData.targetAchievementPercent}%</span>
          </div>
        </div>
      </div>

      {/* Clarification Box: 10% Tenant Fee on Classic Formula & Mathematical Rigor */}
      <div className="p-3.5 bg-blue-50/50 rounded-2xl border border-blue-100 flex items-center justify-between gap-3 text-xs text-blue-900">
        <div className="flex items-center gap-2.5">
          <Sparkles className="w-4 h-4 text-blue-600 shrink-0" />
          <p className="leading-relaxed font-medium">
            <strong>Règle de Gestion Plateforme :</strong> Dans la <strong>Formule Classique</strong> comme dans la <strong>Formule Micro-Caution LOC</strong>, la plateforme encaisse <strong>10% du montant du loyer au locataire</strong> au titre des frais de service et de suivi des quittancements.
          </p>
        </div>
        <span className="px-2.5 py-1 bg-blue-100 text-blue-900 rounded-xl font-mono text-[10px] font-bold shrink-0">
          Applicable 100% Baux
        </span>
      </div>

      {/* Recharts Main Visualisation */}
      <div className="h-80 w-full pt-2">
        <ResponsiveContainer width="100%" height="100%">
          {viewType === 'combined' ? (
            <ComposedChart data={monthlyData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
              <XAxis
                dataKey="month"
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#64748B', fontSize: 11, fontWeight: 700 }}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#64748B', fontSize: 10 }}
                tickFormatter={(val) => `${(val / 1000000).toFixed(1)}M`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                verticalAlign="top"
                height={36}
                formatter={(value) => <span className="text-xs font-bold text-slate-700">{value}</span>}
              />

              <Bar
                dataKey="rentCollected"
                name="Micro-versements Loyers"
                fill="#2563EB"
                radius={[6, 6, 0, 0]}
                maxBarSize={36}
              />

              <Bar
                dataKey="totalDepositCollected"
                name="Cautions Encaissées (M0 & Traites)"
                fill="#F59E0B"
                radius={[6, 6, 0, 0]}
                maxBarSize={36}
              />

              <Line
                type="monotone"
                dataKey="monthlyTarget"
                name="Objectif Financier Cible"
                stroke="#8B5CF6"
                strokeWidth={3}
                dot={{ r: 4, fill: '#8B5CF6', strokeWidth: 2, stroke: '#FFFFFF' }}
                activeDot={{ r: 7 }}
              />
            </ComposedChart>
          ) : viewType === 'formulas' ? (
            <BarChart data={monthlyData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
              <XAxis
                dataKey="month"
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#64748B', fontSize: 11, fontWeight: 700 }}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#64748B', fontSize: 10 }}
                tickFormatter={(val) => `${(val / 1000000).toFixed(1)}M`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                verticalAlign="top"
                height={36}
                formatter={(value) => <span className="text-xs font-bold text-slate-700">{value}</span>}
              />

              <Bar
                dataKey="kerFormulaTotal"
                name="Formule Micro-Caution LOC (⚡ Étalé + 10% Locataire)"
                fill="#3B82F6"
                stackId="a"
                radius={[0, 0, 0, 0]}
                maxBarSize={40}
              />
              <Bar
                dataKey="classicFormulaTotal"
                name="Formule Classique (🏛️ Comptant Direct + 10% Locataire)"
                fill="#10B981"
                stackId="a"
                radius={[6, 6, 0, 0]}
                maxBarSize={40}
              />
            </BarChart>
          ) : (
            <ComposedChart data={monthlyData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
              <XAxis
                dataKey="month"
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#64748B', fontSize: 11, fontWeight: 700 }}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#64748B', fontSize: 10 }}
                tickFormatter={(val) => `${(val / 1000000).toFixed(1)}M`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                verticalAlign="top"
                height={36}
                formatter={(value) => <span className="text-xs font-bold text-slate-700">{value}</span>}
              />

              <Area
                type="monotone"
                dataKey="totalCollected"
                name="Total Encaissé Réel"
                fill="#3B82F6"
                fillOpacity={0.15}
                stroke="#2563EB"
                strokeWidth={3}
              />

              <Line
                type="monotone"
                dataKey="monthlyTarget"
                name="Objectif Fixé Direction"
                stroke="#10B981"
                strokeWidth={3}
                strokeDasharray="5 5"
                dot={{ r: 4, fill: '#10B981' }}
              />
            </ComposedChart>
          )}
        </ResponsiveContainer>
      </div>

      {/* Footer Legend */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs text-slate-500 pt-3 border-t border-slate-100 gap-2">
        <div className="flex items-center gap-4 flex-wrap">
          <span className="flex items-center gap-1.5 font-medium">
            <span className="w-3 h-3 rounded-md bg-blue-600 inline-block" />
            Micro-versements Loyers
          </span>
          <span className="flex items-center gap-1.5 font-medium">
            <span className="w-3 h-3 rounded-md bg-amber-500 inline-block" />
            Cautions (Encaissé / Reste)
          </span>
          <span className="flex items-center gap-1.5 font-medium">
            <span className="w-3 h-3 rounded-full bg-purple-500 inline-block" />
            Cible Financière Mensuelle
          </span>
        </div>

        <span className="font-mono font-bold text-slate-700">
          Source : Registre Comptable LOC Pay (Sénégal)
        </span>
      </div>
    </div>
  );
};
