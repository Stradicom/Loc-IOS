import React, { useState } from 'react';
import { X, Calculator, Sparkles, ArrowRight, ShieldCheck, Check, TrendingDown, HelpCircle, Layers, Building2, Calendar, CheckCircle2 } from 'lucide-react';
import { calculateDepositPlan, calculateClassicPlan, formatFCFA } from '../../utils/finance';

interface CalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialRent?: number;
}

export const CalculatorModal: React.FC<CalculatorModalProps> = ({
  isOpen,
  onClose,
  initialRent = 100000,
}) => {
  const [rent, setRent] = useState<number>(initialRent);
  const [depositMonths, setDepositMonths] = useState<number>(2);
  const [brokerFeeMonths, setBrokerFeeMonths] = useState<number>(1);
  const [activeOption, setActiveOption] = useState<'ker' | 'classic'>('ker');

  if (!isOpen) return null;

  const kerPlan = calculateDepositPlan(rent, depositMonths, brokerFeeMonths);
  const classicPlan = calculateClassicPlan(rent, depositMonths, brokerFeeMonths);

  const presets = [
    { label: 'chambres (50K)', rent: 50000 },
    { label: 'studios (150K)', rent: 150000 },
    { label: 'appartement (350K)', rent: 350000 },
    { label: 'villa (1M)', rent: 1000000 },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in text-slate-800">
      <div className="w-full max-w-lg bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-2xl relative max-h-[92vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Title */}
        <div className="space-y-1 pr-8">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs font-semibold border border-blue-200">
            <Calculator className="w-3.5 h-3.5" />
            Simulateur Officiel LOC
          </div>
          <h2 className="text-xl font-bold text-slate-900">Simulateur des Formules Locatives</h2>
          <p className="text-xs text-slate-500 font-medium">
            Comparez le Financement Micro-Caution LOC et l'Option Paiement Classique (sans LOC).
          </p>
        </div>

        {/* Option Selector Toggle */}
        <div className="mt-4 grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-2xl border border-slate-200">
          <button
            type="button"
            onClick={() => setActiveOption('ker')}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeOption === 'ker'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Micro-Caution LOC</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveOption('classic')}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeOption === 'classic'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Classique (Sans LOC)</span>
          </button>
        </div>

        {/* Inputs */}
        <div className="mt-4 space-y-4">
          {/* Presets */}
          <div className="flex gap-1.5 overflow-x-auto pb-1">
            {presets.map((p) => (
              <button
                key={p.label}
                onClick={() => setRent(p.rent)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
                  rent === p.rent
                    ? 'bg-blue-600 border-blue-600 text-white shadow-sm'
                    : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Loyer Slider */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-600 font-medium">Loyer mensuel du bien :</span>
              <span className="text-base font-extrabold text-blue-700 font-mono">{formatFCFA(rent)}</span>
            </div>
            <input
              type="range"
              min="30000"
              max="1200000"
              step="10000"
              value={rent}
              onChange={(e) => setRent(Number(e.target.value))}
              className="w-full accent-blue-600 bg-slate-200 h-2.5 rounded-lg cursor-pointer transition-all"
              style={{
                background: `linear-gradient(to right, #2563eb 0%, #2563eb ${((rent - 30000) / (1200000 - 30000)) * 100}%, #e2e8f0 ${((rent - 30000) / (1200000 - 30000)) * 100}%, #e2e8f0 100%)`
              }}
            />
            <div className="flex justify-between items-center text-[10px] font-mono select-none px-0.5">
              {[30000, 300000, 600000, 900000, 1200000].map((val) => {
                const isExact = rent === val;
                const isClose = Math.abs(rent - val) < 60000;
                const isPassed = rent >= val;
                return (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setRent(val)}
                    className={`cursor-pointer transition-all ${
                      isExact
                        ? 'text-blue-600 font-bold scale-105'
                        : isClose
                        ? 'text-blue-700 font-semibold'
                        : isPassed
                        ? 'text-slate-700 font-medium'
                        : 'text-slate-400'
                    }`}
                  >
                    {val.toLocaleString('fr-FR')} F
                  </button>
                );
              })}
            </div>
          </div>

          {/* Deposit Breakdown Banner */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-2">
            <div className="flex items-center justify-between font-bold text-slate-900">
              <span className="flex items-center gap-1.5 text-blue-800">
                <Layers className="w-3.5 h-3.5 text-blue-600" />
                Package d'entrée standard (3 mois) :
              </span>
              <span className="text-blue-700 font-mono font-black">
                {kerPlan.totalPackageMonths} mois ({formatFCFA(kerPlan.totalDepositAndBrokerage)})
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 pt-1 border-t border-slate-200">
              <div className="flex justify-between bg-white p-2 rounded-xl border border-slate-200/80">
                <span>Caution (2 mois) :</span>
                <span className="font-semibold text-slate-900 font-mono">{formatFCFA(kerPlan.legalDeposit)}</span>
              </div>
              <div className="flex justify-between bg-white p-2 rounded-xl border border-slate-200/80">
                <span>Frais courtage (1 mois) :</span>
                <span className="font-semibold text-slate-900 font-mono">{formatFCFA(kerPlan.brokerFee)}</span>
              </div>
            </div>
          </div>

          {/* DYNAMIC VIEW ACCORDING TO SELECTED OPTION */}
          {activeOption === 'ker' ? (
            <>
              {/* Comparison Cards: Classique vs LOC */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                {/* Classique */}
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-slate-600 space-y-2">
                  <span className="text-[11px] font-bold block uppercase tracking-wider text-slate-400">
                    Classique (Sans Loc)
                  </span>
                  <div>
                    <span className="text-xs text-slate-500 block">Apport initial requis :</span>
                    <span className="text-lg font-bold text-slate-400 line-through font-mono">
                      {formatFCFA(kerPlan.standardInitialDue)}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-500 border-t border-slate-200 pt-1.5 space-y-0.5">
                    <div>• 2 mois caution : {formatFCFA(kerPlan.legalDeposit)}</div>
                    <div>• 1 mois courtier : {formatFCFA(kerPlan.brokerFee)}</div>
                    <div>• Totalité exigée d'un coup</div>
                  </div>
                </div>

                {/* Avec LOC */}
                <div className="p-3.5 rounded-2xl bg-blue-50 border border-blue-200 text-slate-800 space-y-2 relative overflow-hidden">
                  <div className="absolute top-2 right-2">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                      -{kerPlan.savingsPercent}%
                    </span>
                  </div>
                  <span className="text-[11px] font-bold block uppercase tracking-wider text-blue-800">
                    Avec LOC Échelonné
                  </span>
                  <div>
                    <span className="text-xs text-blue-700 block font-medium">Apport initial requis :</span>
                    <span className="text-lg font-black text-blue-800 font-mono">
                      {formatFCFA(kerPlan.initialTotalDue)}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-600 border-t border-blue-200 pt-1.5 space-y-0.5">
                    <div>• 1er Mois inclus : {formatFCFA(kerPlan.initialRentShare)}</div>
                    <div>• 1/3 Caution restante : {formatFCFA(kerPlan.initialDepositShare)}</div>
                    <div>• Frais dossier (10%) : {formatFCFA(kerPlan.serviceFee)}</div>
                  </div>
                </div>
              </div>

              {/* Detailed Monthly Schedule */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                  Échéancier Mensuel LOC Micro-Caution
                </h4>

                <div className="space-y-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-white border border-slate-200 flex justify-between items-center">
                    <div>
                      <span className="font-bold text-slate-900 block">Mois 0 (Signature / Entrée)</span>
                      <span className="text-[10px] text-slate-500">1er Mois + 1/3 Caution + 10% frais dossier</span>
                    </div>
                    <span className="font-extrabold text-blue-700 font-mono">{formatFCFA(kerPlan.initialTotalDue)}</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white border border-slate-200 flex justify-between items-center">
                    <div>
                      <span className="font-bold text-slate-900 block">Mois 1 à 6 (Période d'échelonnement)</span>
                      <span className="text-[10px] text-slate-500">
                        Loyer ({formatFCFA(kerPlan.monthlyRent)}) + Caution étalée ({formatFCFA(kerPlan.monthlyDepositInstallment)}) + Gestion LOC 10% ({formatFCFA(kerPlan.managementFeeAmount)})
                      </span>
                    </div>
                    <span className="font-extrabold text-slate-900 font-mono">{formatFCFA(kerPlan.monthlyTotalMonths1to6)} <span className="text-[10px] font-normal text-slate-500">/mois</span></span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 flex justify-between items-center">
                    <div>
                      <span className="font-bold text-emerald-900 block">À partir du Mois 7</span>
                      <span className="text-[10px] text-emerald-700">
                        Caution 100% amortie — Loyer ({formatFCFA(kerPlan.monthlyRent)}) + Frais de gestion plateforme LOC (10% : +{formatFCFA(kerPlan.managementFeeAmount)})
                      </span>
                    </div>
                    <span className="font-extrabold text-emerald-800 font-mono text-right">
                      {formatFCFA(kerPlan.monthlyTotalMonth7Onwards)} <span className="text-[10px] font-normal text-emerald-700 block sm:inline">/mois</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Micro-Payment feature notice */}
              <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-[11px] text-amber-900 space-y-1.5">
                <div className="flex items-center gap-1.5 font-bold text-amber-800">
                  <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>Règle de Paiement de l'Apport Initial LOC :</span>
                </div>
                <p className="text-[11px] text-slate-700 leading-relaxed">
                  • <strong className="text-slate-900">Apport Initial ({formatFCFA(kerPlan.initialTotalDue)}) :</strong> Doit obligatoirement être <strong>payé en entier</strong> à la signature pour valider le bail et débloquer les clés.<br />
                  • <strong className="text-slate-900">Paiement en micro-tranches :</strong> Uniquement autorisé et actif <strong>après acquisition et validation effective du bien immobilier</strong> (pour régler vos mensualités entre le 1er et le 30 du mois via Wave ou Orange Money).
                </p>
              </div>
            </>
          ) : (
            /* CLASSIQUE SANS LOC VIEW */
            <div className="space-y-3">
              <div className="p-4 rounded-3xl bg-white border border-slate-200 text-slate-900 space-y-3 shadow-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-xl bg-slate-800 text-white shadow-xs">
                      <Building2 className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-slate-900">Formule Paiement Classique</h4>
                      <p className="text-[10px] text-slate-500 font-semibold">Sans micro-financement de la caution</p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                    0 F Frais de Dossier
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-200 text-xs">
                  <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 shadow-xs">
                    <span className="text-[10px] text-slate-500 font-bold uppercase block">Paiement à l'entrée (Comptant) :</span>
                    <span className="text-base font-black text-slate-900 font-mono mt-0.5 block">
                      {formatFCFA(classicPlan.initialTotalDue)}
                    </span>
                    <span className="text-[10px] text-slate-500 block mt-1">3 mois (2 caution + 1 courtier)</span>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 shadow-xs">
                    <span className="text-[10px] text-slate-500 font-bold uppercase block">Loyer mensuel + Gestion :</span>
                    <span className="text-base font-black text-slate-900 font-mono mt-0.5 block">
                      {formatFCFA(classicPlan.monthlyTotalRent)} <span className="text-[10px] font-normal text-slate-500">/mois</span>
                    </span>
                    <span className="text-[10px] text-slate-500 block mt-1">Loyer ({formatFCFA(rent)}) + 10% Gestion</span>
                  </div>
                </div>

                <div className="space-y-1.5 pt-1 text-[11px] text-slate-700 bg-slate-50 p-3 rounded-2xl border border-slate-200">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span><strong>Bail accordé après visite :</strong> Visite physique du bien organisée avant signature du contrat.</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span><strong>Pièce d'identité uniquement :</strong> Aucun garant ni justificatif de salaire requis.</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span><strong>Sans frais de dossier (0 FCFA) :</strong> Aucun frais de montage ou d'étude de dossier.</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-slate-800 shrink-0" />
                    <span><strong>Frais de gestion plateforme 10% locataire :</strong> Couvre la gestion administrative, quittances OHADA et conciergerie.</span>
                  </div>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-white border border-slate-200 text-[11px] text-slate-800 space-y-1 shadow-xs">
                <span className="font-bold flex items-center gap-1 text-slate-900">
                  <Calendar className="w-3.5 h-3.5 text-blue-600" />
                  Déroulement du Bail Classique :
                </span>
                <p className="text-slate-600 leading-relaxed">
                  1. Vous déposez votre demande de visite en ligne.<br />
                  2. Notre agent LOC vous accompagne pour la visite des lieux.<br />
                  3. Si le bien vous convient, le bail est accordé et signé avec versement comptant des 3 mois.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
