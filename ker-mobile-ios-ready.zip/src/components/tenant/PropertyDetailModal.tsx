import React, { useState } from 'react';
import { 
  X, 
  MapPin, 
  Bed, 
  Bath, 
  Maximize2, 
  Sparkles, 
  ShieldCheck, 
  Check, 
  Phone, 
  ArrowRight, 
  CheckCircle2, 
  ChevronLeft, 
  ChevronRight, 
  Copy,
  ExternalLink,
  Navigation,
  Compass,
  MessageSquare,
  Layers,
  Tag,
  Building2,
  Calendar
} from 'lucide-react';
import { Property, TenantApplication } from '../../types';
import { calculateDepositPlan, calculateClassicPlan, formatFCFA } from '../../utils/finance';
import { getNeighborhoodCoordinates } from '../../data/dakarNeighborhoods';
import { PropertyInteractiveMap } from './PropertyInteractiveMap';

interface PropertyDetailModalProps {
  property: Property | null;
  onClose: () => void;
  onApply: (property: Property) => void;
  onOpenChatWithProperty?: (property: Property) => void;
  hasApplied?: boolean;
  isReimbursingCaution?: boolean;
  cautionMonthsPaid?: number;
  totalCautionMonths?: number;
}

export const PropertyDetailModal: React.FC<PropertyDetailModalProps> = ({
  property,
  onClose,
  onApply,
  onOpenChatWithProperty,
  hasApplied = false,
  isReimbursingCaution = false,
  cautionMonthsPaid = 0,
  totalCautionMonths = 6,
}) => {
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [activePlanTab, setActivePlanTab] = useState<'ker' | 'classic'>('ker');

  if (!property) return null;

  const kerPlan = calculateDepositPlan(property.monthlyRent, property.depositMonths);
  const classicPlan = calculateClassicPlan(property.monthlyRent, property.depositMonths);

  // Determine Google Maps URL and coordinates
  const fallbackCoords = getNeighborhoodCoordinates(property.neighborhood);
  const coords = property.coordinates || fallbackCoords;
  const mapsUrl = property.googleMapsUrl || `https://www.google.com/maps?q=${coords.lat},${coords.lng}`;

  const nextImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveImageIndex((prev) => (prev + 1) % property.images.length);
  };

  const prevImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveImageIndex((prev) => (prev - 1 + property.images.length) % property.images.length);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in text-slate-800">
      <div className="w-full max-w-xl bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-2xl relative max-h-[92vh] flex flex-col">
        {/* Header with Close */}
        <div className="absolute top-3 right-3 z-20">
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/80 backdrop-blur text-slate-700 hover:text-slate-950 border border-slate-200 shadow-sm transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="overflow-y-auto flex-1 pb-24">
          {/* Gallery Carousel */}
          <div className="relative h-64 sm:h-72 w-full bg-slate-100">
            <img
              src={property.images[activeImageIndex]}
              alt={property.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20" />

            {property.images.length > 1 && (
              <>
                <button
                  onClick={prevImage}
                  className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/50 text-white hover:bg-black/70"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={nextImage}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/50 text-white hover:bg-black/70"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
                <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5">
                  {property.images.map((_, idx) => (
                    <div
                      key={idx}
                      className={`h-1.5 rounded-full transition-all ${
                        idx === activeImageIndex ? 'w-5 bg-blue-500' : 'w-1.5 bg-white/60'
                      }`}
                    />
                  ))}
                </div>
              </>
            )}

            <div className="absolute top-3 left-3 flex flex-wrap gap-1.5 z-10">
              <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-white/90 text-slate-900 shadow-sm backdrop-blur">
                {property.typeLabel}
              </span>
              {property.refNumber && (
                <span className="px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-blue-900/80 text-white shadow-sm backdrop-blur border border-blue-400/30">
                  Réf: {property.refNumber}
                </span>
              )}
              {property.floorLevel && (
                <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-slate-900/80 text-white shadow-sm backdrop-blur">
                  {property.floorLevel}
                </span>
              )}
            </div>
          </div>

          {/* Details Section */}
          <div className="p-4 sm:p-6 space-y-6">
            {/* Title & Price */}
            <div className="space-y-1">
              <div className="flex items-center gap-1 text-xs text-blue-600 font-semibold">
                <MapPin className="w-3.5 h-3.5" />
                <span>{property.neighborhood}, {property.city} ({property.address})</span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900">
                {property.title}
              </h1>
              <p className="text-xs text-slate-500">{property.categoryDesc}</p>

              {/* Badges bar */}
              <div className="flex flex-wrap items-center gap-2 pt-1">
                {property.refNumber && (
                  <span className="inline-flex items-center gap-1 text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-md bg-slate-100 text-slate-700 border border-slate-200">
                    <Tag className="w-3 h-3 text-blue-600" />
                    Réf: {property.refNumber}
                  </span>
                )}
                {property.floorLevel && (
                  <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200">
                    <Layers className="w-3 h-3 text-blue-600" />
                    Étage : {property.floorLevel}
                  </span>
                )}
              </div>

              <div className="pt-2 flex items-baseline gap-2">
                <span className="text-2xl font-black text-slate-900 font-mono">
                  {formatFCFA(property.monthlyRent)}
                </span>
                <span className="text-xs text-slate-500">/ mois</span>
                {property.chargesIncluded && (
                  <span className="text-[11px] px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium">
                    Charges comprises
                  </span>
                )}
              </div>
            </div>

            {/* Quick Specs */}
            <div className="grid grid-cols-3 gap-2 py-2 border-y border-slate-200">
              <div className="p-2.5 rounded-2xl bg-slate-50 text-center">
                <Bed className="w-4 h-4 mx-auto text-blue-600 mb-1" />
                <span className="text-xs font-bold text-slate-900 block">{property.rooms} {property.rooms > 1 ? 'Pièces' : 'Pièce'}</span>
                <span className="text-[10px] text-slate-500">Chambres</span>
              </div>
              <div className="p-2.5 rounded-2xl bg-slate-50 text-center">
                <Bath className="w-4 h-4 mx-auto text-blue-600 mb-1" />
                <span className="text-xs font-bold text-slate-900 block">{property.bathrooms} SDB</span>
                <span className="text-[10px] text-slate-500">Eau chaude</span>
              </div>
              <div className="p-2.5 rounded-2xl bg-slate-50 text-center">
                <Maximize2 className="w-4 h-4 mx-auto text-blue-600 mb-1" />
                <span className="text-xs font-bold text-slate-900 block">{property.surface} m²</span>
                <span className="text-[10px] text-slate-500">Superficie</span>
              </div>
            </div>

            {/* DYNAMIC BUSINESS MODEL FINANCING BREAKDOWN CARD */}
            <div className="rounded-3xl bg-slate-50 border border-slate-200 p-4 sm:p-5 space-y-4 shadow-sm">
              {/* Option Selector Toggle */}
              <div className="flex items-center justify-between">
                <div className="flex gap-1.5 p-1 bg-slate-200/80 rounded-2xl w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={() => setActivePlanTab('ker')}
                    className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                      activePlanTab === 'ker'
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'text-slate-700 hover:text-slate-900'
                    }`}
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Micro-Caution LOC</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActivePlanTab('classic')}
                    className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                      activePlanTab === 'classic'
                        ? 'bg-slate-900 text-white shadow-sm'
                        : 'text-slate-700 hover:text-slate-900'
                    }`}
                  >
                    <Building2 className="w-3.5 h-3.5" />
                    <span>Classique (sans LOC)</span>
                  </button>
                </div>
                {activePlanTab === 'ker' && (
                  <span className="hidden sm:inline-flex text-xs font-bold px-2 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                    Économie -{kerPlan.savingsPercent}%
                  </span>
                )}
              </div>

              {activePlanTab === 'ker' ? (
                <>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold text-sm shadow-sm">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-slate-900 text-sm">
                        Plan de Microfinancement LOC
                      </h3>
                      <span className="text-[11px] text-slate-600 font-medium">
                        Formule 1/3 d'acompte + Caution étalée sur 6 mois
                      </span>
                    </div>
                  </div>

                  {/* Timeline Steps */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
                    {/* Step 1: Mois 0 */}
                    <div className="p-3 rounded-2xl bg-white border border-blue-300 shadow-sm relative">
                      <span className="text-[10px] font-bold text-blue-700 uppercase tracking-wider block">
                        Mois 0 (Entrée)
                      </span>
                      <span className="text-base font-extrabold text-blue-800 block my-1 font-mono">
                        {formatFCFA(kerPlan.initialTotalDue)}
                      </span>
                      <div className="text-[10px] text-slate-500 space-y-0.5 border-t border-slate-100 pt-1.5 mt-1">
                        <div>• 1er mois : {formatFCFA(kerPlan.initialRentShare)}</div>
                        <div>• 1/3 Caution : {formatFCFA(kerPlan.initialDepositShare)}</div>
                        <div>• Frais dossier (10%) : {formatFCFA(kerPlan.serviceFee)}</div>
                      </div>
                    </div>

                    {/* Step 2: Mois 1 à 6 */}
                    <div className="p-3 rounded-2xl bg-white border border-slate-200 shadow-sm relative">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                        Mois 1 à 6
                      </span>
                      <span className="text-base font-extrabold text-slate-900 block my-1 font-mono">
                        {formatFCFA(kerPlan.monthlyTotalMonths1to6)}
                      </span>
                      <div className="text-[10px] text-slate-500 space-y-0.5 border-t border-slate-100 pt-1.5 mt-1">
                        <div>• Loyer net : {formatFCFA(kerPlan.monthlyRent)}</div>
                        <div>• Caution étalée : +{formatFCFA(kerPlan.monthlyDepositInstallment)}</div>
                        <div>• Gestion LOC (10%) : +{formatFCFA(kerPlan.managementFeeAmount)}</div>
                      </div>
                    </div>

                    {/* Step 3: Mois 7+ */}
                    <div className="p-3 rounded-2xl bg-white border border-emerald-200 shadow-sm relative">
                      <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block">
                        À partir du Mois 7
                      </span>
                      <span className="text-base font-extrabold text-emerald-800 block my-1 font-mono">
                        {formatFCFA(kerPlan.monthlyTotalMonth7Onwards)}
                      </span>
                      <div className="text-[10px] text-slate-500 space-y-0.5 border-t border-slate-100 pt-1.5 mt-1">
                        <div>• Caution 100% amortie</div>
                        <div>• Loyer net : {formatFCFA(kerPlan.monthlyRent)}</div>
                        <div>• Gestion LOC (10%) : +{formatFCFA(kerPlan.managementFeeAmount)}</div>
                      </div>
                    </div>
                  </div>

                  {/* Upfront Comparison Callout */}
                  <div className="p-3 rounded-xl bg-white border border-slate-200 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-slate-500 block">Apport traditionnel sans LOC :</span>
                      <span className="font-semibold text-slate-400 line-through font-mono">
                        {formatFCFA(kerPlan.standardInitialDue)}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-slate-500 block">Votre économie immédiate :</span>
                      <span className="font-extrabold text-emerald-700 font-mono">
                        +{formatFCFA(kerPlan.immediateSavings)}
                      </span>
                    </div>
                  </div>
                </>
              ) : (
                /* CLASSIQUE PLAN */
                <div className="space-y-3">
                  <div className="p-4 rounded-2xl bg-white border border-slate-200 text-slate-900 space-y-3 shadow-xs">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="p-2 rounded-xl bg-slate-800 text-white shadow-xs">
                          <Building2 className="w-4 h-4" />
                        </div>
                        <div>
                          <h3 className="font-extrabold text-slate-900 text-sm">
                            Paiement Classique (sans LOC)
                          </h3>
                          <span className="text-[11px] text-slate-500 font-medium">
                            Comptant traditionnel • Visite physique préalable
                          </span>
                        </div>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                        0 F Dossier
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1 text-xs">
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 shadow-xs">
                        <span className="text-[10px] text-slate-500 block font-semibold uppercase">Apport au comptant :</span>
                        <span className="text-base font-black text-slate-900 font-mono mt-0.5 block">
                          {formatFCFA(classicPlan.initialTotalDue)}
                        </span>
                        <span className="text-[10px] text-slate-500 block mt-0.5">3 mois (2 caution + 1 courtier)</span>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 shadow-xs">
                        <span className="text-[10px] text-slate-500 block font-semibold uppercase">Loyer mensuel + Gestion :</span>
                        <span className="text-base font-black text-slate-900 font-mono mt-0.5 block">
                          {formatFCFA(classicPlan.monthlyTotalRent)} <span className="text-[10px] font-normal text-slate-500">/mois</span>
                        </span>
                        <span className="text-[10px] text-slate-500 block mt-0.5">Loyer ({formatFCFA(property.monthlyRent)}) + 10% Gestion</span>
                      </div>
                    </div>

                    <div className="space-y-1.5 pt-1 text-[11px] text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-200">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span><strong>Bail accordé après visite :</strong> Visite du logement sur rendez-vous avant signature.</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span><strong>Pièce d'identité uniquement :</strong> Aucun garant ni bulletin de salaire demandé.</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span><strong>Sans frais de dossier (0 FCFA) :</strong> Gratuité totale de constitution du dossier.</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-slate-800 shrink-0" />
                        <span><strong>Frais de gestion plateforme 10% pour le locataire :</strong> Inclus quittances dématérialisées & assistance.</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Description */}
            <div className="space-y-2">
              <h3 className="text-sm font-bold text-slate-900">Description du bien</h3>
              <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-line">
                {property.description}
              </p>
            </div>

            {/* Amenities */}
            <div className="space-y-2">
              <h3 className="text-sm font-bold text-slate-900">Équipements & Commodités</h3>
              <div className="grid grid-cols-2 gap-2">
                {property.amenities.map((amenity, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700"
                  >
                    <Check className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span>{amenity}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Carte Interactive & Navigation Itinéraire LOC */}
            <div className="space-y-2">
              <PropertyInteractiveMap property={property} />
            </div>

            {/* Landlord Contact Card */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-200 flex items-center justify-center font-bold text-slate-700">
                  {property.landlordName.charAt(0)}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-slate-900">{property.landlordName}</span>
                    {property.verifiedLandlord && (
                      <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                    )}
                  </div>
                  <span className="text-[11px] text-slate-500 font-medium">Bailleur Partenaire LOC</span>
                </div>
              </div>

              <a
                href={`tel:${property.landlordPhone}`}
                className="p-2.5 rounded-xl bg-white border border-slate-200 text-slate-700 hover:text-blue-600 shadow-sm"
                title="Appeler"
              >
                <Phone className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        {/* Fixed Bottom Action Bar */}
        <div className="absolute bottom-0 inset-x-0 bg-white/95 backdrop-blur border-t border-slate-200 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 z-30 shadow-lg">
          <div>
            <span className="text-[11px] text-slate-500 block">
              {activePlanTab === 'ker' ? 'Apport initial LOC :' : 'Apport comptant Classique :'}
            </span>
            <span className="text-base font-extrabold text-blue-700 font-mono">
              {formatFCFA(activePlanTab === 'ker' ? kerPlan.initialTotalDue : classicPlan.initialTotalDue)}
            </span>
          </div>

          {isReimbursingCaution ? (
            <div className="flex-1 flex items-center justify-end">
              <div className="w-full py-2.5 px-3.5 rounded-2xl bg-amber-50 border border-amber-300 text-amber-900 text-xs font-bold flex items-center justify-center gap-2">
                <span>🔒 Inéligible : Remboursement caution en cours ({cautionMonthsPaid}/{totalCautionMonths} mois) • Éligible au mois 7</span>
              </div>
            </div>
          ) : (
            <button
              onClick={() => onApply(property)}
              disabled={hasApplied}
              className={`flex-1 py-3 px-4 rounded-2xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all ${
                hasApplied
                  ? 'bg-emerald-100 border border-emerald-300 text-emerald-800 cursor-default'
                  : 'bg-blue-600 hover:bg-blue-700 text-white shadow-sm'
              }`}
            >
              {hasApplied ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Candidature envoyée</span>
                </>
              ) : (
                <>
                  <span>Postuler avec LOC</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
