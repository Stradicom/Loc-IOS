import React, { useState } from 'react';
import { 
  X, 
  UserCheck, 
  Upload, 
  FileText, 
  CheckCircle2, 
  ShieldCheck, 
  Briefcase, 
  Phone, 
  User, 
  DollarSign, 
  Sparkles,
  Info,
  Check
} from 'lucide-react';
import { computeSolvencyScore, formatFCFA } from '../../utils/finance';
import { ProfessionCategory, GuarantorDetails } from '../../types';

interface KYCModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveKYC: (score: number, details?: any) => void;
  initialProfession?: string;
  initialIncome?: number;
}

export const KYCModal: React.FC<KYCModalProps> = ({
  isOpen,
  onClose,
  onSaveKYC,
  initialProfession = 'Responsable Marketing Digital',
  initialIncome = 450000,
}) => {
  const [professionCategory, setProfessionCategory] = useState<ProfessionCategory>('salarie');
  const [profession, setProfession] = useState(initialProfession);
  const [income, setIncome] = useState<number>(initialIncome);
  const [estimatedRent, setEstimatedRent] = useState<number>(120000);
  const [companyName, setCompanyName] = useState('Sonatel S.A.');

  // Garant Solidaire State with full details
  const [hasGuarantor, setHasGuarantor] = useState(true);
  const [guarantorFirstName, setGuarantorFirstName] = useState('Dr. Ousmane');
  const [guarantorLastName, setGuarantorLastName] = useState('Sow');
  const [guarantorPhone, setGuarantorPhone] = useState('+221 77 123 45 67');
  const [guarantorProfession, setGuarantorProfession] = useState('Médecin Chef — Clinique Madeleine');
  const [guaranteedAmount, setGuaranteedAmount] = useState<number>(360000); // Montant garanti en FCFA

  // Uploaded files simulation & real file states
  const [cniUploaded, setCniUploaded] = useState(true);
  const [cniFileName, setCniFileName] = useState<string>('cni_recto_verso.pdf');
  const [payslipUploaded, setPayslipUploaded] = useState(true);
  const [payslipFileName, setPayslipFileName] = useState<string>('bulletin_salaire_recent.pdf');
  const [workContractUploaded, setWorkContractUploaded] = useState(true);
  const [workContractFileName, setWorkContractFileName] = useState<string>('contrat_travail.pdf');
  const [rccmUploaded, setRccmUploaded] = useState(false);
  const [rccmFileName, setRccmFileName] = useState<string>('');
  const [bankUploaded, setBankUploaded] = useState(true);
  const [bankFileName, setBankFileName] = useState<string>('releve_bancaire_recent.pdf');
  const [activityProofUploaded, setActivityProofUploaded] = useState(false);
  const [activityProofFileName, setActivityProofFileName] = useState<string>('');
  const [studentDocUploaded, setStudentDocUploaded] = useState(false);
  const [studentDocFileName, setStudentDocFileName] = useState<string>('');

  if (!isOpen) return null;

  // File upload handler supporting PDF or Photo
  const handleFileUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    setterUpload: React.Dispatch<React.SetStateAction<boolean>>,
    setterName: React.Dispatch<React.SetStateAction<string>>
  ) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setterName(file.name);
      setterUpload(true);
    }
  };

  // Compute solvency score
  const isDocComplete = cniUploaded && (
    (professionCategory === 'salarie' && payslipUploaded && workContractUploaded) ||
    (professionCategory === 'fonctionnaire' && payslipUploaded && workContractUploaded) ||
    (professionCategory === 'entrepreneur' && rccmUploaded && bankUploaded) ||
    (professionCategory === 'commercant' && activityProofUploaded && bankUploaded) ||
    (professionCategory === 'etudiant' && studentDocUploaded && hasGuarantor) ||
    (professionCategory === 'independant' && bankUploaded) ||
    (professionCategory === 'autre' && bankUploaded)
  );

  const employmentType = (professionCategory === 'salarie' || professionCategory === 'fonctionnaire')
    ? 'cdi'
    : professionCategory === 'entrepreneur' || professionCategory === 'commercant'
    ? 'entrepreneur'
    : 'independant';

  const { score, level, recommendation } = computeSolvencyScore(
    income,
    estimatedRent,
    employmentType,
    hasGuarantor,
    isDocComplete
  );

  const handleSave = () => {
    const guarantorDetails: GuarantorDetails = {
      firstName: guarantorFirstName.trim(),
      lastName: guarantorLastName.trim(),
      phone: guarantorPhone.trim(),
      profession: guarantorProfession.trim(),
      guaranteedAmount: guaranteedAmount || estimatedRent * 2,
    };

    onSaveKYC(score, {
      professionCategory,
      profession,
      income,
      estimatedRent,
      hasGuarantor,
      guarantorDetails,
      guarantorName: `${guarantorFirstName} ${guarantorLastName}`.trim(),
      guarantorPhone,
      guaranteedAmount,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fade-in text-slate-800">
      <div className="w-full max-w-xl bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-2xl relative max-h-[92vh] overflow-y-auto space-y-5">
        
        {/* Header with Close */}
        <div className="flex items-start justify-between border-b border-slate-100 pb-3">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[11px] font-bold border border-blue-200">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
              Dossier de Solvabilité LOC Certifié
            </div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900">
              Mon Profil & Pièces Justificatives
            </h2>
            <p className="text-xs text-slate-500">
              Adaptez votre dossier selon votre profession pour obtenir l'éligibilité à l'échelonnement de caution.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-slate-100 text-slate-400 hover:text-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Score Display */}
        <div className="p-4 rounded-2xl bg-blue-50/80 border border-blue-200 flex items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
              Score de Solvabilité LOC
            </span>
            <div className="flex items-center gap-2.5">
              <span className="text-3xl font-black text-blue-700 font-mono leading-none">{score}/100</span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-100 text-emerald-800 border border-emerald-200">
                Risque {level}
              </span>
            </div>
            <p className="text-[11px] text-slate-600 font-medium pt-0.5">{recommendation}</p>
          </div>

          <div className="w-12 h-12 rounded-2xl bg-white border border-blue-200 flex items-center justify-center text-blue-600 shadow-xs shrink-0 font-bold">
            <Sparkles className="w-6 h-6" />
          </div>
        </div>

        {/* Step 1: Profession Selection */}
        <div className="space-y-3">
          <label className="text-xs font-black text-slate-900 flex items-center gap-1.5">
            <Briefcase className="w-4 h-4 text-blue-600" />
            1. Catégorie & Statut Professionnel :
          </label>

          {/* Spacious & Readable Buttons Layout */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {[
              { id: 'salarie', label: 'Salarié', icon: '💼', sub: 'CDI / CDD' },
              { id: 'fonctionnaire', label: 'Fonctionnaire', icon: '🏛️', sub: 'Agent État' },
              { id: 'entrepreneur', label: 'Entrepreneur', icon: '🚀', sub: 'SARL / SAS' },
              { id: 'commercant', label: 'Commerçant', icon: '🏪', sub: 'Boutique / Marché' },
              { id: 'independant', label: 'Indépendant', icon: '💻', sub: 'Freelance / Prestataire' },
              { id: 'autre', label: 'Autres', icon: '🌐', sub: 'Autre profil' },
            ].map((cat) => {
              const isSelected = professionCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setProfessionCategory(cat.id as ProfessionCategory)}
                  className={`p-3 rounded-2xl border text-left text-xs font-bold transition-all flex items-center gap-2.5 ${
                    isSelected
                      ? 'bg-blue-600 text-white border-blue-600 shadow-sm ring-2 ring-blue-500/20'
                      : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100 hover:border-slate-300'
                  }`}
                >
                  <span className="text-lg shrink-0">{cat.icon}</span>
                  <div className="min-w-0">
                    <span className="block font-black text-xs leading-tight">{cat.label}</span>
                    <span className={`block text-[10px] font-normal leading-tight ${isSelected ? 'text-blue-100' : 'text-slate-500'}`}>
                      {cat.sub}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
            <div>
              <span className="text-[10px] font-bold text-slate-500 block mb-1">Intitulé du poste / Métier :</span>
              <input
                type="text"
                value={profession}
                onChange={(e) => setProfession(e.target.value)}
                placeholder="Ex: Comptable, Développeur, Commerçant"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none font-medium"
              />
            </div>

            <div>
              <span className="text-[10px] font-bold text-slate-500 block mb-1">
                {professionCategory === 'fonctionnaire' ? 'Ministère / Administration :' : 'Entreprise / Structure :'}
              </span>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="Ex: SONATEL, Ministère de la Santé..."
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none font-medium"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <span className="text-[10px] font-bold text-slate-500 block mb-1">Revenu net mensuel moyen :</span>
              <div className="relative">
                <input
                  type="number"
                  value={income}
                  onChange={(e) => setIncome(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono focus:bg-white focus:border-blue-500 outline-none font-bold"
                />
                <span className="absolute right-2.5 top-2 text-[10px] text-slate-400 font-bold">FCFA</span>
              </div>
            </div>

            <div>
              <span className="text-[10px] font-bold text-slate-500 block mb-1">Loyer cible souhaité :</span>
              <div className="relative">
                <input
                  type="number"
                  value={estimatedRent}
                  onChange={(e) => setEstimatedRent(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono focus:bg-white focus:border-blue-500 outline-none font-bold"
                />
                <span className="absolute right-2.5 top-2 text-[10px] text-slate-400 font-bold">FCFA</span>
              </div>
            </div>
          </div>
        </div>

        {/* Step 2: Documents Requis selon le Métier (PDF ou Photo) */}
        <div className="space-y-3 pt-2 border-t border-slate-100">
          <div className="flex items-center justify-between">
            <label className="text-xs font-black text-slate-900 flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-blue-600" />
              2. Pièces Justificatives (Format PDF ou Photo) :
            </label>
            <span className="text-[10px] text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full font-bold">
              PDF / JPG / PNG acceptés
            </span>
          </div>

          <div className="space-y-2">
            {/* Common: CNI or Passport */}
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                  🪪
                </div>
                <div className="min-w-0">
                  <span className="font-bold text-slate-900 block truncate">Carte d'Identité (CNI) ou Passeport</span>
                  <span className="text-[10px] text-slate-500 block truncate">
                    {cniUploaded && cniFileName ? `Fichier : ${cniFileName}` : 'Format : PDF ou Photo (recto-verso)'}
                  </span>
                </div>
              </div>
              <label className={`cursor-pointer px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                cniUploaded
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                  : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
              }`}>
                <input
                  type="file"
                  accept="application/pdf,image/png,image/jpeg,image/jpg,image/webp"
                  className="hidden"
                  onChange={(e) => handleFileUpload(e, setCniUploaded, setCniFileName)}
                />
                {cniUploaded ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Upload className="w-3.5 h-3.5" />}
                <span>{cniUploaded ? 'Téléversé' : 'Ajouter PDF/Photo'}</span>
              </label>
            </div>

            {/* If Salarié or Fonctionnaire */}
            {(professionCategory === 'salarie' || professionCategory === 'fonctionnaire') && (
              <>
                {/* 1 Fiche de paie */}
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                      📄
                    </div>
                    <div className="min-w-0">
                      <span className="font-bold text-slate-900 block truncate">
                        {professionCategory === 'fonctionnaire' ? '1 Bulletin de Solde Récent' : '1 Fiche de Paie Récente'}
                      </span>
                      <span className="text-[10px] text-slate-500 block truncate">
                        {payslipUploaded && payslipFileName ? `Fichier : ${payslipFileName}` : 'Format : PDF ou Photo du dernier bulletin'}
                      </span>
                    </div>
                  </div>
                  <label className={`cursor-pointer px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                    payslipUploaded
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                      : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                  }`}>
                    <input
                      type="file"
                      accept="application/pdf,image/png,image/jpeg,image/jpg,image/webp"
                      className="hidden"
                      onChange={(e) => handleFileUpload(e, setPayslipUploaded, setPayslipFileName)}
                    />
                    {payslipUploaded ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Upload className="w-3.5 h-3.5" />}
                    <span>{payslipUploaded ? 'Téléversé' : 'Ajouter PDF/Photo'}</span>
                  </label>
                </div>

                {/* Contrat de travail / Attestation */}
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                      📋
                    </div>
                    <div className="min-w-0">
                      <span className="font-bold text-slate-900 block truncate">
                        {professionCategory === 'fonctionnaire' ? 'Décret / Acte d’Engagement Officiel' : 'Contrat de Travail ou Attestation'}
                      </span>
                      <span className="text-[10px] text-slate-500 block truncate">
                        {workContractUploaded && workContractFileName ? `Fichier : ${workContractFileName}` : 'Format : PDF ou Photo signé'}
                      </span>
                    </div>
                  </div>
                  <label className={`cursor-pointer px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                    workContractUploaded
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                      : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                  }`}>
                    <input
                      type="file"
                      accept="application/pdf,image/png,image/jpeg,image/jpg,image/webp"
                      className="hidden"
                      onChange={(e) => handleFileUpload(e, setWorkContractUploaded, setWorkContractFileName)}
                    />
                    {workContractUploaded ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Upload className="w-3.5 h-3.5" />}
                    <span>{workContractUploaded ? 'Téléversé' : 'Ajouter PDF/Photo'}</span>
                  </label>
                </div>
              </>
            )}

            {/* If Entrepreneur */}
            {professionCategory === 'entrepreneur' && (
              <>
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                      🏢
                    </div>
                    <div className="min-w-0">
                      <span className="font-bold text-slate-900 block truncate">Registre de Commerce (RCCM) & NINEA</span>
                      <span className="text-[10px] text-slate-500 block truncate">
                        {rccmUploaded && rccmFileName ? `Fichier : ${rccmFileName}` : 'Format : PDF ou Photo de l’enregistrement'}
                      </span>
                    </div>
                  </div>
                  <label className={`cursor-pointer px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                    rccmUploaded
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                      : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                  }`}>
                    <input
                      type="file"
                      accept="application/pdf,image/png,image/jpeg,image/jpg,image/webp"
                      className="hidden"
                      onChange={(e) => handleFileUpload(e, setRccmUploaded, setRccmFileName)}
                    />
                    {rccmUploaded ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Upload className="w-3.5 h-3.5" />}
                    <span>{rccmUploaded ? 'Téléversé' : 'Ajouter PDF/Photo'}</span>
                  </label>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                      📊
                    </div>
                    <div className="min-w-0">
                      <span className="font-bold text-slate-900 block truncate">1 Relevé Bancaire</span>
                      <span className="text-[10px] text-slate-500 block truncate">
                        {bankUploaded && bankFileName ? `Fichier : ${bankFileName}` : 'Format : PDF ou Photo du dernier relevé'}
                      </span>
                    </div>
                  </div>
                  <label className={`cursor-pointer px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                    bankUploaded
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                      : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                  }`}>
                    <input
                      type="file"
                      accept="application/pdf,image/png,image/jpeg,image/jpg,image/webp"
                      className="hidden"
                      onChange={(e) => handleFileUpload(e, setBankUploaded, setBankFileName)}
                    />
                    {bankUploaded ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Upload className="w-3.5 h-3.5" />}
                    <span>{bankUploaded ? 'Téléversé' : 'Ajouter PDF/Photo'}</span>
                  </label>
                </div>
              </>
            )}

            {/* If Commerçant / Indépendant / Autres */}
            {(professionCategory === 'commercant' || professionCategory === 'independant' || professionCategory === 'autre') && (
              <>
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                      📑
                    </div>
                    <div className="min-w-0">
                      <span className="font-bold text-slate-900 block truncate">
                        {professionCategory === 'commercant' 
                          ? 'Justificatif d\'Activité (Patente, Déclaration ou Bail)' 
                          : professionCategory === 'independant'
                          ? 'Attestation d\'exercice ou Contrat de prestation'
                          : 'Justificatif de ressources ou attestation'}
                      </span>
                      <span className="text-[10px] text-slate-500 block truncate">
                        {activityProofUploaded && activityProofFileName ? `Fichier : ${activityProofFileName}` : 'Format : PDF ou Photo justificative'}
                      </span>
                    </div>
                  </div>
                  <label className={`cursor-pointer px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                    activityProofUploaded
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                      : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                  }`}>
                    <input
                      type="file"
                      accept="application/pdf,image/png,image/jpeg,image/jpg,image/webp"
                      className="hidden"
                      onChange={(e) => handleFileUpload(e, setActivityProofUploaded, setActivityProofFileName)}
                    />
                    {activityProofUploaded ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Upload className="w-3.5 h-3.5" />}
                    <span>{activityProofUploaded ? 'Téléversé' : 'Ajouter PDF/Photo'}</span>
                  </label>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                      🏦
                    </div>
                    <div className="min-w-0">
                      <span className="font-bold text-slate-900 block truncate">1 Relevé Bancaire</span>
                      <span className="text-[10px] text-slate-500 block truncate">
                        {bankUploaded && bankFileName ? `Fichier : ${bankFileName}` : 'Format : PDF ou Photo du dernier relevé'}
                      </span>
                    </div>
                  </div>
                  <label className={`cursor-pointer px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                    bankUploaded
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                      : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                  }`}>
                    <input
                      type="file"
                      accept="application/pdf,image/png,image/jpeg,image/jpg,image/webp"
                      className="hidden"
                      onChange={(e) => handleFileUpload(e, setBankUploaded, setBankFileName)}
                    />
                    {bankUploaded ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Upload className="w-3.5 h-3.5" />}
                    <span>{bankUploaded ? 'Téléversé' : 'Ajouter PDF/Photo'}</span>
                  </label>
                </div>
              </>
            )}

            {/* If Étudiant */}
            {professionCategory === 'etudiant' && (
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                    🎓
                  </div>
                  <div className="min-w-0">
                    <span className="font-bold text-slate-900 block truncate">Certificat de Scolarité ou Carte d'Étudiant</span>
                    <span className="text-[10px] text-slate-500 block truncate">
                      {studentDocUploaded && studentDocFileName ? `Fichier : ${studentDocFileName}` : 'Format : PDF ou Photo de l\'année en cours'}
                    </span>
                  </div>
                </div>
                <label className={`cursor-pointer px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                  studentDocUploaded
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                    : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                }`}>
                  <input
                    type="file"
                    accept="application/pdf,image/png,image/jpeg,image/jpg,image/webp"
                    className="hidden"
                    onChange={(e) => handleFileUpload(e, setStudentDocUploaded, setStudentDocFileName)}
                  />
                  {studentDocUploaded ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Upload className="w-3.5 h-3.5" />}
                  <span>{studentDocUploaded ? 'Téléversé' : 'Ajouter PDF/Photo'}</span>
                </label>
              </div>
            )}
          </div>
        </div>

        {/* Step 3: Garant Solidaire (Sans demande de CNI) */}
        <div className="p-4 rounded-3xl bg-slate-50 border border-slate-200 space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-blue-600" />
                3. Garant Solidaire
              </span>
              <span className="text-[10px] text-slate-500">
                Renforce votre solvabilité et garantit l'acceptation immédiate par le bailleur
              </span>
            </div>

            <button
              type="button"
              onClick={() => setHasGuarantor(!hasGuarantor)}
              className={`w-11 h-6 rounded-full transition-colors flex items-center p-0.5 ${
                hasGuarantor ? 'bg-blue-600 justify-end' : 'bg-slate-300 justify-start'
              }`}
            >
              <div className="w-5 h-5 rounded-full bg-white shadow-md" />
            </button>
          </div>

          {hasGuarantor && (
            <div className="space-y-3 pt-3 border-t border-slate-200 animate-fade-in text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[10px] font-bold text-slate-700 block mb-1">Prénom du Garant :</label>
                  <input
                    type="text"
                    value={guarantorFirstName}
                    onChange={(e) => setGuarantorFirstName(e.target.value)}
                    placeholder="Ex: Dr. Ousmane"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-700 block mb-1">Nom du Garant :</label>
                  <input
                    type="text"
                    value={guarantorLastName}
                    onChange={(e) => setGuarantorLastName(e.target.value)}
                    placeholder="Ex: Sow"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[10px] font-bold text-slate-700 block mb-1">Numéro de Téléphone :</label>
                  <input
                    type="tel"
                    value={guarantorPhone}
                    onChange={(e) => setGuarantorPhone(e.target.value)}
                    placeholder="+221 77 000 00 00"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-700 block mb-1">Profession / Entreprise du Garant :</label>
                  <input
                    type="text"
                    value={guarantorProfession}
                    onChange={(e) => setGuarantorProfession(e.target.value)}
                    placeholder="Ex: Directeur Général, Médecin..."
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-blue-700 block mb-1 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-blue-600" />
                  Montant Garanti (Cautionnement Solidaire) :
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={guaranteedAmount}
                    onChange={(e) => setGuaranteedAmount(Number(e.target.value))}
                    placeholder="Ex: 360000"
                    className="w-full bg-blue-50 border border-blue-300 rounded-xl px-3 py-2 text-xs text-blue-900 font-mono font-black"
                  />
                  <span className="absolute right-2.5 top-2 text-[10px] text-blue-600 font-bold">FCFA</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Action Button */}
        <div className="pt-2">
          <button
            onClick={handleSave}
            className="w-full py-3.5 px-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 transition-all"
          >
            <ShieldCheck className="w-4 h-4 text-white" />
            <span>Enregistrer et Valider mon Dossier de Solvabilité</span>
          </button>
        </div>

      </div>
    </div>
  );
};
