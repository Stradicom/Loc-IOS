import React, { useState, useMemo } from 'react';
import { 
  Search, 
  SlidersHorizontal, 
  Sparkles, 
  Bed, 
  Bath, 
  Maximize2, 
  ShieldCheck, 
  Check, 
  ArrowUpRight, 
  MapPin, 
  Zap,
  Map as MapIcon,
  List,
  Navigation,
  ExternalLink,
  Compass,
  Tag,
  Layers
} from 'lucide-react';
import { Property, PropertyType } from '../../types';
import { calculateDepositPlan, formatFCFA } from '../../utils/finance';
import { getNeighborhoodCoordinates } from '../../data/dakarNeighborhoods';

interface PropertyListProps {
  properties: Property[];
  onSelectProperty: (property: Property) => void;
  onOpenCalculator: () => void;
  isReimbursingCaution?: boolean;
  cautionMonthsPaid?: number;
  totalCautionMonths?: number;
}

export const PropertyList: React.FC<PropertyListProps> = ({
  properties,
  onSelectProperty,
  onOpenCalculator,
  isReimbursingCaution = false,
  cautionMonthsPaid = 0,
  totalCautionMonths = 6,
}) => {
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [selectedType, setSelectedType] = useState<PropertyType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [maxBudget, setMaxBudget] = useState<number>(1000000);
  const [onlyFurnished, setOnlyFurnished] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedMapProperty, setSelectedMapProperty] = useState<Property | null>(null);

  const approvedProperties = useMemo(() => {
    return properties.filter(p => (p.approvalStatus === 'approved' || p.approvalStatus === undefined) && p.isAvailable !== false);
  }, [properties]);

  const categories: { id: PropertyType | 'all'; label: string; icon: string; count: number }[] = [
    { id: 'all', label: 'Tous', icon: '🏠', count: approvedProperties.length },
    { id: 'chambre', label: 'Chambres', icon: '🛏️', count: approvedProperties.filter(p => p.type === 'chambre').length },
    { id: 'studio', label: 'Studios', icon: '🛋️', count: approvedProperties.filter(p => p.type === 'studio').length },
    { id: 'appartement', label: 'Appartements', icon: '🏢', count: approvedProperties.filter(p => p.type === 'appartement').length },
    { id: 'maison', label: 'Villas', icon: '🏡', count: approvedProperties.filter(p => p.type === 'maison').length },
  ];

  const filteredProperties = useMemo(() => {
    return approvedProperties.filter((p) => {
      const matchesType = selectedType === 'all' || p.type === selectedType;
      const matchesSearch =
        p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.neighborhood.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (p.refNumber && p.refNumber.toLowerCase().includes(searchQuery.toLowerCase())) ||
        p.id.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesBudget = p.monthlyRent <= maxBudget;
      const matchesFurnished = !onlyFurnished || p.furnished;

      return matchesType && matchesSearch && matchesBudget && matchesFurnished;
    });
  }, [approvedProperties, selectedType, searchQuery, maxBudget, onlyFurnished]);

  return (
    <div className="p-3 sm:p-5 pb-24 space-y-4 text-slate-800">
      {/* HERO BANNER - Value Proposition & Caution */}
      <div className="rounded-3xl bg-gradient-to-r from-blue-600 to-indigo-600 p-6 sm:p-7 shadow-lg text-white relative overflow-hidden">
        <div className="relative z-10 space-y-2.5">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-white text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Fintech Immobilière • Dakar Sénégal</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-black text-white leading-tight">
            Emménagez avec seulement 1/3 de votre caution !
          </h2>
          <p className="text-xs sm:text-sm text-blue-100 leading-relaxed max-w-lg">
            LOC avance le solde de votre caution et vos frais d'agence, remboursables en 6 mensualités. Le propriétaire perçoit <strong className="text-white">100% de la caution</strong> dès le 1er jour garanti par LOC.
          </p>

          <div className="pt-1">
            <button
              onClick={onOpenCalculator}
              className="px-4 py-2 rounded-xl bg-white text-blue-600 hover:bg-slate-50 text-xs font-bold inline-flex items-center gap-1.5 shadow-md transition-all"
            >
              <span>Calculer mes mensualités d'échelonnement</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* CAUTION REIMBURSEMENT INELIGIBILITY ALERT (IF ACTIVE LEASE IN MONTHS 1-6) */}
      {isReimbursingCaution && (
        <div className="p-4 rounded-3xl bg-amber-50 border border-amber-300 text-amber-900 shadow-sm flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-2xl bg-amber-200 text-amber-900 flex items-center justify-center font-bold shrink-0 text-lg">
            🔒
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h4 className="text-xs font-black uppercase tracking-wider text-amber-900">
                Caution LOC en cours d'amortissement ({cautionMonthsPaid}/{totalCautionMonths} mois payés)
              </h4>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-200 text-amber-900 border border-amber-300">
                Règle d'éligibilité LOC
              </span>
            </div>
            <p className="text-xs text-amber-800 leading-relaxed">
              Un contrat de bail LOC est actuellement actif avec remboursement échelonné de la caution. Conformément aux règles de solvabilité, tous les autres biens immobiliers sont temporairement inéligibles jusqu'au remboursement complet de votre caution (<strong>Éligibilité réactivée au 7ème mois</strong> après validation de l'intégralité des versements).
            </p>
          </div>
        </div>
      )}

      {/* SEARCH & FILTERS BAR */}
      <div className="bg-white border border-slate-200 rounded-3xl p-3.5 sm:p-4 shadow-sm space-y-3">
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher quartier : Almadies, Mermoz, Plateau, Point E..."
              className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            />
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200 shrink-0">
            <button
              type="button"
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-xl transition-all flex items-center gap-1 text-xs font-bold ${
                viewMode === 'list'
                  ? 'bg-white text-blue-700 shadow-2xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
              title="Vue Liste"
            >
              <List className="w-4 h-4" />
              <span className="hidden md:inline">Liste</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('map')}
              className={`p-2 rounded-xl transition-all flex items-center gap-1 text-xs font-bold ${
                viewMode === 'map'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
              title="Vue Carte Interactive"
            >
              <MapIcon className="w-4 h-4" />
              <span className="hidden md:inline">Carte Dakar</span>
            </button>
          </div>

          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`p-2.5 rounded-2xl border transition-all shrink-0 ${
              showFilters
                ? 'bg-blue-600 border-blue-600 text-white shadow-sm'
                : 'bg-slate-50 border-slate-200 text-slate-600 hover:text-slate-900'
            }`}
            title="Filtres avancés"
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>
        </div>

        {/* Collapsible Advanced Filters */}
        {showFilters && (
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3 animate-in fade-in">
            <div>
              <div className="flex justify-between items-center text-xs mb-1">
                <span className="font-bold text-slate-600">Budget max mensuel :</span>
                <span className="font-bold text-blue-600 font-mono">{formatFCFA(maxBudget)}</span>
              </div>
              <input
                type="range"
                min="40000"
                max="1000000"
                step="20000"
                value={maxBudget}
                onChange={(e) => setMaxBudget(Number(e.target.value))}
                className="w-full accent-blue-600 bg-slate-200 h-2 rounded-lg cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-200">
              <span className="text-xs text-slate-700 font-medium">Logement meublé uniquement</span>
              <button
                type="button"
                onClick={() => setOnlyFurnished(!onlyFurnished)}
                className={`w-10 h-6 rounded-full transition-colors flex items-center p-0.5 ${
                  onlyFurnished ? 'bg-blue-600 justify-end' : 'bg-slate-300 justify-start'
                }`}
              >
                <div className="w-5 h-5 rounded-full bg-white shadow-sm" />
              </button>
            </div>
          </div>
        )}

        {/* Category Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedType(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 flex items-center gap-1.5 transition-all ${
                selectedType === cat.id
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 border border-slate-200 hover:bg-slate-200 hover:text-slate-900'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.label}</span>
              <span className="text-[10px] opacity-80 bg-black/10 px-1.5 py-0.2 rounded-full font-mono">
                {cat.count}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* VIEW MODE: MAP OR LIST */}
      {viewMode === 'map' ? (
        <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm space-y-4 p-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
                <MapIcon className="w-4 h-4 text-blue-600" />
                Carte Interactive des Logements à Dakar ({filteredProperties.length} disponibles)
              </h3>
              <p className="text-xs text-slate-500">
                Cliquez sur un quartier ou un repère pour voir la fiche de produit et calculer votre itinéraire
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[11px] font-semibold text-slate-500">
                Légende :
              </span>
              <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold">
                🔵 Logement LOC vérifié
              </span>
            </div>
          </div>

          {/* Interactive Dakar OpenStreetMap Container */}
          <div className="relative h-96 sm:h-[480px] rounded-2xl overflow-hidden border border-slate-200 bg-slate-100">
            <iframe
              title="Carte générale des biens à Dakar"
              src={`https://www.openstreetmap.org/export/embed.html?bbox=-17.5350%2C14.6500%2C-17.2200%2C14.8100&layer=mapnik`}
              className="w-full h-full border-0"
              loading="lazy"
            />

            {/* Dakar Interactive Property Markers Overlay */}
            <div className="absolute inset-0 pointer-events-none p-4 flex flex-col justify-between">
              {/* Top Bar inside map */}
              <div className="flex justify-between items-start pointer-events-auto">
                <div className="bg-white/95 backdrop-blur-md rounded-2xl p-2.5 shadow-md border border-slate-200/90 max-w-xs">
                  <span className="text-[11px] font-black text-slate-900 block">
                    Presqu'île de Dakar & Pôles
                  </span>
                  <p className="text-[10px] text-slate-500">
                    Almadies, Mamelles, Ouakam, Mermoz, Point E, Plateau, Hann Maristes...
                  </p>
                </div>
              </div>

              {/* Bottom Quick Property Selector Carousel */}
              <div className="pointer-events-auto overflow-x-auto pb-1 scrollbar-none flex items-center gap-2.5">
                {filteredProperties.map((prop) => {
                  const plan = calculateDepositPlan(prop.monthlyRent, prop.depositMonths);
                  const isSelected = selectedMapProperty?.id === prop.id;

                  return (
                    <div
                      key={prop.id}
                      onClick={() => setSelectedMapProperty(prop)}
                      className={`min-w-[260px] sm:min-w-[280px] bg-white/95 backdrop-blur-md rounded-2xl p-3 border cursor-pointer shadow-lg transition-all ${
                        isSelected 
                          ? 'border-blue-600 ring-2 ring-blue-500/30 -translate-y-1' 
                          : 'border-slate-200 hover:border-blue-300'
                      }`}
                    >
                      <div className="flex gap-2.5">
                        <img
                          src={prop.images[0]}
                          alt={prop.title}
                          referrerPolicy="no-referrer"
                          className="w-14 h-14 rounded-xl object-cover shrink-0"
                        />
                        <div className="min-w-0 flex-1">
                          <span className="text-[10px] font-bold text-blue-600 block truncate">
                            📍 {prop.neighborhood}
                          </span>
                          <h4 className="text-xs font-black text-slate-900 truncate">
                            {prop.title}
                          </h4>
                          <span className="text-xs font-black text-slate-900 font-mono block mt-0.5">
                            {formatFCFA(prop.monthlyRent)}/m
                          </span>
                        </div>
                      </div>

                      <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between">
                        <span className="text-[9px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                          Apport : {formatFCFA(plan.initialTotalDue)}
                        </span>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectProperty(prop);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-bold flex items-center gap-1 transition-all"
                        >
                          <span>Fiche & Trajet</span>
                          <ArrowUpRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Selected Property Full Spotlight */}
          {selectedMapProperty && (
            <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-slate-900">
                    {selectedMapProperty.title} ({selectedMapProperty.neighborhood})
                  </h4>
                  <p className="text-[11px] text-slate-600">
                    {selectedMapProperty.address} • {selectedMapProperty.surface} m² • {formatFCFA(selectedMapProperty.monthlyRent)}/mois
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href={`https://www.google.com/maps?q=${selectedMapProperty.coordinates?.lat || 14.7167},${selectedMapProperty.coordinates?.lng || -17.4677}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-2 rounded-xl bg-white hover:bg-slate-100 text-slate-800 text-xs font-bold border border-slate-200 flex items-center gap-1.5 transition-all shadow-2xs"
                >
                  <Navigation className="w-3.5 h-3.5 text-blue-600" />
                  <span>Google Maps</span>
                  <ExternalLink className="w-3 h-3 ml-0.5" />
                </a>

                <button
                  type="button"
                  onClick={() => onSelectProperty(selectedMapProperty)}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all"
                >
                  <span>Ouvrir la Fiche Complète & Itinéraire</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Property Cards Feed */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {filteredProperties.length === 0 ? (
            <div className="col-span-full p-8 text-center bg-white rounded-3xl border border-slate-200 shadow-sm">
              <p className="text-sm text-slate-500">Aucun bien ne correspond à vos critères de recherche.</p>
              <button
                onClick={() => {
                  setSelectedType('all');
                  setSearchQuery('');
                  setMaxBudget(1000000);
                  setOnlyFurnished(false);
                }}
                className="mt-2 text-xs text-blue-600 font-semibold"
              >
                Réinitialiser tous les filtres
              </button>
            </div>
          ) : (
            filteredProperties.map((prop) => {
              const plan = calculateDepositPlan(prop.monthlyRent, prop.depositMonths);

              return (
                <div
                  key={prop.id}
                  onClick={() => onSelectProperty(prop)}
                  className="group bg-white rounded-3xl border border-slate-200/90 hover:border-blue-300 overflow-hidden shadow-sm hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
                >
                  {/* Image Container */}
                  <div className="relative h-48 w-full overflow-hidden bg-slate-100">
                    <img
                      src={prop.images[0]}
                      alt={prop.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20" />

                    {/* Top Badges */}
                    <div className="absolute top-3 left-3 flex items-center gap-1.5">
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-white/90 backdrop-blur text-slate-900 shadow-sm">
                        {prop.typeLabel}
                      </span>
                      {prop.featured && (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-600 text-white shadow-sm">
                          Coup de cœur
                        </span>
                      )}
                    </div>

                    <div className="absolute top-3 right-3">
                      {isReimbursingCaution ? (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-500/95 backdrop-blur text-white shadow-sm flex items-center gap-1">
                          <span>🔒 Inéligible ({cautionMonthsPaid}/6 mois)</span>
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-600 text-white shadow-sm flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3" />
                          Éligible LOC • Apport : {formatFCFA(plan.initialTotalDue)}
                        </span>
                      )}
                    </div>

                    {/* Bottom Image info */}
                    <div className="absolute bottom-3 left-3 right-3 flex justify-between items-end text-white">
                      <div>
                        <span className="text-[11px] font-medium flex items-center gap-1 drop-shadow-md">
                          <MapPin className="w-3 h-3 text-blue-400 shrink-0" />
                          {prop.neighborhood}, {prop.city}
                        </span>
                        <span className="text-base sm:text-lg font-black drop-shadow-md">
                          {formatFCFA(prop.monthlyRent)} <span className="text-xs font-normal text-slate-200">/mois</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Content Body */}
                  <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="font-bold text-slate-900 text-sm leading-snug line-clamp-1 group-hover:text-blue-600 transition-colors">
                        {prop.title}
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">
                        {prop.categoryDesc}
                      </p>

                      {/* Specs Pills */}
                      <div className="flex items-center flex-wrap gap-2 sm:gap-3 mt-2 text-xs text-slate-600">
                        <span className="flex items-center gap-1 font-medium">
                          <Bed className="w-3.5 h-3.5 text-slate-400" />
                          {prop.rooms} {prop.rooms > 1 ? 'pces' : 'pce'}
                        </span>
                        <span className="flex items-center gap-1 font-medium">
                          <Bath className="w-3.5 h-3.5 text-slate-400" />
                          {prop.bathrooms} sdb
                        </span>
                        <span className="flex items-center gap-1 font-medium">
                          <Maximize2 className="w-3.5 h-3.5 text-slate-400" />
                          {prop.surface} m²
                        </span>
                        {prop.furnished && (
                          <span className="text-blue-600 font-bold">Meublé</span>
                        )}
                        {prop.refNumber && (
                          <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded border border-slate-200">
                            Réf: {prop.refNumber}
                          </span>
                        )}
                        {prop.floorLevel && (
                          <span className="text-[10px] font-bold bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded border border-blue-200">
                            {prop.floorLevel}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Localisation & Navigation Pill */}
                    <div className="flex items-center justify-between text-[11px] text-blue-700 bg-blue-50/70 hover:bg-blue-100/80 px-2.5 py-1.5 rounded-xl border border-blue-200/60 transition-colors">
                      <span className="font-bold flex items-center gap-1">
                        <Navigation className="w-3 h-3 text-blue-600" />
                        Carte & Itinéraire en direct
                      </span>
                      <span className="text-[10px] font-semibold text-blue-500 flex items-center">
                        Calculer trajet ↗
                      </span>
                    </div>

                    {/* LOC Micro-Finance Advantage Box */}
                    <div className="p-3 rounded-2xl bg-blue-50/90 border border-blue-200/90 space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-blue-900 font-bold flex items-center gap-1.5">
                          <Sparkles className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                          Apport initial LOC :
                        </span>
                        <span className="font-black text-blue-800 font-mono bg-white px-2 py-0.5 rounded-lg border border-blue-200 shadow-2xs">
                          {formatFCFA(plan.initialTotalDue)}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-slate-600">
                        <span>Sans LOC : <span className="line-through text-slate-400 font-mono">{formatFCFA(plan.standardInitialDue)}</span></span>
                        <span className="text-emerald-700 font-extrabold bg-emerald-100/90 px-1.5 py-0.5 rounded text-[10px]">
                          -{plan.savingsPercent}% à l'entrée
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
