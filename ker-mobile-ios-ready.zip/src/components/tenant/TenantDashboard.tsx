import React, { useState } from 'react';
import { 
  Sparkles, 
  Clock, 
  FileText, 
  CheckCircle2, 
  TrendingUp, 
  ChevronRight,
  Plus,
  ShieldCheck,
  Calculator,
  UserCheck,
  Building,
  Info,
  MessageSquare,
  AlertTriangle,
  Calendar,
  Send,
  MapPin,
  Check,
  Phone,
  ArrowRight,
  Wrench,
  DollarSign,
  User,
  Upload,
  Briefcase
} from 'lucide-react';
import { 
  Property, 
  RentReceipt, 
  MicroPayment, 
  TenantApplication, 
  VisitAppointment, 
  ChatConversation, 
  PaymentMethod,
  UserProfile,
  SignalementItem
} from '../../types';
import { formatFCFA } from '../../utils/finance';
import { RentMicroPaymentsView } from './RentMicroPaymentsView';
import { ApplicationTracker } from './ApplicationTracker';
import { CalendarInviteCard } from '../common/CalendarInviteCard';
import { TenantAppointmentsView } from './TenantAppointmentsView';

interface TenantDashboardProps {
  currentProperty: Property;
  properties?: Property[];
  paidThisMonth?: number;
  paidAmountThisMonth?: number;
  totalDueThisMonth: number;
  microPayments: MicroPayment[];
  receipts: RentReceipt[];
  depositMonthsPaid: number;
  onOpenPayModal?: (presetAmount?: number) => void;
  onOpenPaymentModal?: (presetAmount?: number) => void;
  onViewReceipt: (receipt: RentReceipt) => void;
  onViewContract: () => void;
  onOpenCalculator: () => void;
  onOpenKYCModal?: () => void;
  onApplyAlternativeProperty?: (property: Property) => void;
  applications?: TenantApplication[];
  appointments?: VisitAppointment[];
  conversations?: ChatConversation[];
  signalements?: SignalementItem[];
  onAddSignalement?: (sig: SignalementItem) => void;
  onSendMessage?: (conversationId: string, text: string) => void;
  tenantId?: string;
  currentUser?: UserProfile | null;
  tenantKYCScore?: number;
  onOpenProfile?: () => void;
  onValidateAppointment?: (appointmentId: string, date: string, timeSlot: string, location: string) => void;
  onRescheduleAppointment?: (appointmentId: string, newDate: string, newTimeSlot: string, reason?: string) => void;
  onAddAppointment?: (newAppt: VisitAppointment) => void;
}

export const TenantDashboard: React.FC<TenantDashboardProps> = ({
  currentProperty,
  properties = [],
  paidThisMonth,
  paidAmountThisMonth,
  totalDueThisMonth,
  microPayments,
  receipts,
  depositMonthsPaid,
  onOpenPayModal,
  onOpenPaymentModal,
  onViewReceipt,
  onViewContract,
  onOpenCalculator,
  onOpenKYCModal,
  onApplyAlternativeProperty,
  applications = [],
  appointments = [],
  conversations = [],
  signalements = [],
  onAddSignalement,
  onSendMessage,
  tenantId = 'tenant-demo',
  currentUser,
  tenantKYCScore = 88,
  onOpenProfile,
  onValidateAppointment,
  onRescheduleAppointment,
  onAddAppointment,
}) => {
  const effectivePaid = paidThisMonth !== undefined ? paidThisMonth : (paidAmountThisMonth || 0);
  const handleOpenPay = onOpenPaymentModal || onOpenPayModal || (() => {});

  // Tab State: loyer, suivi, dossier_kyc, rendez_vous, chat, signalements
  const [activeSubView, setActiveSubView] = useState<'loyer' | 'suivi' | 'dossier_kyc' | 'rendez_vous' | 'chat' | 'signalements'>('loyer');
  const [chatMessageInput, setChatMessageInput] = useState('');
  
  // Custom signalement form state
  const [newSigTitle, setNewSigTitle] = useState('');
  const [newSigDesc, setNewSigDesc] = useState('');
  const [newSigCat, setNewSigCat] = useState<'plomberie' | 'electricite' | 'serrurerie' | 'litige_bail' | 'annonce_suspecte' | 'autre'>('plomberie');
  const [newSigPriority, setNewSigPriority] = useState<'basse' | 'moyenne' | 'haute' | 'urgente'>('moyenne');
  const [isAddingSignalement, setIsAddingSignalement] = useState(false);

  // Active user applications
  const tenantApps = applications.filter(a => a.tenantId === tenantId || a.tenantId === 'tenant-demo' || a.tenantId === 'user-cand-1');
  const acceptedApps = tenantApps.filter(a => a.status === 'approved' || a.status === 'lease_signed');
  
  // Filtered signalements for this tenant
  const userSignalements = signalements.filter(
    (s) => s.authorId === tenantId || s.authorId === 'tenant-demo' || (currentProperty && s.propertyId === currentProperty.id)
  );
  
  // Active chat conversation
  const userConv = conversations.find(c => c.participantId === tenantId || c.id === `conv-${tenantId}`) || conversations[0];

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessageInput.trim() || !onSendMessage) return;
    const targetConvId = userConv ? userConv.id : `conv-${tenantId}`;
    onSendMessage(targetConvId, chatMessageInput.trim());
    setChatMessageInput('');
  };

  const handleAddSignalement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSigTitle.trim() || !newSigDesc.trim()) return;
    const newSig: SignalementItem = {
      id: `sig-${Date.now()}`,
      authorId: currentUser?.id || tenantId,
      authorName: currentUser?.fullName || 'Locataire LOC',
      authorRole: 'tenant',
      authorPhone: currentUser?.phone || '+221 77 000 00 00',
      propertyId: currentProperty?.id || acceptedApps[0]?.propertyId,
      propertyTitle: currentProperty?.title || acceptedApps[0]?.propertyTitle || 'Logement LOC',
      title: newSigTitle.trim(),
      description: newSigDesc.trim(),
      category: newSigCat,
      priority: newSigPriority,
      status: 'nouveau',
      createdAt: new Date().toISOString(),
    };
    if (onAddSignalement) {
      onAddSignalement(newSig);
    }
    setNewSigTitle('');
    setNewSigDesc('');
    setIsAddingSignalement(false);
  };

  return (
    <div className="p-2 sm:p-5 pb-24 space-y-6 text-slate-800 animate-fade-in" id="tenant-dashboard-container">
      
      {/* BANNER NOTIFICATION: CANDIDATURE ACCEPTÉE */}
      {acceptedApps.length > 0 && (
        <div className="p-4 rounded-3xl bg-linear-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-fade-in border border-emerald-400/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-xs text-white font-bold flex items-center justify-center shrink-0 text-xl shadow-xs">
              🎉
            </div>
            <div className="space-y-0.5">
              <h3 className="text-xs sm:text-sm font-black tracking-wide">
                Candidature Acceptée pour "{acceptedApps[0].propertyTitle}" !
              </h3>
              <p className="text-[11px] text-emerald-100 font-medium">
                Vous avez reçu un message important dans votre Chat pour valider votre créneau de visite et signer votre bail officiel.
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveSubView('chat')}
            className="py-2.5 px-4 rounded-xl bg-white text-emerald-900 font-extrabold text-xs shadow-sm hover:bg-emerald-50 active:scale-95 transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer"
          >
            <MessageSquare className="w-4 h-4 text-emerald-700" />
            <span>Consulter mon Chat (1)</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* REDESIGNED INNOVATIVE SUB-NAV NAVIGATION BAR */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 bg-white border border-slate-200 p-4 sm:p-5 rounded-3xl shadow-xs">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5 flex-wrap">
            <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
              🏡
            </div>
            <h1 className="text-lg sm:text-xl font-black text-slate-900">
              Espace Locataire LOC
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-200 uppercase flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              Caution Garantie Activée
            </span>
            {onOpenProfile && (
              <button
                type="button"
                onClick={onOpenProfile}
                className="px-2.5 py-1 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-bold border border-blue-200 transition-all flex items-center gap-1.5 cursor-pointer ml-auto sm:ml-0"
              >
                <User className="w-3.5 h-3.5 text-blue-600" />
                <span>Modifier mon profil</span>
              </button>
            )}
          </div>
          <p className="text-xs text-slate-500 font-medium">
            Gérez votre loyer par tranches, suivez vos candidatures en temps réel et certifiez vos pièces justificatives.
          </p>
        </div>

        {/* Tab Selection */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 border border-slate-200/80 rounded-2xl overflow-x-auto">
          {[
            { id: 'loyer', label: 'Mon Loyer & Tranches', icon: DollarSign },
            { id: 'dossier_kyc', label: 'Mon Dossier Solvabilité', icon: FileText },
            { id: 'suivi', label: `Suivi du Dossier (${tenantApps.length})`, icon: UserCheck },
            { id: 'rendez_vous', label: `Mes Rendez-vous (${appointments.length})`, icon: Calendar },
            { id: 'chat', label: acceptedApps.length > 0 ? 'Mon Chat 💬' : 'Mon Chat', icon: MessageSquare, badge: acceptedApps.length > 0 },
            { id: 'signalements', label: 'Signalements', icon: Wrench },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeSubView === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveSubView(tab.id as any)}
                className={`relative py-2 px-3 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-white text-blue-600 shadow-xs border border-slate-200/60 font-black'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping absolute -top-0.5 -right-0.5" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SUBVIEW 1: MON LOYER & MICRO-VERSEMENTS (REDESIGNED VIEW)                 */}
      {/* ========================================================================= */}
      {activeSubView === 'loyer' && (
        <RentMicroPaymentsView
          property={currentProperty}
          properties={properties}
          applications={tenantApps.length > 0 ? tenantApps : applications}
          totalDueThisMonth={totalDueThisMonth}
          paidThisMonth={effectivePaid}
          microPayments={microPayments}
          receipts={receipts}
          depositInstallmentsPaid={depositMonthsPaid}
          isLeaseApproved={Boolean(tenantApps.some(a => a.status === 'approved' || a.status === 'lease_signed') || totalDueThisMonth > 0 || microPayments.length > 0 || depositMonthsPaid > 0)}
          onOpenPaymentModal={handleOpenPay}
          onOpenReceiptDetail={onViewReceipt}
          onNavigateToSuivi={() => setActiveSubView('suivi')}
        />
      )}

      {/* ========================================================================= */}
      {/* SUBVIEW 2: SUIVI DU DOSSIER DE CANDIDATURE (AVEC TOUTES LES OPTIONS)      */}
      {/* ========================================================================= */}
      {activeSubView === 'suivi' && (
        <ApplicationTracker
          applications={tenantApps.length > 0 ? tenantApps : applications}
          properties={properties}
          onApplyAlternativeProperty={(prop) => {
            if (onApplyAlternativeProperty) {
              onApplyAlternativeProperty(prop);
            }
          }}
          onOpenLeaseModal={onViewContract}
          onValidateAppointment={onValidateAppointment}
        />
      )}

      {/* ========================================================================= */}
      {/* SUBVIEW 3: RENDEZ-VOUS & VISITES DE LOGEMENTS                            */}
      {/* ========================================================================= */}
      {activeSubView === 'rendez_vous' && (
        <TenantAppointmentsView
          appointments={appointments}
          applications={tenantApps}
          properties={properties}
          tenantId={tenantId}
          onValidateAppointment={onValidateAppointment}
          onRescheduleAppointment={onRescheduleAppointment}
          onAddAppointment={onAddAppointment}
          onNavigateToChat={() => setActiveSubView('chat')}
        />
      )}

      {/* ========================================================================= */}
      {/* SUBVIEW 3: DOSSIER DE SOLVABILITÉ & GARANT SOLIDAIRE                     */}
      {/* ========================================================================= */}
      {activeSubView === 'dossier_kyc' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-xs space-y-6 animate-fade-in max-w-4xl mx-auto">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[11px] font-bold border border-blue-200">
                <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                Dossier de Solvabilité & Garant
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                Mon Profil Financier & Pièces Justificatives
              </h2>
              <p className="text-xs text-slate-500">
                Justificatifs certifiés selon votre profession pour l'accès prioritaire aux logements et à l'échelonnement.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setActiveSubView('suivi')}
                className="py-2.5 px-3.5 rounded-2xl bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs flex items-center gap-1.5 border border-blue-200 transition-all shrink-0"
              >
                <UserCheck className="w-4 h-4 text-blue-600" />
                <span>Suivi candidature ({tenantApps.length})</span>
              </button>

              {onOpenKYCModal && (
                <button
                  type="button"
                  onClick={onOpenKYCModal}
                  className="py-2.5 px-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-2 shadow-xs transition-all shrink-0"
                >
                  <FileText className="w-4 h-4" />
                  <span>Mettre à jour</span>
                </button>
              )}
            </div>
          </div>

          {/* Solvency Score Banner */}
          <div className="p-5 rounded-2xl bg-linear-to-r from-blue-50 to-indigo-50 border border-blue-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                Score de Solvabilité LOC
              </span>
              <div className="flex items-center gap-3">
                <span className="text-3xl font-black text-blue-700 font-mono">{tenantKYCScore}/100</span>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-100 text-emerald-800 border border-emerald-200">
                  Dossier Excellent • Éligible 100%
                </span>
              </div>
              <p className="text-xs text-slate-600 font-medium pt-1">
                Votre profil financier permet d'accéder aux logements avec caution étalée sur 6 mois sans frais.
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-blue-600 text-white border border-blue-500 text-center shadow-xs">
              <span className="text-[10px] text-blue-100 font-bold uppercase block">Plafond Loyer Conseillé</span>
              <span className="text-base font-black text-white font-mono block">
                {formatFCFA(Math.round((currentUser?.monthlyIncome || 450000) * 0.33))} / mois
              </span>
            </div>
          </div>

          {/* Detailed Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            
            {/* Candidate Professional Info */}
            <div className="p-5 rounded-2xl bg-blue-50/80 border border-blue-200 space-y-3">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                <Briefcase className="w-4 h-4 text-blue-600" />
                Situation Professionnelle
              </h3>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-blue-200/80">
                  <span className="text-slate-600">Statut :</span>
                  <span className="font-bold text-slate-900 capitalize">
                    {currentUser?.employmentType || 'Salarié (CDI)'}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-blue-200/80">
                  <span className="text-slate-600">Profession :</span>
                  <span className="font-bold text-slate-900">
                    {currentUser?.profession || 'Responsable Marketing Digital'}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-blue-200/80">
                  <span className="text-slate-600">Entreprise :</span>
                  <span className="font-bold text-slate-900">Sonatel S.A. / Orange</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-600">Revenu Net Mensuel :</span>
                  <span className="font-mono font-black text-emerald-700">
                    {formatFCFA(currentUser?.monthlyIncome || 450000)}
                  </span>
                </div>
              </div>
            </div>

            {/* Guarantor Details */}
            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-blue-600" />
                Garant Solidaire Enregistré
              </h3>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-200/80">
                  <span className="text-slate-500">Nom & Prénom :</span>
                  <span className="font-bold text-slate-900">Dr. Ousmane Sow</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-200/80">
                  <span className="text-slate-500">Téléphone :</span>
                  <span className="font-mono font-bold text-slate-900">+221 77 123 45 67</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-200/80">
                  <span className="text-slate-500">Profession :</span>
                  <span className="font-bold text-slate-900">Médecin Chef (Clinique Madeleine)</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-500">Montant Garanti (Caution) :</span>
                  <span className="font-mono font-black text-blue-700">
                    {formatFCFA(360000)}
                  </span>
                </div>
              </div>
            </div>

          </div>

          {/* Uploaded Documents List */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            <h3 className="text-xs font-black text-slate-900 block flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-blue-600" />
              Pièces Justificatives Certifiées au Dossier (Salarié / Fonctionnaire)
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-base">🪪</span>
                  <div>
                    <span className="font-bold text-slate-900 block">CNI / Passeport</span>
                    <span className="text-[10px] text-slate-500">Recto-Verso</span>
                  </div>
                </div>
                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                  Validé
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-base">📄</span>
                  <div>
                    <span className="font-bold text-slate-900 block">1 Fiche de Paie</span>
                    <span className="text-[10px] text-slate-500">Dernier bulletin</span>
                  </div>
                </div>
                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                  Certifié
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-base">📋</span>
                  <div>
                    <span className="font-bold text-slate-900 block">Contrat de Travail</span>
                    <span className="text-[10px] text-slate-500">Attestation DRH</span>
                  </div>
                </div>
                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                  Conforme
                </span>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* SUBVIEW 4: MESSAGERIE EN DIRECT AVEC LE SUPPORT LOC                       */}
      {/* ========================================================================= */}
      {activeSubView === 'chat' && (
        <div className="max-w-3xl mx-auto animate-fade-in">
          <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs flex flex-col h-[520px]">
            <div className="pb-3 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-blue-600 text-white font-bold text-sm flex items-center justify-center">
                  📞
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900">Support LOC & Risque</h4>
                  <p className="text-xs text-slate-500 font-medium">Réponse en moins de 15 min • Dakar, Sénégal</p>
                </div>
              </div>
              <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase bg-blue-50 text-blue-800 border border-blue-200">
                Ligne Directe
              </span>
            </div>

            <div className="flex-1 overflow-y-auto py-4 space-y-3 pr-1">
              {userConv && userConv.messages.length > 0 ? (
                userConv.messages.map((msg) => {
                  const isMe = msg.senderRole === 'tenant';
                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                    >
                      <div
                        className={`max-w-[80%] p-3.5 rounded-2xl text-xs space-y-1 ${
                          isMe
                            ? 'bg-blue-600 text-white rounded-br-none shadow-xs'
                            : 'bg-slate-100 text-slate-800 rounded-bl-none border border-slate-200/50'
                        }`}
                      >
                        <span className="text-[9px] opacity-80 font-bold block">{msg.senderName}</span>
                        <p className="text-xs leading-relaxed font-medium whitespace-pre-wrap">{msg.text}</p>
                        
                        {/* Interactive Calendar / Visit Appointment Card */}
                        {msg.appointmentInvite && (
                          <div className="pt-2">
                            <CalendarInviteCard
                              invite={msg.appointmentInvite}
                              currentRole="tenant"
                              onValidateAppointment={onValidateAppointment}
                            />
                          </div>
                        )}
                      </div>
                      <span className="text-[9px] text-slate-400 px-1 mt-1 font-mono">{msg.timestamp}</span>
                    </div>
                  );
                })
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center p-8 space-y-3">
                  <MessageSquare className="w-12 h-12 text-blue-200" />
                  <div>
                    <span className="text-xs font-bold text-slate-800 block">Démarrer une discussion</span>
                    <p className="text-[11px] text-slate-500 mt-1 max-w-[280px]">Posez vos questions à l'équipe LOC ou échangez sur vos micro-versements.</p>
                  </div>
                </div>
              )}
            </div>

            <form onSubmit={handleSendChat} className="pt-3 border-t border-slate-100 flex gap-2">
              <input
                type="text"
                value={chatMessageInput}
                onChange={(e) => setChatMessageInput(e.target.value)}
                placeholder="Écrivez votre message à LOC Support..."
                className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none transition-colors font-medium"
              />
              <button
                type="submit"
                className="p-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white shadow-md transition-all shrink-0 flex items-center justify-center"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUBVIEW 5: SIGNALEMENT DES PANNES & INCIDENTS                             */}
      {/* ========================================================================= */}
      {activeSubView === 'signalements' && (
        <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
          <div className="flex justify-between items-center px-1 flex-wrap gap-2">
            <div>
              <h2 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Wrench className="w-5 h-5 text-blue-600" />
                Signalements & Réclamations de pannes
              </h2>
              <p className="text-xs text-slate-500">Signalez directement les réparations nécessaires ou pannes techniques dans votre logement.</p>
            </div>

            <button
              onClick={() => setIsAddingSignalement(!isAddingSignalement)}
              className="py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Nouveau Signalement</span>
            </button>
          </div>

          {isAddingSignalement && (
            <form onSubmit={handleAddSignalement} className="p-4 rounded-3xl bg-blue-50/70 border border-blue-200 space-y-3 animate-fade-in">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-blue-900 flex items-center gap-1.5">
                  <Wrench className="w-4 h-4 text-blue-600" />
                  Signaler un incident technique
                </span>
                <button
                  type="button"
                  onClick={() => setIsAddingSignalement(false)}
                  className="text-xs text-slate-400 hover:text-slate-700"
                >
                  Fermer
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="sm:col-span-1">
                  <label className="text-[10px] font-bold text-slate-700 block mb-1">Titre de la panne :</label>
                  <input
                    type="text"
                    value={newSigTitle}
                    onChange={(e) => setNewSigTitle(e.target.value)}
                    placeholder="Ex: Fuite sous évier cuisine"
                    required
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-700 block mb-1">Catégorie :</label>
                  <select
                    value={newSigCat}
                    onChange={(e) => setNewSigCat(e.target.value as any)}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900"
                  >
                    <option value="plomberie">Plomberie</option>
                    <option value="electricite">Électricité / Climatisation</option>
                    <option value="serrurerie">Serrurerie / Portes</option>
                    <option value="litige_bail">Litige ou question bail</option>
                    <option value="autre">Autre incident technique</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-700 block mb-1">Priorité :</label>
                  <select
                    value={newSigPriority}
                    onChange={(e) => setNewSigPriority(e.target.value as any)}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-bold"
                  >
                    <option value="basse">Basse (Confort)</option>
                    <option value="moyenne">Moyenne (Standard)</option>
                    <option value="haute">Haute (Gênant)</option>
                    <option value="urgente">Urgente (Dégât des eaux / Sécurité)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-700 block mb-1">Description détaillée de la panne :</label>
                <textarea
                  value={newSigDesc}
                  onChange={(e) => setNewSigDesc(e.target.value)}
                  placeholder="Veuillez décrire le problème précisément pour faciliter l'intervention d'un technicien LOC agréé."
                  required
                  rows={3}
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 outline-none"
                />
              </div>

              <div className="pt-1 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddingSignalement(false)}
                  className="py-2 px-3.5 rounded-xl bg-white border border-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs cursor-pointer"
                >
                  Transmettre au Pôle Technique & Bailleur
                </button>
              </div>
            </form>
          )}

          {userSignalements.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 border border-slate-200 rounded-3xl space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-white border border-slate-200 text-slate-400 mx-auto flex items-center justify-center text-xl shadow-xs">
                🔧
              </div>
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-slate-800">Aucun signalement d'incident enregistré</h4>
                <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
                  En cas d'incident technique ou de réparation nécessaire dans votre logement (plomberie, électricité, serrurerie), transmettez votre signalement ici.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsAddingSignalement(true)}
                className="py-2 px-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs inline-flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Nouveau Signalement</span>
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {userSignalements.map((sig) => (
                <div key={sig.id} className="p-4 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3">
                  <div className="flex items-start justify-between gap-2 flex-wrap">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center font-bold">
                        🔧
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-slate-900">{sig.title}</h4>
                        <p className="text-[10px] text-slate-500 capitalize">
                          {sig.category} • {sig.propertyTitle || 'Logement LOC'} • {new Date(sig.createdAt).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase border ${
                        sig.priority === 'urgente'
                          ? 'bg-rose-100 text-rose-800 border-rose-200'
                          : sig.priority === 'haute'
                          ? 'bg-orange-100 text-orange-800 border-orange-200'
                          : 'bg-slate-100 text-slate-700 border-slate-200'
                      }`}>
                        {sig.priority}
                      </span>
                      <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase border ${
                        sig.status === 'resolu'
                          ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                          : sig.status === 'en_cours'
                          ? 'bg-blue-100 text-blue-800 border-blue-200'
                          : sig.status === 'rejete'
                          ? 'bg-slate-100 text-slate-600 border-slate-200'
                          : 'bg-amber-100 text-amber-800 border-amber-200'
                      }`}>
                        {sig.status === 'resolu' ? 'Résolu' : sig.status === 'en_cours' ? 'Intervention en cours' : sig.status === 'rejete' ? 'Classé sans suite' : 'Transmis à l\'équipe'}
                      </span>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    {sig.description}
                  </p>

                  {sig.assignedArtisan && (
                    <div className="p-3 rounded-xl bg-blue-50 text-[11px] text-blue-900 border border-blue-100 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-blue-600 shrink-0" />
                        <span>Artisan assigné : <strong className="font-bold">{sig.assignedArtisan}</strong></span>
                      </div>
                    </div>
                  )}

                  {sig.adminNotes && (
                    <div className="p-2.5 rounded-xl bg-emerald-50 text-[11px] text-emerald-900 border border-emerald-100">
                      <strong>Note du Pôle Support :</strong> {sig.adminNotes}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

    </div>
  );
};
