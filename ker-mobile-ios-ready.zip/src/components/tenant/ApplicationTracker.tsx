import React, { useState } from 'react';
import { 
  Building2, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  XCircle, 
  FileText, 
  ArrowRight, 
  ShieldCheck, 
  UserCheck, 
  Calendar, 
  MapPin, 
  Sparkles, 
  Check, 
  ExternalLink,
  ChevronRight,
  RefreshCw,
  Phone,
  X,
  CreditCard,
  User,
  Info,
  BadgeCheck,
  Wallet
} from 'lucide-react';
import { TenantApplication, Property } from '../../types';
import { formatFCFA, calculateDepositPlan, calculateClassicPlan } from '../../utils/finance';

interface ApplicationTrackerProps {
  applications: TenantApplication[];
  properties: Property[];
  onApplyAlternativeProperty?: (property: Property) => void;
  onOpenLeaseModal?: () => void;
  onOpenAppointmentScheduler?: () => void;
  onOpenPropertyDetail?: (property: Property) => void;
  tenantId?: string;
  onSelectProperty?: (property: Property) => void;
  onValidateAppointment?: (appointmentId: string, date: string, timeSlot: string, location: string) => void;
}

export const ApplicationTracker: React.FC<ApplicationTrackerProps> = ({
  applications,
  properties,
  onApplyAlternativeProperty,
  onOpenLeaseModal,
  onOpenAppointmentScheduler,
  onOpenPropertyDetail,
  tenantId,
  onSelectProperty,
  onValidateAppointment,
}) => {
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');

  const [selectedAppId, setSelectedAppId] = useState<string>(() => {
    return applications.length > 0 ? applications[0].id : '';
  });

  const filteredApps = applications.filter(app => {
    if (filterStatus === 'all') return true;
    if (filterStatus === 'approved') return app.status === 'approved' || app.status === 'lease_signed';
    return app.status === filterStatus;
  });

  const [isRDVModalOpen, setIsRDVModalOpen] = useState<boolean>(false);
  const [rdvDate, setRdvDate] = useState<string>(() => {
    const tmr = new Date();
    tmr.setDate(tmr.getDate() + 1);
    return tmr.toISOString().split('T')[0];
  });
  const [rdvTime, setRdvTime] = useState<string>('15:00 - 16:00');
  const [confirmedRDV, setConfirmedRDV] = useState<{ date: string; time: string } | null>(null);

  // Determine active application safely
  const activeApp = filteredApps.find(a => a.id === selectedAppId) || filteredApps[0] || applications[0];

  const handleConfirmRDV = () => {
    let displayDate = rdvDate;
    if (rdvDate && rdvDate.includes('-')) {
      try {
        const parts = rdvDate.split('-');
        if (parts.length === 3) {
          const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
          displayDate = d.toLocaleDateString('fr-FR', {
            weekday: 'long',
            day: 'numeric',
            month: 'long',
            year: 'numeric'
          });
          displayDate = displayDate.charAt(0).toUpperCase() + displayDate.slice(1);
        }
      } catch {}
    }

    setConfirmedRDV({ date: displayDate, time: rdvTime });
    if (onValidateAppointment) {
      onValidateAppointment(`appt-${Date.now()}`, displayDate, rdvTime, activeApp?.propertyAddress || 'Dakar, Sénégal');
    }
    setIsRDVModalOpen(false);
  };

  // When filter changes, update selection
  const handleFilterChange = (status: 'all' | 'pending' | 'approved' | 'rejected') => {
    setFilterStatus(status);
    const matching = applications.filter(app => {
      if (status === 'all') return true;
      if (status === 'approved') return app.status === 'approved' || app.status === 'lease_signed';
      return app.status === status;
    });
    if (matching.length > 0) {
      setSelectedAppId(matching[0].id);
    }
  };

  // Find alternative properties recommended for rejected applications
  const getAlternativeProperties = (app: TenantApplication): Property[] => {
    if (app.alternativePropertyIds && app.alternativePropertyIds.length > 0) {
      return properties.filter(p => app.alternativePropertyIds?.includes(p.id) && p.isAvailable);
    }
    const maxAffordableRent = Math.round(app.monthlyIncome * 0.35);
    return properties.filter(
      p => p.isAvailable && p.id !== app.propertyId && p.monthlyRent <= Math.max(maxAffordableRent, 130000)
    ).slice(0, 3);
  };

  const getStatusBadge = (status: TenantApplication['status']) => {
    switch (status) {
      case 'approved':
      case 'lease_signed':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-emerald-100 text-emerald-800 border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Dossier Validé
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-rose-100 text-rose-800 border border-rose-200">
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            Candidature Non Retenue
          </span>
        );
      case 'pending':
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-amber-100 text-amber-900 border border-amber-200">
            <Clock className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
            En cours d'analyse
          </span>
        );
    }
  };

  if (!activeApp) {
    return (
      <div className="bg-white border border-slate-200 rounded-3xl p-8 text-center space-y-3">
        <Building2 className="w-12 h-12 text-slate-300 mx-auto" />
        <h3 className="text-base font-bold text-slate-800">Aucune candidature enregistrée pour le moment</h3>
        <p className="text-xs text-slate-500 max-w-md mx-auto">
          Explorez le catalogue de logements disponibles et postulez avec la formule Micro-Caution LOC ou la formule Classique.
        </p>
      </div>
    );
  }

  const alternativeProps = getAlternativeProperties(activeApp);
  const isClassic = activeApp.applicationOption === 'classic_direct';
  const kerPlan = calculateDepositPlan(activeApp.monthlyRent, 2);
  const classicPlan = calculateClassicPlan(activeApp.monthlyRent, 2);

  return (
    <div className="space-y-6 animate-fade-in text-slate-800">
      
      {/* Top Application Selector & Status Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white border border-slate-200 rounded-2xl p-3 shadow-xs">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          {[
            { id: 'all', label: 'Toutes les candidatures', count: applications.length },
            { id: 'pending', label: 'En cours', count: applications.filter(a => a.status === 'pending').length },
            { id: 'approved', label: 'Validées', count: applications.filter(a => a.status === 'approved' || a.status === 'lease_signed').length },
            { id: 'rejected', label: 'Non retenues', count: applications.filter(a => a.status === 'rejected').length },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => handleFilterChange(tab.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                filterStatus === tab.id
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <span>{tab.label}</span>
              <span className={`px-1.5 py-0.2 rounded-md text-[10px] font-mono ${
                filterStatus === tab.id ? 'bg-white/25 text-white' : 'bg-slate-200 text-slate-700'
              }`}>
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
          <span className="hidden md:inline">•</span>
          <span>{filteredApps.length} dossier(s)</span>
        </div>
      </div>

      {filteredApps.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-3xl p-8 text-center space-y-3">
          <Building2 className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="text-sm font-bold text-slate-800">
            Aucun dossier dans la catégorie « {
              filterStatus === 'pending' ? 'En cours' : filterStatus === 'approved' ? 'Validées' : 'Non retenues'
            } »
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Vous n'avez pas de candidature correspondant à ce filtre actuellement.
          </p>
          <button
            onClick={() => handleFilterChange('all')}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-xs"
          >
            Afficher toutes les candidatures
          </button>
        </div>
      ) : (
        <>
          {/* Applications Cards Carousel / Grid if multiple */}
          {filteredApps.length > 1 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {filteredApps.map((app) => {
                const appIsClassic = app.applicationOption === 'classic_direct';
                return (
                  <div
                    key={app.id}
                    onClick={() => setSelectedAppId(app.id)}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer text-left relative ${
                      selectedAppId === app.id
                        ? 'bg-blue-50/90 border-blue-600 ring-2 ring-blue-500/20 shadow-xs'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <span className="text-xs font-black text-slate-900 line-clamp-1">
                        {app.propertyTitle}
                      </span>
                      <span className="text-[10px] font-mono font-bold text-slate-600 shrink-0">
                        {formatFCFA(app.monthlyRent)}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 mb-2">
                      {appIsClassic ? (
                        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-blue-100 text-blue-900 border border-blue-200">
                          Classique (sans LOC)
                        </span>
                      ) : (
                        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-blue-100 text-blue-800 border border-blue-200">
                          Micro-Caution LOC
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between text-[11px] pt-1.5 border-t border-slate-100">
                      <span className="text-slate-500 text-[10px]">{app.appliedAt}</span>
                      {getStatusBadge(app.status)}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* ============================================================ */}
          {/* MAIN PERSONALIZED DASHBOARD PER FORMULA (LOC vs CLASSIQUE)   */}
          {/* ============================================================ */}
          <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-xs space-y-6">
            
            {/* Header of Active Application */}
            <div className="p-4 sm:p-5 rounded-2xl border border-blue-200/90 bg-gradient-to-r from-blue-50/90 via-blue-50/70 to-indigo-50/60 transition-all">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[10px] font-mono text-slate-500 font-bold uppercase">
                      Réf dossier : #{activeApp.id.toUpperCase()}
                    </span>
                    <span className="text-[10px] text-slate-300">•</span>
                    <span className="text-[10px] text-slate-600 font-medium">Déposé le {activeApp.appliedAt}</span>
                    <span className="text-[10px] text-slate-300">•</span>
                    
                    {isClassic ? (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-blue-700 text-white shadow-xs">
                        Formule Classique (Sans LOC) • Bail après visite
                      </span>
                    ) : (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-blue-600 text-white shadow-xs flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        Formule Micro-Financement Caution LOC
                      </span>
                    )}
                  </div>

                  <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                    {activeApp.propertyTitle}
                  </h2>

                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-700 font-medium">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      {activeApp.propertyAddress}
                    </span>
                    <span>•</span>
                    <span className="font-bold text-slate-900 font-mono">
                      Loyer de base : {formatFCFA(activeApp.monthlyRent)}/mois
                    </span>
                    {activeApp.preferredVisitDate && (
                      <>
                        <span>•</span>
                        <span className="text-amber-900 font-bold flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-amber-700" />
                          Visite souhaitée : {activeApp.preferredVisitDate}
                        </span>
                      </>
                    )}
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                  {getStatusBadge(activeApp.status)}
                  <div className="px-3 py-1.5 rounded-2xl bg-white border border-slate-200 text-slate-900 text-xs font-bold flex items-center gap-1.5 shadow-xs">
                    <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                    Score Solvabilité : <span className="font-mono font-black text-blue-700">{activeApp.kycScore}/100</span>
                  </div>
                </div>
              </div>
            </div>

            {/* ============================================================ */}
            {/* 1. TIMELINE WORKFLOW TRACKER : BRANCHED BY FORMULA           */}
            {/* ============================================================ */}
            {isClassic ? (
              /* --- WORKFLOW TRACKER FOR CLASSIQUE SANS LOC (5 ÉTAPES) --- */
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-black uppercase tracking-wider text-amber-950 flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-amber-700" />
                    Parcours Candidature Classique (Sans LOC) • 5 Étapes Clés
                  </h3>
                  <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                    0 F Frais de Dossier
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
                  {[
                    {
                      step: 1,
                      title: '1. Dépôt Dossier',
                      badge: 'Gratuit (0 F)',
                      desc: 'Justificatifs d\'identité & profession enregistrés sans aucun frais de dossier.',
                      isDone: true,
                      isActive: false,
                    },
                    {
                      step: 2,
                      title: '2. Visite des Lieux',
                      badge: 'Obligatoire',
                      desc: confirmedRDV 
                        ? `Visite confirmée pour le ${confirmedRDV.date}` 
                        : (activeApp.preferredVisitDate ? `Visite demandée pour le ${activeApp.preferredVisitDate}` : 'Créneau à fixer'),
                      isDone: Boolean(confirmedRDV) || activeApp.status === 'approved' || activeApp.status === 'lease_signed',
                      isActive: !confirmedRDV && activeApp.status === 'pending',
                    },
                    {
                      step: 3,
                      title: '3. Rapport & Avis',
                      badge: 'Conformité',
                      desc: 'Validation physique du logement et accord mutuel sur l\'état des lieux.',
                      isDone: activeApp.status === 'approved' || activeApp.status === 'lease_signed',
                      isActive: Boolean(confirmedRDV) && activeApp.status === 'pending',
                    },
                    {
                      step: 4,
                      title: '4. Accord de Bail',
                      badge: 'Post-visite',
                      desc: 'Bail de location officiel délivré après la visite concluante.',
                      isDone: activeApp.status === 'approved' || activeApp.status === 'lease_signed',
                      isActive: activeApp.status === 'approved',
                    },
                    {
                      step: 5,
                      title: '5. Règlement & Clés',
                      badge: '3 mois comptant',
                      desc: 'Paiement comptant (2 mois caution + 1 mois courtier) et remise des clés.',
                      isDone: activeApp.status === 'lease_signed',
                      isActive: activeApp.status === 'lease_signed',
                    },
                  ].map((st) => (
                    <div
                      key={st.step}
                      className={`p-3 rounded-2xl border transition-all relative flex flex-col justify-between ${
                        st.isDone
                          ? 'bg-emerald-50/80 border-emerald-300 text-emerald-950'
                          : st.isActive
                          ? 'bg-blue-50 border-blue-400 ring-2 ring-blue-500/20 text-blue-950 shadow-xs'
                          : 'bg-slate-50/70 border-slate-200 text-slate-400'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[11px] font-black">{st.title}</span>
                          {st.isDone ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          ) : st.isActive ? (
                            <span className="w-2 h-2 rounded-full bg-blue-600 animate-ping shrink-0" />
                          ) : (
                            <span className="w-3.5 h-3.5 rounded-full border border-slate-300 text-[9px] flex items-center justify-center font-bold">
                              {st.step}
                            </span>
                          )}
                        </div>
                        <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded-md mb-1 inline-block ${
                          st.isDone ? 'bg-emerald-200/70 text-emerald-900' : st.isActive ? 'bg-blue-100 text-blue-900' : 'bg-slate-200 text-slate-600'
                        }`}>
                          {st.badge}
                        </span>
                        <p className="text-[10px] leading-relaxed opacity-90 mt-1">
                          {st.desc}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              /* --- WORKFLOW TRACKER FOR MICRO-CAUTION LOC (4 ÉTAPES) --- */
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-blue-600" />
                    Parcours Micro-Financement Caution LOC • 4 Étapes Clés
                  </h3>
                  <span className="text-[11px] font-bold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded-full">
                    Caution Échelonnée 6 Mois
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  {[
                    {
                      step: 1,
                      title: '1. Scoring Solvabilité IA',
                      badge: 'Instant Scoring',
                      desc: `Score KYC (${activeApp.kycScore}/100) validé avec pièces conformes pour profil ${activeApp.professionCategory || 'Salarié'}.`,
                      isDone: true,
                      isActive: false,
                    },
                    {
                      step: 2,
                      title: '2. Accord Caution LOC',
                      badge: 'Garantie J+1',
                      desc: 'Garantie de caution accordée par LOC et sécurisée pour le propriétaire bailleur.',
                      isDone: activeApp.status === 'approved' || activeApp.status === 'lease_signed',
                      isActive: activeApp.status === 'approved',
                    },
                    {
                      step: 3,
                      title: '3. Apport Initial Réduit',
                      badge: '1/3 Caution',
                      desc: `Règlement de l'apport allégé (${formatFCFA(kerPlan.initialTotalDue)}) : 1er mois + 1/3 caution + 10% dossier.`,
                      isDone: activeApp.status === 'lease_signed',
                      isActive: activeApp.status === 'approved',
                    },
                    {
                      step: 4,
                      title: '4. Clés & Micro-Paiements',
                      badge: 'Échéancier 6m',
                      desc: 'Remise des clés et étalement des 2/3 de caution restants sur 6 mensualités souples.',
                      isDone: activeApp.status === 'lease_signed',
                      isActive: activeApp.status === 'lease_signed',
                    },
                  ].map((st) => (
                    <div
                      key={st.step}
                      className={`p-3.5 rounded-2xl border transition-all relative flex flex-col justify-between ${
                        st.isDone
                          ? 'bg-emerald-50/80 border-emerald-300 text-emerald-950'
                          : st.isActive
                          ? 'bg-blue-50 border-blue-400 ring-2 ring-blue-500/20 text-blue-950 shadow-xs'
                          : 'bg-slate-50/70 border-slate-200 text-slate-400'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-black">{st.title}</span>
                          {st.isDone ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          ) : st.isActive ? (
                            <span className="w-2 h-2 rounded-full bg-blue-600 animate-ping shrink-0" />
                          ) : (
                            <span className="w-4 h-4 rounded-full border border-slate-300 text-[10px] flex items-center justify-center font-bold">
                              {st.step}
                            </span>
                          )}
                        </div>
                        <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-md mb-1 inline-block ${
                          st.isDone ? 'bg-emerald-200/70 text-emerald-900' : st.isActive ? 'bg-blue-200/80 text-blue-900' : 'bg-slate-200 text-slate-600'
                        }`}>
                          {st.badge}
                        </span>
                        <p className="text-[11px] leading-relaxed opacity-90 mt-1">
                          {st.desc}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ============================================================ */}
            {/* 2. DEDICATED DASHBOARD PANELS (CLASSIQUE VS LOC)             */}
            {/* ============================================================ */}
            {isClassic ? (
              /* ============================================================ */
              /* DASHBOARD FORMULE CLASSIQUE (SANS LOC)                       */
              /* ============================================================ */
              <div className="space-y-4 pt-1">
                
                {/* Visual Banner Classic */}
                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-xl bg-slate-800 text-white flex items-center justify-center font-bold shrink-0 shadow-xs">
                        <Building2 className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-sm font-black text-slate-900">
                          Suivi du Dossier • Formule Classique sans LOC
                        </h4>
                        <p className="text-xs text-slate-600 font-medium">
                          Régime comptant standard avec visite physique préalable obligatoire.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-1 rounded-full bg-slate-100 border border-slate-200 text-slate-800 text-xs font-bold">
                        Bail accordé après visite
                      </span>
                      <span className="px-2.5 py-1 rounded-full bg-emerald-100 border border-emerald-300 text-emerald-800 text-xs font-bold">
                        Frais dossier : 0 F
                      </span>
                    </div>
                  </div>
                </div>

                {/* 3 Dedicated Classic Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  
                  {/* Card 1: Visite Physique des Lieux */}
                  <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3 flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                          <Calendar className="w-4 h-4 text-blue-600" />
                          Visite Physique
                        </span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          confirmedRDV 
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                            : 'bg-slate-100 text-slate-800 border border-slate-200'
                        }`}>
                          {confirmedRDV ? 'Rendez-vous Confirmé' : (activeApp.preferredVisitDate ? 'Visite Planifiée' : 'À planifier')}
                        </span>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1 text-xs">
                        <div className="flex justify-between">
                          <span className="text-slate-500">Date prévue :</span>
                          <span className="font-bold text-slate-900">
                            {confirmedRDV?.date || activeApp.preferredVisitDate || 'À convenir'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Créneau horaire :</span>
                          <span className="font-bold text-slate-900">
                            {confirmedRDV?.time || '15:00 - 16:00'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Agent LOC :</span>
                          <span className="font-bold text-slate-900">Moussa Ndiaye</span>
                        </div>
                      </div>

                      <p className="text-[11px] text-slate-600">
                        La visite physique sur place permet de vérifier la conformité du logement avant tout accord de bail.
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => setIsRDVModalOpen(true)}
                      className="w-full py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer"
                    >
                      <Calendar className="w-3.5 h-3.5" />
                      <span>{confirmedRDV ? 'Modifier la Visite' : 'Programmer la Visite'}</span>
                    </button>
                  </div>

                  {/* Card 2: Package Comptant à la Signature */}
                  <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3 flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                          <CreditCard className="w-4 h-4 text-blue-600" />
                          Montants au Comptant
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-800">
                          3 mois au total
                        </span>
                      </div>

                      <div className="space-y-1.5 text-xs">
                        <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex justify-between items-center">
                          <span className="text-slate-600">Apport comptant exigé :</span>
                          <span className="font-black font-mono text-slate-900 text-sm">
                            {formatFCFA(classicPlan.initialTotalDue)}
                          </span>
                        </div>
                        <div className="text-[11px] space-y-1 text-slate-600 pl-1">
                          <div className="flex justify-between">
                            <span>• 2 mois caution légale :</span>
                            <span className="font-bold font-mono">{formatFCFA(classicPlan.legalDeposit)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>• 1 mois commission courtier :</span>
                            <span className="font-bold font-mono">{formatFCFA(classicPlan.brokerFee)}</span>
                          </div>
                          <div className="flex justify-between text-emerald-700 font-bold">
                            <span>• Frais de dossier LOC :</span>
                            <span className="font-mono">0 FCFA</span>
                          </div>
                          <div className="flex justify-between text-slate-900 font-bold pt-1 border-t border-slate-100">
                            <span>• Loyer + Gestion (10%) :</span>
                            <span className="font-mono">{formatFCFA(classicPlan.monthlyTotalRent)}/m</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-[10px] text-emerald-900 font-semibold flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>Aucun frais de constitution de dossier prélevé.</span>
                    </div>
                  </div>

                  {/* Card 3: Bail de Location & Signature */}
                  <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3 flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                          <FileText className="w-4 h-4 text-blue-600" />
                          Bail après Visite
                        </span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          activeApp.status === 'approved' || activeApp.status === 'lease_signed'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-800'
                        }`}>
                          {activeApp.status === 'approved' || activeApp.status === 'lease_signed' ? 'Bail Disponible' : 'En attente de visite'}
                        </span>
                      </div>

                      <p className="text-[11px] text-slate-600 leading-relaxed">
                        Le contrat de bail officiel est édité et mis à votre disposition pour signature dès confirmation de la visite physique.
                      </p>

                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1">
                        <span className="font-bold text-slate-900 block">Services inclus plateforme :</span>
                        <div className="text-[11px] text-slate-600 space-y-0.5">
                          <div>✓ Quittances numériques chaque mois</div>
                          <div>✓ Assistance conciergerie LOC 7j/7</div>
                          <div>✓ Historique dématérialisé des paiements</div>
                        </div>
                      </div>
                    </div>

                    {onOpenLeaseModal && (
                      <button
                        type="button"
                        onClick={onOpenLeaseModal}
                        className="w-full py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Consulter le Projet de Bail</span>
                      </button>
                    )}
                  </div>

                </div>
              </div>
            ) : (
              /* ============================================================ */
              /* DASHBOARD FORMULE MICRO-CAUTION LOC                         */
              /* ============================================================ */
              <div className="space-y-4 pt-1">
                
                {/* Visual Banner LOC */}
                <div className="p-4 rounded-2xl bg-blue-50/80 border border-blue-200 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold shrink-0 shadow-xs">
                        <Sparkles className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-sm font-black text-slate-900">
                          Suivi du Dossier • Formule Micro-Financement Caution LOC
                        </h4>
                        <p className="text-xs text-blue-900 font-medium">
                          Caution allégée à 1/3 à l'entrée et 2/3 étalés sur 6 mensualités sans agios.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-1 rounded-full bg-emerald-100 border border-emerald-300 text-emerald-800 text-xs font-bold">
                        Économie immédiate : -{kerPlan.savingsPercent}%
                      </span>
                      <span className="px-2.5 py-1 rounded-full bg-blue-600 text-white text-xs font-bold shadow-xs">
                        Garantie LOC J+1
                      </span>
                    </div>
                  </div>
                </div>

                {/* 3 Dedicated LOC Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  
                  {/* Card 1: Échéancier 6 Mois */}
                  <div className="p-4 rounded-2xl bg-white border border-blue-200/80 shadow-xs space-y-3 flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                          <Wallet className="w-4 h-4 text-blue-600" />
                          Échéancier de la Caution
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                          Amorti sur 6 mois
                        </span>
                      </div>

                      <div className="space-y-1.5 text-xs">
                        <div className="p-2.5 rounded-xl bg-blue-50/70 border border-blue-100 flex justify-between items-center">
                          <span className="text-slate-600">Apport initial payé :</span>
                          <span className="font-black font-mono text-blue-800 text-sm">
                            {formatFCFA(kerPlan.initialTotalDue)}
                          </span>
                        </div>
                        <div className="text-[11px] space-y-1 text-slate-600 pl-1">
                          <div className="flex justify-between">
                            <span>• 1er mois de loyer net :</span>
                            <span className="font-bold font-mono">{formatFCFA(kerPlan.initialRentShare)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>• 1/3 de caution :</span>
                            <span className="font-bold font-mono">{formatFCFA(kerPlan.initialDepositShare)}</span>
                          </div>
                          <div className="flex justify-between text-blue-700 font-bold">
                            <span>• Frais dossier LOC (10%) :</span>
                            <span className="font-mono">{formatFCFA(kerPlan.serviceFee)}</span>
                          </div>
                          <div className="flex justify-between text-emerald-800 font-bold pt-1 border-t border-slate-100">
                            <span>• Mensualité Mois 1 à 6 :</span>
                            <span className="font-mono">{formatFCFA(kerPlan.monthlyTotalMonths1to6)}/m</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="p-2 rounded-xl bg-blue-50 border border-blue-200 text-[10px] text-blue-900 font-semibold flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                      <span>Économie d'entrée : {formatFCFA(kerPlan.immediateSavings)} préservés.</span>
                    </div>
                  </div>

                  {/* Card 2: Garantie LOC J+1 Propriétaire */}
                  <div className="p-4 rounded-2xl bg-white border border-blue-200/80 shadow-xs space-y-3 flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                          <ShieldCheck className="w-4 h-4 text-emerald-600" />
                          Garantie LOC Bailleur
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                          Sécurisé J+1
                        </span>
                      </div>

                      <p className="text-[11px] text-slate-600 leading-relaxed">
                        LOC avance et garantit 100% de la caution au propriétaire à J+1. Le bailleur est entièrement couvert sans risque d'impayé.
                      </p>

                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5 text-xs">
                        <div className="flex justify-between text-[11px]">
                          <span className="text-slate-500">Caution garantie propriétaire :</span>
                          <span className="font-bold font-mono text-emerald-700">{formatFCFA(kerPlan.monthlyRent * 2)}</span>
                        </div>
                        <div className="flex justify-between text-[11px]">
                          <span className="text-slate-500">Délai versement bailleur :</span>
                          <span className="font-bold text-slate-800">24h (J+1)</span>
                        </div>
                        <div className="flex justify-between text-[11px]">
                          <span className="text-slate-500">Protection juridique :</span>
                          <span className="font-bold text-blue-700">OHADA Intégrale</span>
                        </div>
                      </div>
                    </div>

                    <div className="p-2 rounded-xl bg-slate-100 text-[10px] text-slate-700 font-medium text-center">
                      Assuré par le fonds de garantie LOC FinTech
                    </div>
                  </div>

                  {/* Card 3: Micro-Paiements Souples & Bail OHADA */}
                  <div className="p-4 rounded-2xl bg-white border border-blue-200/80 shadow-xs space-y-3 flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                          <FileText className="w-4 h-4 text-blue-600" />
                          Bail & Micro-Paiements
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                          Wave & Orange Money
                        </span>
                      </div>

                      <p className="text-[11px] text-slate-600 leading-relaxed">
                        Réglez votre loyer en 1, 2 ou 3 fois du 1er au 30 du mois en toute flexibilité sans pénalités.
                      </p>

                      <div className="p-3 rounded-xl bg-blue-50/60 border border-blue-100 space-y-1 text-xs">
                        <span className="font-bold text-slate-900 block text-[11px]">Avantages Locataire LOC :</span>
                        <div className="text-[11px] text-slate-600 space-y-0.5">
                          <div>✓ Paiements fractionnés Wave / OM</div>
                          <div>✓ Évolution du score de solvabilité</div>
                          <div>✓ Quittances et bail OHADA certifié</div>
                        </div>
                      </div>
                    </div>

                    {onOpenLeaseModal && (
                      <button
                        type="button"
                        onClick={onOpenLeaseModal}
                        className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Consulter & Signer le Bail</span>
                      </button>
                    )}
                  </div>

                </div>
              </div>
            )}

            {/* ============================================================ */}
            {/* 3. APPLICATION STATUS HANDLERS (REJECTED / APPROVED / PENDING) */}
            {/* ============================================================ */}
            {activeApp.status === 'rejected' && (
              <div className="space-y-6 pt-2">
                
                {/* Rejection Cause Box */}
                <div className="p-5 rounded-3xl bg-rose-50 border border-rose-200 text-rose-900 space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-rose-100 border border-rose-200 flex items-center justify-center text-rose-700 shrink-0 font-bold">
                      <AlertCircle className="w-5 h-5" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-black text-rose-950">
                        Motif et Cause Détaillée du Rejet :
                      </h4>
                      <p className="text-xs font-bold text-rose-900">
                        {activeApp.rejectionReason || 'Taux d’effort locatif supérieur au plafond autorisé par LOC (33% du revenu).'}
                      </p>
                      <p className="text-xs text-rose-800 leading-relaxed font-normal pt-1">
                        {activeApp.rejectionDetails ||
                          `Pour ce logement au loyer de ${formatFCFA(activeApp.monthlyRent)}/mois, le revenu net déclaré (${formatFCFA(activeApp.monthlyIncome)}/mois) ne permet pas de couvrir les critères de solvabilité LOC sans dépassement du seuil d'endettement. LOC protège locataires et bailleurs contre le surendettement.`}
                      </p>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-rose-200/80 flex flex-wrap items-center gap-2 text-[11px] text-rose-800">
                    <span className="font-bold">💡 Conseils pour vos prochaines candidatures :</span>
                    <span>• Choisissez des biens avec un loyer ≤ {formatFCFA(Math.round(activeApp.monthlyIncome * 0.33))}/mois</span>
                    <span>• Ou intégrez un garant solidaire avec un revenu supérieur à {formatFCFA(activeApp.monthlyRent * 3)}.</span>
                  </div>
                </div>

                {/* PROPOSITION D'AUTRES BIENS IMMOBILIERS DISPONIBLES ET ADAPTÉS */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-blue-600" />
                        Biens immobiliers 100% compatibles avec votre profil
                      </h4>
                      <p className="text-xs text-slate-500">
                        Ces logements disponibles à Dakar respectent parfaitement votre budget. Postulez en 1 clic sans ressaisir vos pièces !
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    {alternativeProps.map((prop) => {
                      const propPlan = calculateDepositPlan(prop.monthlyRent, prop.depositMonths);
                      return (
                        <div
                          key={prop.id}
                          className="bg-white border border-slate-200 hover:border-blue-400 rounded-2xl overflow-hidden shadow-xs transition-all flex flex-col justify-between group"
                        >
                          <div className="relative h-32 w-full overflow-hidden bg-slate-100">
                            <img
                              src={prop.images[0]}
                              alt={prop.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                            <div className="absolute top-2 left-2 bg-emerald-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full shadow-xs">
                              Eligible 100% LOC
                            </div>
                            <div className="absolute bottom-2 right-2 bg-black/70 backdrop-blur-xs text-white text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg">
                              {formatFCFA(prop.monthlyRent)}/m
                            </div>
                          </div>

                          <div className="p-3.5 space-y-2.5 flex-1 flex flex-col justify-between">
                            <div>
                              <h5 className="text-xs font-bold text-slate-900 line-clamp-1 group-hover:text-blue-600 transition-colors">
                                {prop.title}
                              </h5>
                              <p className="text-[11px] text-slate-500 line-clamp-1">
                                {prop.neighborhood}, {prop.city}
                              </p>
                            </div>

                            <div className="p-2 rounded-xl bg-blue-50/70 border border-blue-100 text-[11px] flex items-center justify-between">
                              <span className="text-slate-600 font-medium">Apport LOC :</span>
                              <span className="font-mono font-black text-blue-700">
                                {formatFCFA(propPlan.initialTotalDue)}
                              </span>
                            </div>

                            <button
                              type="button"
                              onClick={() => onApplyAlternativeProperty && onApplyAlternativeProperty(prop)}
                              className="w-full py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-all"
                            >
                              <ShieldCheck className="w-3.5 h-3.5" />
                              <span>Postuler en 1 clic</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

              </div>
            )}

            {/* CASE: APPROVED OR LEASE SIGNED */}
            {(activeApp.status === 'approved' || activeApp.status === 'lease_signed') && (
              <div className="p-5 rounded-3xl bg-emerald-50 border border-emerald-200 text-emerald-950 space-y-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-emerald-100 border border-emerald-200 flex items-center justify-center text-emerald-700 shrink-0">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-base font-black text-emerald-950">
                        Félicitations ! Votre candidature a été officiellement approuvée
                      </h4>
                      <p className="text-xs text-emerald-800 leading-relaxed">
                        {isClassic
                          ? 'Votre dossier a été validé par le bailleur suite à la visite physique. Vous pouvez finaliser la signature de votre contrat de bail.'
                          : 'La garantie de caution LOC a été octroyée. Le bailleur a validé votre profil et vous pouvez dès maintenant accéder au bail certifié OHADA et programmer votre installation.'}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-emerald-200/80 text-xs">
                  <div className="p-3 rounded-2xl bg-white border border-emerald-200 space-y-1">
                    <span className="text-[10px] font-bold text-slate-500 uppercase block">Formule Activée</span>
                    <span className="font-bold text-slate-900 block">
                      {isClassic ? 'Paiement Classique sans LOC' : 'Caution Étalée sur 6 Mois'}
                    </span>
                    <p className="text-[11px] text-slate-600">
                      {isClassic
                        ? '0 FCFA de frais de dossier facturés. 10% de frais de gestion mensuels inclus.'
                        : 'Vous ne versez que 1/3 à l’entrée. Les 2/3 restants sont amortis en 6 mensualités sans agios.'}
                    </p>
                  </div>

                  <div className="p-3 rounded-2xl bg-white border border-emerald-200 flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block">RDV Visite & Remise Clés</span>
                      <span className="font-bold text-slate-900 block">
                        {confirmedRDV ? `RDV le ${confirmedRDV.date}` : (activeApp.preferredVisitDate ? `RDV : ${activeApp.preferredVisitDate}` : 'Programmation de Visite')}
                      </span>
                    </div>
                    {confirmedRDV ? (
                      <div className="mt-2 py-1.5 px-3 rounded-xl bg-emerald-100 border border-emerald-300 text-emerald-800 font-bold text-[11px] flex items-center justify-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Confirmé à {confirmedRDV.time}</span>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setIsRDVModalOpen(true);
                          if (onOpenAppointmentScheduler) {
                            onOpenAppointmentScheduler();
                          }
                        }}
                        className="mt-2 py-1.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer"
                      >
                        <Calendar className="w-3.5 h-3.5" />
                        <span>Programmer le RDV</span>
                      </button>
                    )}
                  </div>

                  <div className="p-3 rounded-2xl bg-white border border-emerald-200 flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block">Bail Électronique</span>
                      <span className="font-bold text-slate-900 block">Bail Numérique OHADA</span>
                    </div>
                    {onOpenLeaseModal && (
                      <button
                        type="button"
                        onClick={onOpenLeaseModal}
                        className="mt-2 py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Consulter & Signer</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* CASE: PENDING */}
            {activeApp.status === 'pending' && (
              <div className={`p-5 rounded-3xl border space-y-3 ${
                isClassic 
                  ? 'bg-amber-50/80 border-amber-200 text-amber-950' 
                  : 'bg-blue-50/60 border-blue-200 text-blue-950'
              }`}>
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 rounded-2xl border flex items-center justify-center shrink-0 ${
                    isClassic 
                      ? 'bg-amber-100 border-amber-200 text-amber-700' 
                      : 'bg-blue-100 border-blue-200 text-blue-700'
                  }`}>
                    <Clock className="w-5 h-5 animate-spin" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-black text-slate-900">
                      {isClassic 
                        ? 'Dossier reçu • En attente de réalisation de la visite physique' 
                        : 'Analyse de solvabilité IA et validation de caution en cours'}
                    </h4>
                    <p className="text-xs text-slate-700 leading-relaxed">
                      {isClassic
                        ? 'Votre dossier gratuit sans frais de constitution a bien été enregistré. Un agent LOC vous accompagnera lors de la visite des lieux avant accord définitif du bail.'
                        : 'Votre dossier et vos pièces justificatives ont bien été transmis à l\'équipe LOC. Le délai moyen de traitement est inférieur à 24 heures. Vous recevrez une notification instantanée dès la validation de votre caution.'}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* ============================================================ */}
            {/* 4. RECAPITULATIF DES PIECES & GARANT DU DOSSIER ACTIF        */}
            {/* ============================================================ */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-slate-100 text-xs">
              
              {/* Documents Transmis */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <span className="font-black text-slate-900 block flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-blue-600" />
                  Pièces Justificatives Vérifiées ({activeApp.professionCategory || 'Salarié'})
                </span>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] py-1 border-b border-slate-200/60">
                    <span className="text-slate-600">Carte d'Identité / Passeport</span>
                    <span className="font-bold text-emerald-700 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Conforme
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] py-1 border-b border-slate-200/60">
                    <span className="text-slate-600">Fiche de Paie / Justificatif de Revenu</span>
                    <span className="font-bold text-emerald-700 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Validé
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] py-1">
                    <span className="text-slate-600">Contrat de travail / RCCM</span>
                    <span className="font-bold text-emerald-700 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Certifié
                    </span>
                  </div>
                </div>
              </div>

              {/* Garant Solidaire Info */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <span className="font-black text-slate-900 block flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4 text-blue-600" />
                  Garant Solidaire Enregistré
                </span>

                {activeApp.hasGuarantor ? (
                  <div className="space-y-1.5 text-[11px]">
                    <div className="flex items-center justify-between py-1 border-b border-slate-200/60">
                      <span className="text-slate-600">Identité du Garant</span>
                      <span className="font-bold text-slate-900">
                        {activeApp.guarantorDetails?.firstName} {activeApp.guarantorDetails?.lastName || activeApp.guarantorName}
                      </span>
                    </div>
                    <div className="flex items-center justify-between py-1 border-b border-slate-200/60">
                      <span className="text-slate-600">Téléphone</span>
                      <span className="font-mono font-bold text-slate-900">
                        {activeApp.guarantorDetails?.phone || activeApp.guarantorPhone || '+221 77 123 45 67'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between py-1">
                      <span className="text-slate-600">Montant Caution Garanti</span>
                      <span className="font-mono font-black text-blue-700">
                        {formatFCFA(activeApp.guarantorDetails?.guaranteedAmount || activeApp.guaranteedAmount || activeApp.depositAmount)}
                      </span>
                    </div>
                  </div>
                ) : (
                  <p className="text-[11px] text-slate-500 italic">
                    Aucun garant solidaire joint. Le dossier s'appuie exclusivement sur les revenus personnels du candidat.
                  </p>
                )}
              </div>

            </div>

          </div>
        </>
      )}

      {/* RDV BOOKING MODAL */}
      {isRDVModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in text-slate-800">
          <div className="w-full max-w-md bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-2xl relative">
            <button
              onClick={() => setIsRDVModalOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2 mb-3">
              <div className={`p-2 rounded-xl ${isClassic ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'}`}>
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-black text-slate-900">Programmer votre RDV de Visite</h3>
                <p className="text-xs text-slate-500">Pour le logement : {activeApp?.propertyTitle}</p>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Date souhaitée (Calendrier) :</label>
                <input
                  type="date"
                  min={new Date().toISOString().split('T')[0]}
                  value={rdvDate}
                  onChange={(e) => setRdvDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Créneau horaire :</label>
                <select
                  value={rdvTime}
                  onChange={(e) => setRdvTime(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer"
                >
                  <option value="09:00 - 10:00">09:00 - 10:00 (Matin)</option>
                  <option value="10:30 - 11:30">10:30 - 11:30 (Matin)</option>
                  <option value="14:00 - 15:00">14:00 - 15:00 (Après-midi)</option>
                  <option value="15:30 - 16:30">15:30 - 16:30 (Après-midi)</option>
                  <option value="17:00 - 18:00">17:00 - 18:00 (Fin de journée)</option>
                </select>
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-[11px] text-slate-800 space-y-1">
                <span className="font-bold block">📍 Lieu de rendez-vous :</span>
                <span className="text-slate-700 block">{activeApp?.propertyAddress || 'Sur place à la propriété'}</span>
                <span className="font-semibold text-slate-900 block pt-1">• Accompagnement par l'agent LOC assigné inclus</span>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsRDVModalOpen(false)}
                  className="flex-1 py-3 rounded-xl bg-slate-100 text-slate-700 font-bold hover:bg-slate-200 transition-all cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="button"
                  onClick={handleConfirmRDV}
                  className={`flex-1 py-3 rounded-xl text-white font-bold shadow-xs transition-all cursor-pointer ${
                    isClassic ? 'bg-slate-900 hover:bg-slate-800' : 'bg-blue-600 hover:bg-blue-700'
                  }`}
                >
                  Confirmer le RDV
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

