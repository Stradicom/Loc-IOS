import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  Navigation, 
  Car, 
  Bus, 
  Footprints, 
  Locate, 
  ExternalLink, 
  Copy, 
  Check, 
  Share2, 
  Compass, 
  Layers, 
  Maximize2, 
  Minimize2, 
  RotateCcw, 
  AlertCircle, 
  ShieldCheck, 
  ArrowRight, 
  Clock, 
  DollarSign, 
  Loader2,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { Property } from '../../types';
import { formatFCFA } from '../../utils/finance';
import { getNeighborhoodCoordinates } from '../../data/dakarNeighborhoods';
import { 
  GeoCoordinate, 
  DAKAR_KEY_HUBS, 
  computeDakarRoute, 
  getGoogleMapsNavigationUrl, 
  getWazeNavigationUrl, 
  getAppleMapsNavigationUrl, 
  getWhatsAppShareText 
} from '../../utils/geoNavigation';

interface PropertyInteractiveMapProps {
  property: Property;
  compact?: boolean;
}

export const PropertyInteractiveMap: React.FC<PropertyInteractiveMapProps> = ({
  property,
  compact = false
}) => {
  // Property coordinates
  const propertyCoords: GeoCoordinate = property.coordinates || getNeighborhoodCoordinates(property.neighborhood);
  
  // Navigation & Origin State
  const [selectedOriginId, setSelectedOriginId] = useState<string>('keur_gorgui_vdn');
  const [currentGpsCoords, setCurrentGpsCoords] = useState<GeoCoordinate | null>(null);
  const [isDetectingGps, setIsDetectingGps] = useState<boolean>(false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  
  // Travel Mode
  const [travelMode, setTravelMode] = useState<'driving' | 'transit' | 'walking'>('driving');
  const [mapLayer, setMapLayer] = useState<'osm' | 'satellite'>('osm');
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const [copiedCoords, setCopiedCoords] = useState<boolean>(false);
  const [showDirectionsList, setShowDirectionsList] = useState<boolean>(false);
  const [zoomLevel, setZoomLevel] = useState<number>(15);

  // Active Origin Coordinates
  const activeOriginCoords: GeoCoordinate = 
    selectedOriginId === 'current_gps' && currentGpsCoords
      ? currentGpsCoords
      : (DAKAR_KEY_HUBS.find(h => h.id === selectedOriginId)?.coordinates || { lat: 14.7095, lng: -17.4660 });

  // Compute Route
  const route = computeDakarRoute(
    activeOriginCoords,
    propertyCoords,
    property.neighborhood,
    property.address
  );

  // Handle GPS detection
  const handleDetectGPS = () => {
    if (!navigator.geolocation) {
      setGpsError('La géolocalisation n’est pas disponible sur cet appareil.');
      return;
    }
    setIsDetectingGps(true);
    setGpsError(null);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const coords = {
          lat: Number(pos.coords.latitude.toFixed(6)),
          lng: Number(pos.coords.longitude.toFixed(6))
        };
        setCurrentGpsCoords(coords);
        setSelectedOriginId('current_gps');
        setIsDetectingGps(false);
      },
      (err) => {
        console.warn('GPS Error:', err);
        setGpsError('Impossible d’accéder à votre position GPS. Sélectionnez un repère dakarois ci-dessous.');
        setIsDetectingGps(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const handleCopyCoordinates = () => {
    navigator.clipboard.writeText(`${propertyCoords.lat}, ${propertyCoords.lng}`);
    setCopiedCoords(true);
    setTimeout(() => setCopiedCoords(false), 2000);
  };

  // Maps URL
  const googleMapsUrl = getGoogleMapsNavigationUrl(propertyCoords, activeOriginCoords);
  const wazeUrl = getWazeNavigationUrl(propertyCoords);
  const appleMapsUrl = getAppleMapsNavigationUrl(propertyCoords);
  const whatsappUrl = `https://wa.me/?text=${getWhatsAppShareText(
    property.title,
    property.neighborhood,
    property.address,
    propertyCoords
  )}`;

  // Calculate bounding box for embedded iframe / map center
  const bbox = {
    minLng: Math.min(propertyCoords.lng, activeOriginCoords.lng) - 0.008,
    minLat: Math.min(propertyCoords.lat, activeOriginCoords.lat) - 0.008,
    maxLng: Math.max(propertyCoords.lng, activeOriginCoords.lng) + 0.008,
    maxLat: Math.max(propertyCoords.lat, activeOriginCoords.lat) + 0.008
  };

  const embedMapUrl = `https://www.openstreetmap.org/export/embed.html?bbox=${bbox.minLng}%2C${bbox.minLat}%2C${bbox.maxLng}%2C${bbox.maxLat}&layer=mapnik&marker=${propertyCoords.lat}%2C${propertyCoords.lng}`;

  return (
    <div className={`rounded-3xl bg-white border border-slate-200 overflow-hidden shadow-sm transition-all ${
      isExpanded ? 'fixed inset-4 z-50 overflow-y-auto max-w-5xl mx-auto shadow-2xl ring-1 ring-black/10' : ''
    }`}>
      {/* Header Bar */}
      <div className="p-3.5 sm:p-4 bg-gradient-to-r from-slate-900 via-slate-800 to-blue-950 text-white flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-blue-400">
            <Compass className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xs sm:text-sm font-black text-white">
                Carte & Itinéraire LOC
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-[10px] font-bold border border-blue-400/20">
                Navigation Directe
              </span>
            </div>
            <p className="text-[11px] text-slate-300 truncate max-w-xs sm:max-w-md">
              {property.neighborhood}, Dakar • {property.address}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setMapLayer(mapLayer === 'osm' ? 'satellite' : 'osm')}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 text-xs font-semibold flex items-center gap-1 transition-colors"
            title="Changer de vue"
          >
            <Layers className="w-3.5 h-3.5" />
            <span className="text-[10px] hidden sm:inline">{mapLayer === 'osm' ? 'Satellite' : 'Plan'}</span>
          </button>

          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 transition-colors"
            title={isExpanded ? 'Réduire' : 'Plein écran'}
          >
            {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Main Map Canvas Area */}
      <div className="relative w-full h-64 sm:h-72 bg-slate-100 overflow-hidden border-b border-slate-200">
        {/* OpenStreetMap Embed Iframe */}
        <iframe
          title="Carte de localisation du bien"
          src={embedMapUrl}
          className={`w-full h-full border-0 transition-opacity ${mapLayer === 'satellite' ? 'contrast-125 saturate-110' : ''}`}
          loading="lazy"
        />

        {/* Floating Property Pin Overlay Card */}
        <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md border border-slate-200/90 rounded-2xl p-2.5 shadow-lg max-w-[240px] pointer-events-auto">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-blue-600 flex items-center justify-center text-white shrink-0">
              <MapPin className="w-3.5 h-3.5" />
            </div>
            <div className="min-w-0 flex-1">
              <span className="text-[11px] font-bold text-slate-900 block truncate">
                {property.neighborhood}
              </span>
              <span className="text-[10px] font-extrabold text-blue-600 font-mono">
                {formatFCFA(property.monthlyRent)}/mois
              </span>
            </div>
          </div>
          <div className="mt-1.5 pt-1.5 border-t border-slate-100 flex items-center justify-between text-[9px] text-slate-500 font-mono">
            <span>GPS : {propertyCoords.lat.toFixed(4)}, {propertyCoords.lng.toFixed(4)}</span>
            <button
              onClick={handleCopyCoordinates}
              className="text-blue-600 hover:text-blue-700 flex items-center gap-0.5 font-bold"
              title="Copier les coordonnées"
            >
              {copiedCoords ? <Check className="w-2.5 h-2.5 text-emerald-600" /> : <Copy className="w-2.5 h-2.5" />}
              <span>{copiedCoords ? 'Copié' : 'Copier'}</span>
            </button>
          </div>
        </div>

        {/* Floating Controls in Map */}
        <div className="absolute bottom-3 right-3 flex flex-col gap-1.5">
          <a
            href={googleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md flex items-center gap-1.5 transition-transform hover:scale-105"
          >
            <Navigation className="w-3.5 h-3.5" />
            <span>Ouvrir dans Google Maps</span>
            <ExternalLink className="w-3 h-3 ml-0.5" />
          </a>
        </div>
      </div>

      {/* ITINERARY & NAVIGATION SECTION */}
      <div className="p-3.5 sm:p-5 space-y-4 bg-slate-50/70">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-3">
          <div>
            <h4 className="text-xs sm:text-sm font-black text-slate-900 flex items-center gap-1.5">
              <Navigation className="w-4 h-4 text-blue-600" />
              Calculateur d'Itinéraire & Trajet LOC
            </h4>
            <p className="text-[11px] text-slate-500">
              Estimez votre temps et le coût pour vous rendre à la visite de ce bien
            </p>
          </div>

          {/* Travel Mode Pills */}
          <div className="flex items-center gap-1 bg-white p-1 rounded-2xl border border-slate-200 shadow-2xs self-start sm:self-auto">
            <button
              type="button"
              onClick={() => setTravelMode('driving')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
                travelMode === 'driving'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Car className="w-3.5 h-3.5" />
              <span>Voiture / Taxi</span>
            </button>

            <button
              type="button"
              onClick={() => setTravelMode('transit')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
                travelMode === 'transit'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Bus className="w-3.5 h-3.5" />
              <span>Bus & Tata</span>
            </button>

            <button
              type="button"
              onClick={() => setTravelMode('walking')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
                travelMode === 'walking'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Footprints className="w-3.5 h-3.5" />
              <span>À pied</span>
            </button>
          </div>
        </div>

        {/* Departure Selector */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
            <span>Point de départ pour votre visite :</span>
            <button
              type="button"
              onClick={handleDetectGPS}
              disabled={isDetectingGps}
              className="text-blue-600 hover:text-blue-700 text-[11px] font-bold flex items-center gap-1 cursor-pointer disabled:opacity-50"
            >
              {isDetectingGps ? (
                <>
                  <Loader2 className="w-3 h-3 animate-spin" />
                  <span>Localisation en cours...</span>
                </>
              ) : (
                <>
                  <Locate className="w-3 h-3" />
                  <span>Utiliser ma position GPS actuelle</span>
                </>
              )}
            </button>
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <select
              value={selectedOriginId}
              onChange={(e) => setSelectedOriginId(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-2xs"
            >
              {currentGpsCoords && (
                <option value="current_gps">📍 Ma position GPS en direct</option>
              )}
              <optgroup label="Repères & Carrefours Dakarois">
                {DAKAR_KEY_HUBS.filter(h => h.id !== 'current_gps').map((hub) => (
                  <option key={hub.id} value={hub.id}>
                    {hub.name}
                  </option>
                ))}
              </optgroup>
            </select>

            <div className="p-2 rounded-xl bg-white border border-slate-200 flex items-center justify-between text-xs text-slate-700">
              <span className="text-slate-500">Destination :</span>
              <span className="font-bold text-slate-900 truncate ml-1">{property.neighborhood} ({property.address})</span>
            </div>
          </div>

          {gpsError && (
            <div className="p-2 rounded-xl bg-amber-50 border border-amber-200 text-[11px] text-amber-800 flex items-center gap-1.5">
              <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
              <span>{gpsError}</span>
            </div>
          )}
        </div>

        {/* Route Metrics Dashboard Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {/* 1. Distance */}
          <div className="p-3 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Distance réelle
            </span>
            <span className="text-base sm:text-lg font-black text-slate-900 font-mono block my-0.5">
              {route.distanceKm} km
            </span>
            <span className="text-[10px] text-slate-500 block">Via voirie urbaine</span>
          </div>

          {/* 2. Durée */}
          <div className="p-3 rounded-2xl bg-white border border-blue-200 shadow-2xs">
            <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider block flex items-center gap-1">
              <Clock className="w-3 h-3" />
              Temps estimé
            </span>
            <span className="text-base sm:text-lg font-black text-blue-700 font-mono block my-0.5">
              ~{travelMode === 'driving' ? route.drivingMinutes : travelMode === 'transit' ? route.transitMinutes : route.walkingMinutes} min
            </span>
            <span className="text-[10px] text-emerald-600 font-semibold block">
              Trafic {route.trafficStatus}
            </span>
          </div>

          {/* 3. Coût Taxi / Transport */}
          <div className="p-3 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              {travelMode === 'driving' ? 'Course Taxi estimée' : travelMode === 'transit' ? 'Ticket de bus' : 'Coût déplacement'}
            </span>
            <span className="text-xs sm:text-sm font-black text-slate-900 font-mono block my-1">
              {travelMode === 'driving' ? (
                `${formatFCFA(route.taxiPriceMin)} - ${formatFCFA(route.taxiPriceMax)}`
              ) : travelMode === 'transit' ? (
                '150 - 300 FCFA'
              ) : (
                '0 FCFA (Gratuit)'
              )}
            </span>
            <span className="text-[10px] text-slate-500 block">
              {travelMode === 'driving' ? 'Tarif moyen Dakar' : travelMode === 'transit' ? 'Dem Dikk / Tata' : 'Marche à pied'}
            </span>
          </div>

          {/* 4. Lignes Recommandées */}
          <div className="p-3 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Lignes de transport
            </span>
            <div className="space-y-0.5 mt-1">
              {route.recommendedLines.slice(0, 2).map((line, idx) => (
                <span key={idx} className="text-[10px] font-bold text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded block truncate">
                  {line}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Step-by-Step Guidance Accordion */}
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-2xs">
          <button
            type="button"
            onClick={() => setShowDirectionsList(!showDirectionsList)}
            className="w-full p-3 text-left flex items-center justify-between text-xs font-bold text-slate-800 hover:bg-slate-50 transition-colors"
          >
            <span className="flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-blue-600" />
              Repères dakarois & Conseils de trajet ({route.directions.length} étapes)
            </span>
            {showDirectionsList ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
          </button>

          {showDirectionsList && (
            <div className="p-3.5 border-t border-slate-100 space-y-2.5 bg-slate-50/50">
              {route.directions.map((step) => (
                <div key={step.stepNumber} className="flex items-start gap-2.5 text-xs">
                  <div className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center shrink-0 text-[10px]">
                    {step.stepNumber}
                  </div>
                  <div>
                    <p className="font-semibold text-slate-800">{step.instruction}</p>
                    {step.detail && <p className="text-[11px] text-slate-500">{step.detail}</p>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* QUICK NAVIGATION ACTION BUTTONS */}
        <div className="space-y-2 pt-1">
          <span className="text-[11px] font-bold text-slate-600 block">
            Lancer le guidage GPS externe :
          </span>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {/* Google Maps Button */}
            <a
              href={googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-all"
            >
              <Navigation className="w-4 h-4" />
              <span>Itinéraire Google Maps</span>
              <ExternalLink className="w-3 h-3 ml-auto opacity-75" />
            </a>

            {/* Waze Button */}
            <a
              href={wazeUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-all"
            >
              <Car className="w-4 h-4 text-cyan-400" />
              <span>Naviguer avec Waze</span>
              <ExternalLink className="w-3 h-3 ml-auto opacity-75" />
            </a>

            {/* WhatsApp Share Button */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-all"
            >
              <Share2 className="w-4 h-4" />
              <span>Envoyer au Taxi (WhatsApp)</span>
              <ExternalLink className="w-3 h-3 ml-auto opacity-75" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
