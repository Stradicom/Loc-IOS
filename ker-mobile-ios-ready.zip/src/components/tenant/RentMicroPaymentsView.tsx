import React, { useState } from 'react';
import { 
  DollarSign, 
  CreditCard, 
  Clock, 
  CheckCircle2, 
  Calendar, 
  FileText, 
  Download, 
  ChevronRight, 
  Sparkles, 
  Bell, 
  ShieldCheck, 
  ArrowRight, 
  RefreshCw, 
  TrendingUp, 
  Sliders, 
  Zap, 
  Smartphone,
  Check,
  Building2,
  AlertCircle,
  Lock,
  ArrowUpRight,
  ClipboardList
} from 'lucide-react';
import { MicroPayment, RentReceipt, Property, PaymentMethod, TenantApplication } from '../../types';
import { 
  formatFCFA, 
  calculateDepositPlan,
  getCurrentPeriod,
  getNextPeriod,
  getNextMonthFirstDay,
  getCurrentDueDate
} from '../../utils/finance';

interface RentMicroPaymentsViewProps {
  property?: Property;
  properties?: Property[];
  applications?: TenantApplication[];
  totalDueThisMonth?: number;
  paidThisMonth?: number;
  microPayments?: MicroPayment[];
  receipts?: RentReceipt[];
  depositInstallmentsPaid?: number; // e.g. 3 out of 6
  isLeaseApproved?: boolean;
  onOpenPaymentModal?: (presetAmount?: number) => void;
  onOpenReceiptDetail?: (receipt: RentReceipt) => void;
  onQuickPay?: (amount: number, method: PaymentMethod) => void;
  onNavigateToSuivi?: () => void;
}

export const RentMicroPaymentsView: React.FC<RentMicroPaymentsViewProps> = ({
  property,
  properties = [],
  applications = [],
  totalDueThisMonth,
  paidThisMonth = 0,
  microPayments = [],
  receipts = [],
  depositInstallmentsPaid = 3,
  isLeaseApproved = true,
  onOpenPaymentModal = (_presetAmount?: number) => {},
  onOpenReceiptDetail = (_rec?: RentReceipt) => {},
  onQuickPay,
  onNavigateToSuivi,
}) => {
  const [plannerFrequency, setPlannerFrequency] = useState<'daily' | 'weekly' | 'biweekly' | 'monthly'>('weekly');
  const [autoReminderActive, setAutoReminderActive] = useState(true);
  const [reminderChannel, setReminderChannel] = useState<'whatsapp' | 'sms' | 'push'>('whatsapp');
  const [activeTab, setActiveTab] = useState<'overview' | 'planner' | 'history' | 'receipts'>('overview');

  // Find requested leases from applications (Suivi du dossier)
  // Prioritize approved lease, otherwise first application, otherwise fallback to property
  const approvedApp = applications.find(a => a.status === 'approved' || a.status === 'lease_signed');
  const defaultSelectedAppId = approvedApp ? approvedApp.id : (applications[0]?.id || 'default-property');
  const [selectedApplicationId, setSelectedApplicationId] = useState<string>(defaultSelectedAppId);

  // Active selected application for the planner
  const currentSelectedApp = applications.find(a => a.id === selectedApplicationId) || applications[0];
  
  // Associated property for the selected lease
  const selectedProperty = currentSelectedApp 
    ? (properties.find(p => p.id === currentSelectedApp.propertyId) || (property ? {
        ...property,
        title: currentSelectedApp.propertyTitle || property.title,
        address: currentSelectedApp.propertyAddress || property.address,
        monthlyRent: currentSelectedApp.monthlyRent || property.monthlyRent,
        depositAmount: currentSelectedApp.depositAmount || property.depositAmount
      } : ({
        id: currentSelectedApp.propertyId,
        title: currentSelectedApp.propertyTitle,
        address: currentSelectedApp.propertyAddress,
        monthlyRent: currentSelectedApp.monthlyRent,
        depositAmount: currentSelectedApp.depositAmount,
        city: 'Dakar',
        type: 'appartement',
        isAvailable: true,
        createdAt: '2026-08-01'
      } as unknown as Property)))
    : property;

  // Determine if the selected lease in planner is granted
  const isSelectedLeaseGranted = currentSelectedApp 
    ? (currentSelectedApp.status === 'approved' || currentSelectedApp.status === 'lease_signed')
    : isLeaseApproved;

  // Base monthly rent for the selected lease
  const effectiveRent = currentSelectedApp ? currentSelectedApp.monthlyRent : (selectedProperty?.monthlyRent || 150000);
  
  // Official LOC Deposit Micro-financing Plan
  const kerDepositPlan = calculateDepositPlan(effectiveRent);

  // Monthly target due for planner:
  // If lease approved, use the official LOC microfinancing total (Loyer + mensualité étalée 1/6)
  const planningMonthlyTotal = kerDepositPlan.monthlyTotalMonths1to6;

  // Global rent overview calculations
  const safeMonthlyRent = property?.monthlyRent || effectiveRent;
  const depositMonthlyShare = kerDepositPlan.monthlyDepositInstallment;
  const effectiveTotalDue = totalDueThisMonth !== undefined && totalDueThisMonth > 0
    ? totalDueThisMonth
    : planningMonthlyTotal;
  
  const sumCompletedPayments = (microPayments || [])
    .filter(p => p.status === 'completed')
    .reduce((sum, p) => sum + p.amount, 0);

  const effectivePaid = isLeaseApproved
    ? (paidThisMonth && paidThisMonth > 0 ? Math.max(paidThisMonth, sumCompletedPayments) : sumCompletedPayments)
    : 0;
  const remaining = isLeaseApproved ? Math.max(0, effectiveTotalDue - effectivePaid) : 0;
  const progressPercent = isLeaseApproved ? Math.min(100, Math.round((effectivePaid / (effectiveTotalDue || 1)) * 100)) : 0;

  // Compute Planner Tranches strictly based on the LOC Microfinancing Plan
  const getPlannerTranches = (total: number, freq: 'daily' | 'weekly' | 'biweekly' | 'monthly') => {
    switch (freq) {
      case 'daily':
        return { 
          count: 30, 
          amount: Math.round(total / 30), 
          label: 'Quotidien (30 jours)',
          description: 'Idéal pour commerçants et revenus journaliers'
        };
      case 'weekly':
        return { 
          count: 4, 
          amount: Math.round(total / 4), 
          label: 'Hebdomadaire (4 versements)',
          description: '1 versement chaque lundi ou fin de semaine'
        };
      case 'biweekly':
        return { 
          count: 2, 
          amount: Math.round(total / 2), 
          label: 'Par quinzaine (2 versements)',
          description: '1er et 15 du mois'
        };
      case 'monthly':
      default:
        return { 
          count: 1, 
          amount: total, 
          label: 'Mensuel (1 versement)',
          description: 'Paiement unique le 5 du mois'
        };
    }
  };

  const planner = getPlannerTranches(planningMonthlyTotal, plannerFrequency);

  // Generate tranche items list for the interactive widget
  const generateTrancheList = () => {
    const items = [];
    const baseAmount = planner.amount;
    const days = plannerFrequency === 'daily' ? 1 : plannerFrequency === 'weekly' ? 7 : plannerFrequency === 'biweekly' ? 15 : 30;
    
    for (let i = 1; i <= Math.min(planner.count, 6); i++) {
      const estimatedDay = Math.min(30, 1 + (i - 1) * days);
      items.push({
        index: i,
        name: `Tranche ${i}/${planner.count}`,
        date: `${estimatedDay < 10 ? '0' + estimatedDay : estimatedDay} ${getCurrentPeriod()}`,
        amount: baseAmount,
        isPaid: isSelectedLeaseGranted && (effectivePaid >= baseAmount * i),
      });
    }
    return items;
  };

  const tranchesList = generateTrancheList();

  return (
    <div className="space-y-6 animate-fade-in text-slate-800" id="rent-micro-payments-view">
      
      {/* Sub-Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3">
        {[
          { id: 'overview', label: 'Synthèse du Loyer & Tranches', icon: DollarSign },
          { id: 'planner', label: 'Planificateur Personnalisé', icon: Sliders },
          { id: 'history', label: `Historique des Versements (${microPayments.length})`, icon: Clock },
          { id: 'receipts', label: `Mes Quittances LOC (${receipts.length})`, icon: FileText },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Main Rent Gauge Card (Left 2 cols) */}
          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-xs space-y-6">
            
            {/* Header & Status */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <span className="text-[10px] uppercase font-mono text-slate-400 font-bold tracking-wider block">
                  Période en cours : {getCurrentPeriod()}
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-slate-900">
                  Mon Loyer & Micro-versements
                </h3>
              </div>

              <div className="flex items-center gap-2">
                {!isLeaseApproved ? (
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-700 border border-slate-200 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-slate-500" />
                    Bail en attente d'attribution
                  </span>
                ) : remaining === 0 ? (
                  <span className="px-3 py-1 rounded-full text-xs font-black bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Loyer Entièrement Soldé
                  </span>
                ) : (
                  <span className="px-3 py-1 rounded-full text-xs font-black bg-amber-100 text-amber-900 border border-amber-200 flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-amber-600 animate-pulse" />
                    En cours de règlement ({progressPercent}%)
                  </span>
                )}
              </div>
            </div>

            {/* LEASE PENDING NOTICE BANNER (if lease not yet approved) */}
            {!isLeaseApproved && (
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 space-y-1.5">
                <div className="flex items-center gap-2 font-bold text-xs">
                  <AlertCircle className="w-4 h-4 text-amber-600" />
                  <span>Bail en cours d'instruction ou de validation</span>
                </div>
                <p className="text-xs text-amber-800 leading-relaxed font-medium">
                  Les montants exigibles, l'échéancier et les versements par micro-tranches seront activés dès l'octroi et la signature officielle de votre contrat de bail. Vous pouvez simuler vos tranches dans l'onglet « Planificateur Personnalisé ».
                </p>
              </div>
            )}

            {/* Financial Numbers & Gauge */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1">
                <span className="text-[10px] font-bold uppercase text-slate-500 block">Total Dû du Mois</span>
                <span className="text-xl sm:text-2xl font-black text-slate-900 font-mono block">
                  {isLeaseApproved ? formatFCFA(effectiveTotalDue) : '-- FCFA'}
                </span>
                <span className="text-[10px] text-slate-500 block">
                  {isLeaseApproved 
                    ? `Loyer (${formatFCFA(safeMonthlyRent)}) + 1/6 caution (${formatFCFA(depositMonthlyShare)})`
                    : 'Actif dès signature du bail'}
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1">
                <span className="text-[10px] font-bold uppercase text-emerald-700 block">Déjà Réglé (Tranches)</span>
                <span className="text-xl sm:text-2xl font-black text-emerald-700 font-mono block">
                  {isLeaseApproved ? formatFCFA(effectivePaid) : '0 FCFA'}
                </span>
                <span className="text-[10px] text-emerald-600 font-medium block">
                  {isLeaseApproved ? `${microPayments.length} versement(s) reçu(s)` : 'En attente d’entrée'}
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 space-y-1">
                <span className="text-[10px] font-bold uppercase text-blue-700 block">Solde Restant à Payer</span>
                <span className="text-xl sm:text-2xl font-black text-blue-700 font-mono block">
                  {isLeaseApproved ? formatFCFA(remaining) : '-- FCFA'}
                </span>
                <span className="text-[10px] text-blue-600 font-medium block">
                  {isLeaseApproved ? `Échéance : ${getCurrentDueDate(5)}` : 'Dès activation du bail'}
                </span>
              </div>
            </div>

            {/* Linear Progress Bar */}
            {isLeaseApproved && (
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-bold">
                  <span className="text-slate-600">Progression du mois :</span>
                  <span className="text-blue-700 font-mono font-black">{progressPercent}% réglé</span>
                </div>
                <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden p-0.5 border border-slate-200">
                  <div
                    className="h-full bg-linear-to-r from-blue-600 to-emerald-500 rounded-full transition-all duration-500"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>
            )}

            {/* Quick Action Payment Button / Soldé Lock Banner */}
            {isLeaseApproved && remaining <= 0 ? (
              <div className="p-5 rounded-3xl bg-linear-to-r from-emerald-900 to-teal-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-md">
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/30 text-emerald-200 text-[10px] font-bold">
                    <CheckCircle2 className="w-3 h-3 text-emerald-300" />
                    Loyer du mois 100% Soldé
                  </div>
                  <h4 className="text-base font-black">
                    Félicitations ! Loyer de {getCurrentPeriod()} intégralement payé 🎉
                  </h4>
                  <p className="text-xs text-emerald-200/90 font-normal">
                    Votre quittance officielle LOC est générée dans l'onglet "Mes Quittances". Les versements par tranche sont bloqués jusqu'au {getNextMonthFirstDay()}.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveTab('receipts')}
                  className="py-3 px-5 rounded-2xl font-black text-xs sm:text-sm shrink-0 shadow-md flex items-center justify-center gap-2 transition-all bg-white text-emerald-900 hover:bg-emerald-50 cursor-pointer hover:scale-105"
                >
                  <FileText className="w-4 h-4 text-emerald-600" />
                  <span>Consulter ma Quittance</span>
                  <ArrowRight className="w-4 h-4 text-emerald-600" />
                </button>
              </div>
            ) : (
              <div className="p-5 rounded-3xl bg-linear-to-r from-blue-900 to-indigo-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-md">
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-500/30 text-blue-200 text-[10px] font-bold">
                    <Zap className="w-3 h-3 text-amber-300" />
                    Paiement Express Sans Frais
                  </div>
                  <h4 className="text-base font-black">
                    Effectuer un micro-versement maintenant
                  </h4>
                  <p className="text-xs text-blue-200/90 font-normal">
                    Réglez une tranche selon vos disponibilités via Wave, Orange Money, Free Money ou Carte.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => onOpenPaymentModal()}
                  className="py-3 px-5 rounded-2xl font-black text-xs sm:text-sm shrink-0 shadow-md flex items-center justify-center gap-2 transition-all bg-white text-blue-900 hover:bg-blue-50 cursor-pointer hover:scale-105"
                >
                  <CreditCard className="w-4 h-4 text-blue-600" />
                  <span>Nouveau versement / Tranche</span>
                  <ArrowRight className="w-4 h-4 text-blue-600" />
                </button>
              </div>
            )}

            {/* AMORTISSEMENT CAUTION SUR 6 MOIS */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-black text-slate-900 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-blue-600" />
                  Amortissement de la Caution LOC (6 mensualités)
                </span>
                <span className="font-bold text-blue-700 bg-blue-100 px-2 py-0.5 rounded-full text-[10px]">
                  {isLeaseApproved ? `Mois ${depositInstallmentsPaid} sur 6` : 'Simulé (6 mois)'}
                </span>
              </div>

              <div className="grid grid-cols-6 gap-1.5">
                {[1, 2, 3, 4, 5, 6].map((m) => (
                  <div
                    key={m}
                    className={`p-1.5 sm:p-2 rounded-xl border text-center transition-all ${
                      isLeaseApproved && m <= depositInstallmentsPaid
                        ? 'bg-emerald-100 border-emerald-300 text-emerald-900 font-bold'
                        : isLeaseApproved && m === depositInstallmentsPaid + 1
                        ? 'bg-blue-100 border-blue-400 text-blue-900 font-bold ring-2 ring-blue-500/20'
                        : 'bg-white border-slate-200 text-slate-400'
                    }`}
                  >
                    <span className="text-[8px] sm:text-[9px] uppercase block font-semibold">M{m}</span>
                    <span className="text-[9px] sm:text-[10px] font-mono block">
                      {isLeaseApproved && m <= depositInstallmentsPaid ? '✓' : formatFCFA(depositMonthlyShare).replace(' FCFA', '')}
                    </span>
                  </div>
                ))}
              </div>
              <p className="text-[10px] text-slate-500 leading-normal">
                À partir du 7ème mois, la caution sera totalement amortie et votre mensualité passera au loyer normal ({formatFCFA(safeMonthlyRent)}) + 10% commission de gestion LOC ({formatFCFA(kerDepositPlan.managementFeeAmount)}).
              </p>
            </div>

          </div>

          {/* Right Sidebar: Planificateur & Notifications (1 col) */}
          <div className="space-y-5">
            
            {/* Planificateur de tranches */}
            <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-4">
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-blue-600 text-xs font-black">
                  <Sliders className="w-4 h-4" />
                  <span>Planificateur de Tranches</span>
                </div>
                <h4 className="text-sm font-bold text-slate-900">
                  Adaptez votre rythme de paiement
                </h4>
                <p className="text-xs text-slate-500">
                  Choisissez la cadence adaptée à vos rentrées d'argent :
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'daily', label: 'Quotidien', icon: '📅' },
                  { id: 'weekly', label: 'Hebdo', icon: '🗓️' },
                  { id: 'biweekly', label: 'Quinzaine', icon: '📆' },
                  { id: 'monthly', label: 'Mensuel', icon: '🏦' },
                ].map((freq) => (
                  <button
                    key={freq.id}
                    onClick={() => setPlannerFrequency(freq.id as any)}
                    className={`p-2 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                      plannerFrequency === freq.id
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <span>{freq.icon}</span>
                    <span>{freq.label}</span>
                  </button>
                ))}
              </div>

              <div className="p-3.5 rounded-2xl bg-blue-50 border border-blue-200 space-y-2 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-slate-600 font-medium">Fréquence :</span>
                  <span className="font-bold text-slate-900">{planner.label}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600 font-medium">Montant par tranche :</span>
                  <span className="font-black text-blue-700 font-mono text-sm">
                    {formatFCFA(planner.amount)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600 font-medium">Nombre d'échéances :</span>
                  <span className="font-bold text-slate-900">{planner.count} versement(s)</span>
                </div>
              </div>
            </div>

            {/* Rappels Automatiques WhatsApp / SMS */}
            <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-blue-600" />
                  <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">
                    Rappels Automatiques
                  </h4>
                </div>
                <button
                  type="button"
                  onClick={() => setAutoReminderActive(!autoReminderActive)}
                  className={`w-10 h-5.5 rounded-full transition-colors flex items-center p-0.5 ${
                    autoReminderActive ? 'bg-blue-600 justify-end' : 'bg-slate-300 justify-start'
                  }`}
                >
                  <div className="w-4.5 h-4.5 rounded-full bg-white shadow-xs" />
                </button>
              </div>

              <p className="text-xs text-slate-500">
                Recevez une alerte bienveillante la veille de chaque tranche pour ne jamais oublier un versement.
              </p>

              {autoReminderActive && (
                <div className="space-y-2 pt-1">
                  <span className="text-[10px] font-bold text-slate-500 block">Canal préféré :</span>
                  <div className="grid grid-cols-3 gap-1.5 text-xs">
                    {[
                      { id: 'whatsapp', label: 'WhatsApp', icon: '💬' },
                      { id: 'sms', label: 'SMS', icon: '📱' },
                      { id: 'push', label: 'Notif', icon: '🔔' },
                    ].map((ch) => (
                      <button
                        key={ch.id}
                        type="button"
                        onClick={() => setReminderChannel(ch.id as any)}
                        className={`p-2 rounded-xl border text-[11px] font-bold transition-all flex items-center justify-center gap-1 ${
                          reminderChannel === ch.id
                            ? 'bg-slate-900 text-white border-slate-900'
                            : 'bg-slate-50 text-slate-600 border-slate-200'
                        }`}
                      >
                        <span>{ch.icon}</span>
                        <span>{ch.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

          </div>

        </div>
      )}

      {/* TAB 2: PLANIFICATEUR PERSONNALISÉ (ADAPTÉ AU BAIL DEMANDÉ & PLAN DE MICROFINANCEMENT LOC) */}
      {activeTab === 'planner' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-xs space-y-6 animate-fade-in max-w-4xl mx-auto">
          
          {/* Header & Status */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs font-bold border border-blue-200">
                <Building2 className="w-3.5 h-3.5 text-blue-600" />
                Planificateur Calibré sur le Bail Demandé
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-slate-900">
                Plan de Micro-versements Personnalisé
              </h3>
              <p className="text-xs text-slate-500">
                {isSelectedLeaseGranted 
                  ? "Calculé en fonction du Plan de Microfinancement officiel LOC appliqué à votre bail accordé."
                  : "Simulation prévisionnelle basée sur votre demande de bail en cours d'instruction dans le suivi de dossier."}
              </p>
            </div>

            <div className="p-3 rounded-2xl bg-blue-50 border border-blue-200 text-right">
              <span className="text-[10px] text-slate-500 uppercase font-bold block">
                {isSelectedLeaseGranted ? 'Mensualité LOC Exigible' : 'Mensualité Estimée LOC'}
              </span>
              <span className="text-lg font-black text-blue-700 font-mono">
                {formatFCFA(planningMonthlyTotal)}/mois
              </span>
            </div>
          </div>

          {/* SÉLECTEUR DE BAUX DEMANDÉS (SI MULTIPLES DEMANDES DANS SUIVI DU DOSSIER) */}
          {applications.length > 0 && (
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <ClipboardList className="w-3.5 h-3.5 text-blue-600" />
                  Baux demandés dans votre Suivi de Dossier :
                </span>
                {onNavigateToSuivi && (
                  <button
                    type="button"
                    onClick={onNavigateToSuivi}
                    className="text-[11px] font-bold text-blue-600 hover:text-blue-700 inline-flex items-center gap-1"
                  >
                    <span>Voir le Suivi du Dossier</span>
                    <ArrowUpRight className="w-3 h-3" />
                  </button>
                )}
              </div>

              <div className="flex flex-wrap gap-2">
                {applications.map((app) => {
                  const isSelected = app.id === selectedApplicationId;
                  const isApproved = app.status === 'approved' || app.status === 'lease_signed';
                  return (
                    <button
                      key={app.id}
                      type="button"
                      onClick={() => setSelectedApplicationId(app.id)}
                      className={`px-3 py-2 rounded-xl text-xs font-bold transition-all text-left flex items-center gap-2 border ${
                        isSelected
                          ? 'bg-white border-blue-600 text-blue-900 shadow-xs ring-2 ring-blue-500/20'
                          : 'bg-white/80 border-slate-200 text-slate-700 hover:border-slate-300'
                      }`}
                    >
                      <Building2 className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-blue-600' : 'text-slate-400'}`} />
                      <div>
                        <span className="block font-bold">{app.propertyTitle}</span>
                        <span className="text-[10px] text-slate-500 font-mono">{formatFCFA(app.monthlyRent)}/mois</span>
                      </div>
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ml-1 ${
                        isApproved
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : 'bg-amber-100 text-amber-800 border border-amber-200'
                      }`}>
                        {isApproved ? 'Bail Accordé' : 'En Attente'}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* BANDEAU EXPLICATIF : BAIL ACCORDÉ VS DEMANDE EN ATTENTE */}
          {isSelectedLeaseGranted ? (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <h4 className="text-xs font-black text-emerald-900">
                  Plan de Microfinancement LOC Actif — Bail Accordé
                </h4>
                <p className="text-xs text-emerald-800 leading-relaxed font-medium">
                  Votre échelonnement a été validé. Caution (2 mois) + Courtage (1 mois) étalés sur 6 mois à 0% d'intérêt. Vous pouvez régler vos tranches au fur et à mesure de vos rentrées de trésorerie par Wave ou Orange Money.
                </p>
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-2xl bg-blue-50/80 border border-blue-200 flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <h4 className="text-xs font-black text-blue-900">
                  Simulation LOC pour le Bail Demandé ({currentSelectedApp?.propertyTitle || selectedProperty?.title || 'Bien sélectionné'})
                </h4>
                <p className="text-xs text-blue-800 leading-relaxed font-medium">
                  Votre dossier de candidature est actuellement en cours d'analyse sous 24h. Ce plan de microfinancement s'activera dès la signature de votre contrat de bail.
                </p>
              </div>
            </div>
          )}

          {/* DÉCOMPOSITION DU PLAN DE MICROFINANCEMENT LOC & CHOIX DE LA CADENCE */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            
            {/* Colonne 1 : Détail du Plan de Microfinancement LOC */}
            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-blue-600" />
                  1. Plan de Microfinancement LOC
                </span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  isSelectedLeaseGranted 
                    ? 'bg-emerald-100 text-emerald-800' 
                    : 'bg-amber-100 text-amber-800'
                }`}>
                  {isSelectedLeaseGranted ? 'Bail Accordé' : 'Bail Demandé'}
                </span>
              </div>

              {/* Fiche Bien */}
              <div className="p-3 rounded-xl bg-white border border-slate-200/80 space-y-1">
                <span className="font-bold text-xs text-slate-900 block line-clamp-1">
                  {currentSelectedApp?.propertyTitle || selectedProperty?.title || 'Logement LOC'}
                </span>
                <span className="text-[11px] text-slate-500 block">
                  {currentSelectedApp?.propertyAddress || selectedProperty?.address || 'Dakar, Sénégal'}
                </span>
              </div>

              {/* Lignes Financières LOC */}
              <div className="text-[11px] text-slate-600 space-y-1.5 pt-1">
                <div className="flex justify-between py-1 border-b border-slate-200/60">
                  <span className="text-slate-500">Loyer mensuel :</span>
                  <span className="font-mono font-bold text-slate-900">{formatFCFA(kerDepositPlan.monthlyRent)}/mois</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-200/60">
                  <span className="text-slate-500">Caution étalée (sur 6 mois) :</span>
                  <span className="font-mono font-bold text-emerald-700">+{formatFCFA(kerDepositPlan.monthlyDepositInstallment)}/mois</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-200/60">
                  <span className="text-slate-500">Frais de gestion LOC (10%) :</span>
                  <span className="font-mono font-bold text-indigo-700">+{formatFCFA(kerDepositPlan.managementFeeAmount)}/mois</span>
                </div>
                <div className="flex justify-between pt-1 font-bold text-slate-900">
                  <span>Mensualité totale (Mois 1-6) :</span>
                  <span className="font-mono font-black text-blue-700">{formatFCFA(planningMonthlyTotal)}/mois</span>
                </div>
                <div className="flex justify-between pt-1 text-slate-500">
                  <span>À partir du Mois 7 (caution amortie) :</span>
                  <span className="font-mono font-bold text-emerald-700">{formatFCFA(kerDepositPlan.monthlyTotalMonth7Onwards)}/mois</span>
                </div>
              </div>

              {/* Économie à l'entrée */}
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-[11px] text-emerald-900 flex items-center justify-between font-medium">
                <span>Économie d'apport à l'entrée :</span>
                <span className="font-bold font-mono text-emerald-700">
                  -{formatFCFA(kerDepositPlan.immediateSavings)} ({kerDepositPlan.savingsPercent}%)
                </span>
              </div>
            </div>

            {/* Colonne 2 : Cadence des versements */}
            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-blue-600" />
                2. Choisissez votre cadence de versement :
              </span>

              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'daily', title: 'Quotidien', count: '30 tranches', icon: '📅' },
                  { id: 'weekly', title: 'Hebdomadaire', count: '4 tranches', icon: '🗓️' },
                  { id: 'biweekly', title: 'Quinzaine', count: '2 tranches', icon: '📆' },
                  { id: 'monthly', title: 'Mensuel', count: '1 tranche', icon: '🏦' },
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setPlannerFrequency(f.id as any)}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      plannerFrequency === f.id
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-white text-slate-800 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <span>{f.icon}</span>
                      <span className="text-xs font-black">{f.title}</span>
                    </div>
                    <span className={`text-[10px] block mt-0.5 ${plannerFrequency === f.id ? 'text-blue-100' : 'text-slate-500'}`}>
                      {f.count}
                    </span>
                  </button>
                ))}
              </div>

              <div className="p-3 rounded-xl bg-blue-50/80 border border-blue-200 text-xs text-blue-900 flex items-center justify-between">
                <span className="font-medium">Montant par tranche :</span>
                <span className="font-mono font-black text-blue-700 text-sm">
                  {formatFCFA(planner.amount)}
                </span>
              </div>
            </div>

          </div>

          {/* Tableau Détaillé des Échéances Planifiées */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-blue-600" />
                Échéancier des Tranches ({planner.label})
              </h4>
              <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-200 font-mono">
                {planner.amount.toLocaleString()} FCFA / tranche
              </span>
            </div>

            <div className="border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-100 text-xs">
              <div className="bg-slate-50 p-3 font-bold text-slate-600 grid grid-cols-12 gap-2 text-[11px] uppercase">
                <span className="col-span-3">Tranche</span>
                <span className="col-span-3">Date Prévue</span>
                <span className="col-span-3 text-right">Montant</span>
                <span className="col-span-3 text-right">Action</span>
              </div>

              {tranchesList.map((tranche) => (
                <div key={tranche.index} className="p-3 grid grid-cols-12 gap-2 items-center hover:bg-slate-50/60 transition-colors">
                  <div className="col-span-3 flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 text-[10px] font-mono font-bold flex items-center justify-center">
                      {tranche.index}
                    </span>
                    <span className="font-bold text-slate-900">{tranche.name}</span>
                  </div>

                  <div className="col-span-3 text-slate-600 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>{tranche.date}</span>
                  </div>

                  <div className="col-span-3 text-right font-mono font-black text-slate-900">
                    {formatFCFA(tranche.amount)}
                  </div>

                  <div className="col-span-3 text-right">
                    {tranche.isPaid ? (
                      <span className="inline-flex items-center gap-1 text-emerald-700 font-bold text-[10px] bg-emerald-100 px-2 py-0.5 rounded-full border border-emerald-200">
                        <Check className="w-3 h-3 text-emerald-600" /> Réglé
                      </span>
                    ) : isSelectedLeaseGranted ? (
                      <button
                        type="button"
                        onClick={() => onOpenPaymentModal(tranche.amount)}
                        className="py-1 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-[10px] shadow-xs inline-flex items-center gap-1 cursor-pointer transition-all hover:scale-105"
                      >
                        <Zap className="w-2.5 h-2.5 text-amber-300" />
                        <span>Payer cette tranche ({formatFCFA(tranche.amount)})</span>
                      </button>
                    ) : (
                      <span className="text-[10px] text-slate-400 font-medium italic">
                        Dès accord bail
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* TAB 3: HISTORIQUE DES VERSEMENTS */}
      {activeTab === 'history' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div>
              <h3 className="text-lg font-black text-slate-900">
                Historique Complet des Micro-versements
              </h3>
              <p className="text-xs text-slate-500">
                Toutes les tranches reçues et horodatées avec leur référence opérateur certifiée.
              </p>
            </div>

            <button
              type="button"
              onClick={() => onOpenPaymentModal()}
              className="py-2.5 px-4 rounded-xl font-black text-xs flex items-center gap-2 shadow-sm bg-blue-600 hover:bg-blue-700 text-white cursor-pointer transition-all hover:scale-105"
            >
              <CreditCard className="w-4 h-4" />
              <span>Nouveau versement</span>
            </button>
          </div>

          {microPayments.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 border border-dashed border-slate-200 rounded-2xl space-y-2">
              <Clock className="w-8 h-8 text-slate-400 mx-auto" />
              <p className="text-xs font-bold text-slate-700">Aucun micro-versement pour le moment</p>
              <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
                Commencez à payer votre loyer par tranches via Wave ou Orange Money selon vos rentrées d'argent.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {microPayments.map((pay) => (
                <div key={pay.id} className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-sm font-bold shadow-xs ${
                      pay.method === 'wave'
                        ? 'bg-sky-100 text-sky-700 border border-sky-200'
                        : pay.method === 'orange_money'
                        ? 'bg-orange-100 text-orange-700 border border-orange-200'
                        : 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                    }`}>
                      {pay.method === 'wave' ? '🌊' : pay.method === 'orange_money' ? '🍊' : '💳'}
                    </div>

                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">{pay.notes || 'Micro-versement de loyer'}</span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-slate-100 text-slate-600">
                          {pay.reference}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400">{pay.date} • {pay.forMonth}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-3">
                    <div className="text-right">
                      <span className="text-sm font-black font-mono text-slate-900 block">
                        +{formatFCFA(pay.amount)}
                      </span>
                      <span className="text-[10px] font-bold text-emerald-600 flex items-center gap-1 justify-end">
                        <Check className="w-3 h-3" /> Validé & Encaissé
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: QUITTANCES DE LOYER CERTIFIEES */}
      {activeTab === 'receipts' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div>
              <h3 className="text-lg font-black text-slate-900">
                Mes Quittances de Loyer Certifiées LOC
              </h3>
              <p className="text-xs text-slate-500">
                Documents juridiques authentifiés attestant du règlement complet de votre loyer et de la caution.
              </p>
            </div>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full">
              Signature Électronique Certifiée
            </span>
          </div>

          {receipts.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 border border-dashed border-slate-200 rounded-2xl space-y-2">
              <FileText className="w-8 h-8 text-slate-400 mx-auto" />
              <p className="text-xs font-bold text-slate-700">Aucune quittance générée pour le moment</p>
              <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
                Votre quittance mensuelle officielle est générée automatiquement dès que le montant total du loyer est soldé.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {receipts.map((rec) => (
                <div
                  key={rec.id}
                  className="p-4 rounded-2xl border border-slate-200 hover:border-blue-400 bg-slate-50/50 hover:bg-white transition-all space-y-3 flex flex-col justify-between shadow-xs"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono font-bold text-slate-500">
                        {rec.receiptNumber}
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-100 text-emerald-800">
                        Soldé
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-slate-900">
                      Quittance de Loyer — {rec.period}
                    </h4>

                    <div className="text-xs text-slate-600 space-y-1 bg-white p-2.5 rounded-xl border border-slate-200/80">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Bailleur :</span>
                        <span className="font-medium text-slate-800">{rec.landlordName}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Total Réglé :</span>
                        <span className="font-mono font-bold text-slate-900">{formatFCFA(rec.totalPaid)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Date d'acquittement :</span>
                        <span className="text-slate-700">{rec.datePaid}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => onOpenReceiptDetail(rec)}
                    className="w-full py-2 px-3 rounded-xl bg-blue-50 hover:bg-blue-600 hover:text-white text-blue-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Consulter & Télécharger la Quittance PDF</span>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

    </div>
  );
};
