import React, { useState } from 'react';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  XCircle, 
  CalendarClock, 
  RotateCcw, 
  Plus, 
  MessageSquare, 
  Building2, 
  Sparkles, 
  AlertCircle,
  X,
  Send,
  CalendarCheck
} from 'lucide-react';
import { VisitAppointment, Property, TenantApplication } from '../../types';

interface TenantAppointmentsViewProps {
  appointments?: VisitAppointment[];
  applications?: TenantApplication[];
  properties?: Property[];
  tenantId?: string;
  onValidateAppointment?: (appointmentId: string, date: string, timeSlot: string, location: string) => void;
  onRescheduleAppointment?: (appointmentId: string, newDate: string, newTimeSlot: string, reason?: string) => void;
  onAddAppointment?: (newAppt: VisitAppointment) => void;
  onNavigateToChat?: () => void;
}

export const TenantAppointmentsView: React.FC<TenantAppointmentsViewProps> = ({
  appointments = [],
  applications = [],
  properties = [],
  tenantId = 'tenant-demo',
  onValidateAppointment,
  onRescheduleAppointment,
  onAddAppointment,
  onNavigateToChat,
}) => {
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'confirmed' | 'completed'>('all');
  
  // Reschedule Modal State
  const [selectedApptForReschedule, setSelectedApptForReschedule] = useState<VisitAppointment | null>(null);
  const [rescheduleDateOption, setRescheduleDateOption] = useState<'demain' | 'samedi' | 'lundi' | 'custom'>('demain');
  const [customDate, setCustomDate] = useState('');
  const [rescheduleTimeSlot, setRescheduleTimeSlot] = useState('11:00 - 12:30');
  const [rescheduleReason, setRescheduleReason] = useState('');

  // New Appointment Request Modal State
  const [isNewAppointmentModalOpen, setIsNewAppointmentModalOpen] = useState(false);
  const [selectedPropertyId, setSelectedPropertyId] = useState(properties[0]?.id || '');
  const [newApptDate, setNewApptDate] = useState('Demain');
  const [newApptTimeSlot, setNewApptTimeSlot] = useState('14:00 - 15:30');
  const [newApptNotes, setNewApptNotes] = useState('');

  // Filter user appointments
  const userAppointments = appointments.filter(
    (a) => a.tenantId === tenantId || a.tenantId === 'tenant-demo' || a.tenantId === 'user-cand-1' || !a.tenantId
  );

  const filteredAppointments = userAppointments.filter((a) => {
    if (filterStatus === 'all') return true;
    return a.status === filterStatus;
  });

  const handleOpenRescheduleModal = (appt: VisitAppointment) => {
    setSelectedApptForReschedule(appt);
    setRescheduleTimeSlot(appt.timeSlot || '11:00 - 12:30');
    setRescheduleReason('');
    setRescheduleDateOption('demain');
    setCustomDate('');
  };

  const handleConfirmReschedule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedApptForReschedule) return;

    let finalDateString = 'Demain';
    if (rescheduleDateOption === 'demain') {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      finalDateString = tomorrow.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });
    } else if (rescheduleDateOption === 'samedi') {
      finalDateString = 'Ce Samedi à venir';
    } else if (rescheduleDateOption === 'lundi') {
      finalDateString = 'Lundi Prochain';
    } else if (rescheduleDateOption === 'custom' && customDate) {
      const d = new Date(customDate);
      if (!isNaN(d.getTime())) {
        finalDateString = d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
      } else {
        finalDateString = customDate;
      }
    }

    if (onRescheduleAppointment) {
      onRescheduleAppointment(
        selectedApptForReschedule.id,
        finalDateString,
        rescheduleTimeSlot,
        rescheduleReason.trim()
      );
    } else if (onValidateAppointment) {
      onValidateAppointment(
        selectedApptForReschedule.id,
        finalDateString,
        rescheduleTimeSlot,
        selectedApptForReschedule.propertyAddress || 'Sur place au logement'
      );
    }

    setSelectedApptForReschedule(null);
  };

  const handleCreateNewAppointmentRequest = (e: React.FormEvent) => {
    e.preventDefault();
    const targetProp = properties.find((p) => p.id === selectedPropertyId) || properties[0];
    const newAppt: VisitAppointment = {
      id: `appt-${Date.now()}`,
      propertyId: targetProp?.id || 'prop-default',
      propertyRefNumber: targetProp?.refNumber || 'LOC-DKR-001',
      propertyTitle: targetProp?.title || 'Logement LOC Dakar',
      propertyAddress: targetProp?.address || 'Dakar, Sénégal',
      tenantId: tenantId,
      tenantName: 'Locataire Candidat',
      tenantPhone: '+221 77 000 00 00',
      date: newApptDate,
      timeSlot: newApptTimeSlot,
      status: 'pending',
      notes: `Demande directe de visite candidat. Note : ${newApptNotes}`,
      validatedByTenant: true,
      validatedAt: new Date().toISOString(),
    };

    if (onAddAppointment) {
      onAddAppointment(newAppt);
    }

    setIsNewAppointmentModalOpen(false);
    setNewApptNotes('');
  };

  const getStatusBadge = (status: VisitAppointment['status'], validatedByTenant?: boolean) => {
    if (status === 'confirmed' || validatedByTenant) {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
          Rendez-vous Confirmé
        </span>
      );
    }
    if (status === 'completed') {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-200">
          <CalendarCheck className="w-3.5 h-3.5 text-blue-600" />
          Visite Effectuée
        </span>
      );
    }
    if (status === 'cancelled') {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-200">
          <XCircle className="w-3.5 h-3.5 text-rose-600" />
          Annulé
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-200 animate-pulse">
        <CalendarClock className="w-3.5 h-3.5 text-amber-600" />
        En attente de confirmation
      </span>
    );
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-5xl mx-auto">
      
      {/* HEADER BAR */}
      <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-blue-100 text-blue-800 border border-blue-200 flex items-center gap-1">
              <CalendarIcon className="w-3.5 h-3.5 text-blue-600" />
              Espace Visites & Rendez-vous
            </span>
          </div>
          <h2 className="text-xl font-black text-slate-900">
            Mes Rendez-vous de Visite & Signature
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            Planifiez, validez ou reprogrammez vos visites de logements et rendez-vous de remise des clés LOC.
          </p>
        </div>

        <button
          onClick={() => setIsNewAppointmentModalOpen(true)}
          className="py-2.5 px-4 rounded-2xl bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-all shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Demander un Rendez-vous</span>
        </button>
      </div>

      {/* FILTER TABS */}
      <div className="flex items-center gap-2 p-1.5 bg-slate-100 border border-slate-200/80 rounded-2xl overflow-x-auto">
        {[
          { id: 'all', label: `Tous mes RDV (${userAppointments.length})` },
          { id: 'pending', label: 'En attente' },
          { id: 'confirmed', label: 'Confirmés' },
          { id: 'completed', label: 'Visites Effectuées' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilterStatus(tab.id as any)}
            className={`py-2 px-3.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
              filterStatus === tab.id
                ? 'bg-white text-blue-700 shadow-xs border border-slate-200/60 font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* APPOINTMENTS LIST */}
      {filteredAppointments.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-3xl p-8 sm:p-12 text-center space-y-4 shadow-xs">
          <div className="w-16 h-16 rounded-3xl bg-blue-50 text-blue-600 mx-auto flex items-center justify-center text-2xl border border-blue-100 shadow-xs">
            📅
          </div>
          <div className="space-y-1 max-w-md mx-auto">
            <h3 className="text-sm font-black text-slate-900">
              Aucun rendez-vous trouvé
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Dès que votre candidature est acceptée ou lorsqu'un créneau de visite est planifié avec le bailleur, vos dates et heures de rendez-vous s'affichent ici.
            </p>
          </div>
          <button
            onClick={() => setIsNewAppointmentModalOpen(true)}
            className="py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs inline-flex items-center gap-2 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Demander un créneau de visite</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredAppointments.map((appt) => {
            const isPending = appt.status === 'pending' && !appt.validatedByTenant;
            return (
              <div
                key={appt.id}
                className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs hover:border-blue-300 transition-all space-y-4 flex flex-col justify-between"
              >
                <div className="space-y-3">
                  
                  {/* Top Header & Status */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-9 h-9 rounded-2xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0 border border-blue-100">
                        <Building2 className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="text-sm font-black text-slate-900 line-clamp-1">
                          {appt.propertyTitle}
                        </h3>
                        <span className="text-[10px] font-mono font-bold text-slate-400">
                          RÉF : {appt.propertyRefNumber || 'LOC-DKR'}
                        </span>
                      </div>
                    </div>

                    <div>
                      {getStatusBadge(appt.status, appt.validatedByTenant)}
                    </div>
                  </div>

                  {/* Date & Location Card */}
                  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2 text-xs">
                    <div className="flex items-center gap-2 text-slate-800">
                      <CalendarIcon className="w-4 h-4 text-blue-600 shrink-0" />
                      <span className="font-bold">Date :</span>
                      <span className="font-bold text-blue-900 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-200">
                        {appt.date}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-slate-800">
                      <Clock className="w-4 h-4 text-blue-600 shrink-0" />
                      <span className="font-bold">Horaire :</span>
                      <span className="font-mono font-bold text-slate-900">
                        {appt.timeSlot}
                      </span>
                    </div>

                    <div className="flex items-start gap-2 text-slate-700 pt-1 border-t border-slate-200/60">
                      <MapPin className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                      <span className="text-[11px] font-medium leading-tight">
                        {appt.propertyAddress || 'Sur place au logement (Dakar)'}
                      </span>
                    </div>
                  </div>

                  {/* Notes */}
                  {appt.notes && (
                    <p className="text-[11px] text-slate-600 bg-blue-50/50 p-2.5 rounded-xl border border-blue-100/80 leading-relaxed">
                      💡 <span className="font-semibold text-slate-800">Note :</span> {appt.notes}
                    </p>
                  )}

                </div>

                {/* ACTION BUTTONS */}
                <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center gap-2">
                  
                  {/* Validate button if pending */}
                  {isPending && onValidateAppointment && (
                    <button
                      onClick={() =>
                        onValidateAppointment(
                          appt.id,
                          appt.date,
                          appt.timeSlot,
                          appt.propertyAddress || 'Sur place au logement'
                        )
                      }
                      className="flex-1 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Valider ce créneau</span>
                    </button>
                  )}

                  {/* Reschedule button */}
                  <button
                    onClick={() => handleOpenRescheduleModal(appt)}
                    className="flex-1 py-2.5 px-3 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-blue-600" />
                    <span>Reprogrammer le RDV</span>
                  </button>

                  {/* Chat button */}
                  {onNavigateToChat && (
                    <button
                      onClick={onNavigateToChat}
                      className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-all cursor-pointer"
                      title="Ouvrir le Chat"
                    >
                      <MessageSquare className="w-4 h-4 text-slate-600" />
                    </button>
                  )}

                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: REPROGRAMMER LE RENDEZ-VOUS                                       */}
      {/* ========================================================================= */}
      {selectedApptForReschedule && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full space-y-5 shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                  <RotateCcw className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    Reprogrammer mon Rendez-vous
                  </h3>
                  <p className="text-xs text-slate-500">
                    {selectedApptForReschedule.propertyTitle}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setSelectedApptForReschedule(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConfirmReschedule} className="space-y-4 text-xs">
              
              {/* Date Presets */}
              <div className="space-y-2">
                <label className="font-bold text-slate-800 block">
                  Choisir la nouvelle date souhaitée :
                </label>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => setRescheduleDateOption('demain')}
                    className={`p-2.5 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                      rescheduleDateOption === 'demain'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    Demain
                  </button>

                  <button
                    type="button"
                    onClick={() => setRescheduleDateOption('samedi')}
                    className={`p-2.5 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                      rescheduleDateOption === 'samedi'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    Ce Samedi
                  </button>

                  <button
                    type="button"
                    onClick={() => setRescheduleDateOption('lundi')}
                    className={`p-2.5 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                      rescheduleDateOption === 'lundi'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    Lundi Prochain
                  </button>

                  <button
                    type="button"
                    onClick={() => setRescheduleDateOption('custom')}
                    className={`p-2.5 rounded-xl border text-center font-bold transition-all cursor-pointer ${
                      rescheduleDateOption === 'custom'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    Date précise
                  </button>
                </div>

                {rescheduleDateOption === 'custom' && (
                  <div className="pt-2 animate-fade-in">
                    <input
                      type="date"
                      value={customDate}
                      onChange={(e) => setCustomDate(e.target.value)}
                      required
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs text-slate-900 font-bold focus:bg-white focus:border-blue-500 outline-none"
                    />
                  </div>
                )}
              </div>

              {/* Time Slot */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-800 block">
                  Créneau horaire souhaité :
                </label>
                <select
                  value={rescheduleTimeSlot}
                  onChange={(e) => setRescheduleTimeSlot(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900 focus:bg-white focus:border-blue-500 outline-none"
                >
                  <option value="09:00 - 10:30">Matin : 09:00 - 10:30</option>
                  <option value="11:00 - 12:30">Matin : 11:00 - 12:30</option>
                  <option value="14:00 - 15:30">Après-midi : 14:00 - 15:30</option>
                  <option value="16:00 - 17:30">Après-midi : 16:00 - 17:30</option>
                  <option value="18:00 - 19:30">Fin de journée : 18:00 - 19:30</option>
                </select>
              </div>

              {/* Reason / Note */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-800 block">
                  Motif de la reprogrammation (optionnel) :
                </label>
                <textarea
                  value={rescheduleReason}
                  onChange={(e) => setRescheduleReason(e.target.value)}
                  placeholder="Ex: Impératif professionnel imprévu, je souhaite décaler la visite à ce samedi matin."
                  rows={3}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none"
                />
              </div>

              <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-[11px] leading-relaxed">
                ℹ️ Dès validation, l'équipe LOC et le propriétaire recevront une notification immédiate avec votre nouvelle date proposée.
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedApptForReschedule(null)}
                  className="flex-1 py-3 px-4 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold transition-all cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold shadow-md shadow-blue-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Confirmer la reprogrammation</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: DEMANDER UN RENDEZ-VOUS                                           */}
      {/* ========================================================================= */}
      {isNewAppointmentModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full space-y-5 shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    Solliciter un Créneau de Visite
                  </h3>
                  <p className="text-xs text-slate-500">
                    Proposez une date de visite pour le logement de votre choix
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsNewAppointmentModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateNewAppointmentRequest} className="space-y-4 text-xs">
              
              {/* Property Selection */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-800 block">
                  Sélectionner le bien immobilier :
                </label>
                <select
                  value={selectedPropertyId}
                  onChange={(e) => setSelectedPropertyId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900 focus:bg-white focus:border-blue-500 outline-none"
                >
                  {properties.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.title} • {p.neighborhood} ({p.rentPrice ? p.rentPrice.toLocaleString('fr-FR') + ' FCFA' : ''})
                    </option>
                  ))}
                </select>
              </div>

              {/* Proposed Date */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-800 block">
                  Date de visite souhaitée :
                </label>
                <input
                  type="text"
                  value={newApptDate}
                  onChange={(e) => setNewApptDate(e.target.value)}
                  placeholder="Ex: Demain ou Ce Samedi 10H"
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900 focus:bg-white focus:border-blue-500 outline-none"
                />
              </div>

              {/* Proposed Time Slot */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-800 block">
                  Créneau horaire :
                </label>
                <select
                  value={newApptTimeSlot}
                  onChange={(e) => setNewApptTimeSlot(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900 focus:bg-white focus:border-blue-500 outline-none"
                >
                  <option value="09:00 - 10:30">Matin : 09:00 - 10:30</option>
                  <option value="11:00 - 12:30">Matin : 11:00 - 12:30</option>
                  <option value="14:00 - 15:30">Après-midi : 14:00 - 15:30</option>
                  <option value="16:00 - 17:30">Après-midi : 16:00 - 17:30</option>
                  <option value="18:00 - 19:30">Fin de journée : 18:00 - 19:30</option>
                </select>
              </div>

              {/* Notes */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-800 block">
                  Précisions / Disponibilités :
                </label>
                <textarea
                  value={newApptNotes}
                  onChange={(e) => setNewApptNotes(e.target.value)}
                  placeholder="Ex: Souhaite visiter l'appartement avec mon garant solidaire."
                  rows={3}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none"
                />
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsNewAppointmentModalOpen(false)}
                  className="flex-1 py-3 px-4 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold transition-all cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold shadow-md shadow-blue-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Transmettre la demande</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
