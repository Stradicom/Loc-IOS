import React from 'react';
import { X, Download, ShieldCheck, Printer, CheckCircle2, FileText } from 'lucide-react';
import { RentReceipt } from '../../types';
import { formatFCFA } from '../../utils/finance';

interface ReceiptModalProps {
  receipt: RentReceipt | null;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ receipt, onClose }) => {
  if (!receipt) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in text-slate-800">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-2xl relative max-h-[92vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="text-center space-y-1 pb-4 border-b border-slate-200">
          <div className="w-10 h-10 rounded-2xl bg-blue-600 flex items-center justify-center text-white font-black text-xl mx-auto mb-2 shadow-sm">
            K
          </div>
          <h2 className="text-lg font-black text-slate-900 tracking-tight">LOC FINTECH IMMO</h2>
          <p className="text-[11px] text-slate-500 font-medium">Plateforme de Gestion & Microfinancement Locatif</p>
          <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold border border-emerald-200 mt-1">
            <CheckCircle2 className="w-3 h-3" />
            QUITTANCE DE LOYER CERTIFIÉE
          </div>
        </div>

        {/* Receipt Content Body */}
        <div className="py-4 space-y-3.5 text-xs">
          {/* Metadata info */}
          <div className="grid grid-cols-2 gap-2 p-3 rounded-2xl bg-slate-50 border border-slate-200">
            <div>
              <span className="text-[10px] text-slate-500 block">N° Quittance :</span>
              <span className="font-mono font-bold text-slate-900 text-[11px]">{receipt.receiptNumber}</span>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-500 block">Date de règlement :</span>
              <span className="font-semibold text-slate-700 text-[11px]">{receipt.datePaid}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block">Période concernée :</span>
              <span className="font-bold text-blue-700 text-[11px]">{receipt.period}</span>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-500 block">Statut du loyer :</span>
              <span className="font-bold text-emerald-700 text-[11px]">Intégralement Réglé</span>
            </div>
          </div>

          {/* Parties */}
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <div>
              <span className="text-[10px] text-slate-500 block">Locataire :</span>
              <span className="font-bold text-slate-900">{receipt.tenantName}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block">Bailleur / Propriétaire :</span>
              <span className="font-bold text-slate-700">{receipt.landlordName}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block">Adresse du logement loué :</span>
              <span className="text-slate-700 font-medium">{receipt.propertyTitle} — {receipt.propertyAddress}</span>
            </div>
          </div>

          {/* Breakdown calculation */}
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Ventilation du Paiement
            </span>
            <div className="space-y-1 text-slate-700">
              <div className="flex justify-between">
                <span>Loyer net mensuel :</span>
                <span className="font-mono font-bold text-slate-900">{formatFCFA(receipt.baseRent)}</span>
              </div>
              {receipt.depositInstallment > 0 && (
                <div className="flex justify-between text-blue-700">
                  <span>Part caution échelonnée LOC :</span>
                  <span className="font-mono font-bold">+{formatFCFA(receipt.depositInstallment)}</span>
                </div>
              )}
              {receipt.serviceFee > 0 && (
                <div className="flex justify-between text-slate-500">
                  <span>Frais de dossier LOC (10%) :</span>
                  <span className="font-mono">+{formatFCFA(receipt.serviceFee)}</span>
                </div>
              )}
              {Boolean(receipt.managementFee && receipt.managementFee > 0) && (
                <div className="flex justify-between text-emerald-700">
                  <span>Frais de gestion plateforme LOC (10%) :</span>
                  <span className="font-mono font-bold">+{formatFCFA(receipt.managementFee!)}</span>
                </div>
              )}
              <div className="pt-2 border-t border-slate-200 flex justify-between font-black text-sm text-emerald-700">
                <span>TOTAL ACQUITTÉ :</span>
                <span className="font-mono">{formatFCFA(receipt.totalPaid)}</span>
              </div>
            </div>
          </div>

          {/* Digital Stamp */}
          <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-[10px] font-mono text-slate-500 space-y-0.5">
            <div className="flex items-center gap-1 text-slate-600 font-sans font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
              <span>Empreinte cryptographique certifiée LOC :</span>
            </div>
            <p className="truncate text-slate-500">{receipt.signatureToken}</p>
          </div>
        </div>

        {/* Action button */}
        <div className="pt-2">
          <button
            onClick={() => {
              window.print?.();
            }}
            className="w-full py-3 px-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Télécharger la Quittance PDF</span>
          </button>
        </div>
      </div>
    </div>
  );
};
