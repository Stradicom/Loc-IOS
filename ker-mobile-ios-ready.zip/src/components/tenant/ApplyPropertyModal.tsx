import React, { useState } from 'react';
import { 
  X, 
  UserCheck, 
  ShieldCheck, 
  FileText, 
  CheckCircle2, 
  Upload, 
  Building2, 
  ArrowRight, 
  Sparkles, 
  Briefcase, 
  Check, 
  AlertCircle,
  Phone,
  User,
  DollarSign,
  Calendar
} from 'lucide-react';
import { Property, TenantApplication, ProfessionCategory, GuarantorDetails, UserProfile } from '../../types';
import { formatFCFA, calculateDepositPlan, calculateClassicPlan, computeSolvencyScore } from '../../utils/finance';

interface ApplyPropertyModalProps {
  property: Property | null;
  currentUser: UserProfile | null;
  isOpen: boolean;
  onClose: () => void;
  onSubmitApplication: (applicationData: Partial<TenantApplication>) => void;
}

export const ApplyPropertyModal: React.FC<ApplyPropertyModalProps> = ({
  property,
  currentUser,
  isOpen,
  onClose,
  onSubmitApplication,
}) => {
  // Application Mode Choice
  const [applicationOption, setApplicationOption] = useState<'ker_financing' | 'classic_direct'>('ker_financing');
  const [preferredVisitDate, setPreferredVisitDate] = useState<string>(
    new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0]
  );
  const [preferredVisitTimeSlot, setPreferredVisitTimeSlot] = useState<'matin' | 'apres_midi' | 'soir'>('apres_midi');

  // Form State
  const [professionCategory, setProfessionCategory] = useState<ProfessionCategory>('salarie');
  const [profession, setProfession] = useState(currentUser?.profession || 'Responsable Marketing Digital');
  const [companyName, setCompanyName] = useState('Entreprise à Dakar');
  const [income, setIncome] = useState<number>(currentUser?.monthlyIncome || 450000);
  const [employmentType, setEmploymentType] = useState<'cdi' | 'cdd' | 'fonctionnaire' | 'entrepreneur' | 'independant' | 'etudiant' | 'autre'>('cdi');

  // Guarantor state
  const [hasGuarantor, setHasGuarantor] = useState(true);
  const [guarantorFirstName, setGuarantorFirstName] = useState('Dr. Ousmane');
  const [guarantorLastName, setGuarantorLastName] = useState('Sow');
  const [guarantorPhone, setGuarantorPhone] = useState('+221 77 123 45 67');
  const [guarantorProfession, setGuarantorProfession] = useState('Médecin Chef — Clinique Madeleine');
  const [guaranteedAmount, setGuaranteedAmount] = useState<number>(property ? property.monthlyRent * 2 : 300000);

  // Documents checklist state & file names
  const [cniUploaded, setCniUploaded] = useState(true);
  const [cniFileName, setCniFileName] = useState<string>('cni_recto_verso.pdf');
  const [payslipUploaded, setPayslipUploaded] = useState(true);
  const [payslipFileName, setPayslipFileName] = useState<string>('bulletin_salaire_recent.pdf');
  const [workContractUploaded, setWorkContractUploaded] = useState(true);
  const [workContractFileName, setWorkContractFileName] = useState<string>('contrat_travail.pdf');
  const [rccmUploaded, setRccmUploaded] = useState(false);
  const [rccmFileName, setRccmFileName] = useState<string>('');
  const [bankUploaded, setBankUploaded] = useState(true);
  const [bankFileName, setBankFileName] = useState<string>('releve_bancaire_recent.pdf');
  const [activityProofUploaded, setActivityProofUploaded] = useState(false);
  const [activityProofFileName, setActivityProofFileName] = useState<string>('');
  const [studentDocUploaded, setStudentDocUploaded] = useState(false);
  const [studentDocFileName, setStudentDocFileName] = useState<string>('');

  if (!isOpen || !property) return null;

  const kerPlan = calculateDepositPlan(property.monthlyRent, property.depositMonths);
  const classicPlan = calculateClassicPlan(property.monthlyRent, property.depositMonths);

  const handleFileUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    setterUpload: React.Dispatch<React.SetStateAction<boolean>>,
    setterName: React.Dispatch<React.SetStateAction<string>>
  ) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setterName(file.name);
      setterUpload(true);
    }
  };

  // Calculate live score
  const isDocComplete = applicationOption === 'classic_direct' 
    ? cniUploaded 
    : (cniUploaded && (
        (professionCategory === 'salarie' && payslipUploaded && workContractUploaded) ||
        (professionCategory === 'fonctionnaire' && payslipUploaded && workContractUploaded) ||
        (professionCategory === 'entrepreneur' && rccmUploaded && bankUploaded) ||
        (professionCategory === 'commercant' && activityProofUploaded && bankUploaded) ||
        (professionCategory === 'independant' && bankUploaded) ||
        (professionCategory === 'etudiant' && studentDocUploaded && hasGuarantor) ||
        (professionCategory === 'autre' && bankUploaded)
      ));

  const { score, level } = computeSolvencyScore(
    income,
    property.monthlyRent,
    employmentType === 'fonctionnaire' ? 'cdi' : employmentType === 'etudiant' ? 'cdd' : employmentType === 'autre' ? 'independant' : employmentType,
    applicationOption === 'classic_direct' ? false : hasGuarantor,
    isDocComplete
  );

  const rentRatio = Math.round((property.monthlyRent / (income || 1)) * 100);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const isClassic = applicationOption === 'classic_direct';
    const effectiveHasGuarantor = isClassic ? false : hasGuarantor;

    const guarantorDetails: GuarantorDetails = {
      firstName: guarantorFirstName.trim(),
      lastName: guarantorLastName.trim(),
      phone: guarantorPhone.trim(),
      profession: guarantorProfession.trim(),
      guaranteedAmount: guaranteedAmount || property.monthlyRent * 2,
    };

    const applicationPayload: Partial<TenantApplication> = {
      propertyId: property.id,
      propertyTitle: property.title,
      propertyAddress: property.address,
      monthlyRent: property.monthlyRent,
      depositAmount: isClassic
        ? classicPlan.totalDepositAndBrokerage
        : kerPlan.totalDepositAndBrokerage,
      applicationOption,
      preferredVisitDate: isClassic 
        ? `${preferredVisitDate} (${preferredVisitTimeSlot === 'matin' ? 'Matin 09h-12h' : preferredVisitTimeSlot === 'apres_midi' ? 'Après-midi 14h-18h' : 'Soir 18h-20h'})` 
        : undefined,
      tenantProfession: profession,
      professionCategory,
      monthlyIncome: income,
      employmentType,
      hasGuarantor: effectiveHasGuarantor,
      guarantorDetails: effectiveHasGuarantor ? guarantorDetails : undefined,
      guarantorName: effectiveHasGuarantor ? `${guarantorFirstName} ${guarantorLastName}`.trim() : undefined,
      guarantorPhone: effectiveHasGuarantor ? guarantorPhone : undefined,
      guaranteedAmount: effectiveHasGuarantor ? guaranteedAmount : undefined,
      kycScore: isClassic ? 100 : score,
      riskLevel: isClassic ? 'low' : (level as any),
      status: 'pending',
      appliedAt: new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }),
      currentStep: 2,
      kycDocuments: isClassic
        ? {
            idCard: cniUploaded,
            payslip: false,
            workContract: false,
            rccmNinea: false,
            bankStatements: false,
            activityProof: false,
            studentCertificate: false,
            payslips: false,
            workCertificate: false,
          }
        : {
            idCard: cniUploaded,
            payslip: payslipUploaded,
            workContract: workContractUploaded,
            rccmNinea: rccmUploaded,
            bankStatements: bankUploaded,
            activityProof: activityProofUploaded,
            studentCertificate: studentDocUploaded,
            payslips: payslipUploaded,
            workCertificate: workContractUploaded,
          },
    };

    onSubmitApplication(applicationPayload);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fade-in text-slate-800">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-2xl relative max-h-[92vh] overflow-y-auto space-y-5">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-400 hover:text-slate-800 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="space-y-1 pr-8">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[11px] font-bold border border-blue-200">
            <Building2 className="w-3.5 h-3.5 text-blue-600" />
            Candidature & Dossier de Solvabilité LOC
          </div>
          <h2 className="text-xl font-black text-slate-900">
            Postuler pour : {property.title}
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            {property.neighborhood}, {property.city} • Loyer : {formatFCFA(property.monthlyRent)}/mois
          </p>
        </div>

        {/* Formula Selection Cards */}
        <div className="space-y-2">
          <label className="text-xs font-black text-slate-900 block flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-blue-600" />
            Choix de la Formule Locative :
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Option 1: LOC Micro-Caution */}
            <div
              onClick={() => setApplicationOption('ker_financing')}
              className={`p-3.5 rounded-2xl border cursor-pointer transition-all relative ${
                applicationOption === 'ker_financing'
                  ? 'bg-blue-50/90 border-blue-500 ring-2 ring-blue-500/20 shadow-sm'
                  : 'bg-white border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <div className={`p-1.5 rounded-xl ${applicationOption === 'ker_financing' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                    <Sparkles className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Micro-Financement LOC</h4>
                    <p className="text-[10px] text-blue-700 font-semibold">Caution étalée sur 6 mois</p>
                  </div>
                </div>
                <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                  applicationOption === 'ker_financing' ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-300'
                }`}>
                  {applicationOption === 'ker_financing' && <Check className="w-3 h-3 stroke-[3]" />}
                </div>
              </div>

              <div className="mt-2.5 pt-2 border-t border-blue-100/80 space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-500">Apport initial requis :</span>
                  <span className="font-extrabold text-blue-700 font-mono">{formatFCFA(kerPlan.initialTotalDue)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Frais dossier :</span>
                  <span className="font-bold text-slate-700 font-mono">{formatFCFA(kerPlan.serviceFee)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Frais gestion locataire :</span>
                  <span className="font-bold text-slate-700 font-mono">10% ({formatFCFA(kerPlan.managementFeeAmount)}/m)</span>
                </div>
              </div>
            </div>

            {/* Option 2: Paiement Classique (sans LOC) */}
            <div
              onClick={() => setApplicationOption('classic_direct')}
              className={`p-3.5 rounded-2xl border cursor-pointer transition-all relative ${
                applicationOption === 'classic_direct'
                  ? 'bg-white border-slate-800 ring-2 ring-slate-800/10 shadow-sm text-slate-900'
                  : 'bg-white border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <div className={`p-1.5 rounded-xl ${applicationOption === 'classic_direct' ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600'}`}>
                    <Building2 className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">
                      Paiement Classique (sans LOC)
                    </h4>
                    <p className="text-[10px] text-slate-500 font-semibold">
                      Bail accordé après visite
                    </p>
                  </div>
                </div>
                <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                  applicationOption === 'classic_direct' ? 'border-slate-800 bg-slate-800 text-white' : 'border-slate-300'
                }`}>
                  {applicationOption === 'classic_direct' && <Check className="w-3 h-3 stroke-[3]" />}
                </div>
              </div>

              <div className="mt-2.5 pt-2 border-t border-slate-200 space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-500">Package comptant à l'entrée :</span>
                  <span className="font-extrabold font-mono text-slate-900">
                    {formatFCFA(classicPlan.initialTotalDue)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Frais dossier :</span>
                  <span className="font-bold text-emerald-700 font-mono">0 FCFA (Gratuit)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Frais gestion locataire :</span>
                  <span className="font-bold font-mono text-slate-900">
                    10% ({formatFCFA(classicPlan.managementFeeAmount)}/m)
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Details / Visit Banner for Classic mode vs LOC mode */}
        {applicationOption === 'classic_direct' ? (
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-black text-slate-900">
                <Building2 className="w-4 h-4 text-blue-600" />
                <span>Modalités de la Formule Classique (Comptant 3 mois) :</span>
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                0 F Frais de Dossier
              </span>
            </div>

            {/* Financial Details in Blue Typography */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs">
              <div className="space-y-0.5">
                <span className="text-[10px] text-slate-500 font-medium block">Caution légale (2 mois)</span>
                <span className="text-sm font-black text-blue-600 font-mono block">
                  {formatFCFA(classicPlan.legalDeposit)}
                </span>
              </div>
              <div className="space-y-0.5">
                <span className="text-[10px] text-slate-500 font-medium block">Courtage / Agence (1 m)</span>
                <span className="text-sm font-black text-blue-600 font-mono block">
                  {formatFCFA(classicPlan.brokerFee)}
                </span>
              </div>
              <div className="space-y-0.5">
                <span className="text-[10px] text-slate-500 font-medium block">Total à l'entrée (3 mois)</span>
                <span className="text-sm font-black text-blue-600 font-mono block">
                  {formatFCFA(classicPlan.initialTotalDue)}
                </span>
              </div>
              <div className="space-y-0.5">
                <span className="text-[10px] text-slate-500 font-medium block">Gestion locataire (10%)</span>
                <span className="text-sm font-black text-blue-600 font-mono block">
                  {formatFCFA(classicPlan.managementFeeAmount)}/m
                </span>
              </div>
            </div>

            {/* Visit Details */}
            <div className="p-3 rounded-xl bg-blue-50/50 border border-blue-100 space-y-2.5">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
                <Calendar className="w-3.5 h-3.5 text-blue-600" />
                <span>Programmation de la Visite Physique Préalable :</span>
              </div>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                Le bail est formalisé et validé <strong>exclusivement après votre visite physique des lieux</strong> avec un agent agréé LOC.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                <div>
                  <label className="text-[10px] font-bold text-slate-700 block mb-1">Date souhaitée pour la visite :</label>
                  <input
                    type="date"
                    min={new Date().toISOString().split('T')[0]}
                    value={preferredVisitDate}
                    onChange={(e) => setPreferredVisitDate(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-700 block mb-1">Créneau horaire souhaité :</label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {[
                      { id: 'matin', label: 'Matin', time: '09h - 12h' },
                      { id: 'apres_midi', label: 'Après-midi', time: '14h - 18h' },
                      { id: 'soir', label: 'Soir', time: '18h - 20h' },
                    ].map((slot) => (
                      <button
                        key={slot.id}
                        type="button"
                        onClick={() => setPreferredVisitTimeSlot(slot.id as any)}
                        className={`p-1.5 rounded-lg border text-center text-[10px] transition-all font-medium ${
                          preferredVisitTimeSlot === slot.id
                            ? 'bg-blue-600 text-white border-blue-600 font-bold shadow-xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <span className="block font-bold leading-tight">{slot.label}</span>
                        <span className={`block text-[9px] leading-tight ${preferredVisitTimeSlot === slot.id ? 'text-blue-100' : 'text-slate-400'}`}>
                          {slot.time}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Dynamic Target Property & LOC Advantage Banner */
          <div className="p-4 rounded-2xl bg-blue-50/80 border border-blue-200 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="space-y-0.5">
              <span className="text-[10px] text-slate-500 font-bold uppercase">Loyer Mensuel Net</span>
              <span className="text-base font-black text-slate-900 font-mono block">
                {formatFCFA(property.monthlyRent)}
              </span>
            </div>
            <div className="space-y-0.5">
              <span className="text-[10px] text-blue-700 font-bold uppercase">Apport Initial LOC</span>
              <span className="text-base font-black text-blue-700 font-mono block">
                {formatFCFA(kerPlan.initialTotalDue)}
              </span>
            </div>
            <div className="space-y-0.5">
              <span className="text-[10px] text-emerald-700 font-bold uppercase">Score Solvabilité Estimé</span>
              <div className="flex items-center gap-1.5">
                <span className="text-base font-black text-emerald-700 font-mono">{score}/100</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 font-bold">
                  Taux {rentRatio}%
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Application Form */}
        <form onSubmit={handleSubmit} className="space-y-5">
          
          {/* SECTION 1: Métier & Profession */}
          <div className="space-y-3">
            <label className="text-xs font-black text-slate-900 block flex items-center gap-1.5">
              <Briefcase className="w-4 h-4 text-blue-600" />
              1. Statut & Situation Professionnelle du Candidat
            </label>

            {/* Profession Category Selector */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {[
                { id: 'salarie', label: 'Salarié', type: 'cdi', icon: '💼', sub: 'CDI / CDD' },
                { id: 'fonctionnaire', label: 'Fonctionnaire', type: 'fonctionnaire', icon: '🏛️', sub: 'Agent État' },
                { id: 'entrepreneur', label: 'Entrepreneur', type: 'entrepreneur', icon: '🚀', sub: 'SARL / SAS' },
                { id: 'commercant', label: 'Commerçant', type: 'entrepreneur', icon: '🏪', sub: 'Boutique / Marché' },
                { id: 'independant', label: 'Indépendant', type: 'independant', icon: '💻', sub: 'Freelance' },
                { id: 'autre', label: 'Autres', type: 'autre', icon: '🌐', sub: 'Autre profil' },
              ].map((item) => {
                const isSelected = professionCategory === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setProfessionCategory(item.id as ProfessionCategory);
                      setEmploymentType(item.type as any);
                    }}
                    className={`p-3 rounded-2xl border text-left text-xs font-bold transition-all flex items-center gap-2.5 ${
                      isSelected
                        ? 'bg-blue-600 text-white border-blue-600 shadow-sm ring-2 ring-blue-500/20'
                        : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100 hover:border-slate-300'
                    }`}
                  >
                    <span className="text-lg shrink-0">{item.icon}</span>
                    <div className="min-w-0">
                      <span className="block font-black text-xs leading-tight">{item.label}</span>
                      <span className={`block text-[10px] font-normal leading-tight ${isSelected ? 'text-blue-100' : 'text-slate-500'}`}>
                        {item.sub}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-[10px] font-bold text-slate-600 block mb-1">Métier / Intitulé du Poste :</label>
                <input
                  type="text"
                  value={profession}
                  onChange={(e) => setProfession(e.target.value)}
                  placeholder="Ex: Analyste Financier, Enseignant, Grossiste, Consultant..."
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none font-medium"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-600 block mb-1">
                  {professionCategory === 'fonctionnaire' 
                    ? 'Ministère / Établissement Public :' 
                    : professionCategory === 'independant' || professionCategory === 'autre'
                    ? 'Activité / Clientèle / Structure :'
                    : 'Entreprise / Structure :'}
                </label>
                <input
                  type="text"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="Ex: SONATEL, Ministère, Freelance, Cabinet..."
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none font-medium"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-[10px] font-bold text-slate-600 block mb-1">Revenu Net Mensuel :</label>
                <div className="relative">
                  <input
                    type="number"
                    value={income}
                    onChange={(e) => setIncome(Number(e.target.value))}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono font-bold focus:bg-white focus:border-blue-500 outline-none"
                  />
                  <span className="absolute right-3 top-2 text-[10px] text-slate-400 font-bold">FCFA</span>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-600 block mb-1">Type de Contrat :</label>
                <select
                  value={employmentType}
                  onChange={(e) => setEmploymentType(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:border-blue-500 outline-none font-medium"
                >
                  <option value="cdi">CDI (Contrat Durée Indéterminée)</option>
                  <option value="fonctionnaire">Fonctionnaire / Agent de l'État</option>
                  <option value="cdd">CDD (Contrat Durée Déterminée)</option>
                  <option value="entrepreneur">Entrepreneur / Gérant RCCM</option>
                  <option value="independant">Indépendant (Freelance / Profession Libérale)</option>
                  <option value="autre">Autres / Prestations diverses</option>
                </select>
              </div>
            </div>
          </div>

          {/* SECTION 2: Pièces Justificatives */}
          <div className="space-y-3 pt-3 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-blue-600" />
                {applicationOption === 'classic_direct'
                  ? "2. Justificatif Requis : Pièce d'Identité uniquement"
                  : "2. Justificatifs Requis (Format PDF ou Photo) :"}
              </label>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${
                applicationOption === 'classic_direct'
                  ? 'text-emerald-800 bg-emerald-100 border-emerald-300'
                  : 'text-emerald-700 bg-emerald-50 border-emerald-200'
              }`}>
                {applicationOption === 'classic_direct' ? '1 seule pièce requise' : 'PDF / JPG / PNG acceptés'}
              </span>
            </div>

            {applicationOption === 'classic_direct' && (
              <div className="p-3 rounded-2xl bg-emerald-50/80 border border-emerald-200 text-xs text-emerald-950 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>
                  <strong>Formule Classique simplifiée :</strong> Seule votre pièce d'identité est nécessaire pour enregistrer votre visite et établir le contrat. Aucun garant ni bulletin de salaire n'est demandé.
                </span>
              </div>
            )}

            <div className="space-y-2">
              {/* CNI / Passport */}
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                    🪪
                  </div>
                  <div className="min-w-0">
                    <span className="font-bold text-slate-900 block truncate">Carte d'Identité (CNI) ou Passeport</span>
                    <span className="text-[10px] text-slate-500 block truncate">
                      {cniUploaded && cniFileName ? `Fichier : ${cniFileName}` : 'Format : PDF ou Photo (recto / verso)'}
                    </span>
                  </div>
                </div>
                <label className={`cursor-pointer px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                  cniUploaded
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                    : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                }`}>
                  <input
                    type="file"
                    accept="application/pdf,image/png,image/jpeg,image/jpg,image/webp"
                    className="hidden"
                    onChange={(e) => handleFileUpload(e, setCniUploaded, setCniFileName)}
                  />
                  {cniUploaded ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Upload className="w-3.5 h-3.5" />}
                  <span>{cniUploaded ? 'Téléversé' : 'Ajouter PDF/Photo'}</span>
                </label>
              </div>

              {/* Justificatifs supplémentaires UNIQUEMENT pour la Formule LOC */}
              {applicationOption === 'ker_financing' && (
                <>
                  {/* Salarié & Fonctionnaire */}
                  {(professionCategory === 'salarie' || professionCategory === 'fonctionnaire') && (
                    <>
                      <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                            📄
                          </div>
                          <div className="min-w-0">
                            <span className="font-bold text-slate-900 block truncate">
                              {professionCategory === 'fonctionnaire' ? '1 Bulletin de Solde Récent' : '1 Fiche de Paie Récente'}
                            </span>
                            <span className="text-[10px] text-slate-500 block truncate">
                              {payslipUploaded && payslipFileName ? `Fichier : ${payslipFileName}` : 'Format : PDF ou Photo du dernier bulletin'}
                            </span>
                          </div>
                        </div>
                        <label className={`cursor-pointer px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                          payslipUploaded
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                        }`}>
                          <input
                            type="file"
                            accept="application/pdf,image/png,image/jpeg,image/jpg,image/webp"
                            className="hidden"
                            onChange={(e) => handleFileUpload(e, setPayslipUploaded, setPayslipFileName)}
                          />
                          {payslipUploaded ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Upload className="w-3.5 h-3.5" />}
                          <span>{payslipUploaded ? 'Téléversé' : 'Ajouter PDF/Photo'}</span>
                        </label>
                      </div>

                      <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                            📋
                          </div>
                          <div className="min-w-0">
                            <span className="font-bold text-slate-900 block truncate">
                              {professionCategory === 'fonctionnaire' ? 'Acte d’Engagement / Arrêté de Nomination' : 'Contrat de Travail ou Attestation'}
                            </span>
                            <span className="text-[10px] text-slate-500 block truncate">
                              {workContractUploaded && workContractFileName ? `Fichier : ${workContractFileName}` : 'Format : PDF ou Photo officiel'}
                            </span>
                          </div>
                        </div>
                        <label className={`cursor-pointer px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                          workContractUploaded
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                        }`}>
                          <input
                            type="file"
                            accept="application/pdf,image/png,image/jpeg,image/jpg,image/webp"
                            className="hidden"
                            onChange={(e) => handleFileUpload(e, setWorkContractUploaded, setWorkContractFileName)}
                          />
                          {workContractUploaded ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Upload className="w-3.5 h-3.5" />}
                          <span>{workContractUploaded ? 'Téléversé' : 'Ajouter PDF/Photo'}</span>
                        </label>
                      </div>
                    </>
                  )}

                  {/* Entrepreneur */}
                  {professionCategory === 'entrepreneur' && (
                    <>
                      <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                            🏢
                          </div>
                          <div className="min-w-0">
                            <span className="font-bold text-slate-900 block truncate">Registre de Commerce (RCCM) & NINEA</span>
                            <span className="text-[10px] text-slate-500 block truncate">
                              {rccmUploaded && rccmFileName ? `Fichier : ${rccmFileName}` : 'Format : PDF ou Photo de l’enregistrement'}
                            </span>
                          </div>
                        </div>
                        <label className={`cursor-pointer px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                          rccmUploaded
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                        }`}>
                          <input
                            type="file"
                            accept="application/pdf,image/png,image/jpeg,image/jpg,image/webp"
                            className="hidden"
                            onChange={(e) => handleFileUpload(e, setRccmUploaded, setRccmFileName)}
                          />
                          {rccmUploaded ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Upload className="w-3.5 h-3.5" />}
                          <span>{rccmUploaded ? 'Téléversé' : 'Ajouter PDF/Photo'}</span>
                        </label>
                      </div>

                      <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                            📊
                          </div>
                          <div className="min-w-0">
                            <span className="font-bold text-slate-900 block truncate">1 Relevé Bancaire Professionnel</span>
                            <span className="text-[10px] text-slate-500 block truncate">
                              {bankUploaded && bankFileName ? `Fichier : ${bankFileName}` : 'Format : PDF ou Photo du dernier relevé'}
                            </span>
                          </div>
                        </div>
                        <label className={`cursor-pointer px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                          bankUploaded
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                        }`}>
                          <input
                            type="file"
                            accept="application/pdf,image/png,image/jpeg,image/jpg,image/webp"
                            className="hidden"
                            onChange={(e) => handleFileUpload(e, setBankUploaded, setBankFileName)}
                          />
                          {bankUploaded ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Upload className="w-3.5 h-3.5" />}
                          <span>{bankUploaded ? 'Téléversé' : 'Ajouter PDF/Photo'}</span>
                        </label>
                      </div>
                    </>
                  )}

                  {/* Commerçant */}
                  {professionCategory === 'commercant' && (
                    <>
                      <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                            🏪
                          </div>
                          <div className="min-w-0">
                            <span className="font-bold text-slate-900 block truncate">Justificatif d'Activité (Patente ou Bail commercial)</span>
                            <span className="text-[10px] text-slate-500 block truncate">
                              {activityProofUploaded && activityProofFileName ? `Fichier : ${activityProofFileName}` : 'Format : PDF ou Photo de l’activité'}
                            </span>
                          </div>
                        </div>
                        <label className={`cursor-pointer px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                          activityProofUploaded
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                        }`}>
                          <input
                            type="file"
                            accept="application/pdf,image/png,image/jpeg,image/jpg,image/webp"
                            className="hidden"
                            onChange={(e) => handleFileUpload(e, setActivityProofUploaded, setActivityProofFileName)}
                          />
                          {activityProofUploaded ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Upload className="w-3.5 h-3.5" />}
                          <span>{activityProofUploaded ? 'Téléversé' : 'Ajouter PDF/Photo'}</span>
                        </label>
                      </div>

                      <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                            🏦
                          </div>
                          <div className="min-w-0">
                            <span className="font-bold text-slate-900 block truncate">1 Relevé Bancaire</span>
                            <span className="text-[10px] text-slate-500 block truncate">
                              {bankUploaded && bankFileName ? `Fichier : ${bankFileName}` : 'Format : PDF ou Photo du dernier relevé'}
                            </span>
                          </div>
                        </div>
                        <label className={`cursor-pointer px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                          bankUploaded
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                        }`}>
                          <input
                            type="file"
                            accept="application/pdf,image/png,image/jpeg,image/jpg,image/webp"
                            className="hidden"
                            onChange={(e) => handleFileUpload(e, setBankUploaded, setBankFileName)}
                          />
                          {bankUploaded ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Upload className="w-3.5 h-3.5" />}
                          <span>{bankUploaded ? 'Téléversé' : 'Ajouter PDF/Photo'}</span>
                        </label>
                      </div>
                    </>
                  )}

                  {/* Indépendant & Autres */}
                  {(professionCategory === 'independant' || professionCategory === 'autre') && (
                    <>
                      <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                            📑
                          </div>
                          <div className="min-w-0">
                            <span className="font-bold text-slate-900 block truncate">
                              {professionCategory === 'independant' 
                                ? 'Contrat de prestation, portfolio ou attestation d’exercice' 
                                : 'Justificatif de ressources, attestation ou carte professionnelle'}
                            </span>
                            <span className="text-[10px] text-slate-500 block truncate">
                              {activityProofUploaded && activityProofFileName ? `Fichier : ${activityProofFileName}` : 'Format : PDF ou Photo justificative'}
                            </span>
                          </div>
                        </div>
                        <label className={`cursor-pointer px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                          activityProofUploaded
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                        }`}>
                          <input
                            type="file"
                            accept="application/pdf,image/png,image/jpeg,image/jpg,image/webp"
                            className="hidden"
                            onChange={(e) => handleFileUpload(e, setActivityProofUploaded, setActivityProofFileName)}
                          />
                          {activityProofUploaded ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Upload className="w-3.5 h-3.5" />}
                          <span>{activityProofUploaded ? 'Téléversé' : 'Ajouter PDF/Photo'}</span>
                        </label>
                      </div>

                      <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs gap-2">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                            🏦
                          </div>
                          <div className="min-w-0">
                            <span className="font-bold text-slate-900 block truncate">1 Relevé Bancaire</span>
                            <span className="text-[10px] text-slate-500 block truncate">
                              {bankUploaded && bankFileName ? `Fichier : ${bankFileName}` : 'Format : PDF ou Photo du dernier relevé'}
                            </span>
                          </div>
                        </div>
                        <label className={`cursor-pointer px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                          bankUploaded
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                        }`}>
                          <input
                            type="file"
                            accept="application/pdf,image/png,image/jpeg,image/jpg,image/webp"
                            className="hidden"
                            onChange={(e) => handleFileUpload(e, setBankUploaded, setBankFileName)}
                          />
                          {bankUploaded ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Upload className="w-3.5 h-3.5" />}
                          <span>{bankUploaded ? 'Téléversé' : 'Ajouter PDF/Photo'}</span>
                        </label>
                      </div>
                    </>
                  )}
                </>
              )}
            </div>
          </div>

          {/* SECTION 3: Garant Solidaire (UNIQUEMENT pour Formule LOC) */}
          {applicationOption === 'ker_financing' && (
            <div className="p-4 rounded-3xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <span className="text-xs font-black text-slate-900 block flex items-center gap-1.5">
                    <UserCheck className="w-4 h-4 text-blue-600" />
                    3. Garant Solidaire
                  </span>
                  <span className="text-[10px] text-slate-500">
                    Ajoute une garantie légale et favorise la validation express de votre caution
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => setHasGuarantor(!hasGuarantor)}
                  className={`w-11 h-6 rounded-full transition-colors flex items-center p-0.5 ${
                    hasGuarantor ? 'bg-blue-600 justify-end' : 'bg-slate-300 justify-start'
                  }`}
                >
                  <div className="w-5 h-5 rounded-full bg-white shadow-md" />
                </button>
              </div>

              {hasGuarantor && (
                <div className="space-y-3 pt-2 border-t border-slate-200 animate-fade-in text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="text-[10px] font-bold text-slate-700 block mb-1">Prénom du Garant :</label>
                      <input
                        type="text"
                        value={guarantorFirstName}
                        onChange={(e) => setGuarantorFirstName(e.target.value)}
                        placeholder="Ex: Dr. Ousmane"
                        required={hasGuarantor}
                        className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-700 block mb-1">Nom du Garant :</label>
                      <input
                        type="text"
                        value={guarantorLastName}
                        onChange={(e) => setGuarantorLastName(e.target.value)}
                        placeholder="Ex: Sow"
                        required={hasGuarantor}
                        className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="text-[10px] font-bold text-slate-700 block mb-1">Numéro de Téléphone du Garant :</label>
                      <input
                        type="tel"
                        value={guarantorPhone}
                        onChange={(e) => setGuarantorPhone(e.target.value)}
                        placeholder="+221 77 123 45 67"
                        required={hasGuarantor}
                        className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-700 block mb-1">Profession / Employeur du Garant :</label>
                      <input
                        type="text"
                        value={guarantorProfession}
                        onChange={(e) => setGuarantorProfession(e.target.value)}
                        placeholder="Ex: Médecin Chef, Directeur..."
                        className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-blue-700 block mb-1 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-blue-600" />
                      Montant Garanti (Caution Solidaire) :
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        value={guaranteedAmount}
                        onChange={(e) => setGuaranteedAmount(Number(e.target.value))}
                        placeholder="Ex: 360000"
                        className="w-full bg-blue-50 border border-blue-300 rounded-xl px-3 py-2 text-xs text-blue-900 font-mono font-black"
                      />
                      <span className="absolute right-2.5 top-2 text-[10px] text-blue-600 font-bold">FCFA</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Action Button */}
          <div className="pt-2">
            <button
              type="submit"
              className={`w-full py-4 px-6 rounded-2xl font-black text-sm shadow-md flex items-center justify-center gap-2 transition-all ${
                applicationOption === 'classic_direct'
                  ? 'bg-slate-900 hover:bg-black text-white'
                  : 'bg-blue-600 hover:bg-blue-700 text-white'
              }`}
            >
              {applicationOption === 'classic_direct' ? (
                <>
                  <Building2 className="w-5 h-5 text-emerald-400" />
                  <span>Demander une Visite & Postuler en Formule Classique</span>
                  <ArrowRight className="w-4 h-4 ml-1" />
                </>
              ) : (
                <>
                  <ShieldCheck className="w-5 h-5 text-white" />
                  <span>Transmettre ma Candidature avec Caution Échelonnée LOC</span>
                  <ArrowRight className="w-4 h-4 ml-1" />
                </>
              )}
            </button>
            <p className="text-[10px] text-center text-slate-400 mt-2 font-medium">
              {applicationOption === 'classic_direct'
                ? 'Bail accordé après visite • 0 F Frais de dossier • 10% Frais de gestion plateforme locataire'
                : 'Vérification automatique en temps réel par les algorithmes de risque LOC • Conforme Droit OHADA'}
            </p>
          </div>

        </form>

      </div>
    </div>
  );
};
