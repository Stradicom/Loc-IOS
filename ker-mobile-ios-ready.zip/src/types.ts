export type PropertyType = 'chambre' | 'studio' | 'appartement' | 'maison';

export type Role = 'tenant' | 'landlord' | 'admin';

export type PaymentMethod = 'wave' | 'orange_money' | 'free_money' | 'card';

export interface UserProfile {
  id: string;
  role: Role;
  firstName?: string;
  lastName?: string;
  fullName: string;
  companyName?: string;
  phone: string;
  email: string;
  avatarText: string;
  avatarUrl?: string;
  badgeLabel: string;
  details: string;
  password?: string;
  profession?: string;
  monthlyIncome?: number;
  userType?: 'locataire' | 'proprietaire' | 'courtier';
  landlordType?: 'proprietaire' | 'courtier';
  brokerLicenseNumber?: string;
  ninea?: string;
  rccm?: string;
  isIdVerified?: boolean;
  idCardDocumentUrl?: string;
  hasSignedConvention?: boolean;
  conventionType?: 'convention_proprietaire' | 'convention_courtier_50_50';
  conventionSignedAt?: string;
  preferredPayoutMethod?: 'wave' | 'orange_money' | 'virement_bancaire';
  payoutPhoneOrRib?: string;
  isAccreditedAgency?: boolean;
  isNewUser?: boolean;
}

export interface VisitAppointment {
  id: string;
  propertyId: string;
  propertyRefNumber?: string;
  propertyTitle: string;
  propertyAddress: string;
  tenantId: string;
  tenantName: string;
  tenantPhone: string;
  tenantAvatar?: string;
  date: string;
  timeSlot: string;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  notes?: string;
  validatedByTenant?: boolean;
  validatedAt?: string;
  landlordId?: string;
  landlordName?: string;
}

export interface BrokerAccreditationRequest {
  id: string;
  userId: string;
  agencyName: string;
  managerName: string;
  licenseNumber: string;
  ninea: string;
  rccm: string;
  email: string;
  phone: string;
  idCardUrl?: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedAt: string;
}

export interface Property {
  id: string;
  title: string;
  type: PropertyType;
  typeLabel: string;
  categoryDesc: string; // e.g. "Chambre indépendante meublée", "Studio individuel", "F4 Vue Mer", "Villa Duplex"
  city: string;
  neighborhood: string;
  address: string;
  monthlyRent: number; // in FCFA
  depositMonths: number; // standard deposit in months (2 months)
  brokerFeeMonths: number; // brokerage fee (1 month)
  totalPackageMonths: number; // total package = 3 months
  chargesIncluded: boolean;
  surface: number; // in m²
  rooms: number;
  bathrooms: number;
  furnished: boolean;
  featured?: boolean;
  images: string[];
  description: string;
  amenities: string[];
  coordinates?: {
    lat: number;
    lng: number;
  };
  googleMapsUrl?: string;
  refNumber?: string; // Numéro de référence (ex: LOC-2026-001)
  floorLevel?: string; // Niveau du bien (RDC, 1er étage, 2ème étage, etc.)
  landlordId: string;
  landlordName: string;
  landlordPhone: string;
  verifiedLandlord: boolean;
  isAvailable: boolean;
  approvalStatus?: 'pending' | 'approved' | 'rejected';
  isManagedByKer?: boolean; // True si le propriétaire donne la gestion de son bien à LOC (imputation 3% sur loyer)
  managementMode?: 'delegated_ker' | 'autonomous_owner' | 'broker_mandate';
  landlordType?: 'proprietaire' | 'courtier';
  createdAt: string;
}

export interface ClassicDirectPaymentPlan {
  monthlyRent: number;
  depositMonths: number; // 2 mois de caution légale
  brokerFeeMonths: number; // 1 mois de frais de courtage / agence
  totalPackageMonths: number; // 3 mois de loyer au total
  legalDeposit: number; // 2 mois de loyer
  brokerFee: number; // 1 mois de loyer
  totalDepositAndBrokerage: number; // 3 mois au comptant
  initialTotalDue: number; // 3 mois de loyer payés en 1 fois (comptant à l'entrée)
  serviceFee: number; // 0 FCFA (Sans frais de dossier)
  managementFeeRate: number; // 10% pour le locataire
  managementFeeAmount: number; // 10% du loyer mensuel
  monthlyTotalRent: number; // Loyer + 10% gestion plateforme
  bailGrantCondition: string; // 'Bail accordé après visite des lieux'
}

export interface DepositFinancingPlan {
  monthlyRent: number;
  depositMonths: number; // 2 mois de caution légale
  brokerFeeMonths: number; // 1 mois de frais de courtage / agence
  totalPackageMonths: number; // 3 mois au total
  legalDeposit: number; // 2 * monthlyRent
  brokerFee: number; // 1 * monthlyRent
  totalDepositAndBrokerage: number; // 3 * monthlyRent (3 mois totaux à étaler)
  serviceFee: number; // 10% de la caution globale (frais de dossier LOC)
  initialDepositShare: number; // 1/3 du package de 3 mois = 1 mois
  initialRentShare: number; // 1er mois de loyer
  initialTotalDue: number; // 1er mois + 1/3 package (1 mois) + 10% de la caution globale en frais de dossier
  standardInitialDue: number; // 3 mois au comptant (Classique sans LOC)
  immediateSavings: number; // Économie immédiate à l'entrée
  savingsPercent: number; // % d'économie à l'entrée
  deferredDepositTotal: number; // Reliquat de 2 mois à étaler
  monthlyDepositInstallment: number; // 2 mois / 6 mois = 1/3 de loyer par mois
  monthlyTotalMonths1to6: number; // Loyer + Mensualité caution étalée + Frais de gestion LOC Locataire (10%)
  managementFeeRate: number; // 10% de commission pour les frais de gestion de la plateforme LOC Locataire (dès le 1er mois)
  managementFeeAmount: number; // Montant de la commission (10% du loyer)
  monthlyTotalMonth7Onwards: number; // Loyer + 10% frais de gestion plateforme LOC Locataire (caution 100% amortie)
}

export interface LandlordFinancialPlan {
  grossMonthlyRent: number; // Montant brut du loyer mensuel
  isManagedLease: boolean; // Si le bail est sous mandat de gestion LOC
  commissionRate: number; // Commission de gestion LOC (3% du montant du loyer pour les agences et propriétaires)
  commissionAmount: number; // Montant de la commission LOC (3%)
  netRentPayout: number; // Loyer net reversé au bailleur (97%)
  guaranteedDepositMonths: number; // 2 mois de caution garantie
  guaranteedDepositAmount: number; // 100% caution avancée à J+1 sans déduction
}

export interface MicroPayment {
  id: string;
  date: string;
  amount: number;
  method: PaymentMethod;
  reference: string;
  status: 'completed' | 'pending' | 'failed';
  forMonth: string; // e.g. "Septembre 2026"
  notes?: string;
}

export interface RentReceipt {
  id: string;
  receiptNumber: string;
  tenantName: string;
  landlordName: string;
  propertyTitle: string;
  propertyAddress: string;
  period: string; // e.g. "Septembre 2026"
  datePaid: string;
  baseRent: number;
  depositInstallment: number;
  serviceFee: number;
  managementFee?: number; // 10% frais de gestion plateforme LOC (à partir du 7ème mois)
  totalPaid: number;
  status: 'paid' | 'partial' | 'late';
  signatureToken: string;
}

export type ProfessionCategory = 
  | 'salarie' 
  | 'fonctionnaire' 
  | 'entrepreneur' 
  | 'commercant' 
  | 'independant' 
  | 'etudiant' 
  | 'autre';

export interface GuarantorDetails {
  lastName: string;
  firstName: string;
  phone: string;
  profession?: string;
  guaranteedAmount: number; // Montant garanti en FCFA
  idCardUploaded?: boolean;
}

export interface AttachedDocFile {
  id: string;
  name: string;
  size: string;
  type: string;
  category: 'id' | 'payslips' | 'bank' | 'contract' | 'other';
  dataUrl?: string;
}

export interface TenantApplication {
  id: string;
  propertyId: string;
  propertyTitle: string;
  propertyAddress: string;
  landlordId?: string;
  monthlyRent: number;
  depositAmount: number;
  tenantId: string;
  tenantName: string;
  tenantPhone: string;
  tenantEmail: string;
  tenantProfession: string;
  professionCategory?: ProfessionCategory;
  companyName?: string;
  monthlyIncome: number;
  employmentType: 'cdi' | 'cdd' | 'fonctionnaire' | 'entrepreneur' | 'independant' | 'etudiant' | 'autre';
  hasGuarantor: boolean;
  guarantorDetails?: GuarantorDetails;
  guarantorName?: string;
  guarantorPhone?: string;
  guaranteedAmount?: number;
  kycScore: number; // 0 to 100
  riskLevel: 'faible' | 'modéré' | 'élevé';
  status: 'pending' | 'approved' | 'rejected' | 'lease_signed' | 'cancelled';
  cancellationReason?: string;
  rejectionReason?: string;
  rejectionReasons?: string[]; // Causes du rejet sélectionnées par l'admin
  rejectionDetails?: string;
  attachedFiles?: AttachedDocFile[];
  alternativePropertyIds?: string[];
  appliedAt: string;
  applicationOption?: 'ker_financing' | 'classic_direct'; // 'ker_financing' (Micro-Caution) ou 'classic_direct' (Paiement Classique sans LOC)
  preferredVisitDate?: string; // Date souhaitée pour la visite physique du bien (pour le mode classique)
  currentStep?: number;
  grantingStep?: 1 | 2 | 3; // 1: Solvabilité & Scoring, 2: Visite & Bail, 3: Garantie & Clés
  handoverDate?: string; // Date de remise des clés (ex: "2026-09-05")
  rentDueDateDay?: number; // Jour d'échéance mensuelle réglé auto (ex: 5)
  kycDocuments: {
    idCard: boolean; // CNI ou Passeport
    payslip?: boolean; // 1 fiche de paie récente (Salarié / Fonctionnaire)
    workContract?: boolean; // Contrat de travail / Attestation (Salarié / Fonctionnaire)
    rccmNinea?: boolean; // Registre de commerce & NINEA (Entrepreneur)
    bankStatements?: boolean; // 3 derniers relevés bancaires ou flux Wave/OM pro
    activityProof?: boolean; // Justificatif d'activité (Commerçant / Indépendant)
    studentCertificate?: boolean; // Certificat de scolarité (Étudiant)
    guarantorIdDoc?: boolean; // Pièce d'identité du garant
    payslips?: boolean; // Compatibilité ascendante
    workCertificate?: boolean; // Compatibilité ascendante
  };
}

export interface LeaseContract {
  id: string;
  applicationId: string;
  propertyTitle: string;
  propertyAddress: string;
  tenantName: string;
  landlordName: string;
  monthlyRent: number;
  depositTotal: number;
  depositFinancedByKer: boolean;
  startDate: string;
  endDate: string;
  tenantSigned: boolean;
  tenantSignedAt?: string;
  landlordSigned: boolean;
  landlordSignedAt?: string;
  contractPdfUrl?: string;
  status: 'draft' | 'awaiting_signatures' | 'active' | 'terminated';
}

export interface ArrearsCase {
  id: string;
  tenantName: string;
  tenantPhone: string;
  propertyTitle: string;
  dueAmount: number;
  daysLate: number;
  lastReminderDate: string;
  remindersCount: number;
  status: 'relance_douce' | 'relance_ferme' | 'garantie_activee' | 'regularise' | 'contentieux_huissier' | 'echeancier_accorde';
  landlordName?: string;
  landlordPhone?: string;
  phase?: 1 | 2 | 3 | 4;
  notes?: string;
  installmentsPlan?: {
    totalTranches: number;
    amountPerTranche: number;
    paidTranches: number;
  };
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: Role;
  text: string;
  timestamp: string;
  isRead: boolean;
  appointmentInvite?: {
    appointmentId: string;
    propertyId: string;
    propertyTitle: string;
    propertyAddress?: string;
    date: string;
    timeSlot: string;
    location: string;
    purpose?: string;
    note?: string;
    isConfirmedByTenant?: boolean;
  };
  attachments?: {
    type: 'receipt' | 'lease' | 'id_doc' | 'image';
    title: string;
    url?: string;
  }[];
}

export interface ChatConversation {
  id: string;
  participantId: string;
  participantName: string;
  participantRole: Role;
  participantPhone: string;
  participantAvatar: string;
  participantTag: string;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  propertyTitle?: string;
  messages: ChatMessage[];
  priority?: 'normal' | 'urgent' | 'recouvrement';
  updatedAt?: number;
  createdAt?: number;
}

export interface SupportTicket {
  id: string;
  ticketNumber: string; // e.g. TCK-2026-001
  userId?: string;
  userName: string;
  userPhone?: string;
  userEmail?: string;
  userRole: Role | 'guest';
  subject: string;
  propertyTitle?: string;
  propertyRef?: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  priority: 'normal' | 'urgent' | 'high';
  createdAt: string;
  updatedAt: string;
  lastMessage: string;
  messages: ChatMessage[];
}

export interface LandlordPartner {
  id: string;
  name: string;
  companyName?: string;
  type: 'agence' | 'particulier' | 'sci';
  landlordCategory?: 'proprietaire_particulier' | 'courtier_agent' | 'sci';
  brokerLicenseNumber?: string;
  phone: string;
  email: string;
  avatarText: string;
  totalProperties: number;
  occupiedProperties: number;
  totalMonthlyVolume: number;
  commissionEarnedKer: number;
  payoutMethod: 'Wave Business' | 'Virement CBAO' | 'Virement BOA' | 'Orange Money';
  payoutAccountNumber: string;
  payoutCycle: string;
  verified: boolean;
  rating: number;
  memberSince: string;
  isManagedByKer?: boolean; // True si sous mandat de gestion déléguée LOC (imputation 3% de frais de gestion)
  status: 'active' | 'pending_verification' | 'paused';
  username?: string; // Nom d'utilisateur / identifiant créé par l'admin
  password?: string; // Mot de passe d'accès défini par l'admin
  loginAccessCreated?: boolean; // Indique si l'accès personnel est actif
}

export type KerProfitPillar = 
  | 'frais_dossier' 
  | 'commission_courtage' 
  | 'gestion_locataire' 
  | 'gestion_proprietaire';

export interface AccountingLedgerEntry {
  id: string;
  entryNumber: string; // Ex: ECR-2026-09-014
  date: string;
  period: string; // Ex: "Septembre 2026"
  pillar: KerProfitPillar | 'reversement_bailleur' | 'versement_courtier_caution' | 'caution_encaissee';
  thirdPartyType: 'locataire' | 'proprietaire_gere' | 'proprietaire_direct' | 'courtier';
  thirdPartyName: string;
  propertyTitle: string;
  propertyRef: string;
  grossAmount: number; // Montant brut concerné
  debit: number; // Flux entrant Trésorerie
  credit: number; // Flux sortant (Reversement)
  kerProfit: number; // Bénéfice LOC capté
  kerProfitCategory: 'Frais de Dossiers' | 'Commission Frais de Courtage' | 'Frais de Gestion Plateforme Locataire' | 'Frais de Gestion Propriétaire (3%)' | 'Sans Marge Directe';
  ruleApplied: string; // Explication comptable
  paymentMethod: string;
  status: 'comptabilise' | 'lettre' | 'en_attente';
}

export interface KerRevenueDispatch {
  totalRevenue: number;
  fraisDossiers: {
    amount: number;
    percentage: number;
    count: number;
    description: string;
  };
  commissionCourtage: {
    amount: number;
    percentage: number;
    count: number;
    description: string;
  };
  gestionPlateformeLocataire: {
    amount: number;
    percentage: number;
    count: number;
    description: string;
  };
  gestionProprietaire: {
    amount: number;
    percentage: number;
    count: number;
    description: string;
    delegatedVolume: number;
    directVolume: number;
  };
}

export interface AdminUser {
  id: string;
  username: string; // e.g. "Wiki"
  password?: string; // e.g. "Loc@111"
  fullName: string;
  email: string;
  roleLabel: string;
  isSuperAdmin: boolean;
  department: 'Direction Générale' | 'Analyse Risque & Scoring' | 'Gestion des Baux' | 'Recouvrement & Contentieux' | 'Support & Onboarding' | 'Département Risque & Juridique' | 'Pôle Financier & Trésorerie';
  permissions: string[];
  createdAt: string;
  status: 'active' | 'inactive';
  lastLogin?: string;
}

export interface RoomPhotoConfig {
  roomId: string;
  roomName: string;
  roomType: 'salon' | 'chambre' | 'cuisine' | 'salle_de_bain' | 'facade' | 'balcon';
  imageUrl: string;
  isCover?: boolean;
}

export interface AppNotification {
  id: string;
  userId: string; // Target user ID or 'all'
  role: Role | 'all'; // Target role or 'all'
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'alert';
  category: 'dossier' | 'property' | 'feature' | 'payment_reminder' | 'payment_delay' | 'penalty' | 'visite';
  createdAt: string;
  isRead: boolean;
  actionUrl?: string;
}

export interface SignalementItem {
  id: string;
  authorId: string;
  authorName: string;
  authorRole: 'tenant' | 'landlord' | 'visitor';
  authorPhone?: string;
  propertyId?: string;
  propertyTitle?: string;
  title: string;
  description: string;
  category: 'plomberie' | 'electricite' | 'serrurerie' | 'litige_bail' | 'annonce_suspecte' | 'autre';
  priority: 'basse' | 'moyenne' | 'haute' | 'urgente';
  status: 'nouveau' | 'en_cours' | 'resolu' | 'rejete';
  createdAt: string;
  adminNotes?: string;
  assignedArtisan?: string;
}

