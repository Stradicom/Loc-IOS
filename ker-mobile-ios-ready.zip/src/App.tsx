import React, { useState, useEffect } from 'react';
import { Role, Property, RentReceipt, MicroPayment, TenantApplication, PaymentMethod, ArrearsCase, UserProfile, LandlordPartner, ChatConversation, ChatMessage, AdminUser, VisitAppointment, BrokerAccreditationRequest, AppNotification, SignalementItem } from './types';
import { 
  initialProperties, 
  initialTenantUser, 
  initialMicroPayments, 
  initialReceipts, 
  initialApplications, 
  initialArrears,
  initialLandlords,
  initialConversations,
  mockUserProfiles,
  initialAdminUsers,
  initialVisitAppointments,
  initialNotifications,
  initialSignalements
} from './data/mockData';
import { testConnection } from './lib/firebase';
import { 
  fetchPropertiesFromFirestore, 
  savePropertyToFirestore, 
  updatePropertyAvailabilityInFirestore, 
  deletePropertyFromFirestore,
  saveApplicationToFirestore, 
  updateApplicationStatusInFirestore, 
  saveAppointmentToFirestore, 
  updateAppointmentStatusInFirestore,
  fetchUsersFromFirestore,
  saveUserProfileToFirestore,
  savePaymentToFirestore,
  saveReceiptToFirestore,
  saveLandlordToFirestore,
  saveConversationToFirestore,
  saveArrearsToFirestore,
  updateArrearsStatusInFirestore,
  subscribeCollection,
  purgeAllDemoDataFromFirestore,
  logoutUser,
  saveNotificationToFirestore,
  markNotificationAsReadInFirestore,
  markAllNotificationsAsReadInFirestore,
  saveSignalementToFirestore,
  updateSignalementInFirestore
} from './services/firebaseService';
import { Header } from './components/common/Header';
import { BottomNav } from './components/common/BottomNav';
import { NotificationCenter } from './components/common/NotificationCenter';
import { MobileMoneyModal } from './components/common/MobileMoneyModal';
import { PropertyList } from './components/tenant/PropertyList';
import { PropertyDetailModal } from './components/tenant/PropertyDetailModal';
import { TenantDashboard } from './components/tenant/TenantDashboard';
import { CalculatorModal } from './components/tenant/CalculatorModal';
import { KYCModal } from './components/tenant/KYCModal';
import { ReceiptModal } from './components/tenant/ReceiptModal';
import { ApplyPropertyModal } from './components/tenant/ApplyPropertyModal';
import { ApplicationTracker } from './components/tenant/ApplicationTracker';
import { LandlordDashboard } from './components/landlord/LandlordDashboard';
import { NewPropertyModal } from './components/landlord/NewPropertyModal';
import { LeaseModal } from './components/landlord/LeaseModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { ApproveAppointmentModal } from './components/admin/ApproveAppointmentModal';
import { AdminAuthGate } from './components/admin/AdminAuthGate';
import { AuthModal } from './components/auth/AuthModal';
import { ProfileModal } from './components/common/ProfileModal';
import { LandingPage } from './components/home/LandingPage';
import { FloatingChatWidget } from './components/common/FloatingChatWidget';
import { Sparkles, Building2, FileCheck, UserCheck, ShieldCheck, ArrowLeft, LogIn, ClipboardList } from 'lucide-react';
import confetti from 'canvas-confetti';
import { getCurrentPeriod } from './utils/finance';

// LocalStorage Persistence Helpers with non-destructive preservation
const LOC_DATA_VERSION = 'v2026.11.13_loc_brand_v1';
try {
  const storedVer = localStorage.getItem('loc_data_version');
  if (storedVer !== LOC_DATA_VERSION) {
    localStorage.clear();
    localStorage.setItem('loc_data_version', LOC_DATA_VERSION);
  }
} catch {
  // ignore localStorage errors
}

function getStored<T>(key: string, fallback: T): T {
  try {
    let item = localStorage.getItem(key);
    if (item === null && key.startsWith('loc_')) {
      const legacyKey = key.replace(/^loc_/, 'ker_');
      item = localStorage.getItem(legacyKey);
    }
    if (item === null) return fallback;
    const parsed = JSON.parse(item) as T;
    // Preservation check: if fallback is a non-empty array and parsed is an array, ensure no baseline items are deleted
    if (Array.isArray(fallback) && fallback.length > 0 && Array.isArray(parsed)) {
      if (parsed.length === 0) return fallback;
      // Preserve both parsed user-added items and any initial baseline items
      const parsedIds = new Set((parsed as any[]).map(x => (x && typeof x === 'object' ? x.id : null)).filter(Boolean));
      const missingFromFallback = (fallback as any[]).filter(x => x && typeof x === 'object' && x.id && !parsedIds.has(x.id));
      return [...parsed, ...missingFromFallback] as unknown as T;
    }
    return parsed;
  } catch {
    return fallback;
  }
}

function setStored<T>(key: string, value: T): void {
  try {
    if (value === null || value === undefined) {
      localStorage.removeItem(key);
    } else {
      localStorage.setItem(key, JSON.stringify(value));
    }
  } catch (e) {
    console.warn(`Error storing ${key}:`, e);
  }
}

export default function App() {
  // Navigation & Authentication State (persisted across refresh)
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => getStored('loc_current_user', null));
  const [registeredUsers, setRegisteredUsers] = useState<UserProfile[]>(() => getStored('loc_registered_users', Object.values(mockUserProfiles)));
  const [activeRole, setActiveRole] = useState<Role>(() => getStored('loc_active_role', 'tenant'));
  const [publicView, setPublicView] = useState<'home' | 'catalog'>(() => getStored('loc_public_view', 'home'));
  const [tenantTab, setTenantTab] = useState<string>(() => getStored('loc_tenant_tab', 'dashboard')); // 'dashboard' | 'explore' | 'kyc'
  const [landlordTab, setLandlordTab] = useState<any>(() => getStored('loc_landlord_tab', 'revenues'));
  const [adminTab, setAdminTab] = useState<any>(() => getStored('loc_admin_tab', 'applications'));
  const [selectedAdminConversationId, setSelectedAdminConversationId] = useState<string | null>(null);
  const [isAuthOpen, setIsAuthOpen] = useState<boolean>(false);
  const [authInitialRole, setAuthInitialRole] = useState<Role>('tenant');

  // Admin Security State
  const [adminUsers, setAdminUsers] = useState<AdminUser[]>(() => getStored('loc_admin_users', initialAdminUsers));
  const [currentAdmin, setCurrentAdmin] = useState<AdminUser | null>(() => getStored('loc_current_admin', null));

  // Application Data State - All preloaded with initial recorded platform data
  const [properties, setProperties] = useState<Property[]>(() => getStored('loc_properties', initialProperties));
  const [applications, setApplications] = useState<TenantApplication[]>(() => getStored('loc_applications', initialApplications));
  const [microPayments, setMicroPayments] = useState<MicroPayment[]>(() => getStored('loc_micro_payments', initialMicroPayments));
  const [receipts, setReceipts] = useState<RentReceipt[]>(() => getStored('loc_receipts', initialReceipts));
  const [arrears, setArrears] = useState<ArrearsCase[]>(() => getStored('loc_arrears', initialArrears));
  const [landlords, setLandlords] = useState<LandlordPartner[]>(() => getStored('loc_landlords', initialLandlords));
  const [conversations, setConversations] = useState<ChatConversation[]>(() => getStored('loc_conversations', initialConversations));
  const [appointments, setAppointments] = useState<VisitAppointment[]>(() => getStored('loc_appointments', initialVisitAppointments));
  const [signalements, setSignalements] = useState<SignalementItem[]>(() => getStored('loc_signalements', initialSignalements));
  const [reserveFundAmount, setReserveFundAmount] = useState<number>(() => getStored('loc_reserve_fund', 0));
  const [notifications, setNotifications] = useState<AppNotification[]>(() => getStored('loc_notifications', initialNotifications));

  // Sync state changes with localStorage
  useEffect(() => { setStored('loc_current_user', currentUser); }, [currentUser]);
  useEffect(() => { setStored('loc_registered_users', registeredUsers); }, [registeredUsers]);
  useEffect(() => { setStored('loc_active_role', activeRole); }, [activeRole]);
  useEffect(() => { setStored('loc_public_view', publicView); }, [publicView]);
  useEffect(() => { setStored('loc_tenant_tab', tenantTab); }, [tenantTab]);
  useEffect(() => { setStored('loc_landlord_tab', landlordTab); }, [landlordTab]);
  useEffect(() => { setStored('loc_admin_tab', adminTab); }, [adminTab]);
  useEffect(() => { setStored('loc_admin_users', adminUsers); }, [adminUsers]);
  useEffect(() => { setStored('loc_current_admin', currentAdmin); }, [currentAdmin]);
  useEffect(() => { setStored('loc_properties', properties); }, [properties]);
  useEffect(() => { setStored('loc_applications', applications); }, [applications]);
  useEffect(() => { setStored('loc_micro_payments', microPayments); }, [microPayments]);
  useEffect(() => { setStored('loc_receipts', receipts); }, [receipts]);
  useEffect(() => { setStored('loc_arrears', arrears); }, [arrears]);
  useEffect(() => { setStored('loc_landlords', landlords); }, [landlords]);
  useEffect(() => { setStored('loc_conversations', conversations); }, [conversations]);
  useEffect(() => { setStored('loc_appointments', appointments); }, [appointments]);
  useEffect(() => { setStored('loc_signalements', signalements); }, [signalements]);
  useEffect(() => { setStored('loc_reserve_fund', reserveFundAmount); }, [reserveFundAmount]);
  useEffect(() => { setStored('loc_notifications', notifications); }, [notifications]);

  const handleUpdateSignalement = (updatedSig: SignalementItem) => {
    setSignalements((prev) => prev.map((s) => (s.id === updatedSig.id ? updatedSig : s)));
    updateSignalementInFirestore(updatedSig.id, updatedSig).catch((e) => console.warn('Firestore update sig error:', e));

    // Send notification to tenant if updated
    if (updatedSig.authorId) {
      const notif: AppNotification = {
        id: `notif-sig-${Date.now()}`,
        userId: updatedSig.authorId,
        role: 'tenant',
        title: `Mise à jour signalement : ${updatedSig.title}`,
        message: `Votre signalement a été mis à jour. Statut : ${updatedSig.status === 'resolu' ? 'Résolu' : updatedSig.status === 'en_cours' ? 'En cours d\'intervention' : updatedSig.status}${updatedSig.assignedArtisan ? ` • Artisan : ${updatedSig.assignedArtisan}` : ''}.`,
        type: updatedSig.status === 'resolu' ? 'success' : 'info',
        category: 'property',
        createdAt: new Date().toISOString(),
        isRead: false,
      };
      setNotifications((prev) => [notif, ...prev]);
      saveNotificationToFirestore(notif).catch((e) => console.warn('Firestore notif error:', e));
    }
  };

  const handleAddSignalement = (newSig: SignalementItem) => {
    setSignalements((prev) => [newSig, ...prev]);
    saveSignalementToFirestore(newSig).catch((e) => console.warn('Firestore save sig error:', e));

    // 1. Notification to admin
    const adminNotif: AppNotification = {
      id: `notif-admin-sig-${Date.now()}`,
      userId: 'all',
      role: 'admin',
      title: `⚠️ Nouveau Signalement : ${newSig.title}`,
      message: `${newSig.authorName} a signalé un problème (${newSig.category}) pour "${newSig.propertyTitle || 'un logement'}". Priorité : ${newSig.priority}.`,
      type: 'warning',
      category: 'property',
      createdAt: new Date().toISOString(),
      isRead: false,
    };
    setNotifications((prev) => [adminNotif, ...prev]);
    saveNotificationToFirestore(adminNotif).catch((e) => console.warn('Firestore notif error:', e));

    // 2. Notification to landlord if property is linked
    if (newSig.propertyId) {
      const prop = properties.find((p) => p.id === newSig.propertyId);
      if (prop && prop.landlordId) {
        const landlordNotif: AppNotification = {
          id: `notif-land-sig-${Date.now()}`,
          userId: prop.landlordId,
          role: 'landlord',
          title: `⚠️ Incident technique sur votre bien : ${newSig.title}`,
          message: `Un incident (${newSig.category}) a été signalé sur "${prop.title}". L'équipe LOC prend en charge le suivi et la réparation.`,
          type: 'info',
          category: 'property',
          createdAt: new Date().toISOString(),
          isRead: false,
        };
        setNotifications((prev) => [landlordNotif, ...prev]);
        saveNotificationToFirestore(landlordNotif).catch((e) => console.warn('Firestore notif error:', e));
      }
    }

    setSystemAlert({
      message: `Votre signalement "${newSig.title}" a été transmis avec succès aux équipes LOC et au bailleur !`,
      type: 'success',
    });
    setTimeout(() => setSystemAlert(null), 4000);
  };

  // Tenant Live Financial State (Septembre 2026 : loyer en cours de fractionnement, non soldé)
  const [tenantKYCScore, setTenantKYCScore] = useState<number>(() => getStored('loc_kyc_score', initialTenantUser.kycScore || 88));
  const [paidThisMonth, setPaidThisMonth] = useState<number>(() => getStored('loc_paid_this_month', initialTenantUser.currentMonthPaidAmount || 70000));
  const [totalDueThisMonth, setTotalDueThisMonth] = useState<number>(() => getStored('loc_total_due_this_month', initialTenantUser.currentMonthTotalDue || 133333));
  const [depositMonthsPaid, setDepositMonthsPaid] = useState<number>(() => getStored('loc_deposit_months_paid', initialTenantUser.depositInstallmentsPaidMonths || 4));
  const [paymentPresetAmount, setPaymentPresetAmount] = useState<number | undefined>(undefined);

  useEffect(() => { setStored('loc_paid_this_month', paidThisMonth); }, [paidThisMonth]);
  useEffect(() => { setStored('loc_total_due_this_month', totalDueThisMonth); }, [totalDueThisMonth]);
  useEffect(() => { setStored('loc_deposit_months_paid', depositMonthsPaid); }, [depositMonthsPaid]);

  // Helper to open payment modal with an optional predefined tranche amount
  const handleOpenPaymentModal = (presetAmount?: number) => {
    setPaymentPresetAmount(presetAmount);
    setIsPaymentModalOpen(true);
  };

  // Active Selected Property / Modals
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [propertyToApply, setPropertyToApply] = useState<Property | null>(null);
  const [isApplyModalOpen, setIsApplyModalOpen] = useState<boolean>(false);
  const [isCalculatorOpen, setIsCalculatorOpen] = useState<boolean>(false);
  const [isKYCOpen, setIsKYCOpen] = useState<boolean>(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState<boolean>(false);
  const [selectedReceipt, setSelectedReceipt] = useState<RentReceipt | null>(null);
  const [isNotifCenterOpen, setIsNotifCenterOpen] = useState<boolean>(false);
  const [isNewPropertyModalOpen, setIsNewPropertyModalOpen] = useState<boolean>(false);
  const [editingProperty, setEditingProperty] = useState<Property | null>(null);
  const [leaseApplicationToSign, setLeaseApplicationToSign] = useState<TenantApplication | null>(null);
  const [appToApproveWithAppointment, setAppToApproveWithAppointment] = useState<TenantApplication | null>(null);

  const handleSaveProfile = async (updatedProfile: UserProfile) => {
    setCurrentUser(updatedProfile);
    setRegisteredUsers(prev => prev.map(u => u.id === updatedProfile.id ? updatedProfile : u));
    try {
      await saveUserProfileToFirestore(updatedProfile);
    } catch (err) {
      console.warn('Could not save user profile to firestore:', err);
    }
  };

  // Initialize Firebase connection and subscribe to real-time updates from Firestore without overwriting existing data
  useEffect(() => {
    testConnection();

    const unsubProps = subscribeCollection<Property>('properties', (data) => setProperties(data), initialProperties);
    const unsubApps = subscribeCollection<TenantApplication>('applications', (data) => setApplications(data), initialApplications);
    const unsubAppts = subscribeCollection<VisitAppointment>('appointments', (data) => setAppointments(data), initialVisitAppointments);
    const unsubUsers = subscribeCollection<UserProfile>('users', (data) => setRegisteredUsers(data), Object.values(mockUserProfiles));
    const unsubPayments = subscribeCollection<MicroPayment>('payments', (data) => setMicroPayments(data), initialMicroPayments);
    const unsubReceipts = subscribeCollection<RentReceipt>('receipts', (data) => setReceipts(data), initialReceipts);
    const unsubLandlords = subscribeCollection<LandlordPartner>('landlords', (data) => setLandlords(data), initialLandlords);
    const unsubConvs = subscribeCollection<ChatConversation>('conversations', (data) => setConversations(data), initialConversations);
    const unsubArrears = subscribeCollection<ArrearsCase>('arrears', (data) => setArrears(data), initialArrears);
    const unsubNotifs = subscribeCollection<AppNotification>('notifications', (data) => setNotifications(data), initialNotifications);
    const unsubSignalements = subscribeCollection<SignalementItem>('signalements', (data) => setSignalements(data), initialSignalements);

    return () => {
      unsubProps();
      unsubApps();
      unsubAppts();
      unsubUsers();
      unsubPayments();
      unsubReceipts();
      unsubLandlords();
      unsubConvs();
      unsubArrears();
      unsubNotifs();
      unsubSignalements();
    };
  }, []);

  // System notification banner
  const [systemAlert, setSystemAlert] = useState<{ message: string; type: 'success' | 'info' } | null>(null);

  // Current rented property for the demo tenant
  const currentRentedProperty = properties.find(p => p.id === initialTenantUser.currentRentPropertyId) || properties[4] || properties[0] || initialProperties[0];

  // Handler for Role change in authenticated mode
  const handleRoleChange = (newRole: Role) => {
    setActiveRole(newRole);
    setCurrentUser(mockUserProfiles[newRole]);
    if (newRole === 'tenant') setTenantTab('dashboard');
    if (newRole === 'admin') {
      const wikiAdmin = adminUsers.find(a => a.username === 'Wiki') || adminUsers[0];
      if (wikiAdmin) {
        setCurrentAdmin(wikiAdmin);
      }
    }
  };

  // Open Auth Modal for a specific role
  const handleOpenAuth = (role?: Role) => {
    if (role) setAuthInitialRole(role);
    setIsAuthOpen(true);
  };

  // Handler for User Registration
  const handleRegisterUser = (newUser: UserProfile) => {
    setRegisteredUsers((prev) => [newUser, ...prev.filter(u => u.id !== newUser.id)]);
    saveUserProfileToFirestore(newUser).catch(err => console.warn('Firestore register user error:', err));
  };

  // Handler for Login Success
  const handleLoginSuccess = (profile: UserProfile) => {
    setActiveRole(profile.role);
    setCurrentUser(profile);
    saveUserProfileToFirestore(profile).catch(err => console.warn('Firestore login user save error:', err));

    if (profile.role === 'admin') {
      const wikiAdmin = adminUsers.find(a => a.username === 'Wiki') || adminUsers[0];
      if (wikiAdmin) {
        setCurrentAdmin(wikiAdmin);
      }
    }

    // If new user: Reset counters to 0 and redirect tenant to explore section!
    if (profile.isNewUser) {
      if (profile.role === 'tenant') {
        setPaidThisMonth(0);
        setTotalDueThisMonth(0);
        setDepositMonthsPaid(0);
        setMicroPayments([]);
        setReceipts([]);
        setTenantTab('explore'); // Redirection vers Explorer !
      } else if (profile.role === 'landlord') {
        // New landlord gets clean zero-state
      }
    } else {
      if (profile.role === 'tenant') setTenantTab('dashboard');
    }

    try {
      confetti({
        particleCount: 50,
        spread: 50,
      });
    } catch {}

    setSystemAlert({
      message: 'Connecté',
      type: 'success',
    });

    setTimeout(() => {
      setSystemAlert(null);
    }, 3000);
  };

  // Handler for Profile Update
  const handleUpdateProfile = (updated: UserProfile) => {
    setCurrentUser(updated);
    setRegisteredUsers((prev) => prev.map(u => u.id === updated.id ? updated : u));
    saveUserProfileToFirestore(updated).catch(err => console.warn('Firestore profile update error:', err));
    setSystemAlert({
      message: 'Profil et coordonnées de paiement (Wave/OM/Banque) mis à jour avec succès !',
      type: 'success',
    });
    setTimeout(() => setSystemAlert(null), 4000);
  };

  // Handler for Property Availability Toggle
  const handleTogglePropertyAvailability = (propertyId: string, isAvailable: boolean) => {
    setProperties((prev) =>
      prev.map(p => p.id === propertyId ? { ...p, isAvailable } : p)
    );
    updatePropertyAvailabilityInFirestore(propertyId, isAvailable).catch(err => console.warn('Firestore update error:', err));
    setSystemAlert({
      message: `Disponibilité du bien mise à jour : ${isAvailable ? '🟢 Disponible' : '🟠 Non disponible (Loué / Maintenance)'}`,
      type: 'info',
    });
    setTimeout(() => setSystemAlert(null), 3500);
  };

  // Handler for Visit Appointments
  const handleConfirmAppointment = (appointmentId: string) => {
    setAppointments((prev) =>
      prev.map(a => a.id === appointmentId ? { ...a, status: 'confirmed' as const } : a)
    );
    updateAppointmentStatusInFirestore(appointmentId, 'confirmed').catch(err => console.warn('Firestore update error:', err));
    setSystemAlert({
      message: 'Rendez-vous de visite confirmé ! Une notification a été envoyée au candidat.',
      type: 'success',
    });
    setTimeout(() => setSystemAlert(null), 3500);
  };

  const handleCancelAppointment = (appointmentId: string) => {
    setAppointments((prev) =>
      prev.map(a => a.id === appointmentId ? { ...a, status: 'cancelled' as const } : a)
    );
    updateAppointmentStatusInFirestore(appointmentId, 'cancelled').catch(err => console.warn('Firestore update error:', err));
    setSystemAlert({
      message: 'Rendez-vous de visite décliné.',
      type: 'info',
    });
    setTimeout(() => setSystemAlert(null), 3500);
  };

  const handleAddAppointment = (newAppt: VisitAppointment) => {
    setAppointments((prev) => [newAppt, ...prev.filter(a => a.id !== newAppt.id)]);
    saveAppointmentToFirestore(newAppt).catch(err => console.warn('Firestore save error:', err));
    setSystemAlert({
      message: `Rendez-vous de visite programmé avec ${newAppt.tenantName} pour le ${newAppt.date} (${newAppt.timeSlot}) !`,
      type: 'success',
    });
    setTimeout(() => setSystemAlert(null), 4000);
  };

  // Handler for Landlord Chat Message
  const handleSendLandlordMessage = (conversationId: string, text: string) => {
    const targetConv = conversations.find(c => c.id === conversationId);
    if (targetConv) {
      const newMsg = {
        id: `msg-${Date.now()}`,
        senderId: currentUser?.id || 'landlord-1',
        senderName: currentUser?.fullName || 'Mamadou Diop',
        senderRole: 'landlord' as const,
        text,
        timestamp: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
        isRead: true,
      };
      const updatedConv = {
        ...targetConv,
        lastMessage: text,
        lastMessageTime: newMsg.timestamp,
        messages: [...targetConv.messages, newMsg],
      };
      setConversations((prev) => prev.map((c) => c.id === conversationId ? updatedConv : c));
      saveConversationToFirestore(updatedConv).catch(err => console.warn('Firestore conv save error:', err));
    }
  };

  // Handler for Tenant Chat Message
  const handleSendTenantMessage = (conversationId: string, text: string) => {
    const targetConv = conversations.find(c => c.id === conversationId || c.participantId === currentUser?.id);
    if (targetConv) {
      const newMsg = {
        id: `msg-${Date.now()}`,
        senderId: currentUser?.id || 'tenant-1',
        senderName: currentUser?.fullName || 'Locataire',
        senderRole: 'tenant' as const,
        text,
        timestamp: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
        isRead: false,
      };
      const updatedConv = {
        ...targetConv,
        lastMessage: text,
        lastMessageTime: newMsg.timestamp,
        messages: [...targetConv.messages, newMsg],
      };
      setConversations((prev) => prev.map((c) => c.id === targetConv.id ? updatedConv : c));
      saveConversationToFirestore(updatedConv).catch(err => console.warn('Firestore conv save error:', err));
    } else {
      const newMsg = {
        id: `msg-${Date.now()}`,
        senderId: currentUser?.id || 'tenant-1',
        senderName: currentUser?.fullName || 'Locataire',
        senderRole: 'tenant' as const,
        text,
        timestamp: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
        isRead: false,
      };
      const newConv: ChatConversation = {
        id: conversationId,
        participantId: currentUser?.id || 'tenant-1',
        participantName: currentUser?.fullName || 'Locataire',
        participantRole: 'tenant' as const,
        participantPhone: currentUser?.phone || '77 123 45 67',
        participantAvatar: (currentUser?.fullName || 'L').split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2),
        participantTag: 'Locataire',
        lastMessage: text,
        lastMessageTime: newMsg.timestamp,
        messages: [newMsg],
        unreadCount: 0,
      };
      setConversations((prev) => [newConv, ...prev]);
      saveConversationToFirestore(newConv).catch(err => console.warn('Firestore conv save error:', err));
    }
  };

  // Handler for Lease Signature Notification
  const handleSendLeaseNotification = (applicationId: string, tenantName: string) => {
    setSystemAlert({
      message: `Notification de signature de bail envoyée avec succès par SMS & WhatsApp à ${tenantName} !`,
      type: 'success',
    });
    setTimeout(() => setSystemAlert(null), 4000);
  };

  // Handler for Broker Accreditation
  const handleSubmitAccreditation = (req: BrokerAccreditationRequest) => {
    if (currentUser) {
      const updated: UserProfile = {
        ...currentUser,
        isAccreditedAgency: true,
        brokerLicenseNumber: req.licenseNumber,
        companyName: req.agencyName,
      };
      setCurrentUser(updated);
      saveUserProfileToFirestore(updated).catch(err => console.warn('Firestore profile save error:', err));
    }
    setSystemAlert({
      message: 'Demande d\'accréditation transmise au pôle juridique LOC. Badge Agence Agréée activé !',
      type: 'success',
    });
    setTimeout(() => setSystemAlert(null), 5000);
  };

  // Handler for Payout Request
  const handleTriggerPayoutRequest = (amount: number) => {
    try {
      confetti({
        particleCount: 60,
        spread: 60,
      });
    } catch {}
    setSystemAlert({
      message: `Demande de virement de ${amount.toLocaleString('fr-FR')} FCFA validée ! Virement instantané transmis vers votre compte ${currentUser?.preferredPayoutMethod || 'Wave'}.`,
      type: 'success',
    });
    setTimeout(() => setSystemAlert(null), 5000);
  };


  // Handler for Logout
  const handleLogout = () => {
    logoutUser().catch(err => console.warn('Firebase logout warning:', err));
    setCurrentUser(null);
    setCurrentAdmin(null);
    setPublicView('home');
    setSystemAlert({
      message: 'Vous êtes déconnecté. À très bientôt sur LOC !',
      type: 'info',
    });
    setTimeout(() => {
      setSystemAlert(null);
    }, 3000);
  };

  // Handler: Micro-Payment by tranche
  const handlePaymentSuccess = (amount: number, method: PaymentMethod, reference: string) => {
    const currentPeriodName = getCurrentPeriod();
    const currentYear = new Date().getFullYear();
    const currentMonthNum = String(new Date().getMonth() + 1).padStart(2, '0');

    const newPayment: MicroPayment = {
      id: `pay-${Date.now()}`,
      date: new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }),
      amount,
      method,
      reference,
      status: 'completed',
      forMonth: currentPeriodName,
      notes: `Versement de tranche ${method.toUpperCase()}`,
    };

    setMicroPayments([newPayment, ...microPayments]);
    savePaymentToFirestore(newPayment).catch(err => console.warn('Firestore payment save error:', err));
    const newPaidTotal = paidThisMonth + amount;
    setPaidThisMonth(newPaidTotal);

    // 1. Send automated payment confirmation notification to tenant
    const paymentNotif: AppNotification = {
      id: `notif-pay-${Date.now()}`,
      userId: currentUser?.id || 'tenant-demo',
      role: 'tenant',
      title: '💸 Micro-versement enregistré !',
      message: `Votre micro-versement de ${amount.toLocaleString('fr-FR')} FCFA via ${method.toUpperCase()} a été reçu avec succès. Progression loyer : ${Math.round((newPaidTotal / totalDueThisMonth) * 100)}%.`,
      type: 'success',
      category: 'feature',
      createdAt: new Date().toISOString(),
      isRead: false
    };
    saveNotificationToFirestore(paymentNotif).catch(e => console.warn('Firestore payment notify error:', e));

    // 2. Send automated notification to the landlord partner
    if (currentRentedProperty) {
      const landlordPayNotif: AppNotification = {
        id: `notif-landlord-pay-${Date.now()}`,
        userId: currentRentedProperty.landlordId || 'landlord-1',
        role: 'landlord',
        title: '💰 Encaissement reçu !',
        message: `Le locataire de "${currentRentedProperty.title || 'Logement LOC'}" a versé ${amount.toLocaleString('fr-FR')} FCFA. Progression : ${Math.round((newPaidTotal / totalDueThisMonth) * 100)}%.`,
        type: 'info',
        category: 'feature',
        createdAt: new Date().toISOString(),
        isRead: false
      };
      saveNotificationToFirestore(landlordPayNotif).catch(e => console.warn('Firestore landlord pay notify error:', e));
    }

    // If fully paid, add an official receipt
    if (newPaidTotal >= totalDueThisMonth && currentRentedProperty) {
      const newRec: RentReceipt = {
        id: `rec-${currentMonthNum}-${currentYear}-${Date.now()}`,
        receiptNumber: `LOC-REC-${currentYear}-${currentMonthNum}-${Math.floor(1000 + Math.random() * 9000)}`,
        tenantName: currentUser?.fullName || 'Aïssatou Sow',
        landlordName: currentRentedProperty.landlordName || 'Bailleur LOC',
        propertyTitle: currentRentedProperty.title || 'Logement LOC',
        propertyAddress: currentRentedProperty.address || 'Dakar',
        period: currentPeriodName,
        datePaid: new Date().toISOString().split('T')[0],
        baseRent: currentRentedProperty.monthlyRent || 150000,
        depositInstallment: Math.round(((currentRentedProperty.monthlyRent || 150000) * 2) / 6),
        serviceFee: 0,
        totalPaid: totalDueThisMonth,
        status: 'paid',
        signatureToken: `SHA256-LOC-CERT-${Math.random().toString(36).substring(2, 12).toUpperCase()}`,
      };
      setReceipts([newRec, ...receipts]);
      saveReceiptToFirestore(newRec).catch(err => console.warn('Firestore receipt save error:', err));

      // 3. Send automated receipt generation notification
      const receiptNotif: AppNotification = {
        id: `notif-rec-${Date.now()}`,
        userId: currentUser?.id || 'tenant-demo',
        role: 'tenant',
        title: '🧾 Quittance de loyer disponible',
        message: `Félicitations ! Votre loyer de ${currentPeriodName} est entièrement soldé. Votre quittance de loyer certifiée LOC est disponible.`,
        type: 'success',
        category: 'dossier',
        createdAt: new Date().toISOString(),
        isRead: false
      };
      saveNotificationToFirestore(receiptNotif).catch(e => console.warn('Firestore receipt notify error:', e));
    }

    setSystemAlert({
      message: `Versement de ${amount.toLocaleString('fr-FR')} FCFA validé avec succès par ${method.toUpperCase()} !`,
      type: 'success',
    });

    setTimeout(() => {
      setSystemAlert(null);
    }, 4500);
  };

  // Handler: Tenant Applies for a property -> Opens ApplyPropertyModal with Solvency KYC & Guarantor
  const handleApplyProperty = (property: Property) => {
    if (!currentUser) {
      handleOpenAuth('tenant');
      setSystemAlert({
        message: 'Veuillez vous connecter ou créer votre compte locataire pour soumettre votre dossier LOC.',
        type: 'info',
      });
      return;
    }

    setPropertyToApply(property);
    setIsApplyModalOpen(true);
  };

  // Handler: Submit finalized dynamic solvency folder & application
  const handleSaveApplication = (appData: Partial<TenantApplication>) => {
    if (!currentUser || !propertyToApply) return;

    const chosenOption = appData.applicationOption || 'ker_financing';
    const isClassic = chosenOption === 'classic_direct';

    const newApp: TenantApplication = {
      id: `app-${Date.now()}`,
      propertyId: propertyToApply.id,
      propertyTitle: propertyToApply.title,
      propertyAddress: propertyToApply.address,
      monthlyRent: propertyToApply.monthlyRent,
      depositAmount: isClassic
        ? propertyToApply.monthlyRent * 3
        : (appData.depositAmount || propertyToApply.monthlyRent * (propertyToApply.depositMonths + propertyToApply.brokerFeeMonths)),
      applicationOption: chosenOption,
      preferredVisitDate: appData.preferredVisitDate,
      attachedFiles: appData.attachedFiles,
      tenantId: currentUser.id,
      tenantName: currentUser.fullName,
      tenantPhone: currentUser.phone,
      tenantEmail: currentUser.email,
      tenantProfession: appData.tenantProfession || currentUser.profession || 'Salarié',
      professionCategory: appData.professionCategory || 'salarie',
      companyName: appData.companyName || 'Dakar S.A.',
      monthlyIncome: appData.monthlyIncome || currentUser.monthlyIncome || 450000,
      employmentType: appData.employmentType || 'cdi',
      hasGuarantor: isClassic ? false : (appData.hasGuarantor ?? true),
      guarantorName: isClassic ? undefined : (appData.guarantorName || (appData.guarantorDetails ? `${appData.guarantorDetails.firstName} ${appData.guarantorDetails.lastName}` : 'Dr. Ousmane Sow')),
      guarantorPhone: isClassic ? undefined : (appData.guarantorPhone || appData.guarantorDetails?.phone || '+221 77 123 45 67'),
      guarantorDetails: isClassic ? undefined : appData.guarantorDetails,
      kycScore: isClassic ? 100 : (appData.kycScore || 90),
      riskLevel: isClassic ? 'faible' : (appData.riskLevel || 'faible'),
      status: 'pending',
      appliedAt: new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }),
      kycDocuments: appData.kycDocuments || {
        idCard: true,
        payslips: !isClassic,
        bankStatements: !isClassic,
        workCertificate: !isClassic,
      },
      currentStep: 1,
    };

    setTenantKYCScore(newApp.kycScore);
    setApplications((prev) => [newApp, ...prev.filter(a => a.id !== newApp.id)]);
    saveApplicationToFirestore(newApp).catch(err => console.warn('Firestore application save error:', err));
    
    // 1. Send automated notification to ADMIN for new application received
    const formulaLabel = isClassic ? 'Formule classique' : 'Formule Micro-caution';
    const adminAppNotif: AppNotification = {
      id: `notif-admin-app-${Date.now()}`,
      userId: 'admin',
      role: 'admin',
      title: `📋 Nouvelle candidature [${formulaLabel}] reçue !`,
      message: `Nouvelle candidature (${formulaLabel}) soumise par ${newApp.tenantName} (${newApp.tenantProfession || 'Locataire'}, ${newApp.monthlyIncome ? newApp.monthlyIncome.toLocaleString('fr-FR') + ' FCFA/mois' : ''}) pour "${newApp.propertyTitle}".`,
      type: 'info',
      category: 'dossier',
      createdAt: new Date().toISOString(),
      isRead: false,
    };
    setNotifications((prev) => [adminAppNotif, ...prev]);
    saveNotificationToFirestore(adminAppNotif).catch(e => console.warn('Firestore admin notify error:', e));

    // 2. Send automated notification to LANDLORD if property has landlordId
    if (propertyToApply.landlordId) {
      const landlordAppNotif: AppNotification = {
        id: `notif-landlord-app-${Date.now()}`,
        userId: propertyToApply.landlordId,
        role: 'landlord',
        title: `📄 Nouvelle candidature (${formulaLabel}) sur votre bien !`,
        message: `${newApp.tenantName} a déposé sa candidature (${formulaLabel}) pour "${propertyToApply.title}".`,
        type: 'info',
        category: 'dossier',
        createdAt: new Date().toISOString(),
        isRead: false,
      };
      setNotifications((prev) => [landlordAppNotif, ...prev]);
      saveNotificationToFirestore(landlordAppNotif).catch(e => console.warn('Firestore landlord notify error:', e));
    }

    // Automatically switch tenant to dashboard/suivi
    setTenantTab('dashboard');

    try {
      confetti({
        particleCount: 70,
        spread: 60,
      });
    } catch {}

    setSystemAlert({
      message: `🎉 Candidature pour "${propertyToApply.title}" soumise avec succès ! Score de solvabilité LOC : ${newApp.kycScore}/100. Suivi en temps réel activé.`,
      type: 'success',
    });

    setIsApplyModalOpen(false);
    setPropertyToApply(null);

    setTimeout(() => {
      setSystemAlert(null);
    }, 5000);
  };

  // Helper to send a chat message into a user's conversation (or create it if absent)
  const sendChatMessageToUser = (
    recipientId: string,
    recipientName: string,
    recipientRole: Role,
    recipientPhone: string,
    propertyTitle: string,
    text: string,
    appointmentInvite?: ChatMessage['appointmentInvite']
  ) => {
    const existingConv = conversations.find(
      (c) =>
        c.participantId === recipientId ||
        c.id === `conv-${recipientId}` ||
        (recipientRole === 'landlord' && (c.participantRole === 'landlord' || c.participantId === 'landlord-1')) ||
        (recipientRole === 'tenant' && c.participantRole === 'tenant' && c.participantId === recipientId)
    );

    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      senderId: 'admin-1',
      senderName: 'LOC Support & Risque',
      senderRole: 'admin',
      text,
      timestamp: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
      isRead: false,
      appointmentInvite,
    };

    if (existingConv) {
      const updatedConv: ChatConversation = {
        ...existingConv,
        lastMessage: text,
        lastMessageTime: newMsg.timestamp,
        unreadCount: (existingConv.unreadCount || 0) + 1,
        messages: [...existingConv.messages, newMsg],
      };
      setConversations((prev) => prev.map((c) => (c.id === existingConv.id ? updatedConv : c)));
      saveConversationToFirestore(updatedConv).catch((err) => console.warn('Firestore conv save error:', err));
    } else {
      const newConv: ChatConversation = {
        id: `conv-${recipientId}-${Date.now()}`,
        participantId: recipientId,
        participantName: recipientName,
        participantRole: recipientRole,
        participantPhone: recipientPhone || '+221 77 000 00 00',
        participantAvatar: currentUser?.avatarUrl || (recipientName || 'KC').split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2),
        participantTag: recipientRole === 'landlord' ? 'Bailleur Partenaire' : 'Candidat Locataire',
        propertyTitle,
        lastMessage: text,
        lastMessageTime: newMsg.timestamp,
        unreadCount: 1,
        messages: [newMsg],
      };
      setConversations((prev) => [newConv, ...prev]);
      saveConversationToFirestore(newConv).catch((err) => console.warn('Firestore conv save error:', err));
    }
  };

  // Handler: Cancel lease validation after visit if candidate's expectations were not met
  const handleCancelLeaseValidation = (appId: string) => {
    const app = applications.find(a => a.id === appId);
    if (!app) return;

    setApplications(prev => prev.map(a => a.id === appId ? { ...a, status: 'cancelled' } : a));
    setProperties(prev => prev.map(p => p.id === app.propertyId ? { ...p, availableStatus: 'disponible' } : p));

    const cancelNotif: AppNotification = {
      id: `notif-cancel-lease-${Date.now()}`,
      userId: app.tenantId,
      role: 'tenant',
      title: 'Validation de bail annulée après visite',
      message: `Suite à votre visite du bien "${app.propertyTitle}", la validation du bail a été annulée car le logement ne correspondait pas totalement à vos attentes. Votre dossier LOC reste 100% actif et prioritaire pour d'autres logements.`,
      type: 'warning',
      category: 'dossier',
      createdAt: 'À l\'instant',
      isRead: false
    };
    setNotifications(prev => [cancelNotif, ...prev]);

    setSystemAlert({
      message: `Validation du bail pour "${app.tenantName}" annulée. Le logement a été remis en statut "Disponible".`,
      type: 'info'
    });
    setTimeout(() => setSystemAlert(null), 5000);
  };

  // Handler: Direct solvency score adjustment
  const handleUpdateApplicationScore = (appId: string, newScore: number) => {
    setApplications(prev => prev.map(a => a.id === appId ? { ...a, kycScore: newScore } : a));
    setSystemAlert({
      message: `Score de solvabilité mis à jour (${newScore}/100).`,
      type: 'success'
    });
    setTimeout(() => setSystemAlert(null), 3000);
  };

  // Handler: Approves application (Admin / Landlord)
  const handleApproveApplication = (appId: string) => {
    const app = applications.find((a) => a.id === appId);
    if (!app) return;

    // Use default schedule if direct approval
    const defaultAppointment = {
      date: 'Demain',
      time: '11:00 - 12:00',
      location: app.propertyAddress || 'Sur place au logement',
      purpose: 'Visite des lieux et validation du bail officiel',
      note: 'Dossier certifié avec caution garantie 100% dès J1',
    };

    handleConfirmSchedule(app, defaultAppointment);
  };

  // Handler: Rejects application (Admin / Landlord)
  const handleRejectApplication = (appId: string, rejectionReasons?: string[], rejectionNote?: string) => {
    const mainReason = rejectionReasons && rejectionReasons.length > 0 ? rejectionReasons.join(' • ') : 'Taux d’effort locatif supérieur au seuil LOC';
    
    const app = applications.find(a => a.id === appId);

    setApplications(applications.map(a => a.id === appId ? { 
      ...a, 
      status: 'rejected',
      rejectionReason: mainReason,
      rejectionReasons: rejectionReasons,
      rejectionDetails: rejectionNote
    } : a));
    
    updateApplicationStatusInFirestore(appId, 'rejected', {
      rejectionReason: mainReason,
      rejectionReasons: rejectionReasons,
      rejectionDetails: rejectionNote
    }).catch(err => console.warn('Firestore app update error:', err));

    if (app) {
      // 1. NOTIFICATION & CHAT TO CANDIDATE
      const candidateNotif: AppNotification = {
        id: `notif-cand-rej-${Date.now()}`,
        userId: app.tenantId,
        role: 'tenant',
        title: '❌ Dossier Candidature Non Retenu',
        message: `Votre candidature pour "${app.propertyTitle}" n'a pas été retenue suite à l'audit LOC. Motif : ${mainReason}.`,
        type: 'warning',
        category: 'dossier',
        createdAt: new Date().toISOString(),
        isRead: false,
      };
      setNotifications((prev) => [candidateNotif, ...prev]);
      saveNotificationToFirestore(candidateNotif).catch((e) => console.warn('Firestore notif error:', e));

      const candidateChatText = `Bonjour ${app.tenantName},\n\nNous vous informons qu'après analyse approfondie de votre dossier pour "${app.propertyTitle}", votre candidature n'a pas été retenue par le pôle risque LOC.\n\n❌ Motif : ${mainReason}\n${rejectionNote ? `📝 Précisions : ${rejectionNote}\n` : ''}\n💡 Nos équipes restent à votre disposition pour vous orienter vers d'autres logements de notre catalogue 100% adaptés à vos revenus.`;
      
      sendChatMessageToUser(
        app.tenantId,
        app.tenantName,
        'tenant',
        app.tenantPhone,
        app.propertyTitle,
        candidateChatText
      );

      // 2. NOTIFICATION & CHAT TO LANDLORD
      const landlordId = app.landlordId || properties.find((p) => p.id === app.propertyId)?.landlordId || 'landlord-1';
      const landlordNotif: AppNotification = {
        id: `notif-land-rej-${Date.now()}`,
        userId: landlordId,
        role: 'landlord',
        title: 'ℹ️ Candidature Déboutée (Audit Risque)',
        message: `Une candidature pour "${app.propertyTitle}" a été rejetée lors de l'audit LOC. Votre annonce reste active.`,
        type: 'info',
        category: 'dossier',
        createdAt: new Date().toISOString(),
        isRead: false,
      };
      setNotifications((prev) => [landlordNotif, ...prev]);
      saveNotificationToFirestore(landlordNotif).catch((e) => console.warn('Firestore notif error:', e));

      const landlordChatText = `Information LOC : Le dossier de candidature pour votre bien "${app.propertyTitle}" a été refusé suite à l'audit de solvabilité LOC. Votre bien reste actif et est proposé en priorité aux candidats solvables.`;
      
      sendChatMessageToUser(
        landlordId,
        'Bailleur Partenaire',
        'landlord',
        '+221 77 123 45 67',
        app.propertyTitle,
        landlordChatText
      );
    }
    
    setSystemAlert({
      message: 'Candidature rejetée. Le candidat et le bailleur ont été immédiatement notifiés par chat et notification.',
      type: 'info',
    });
    setTimeout(() => setSystemAlert(null), 4000);
  };

  // Handler: Landlord signs lease
  const handleSignLeaseComplete = (appId: string) => {
    setApplications(applications.map(a => a.id === appId ? { ...a, status: 'lease_signed' } : a));
    updateApplicationStatusInFirestore(appId, 'lease_signed').catch(err => console.warn('Firestore app update error:', err));
    
    // Also ensure property is marked unavailable
    const app = applications.find(a => a.id === appId);
    if (app) {
      setProperties((prevProps) =>
        prevProps.map((p) => (p.id === app.propertyId ? { ...p, isAvailable: false } : p))
      );
      const targetProp = properties.find((p) => p.id === app.propertyId);
      if (targetProp) {
        savePropertyToFirestore({ ...targetProp, isAvailable: false }).catch((err) =>
          console.warn('Firestore property update error on lease sign:', err)
        );
      }
    }

    setLeaseApplicationToSign(null);
    setSystemAlert({
      message: 'Bail signé électroniquement avec succès ! Le locataire peut désormais emménager.',
      type: 'success',
    });
    setTimeout(() => {
      setSystemAlert(null);
    }, 4500);
  };

  // Handler: Landlord publishes new property
  const handleAddProperty = (newProp: Property) => {
    setProperties((prev) => [newProp, ...prev.filter(p => p.id !== newProp.id)]);
    savePropertyToFirestore(newProp).catch(err => console.warn('Firestore property save error:', err));
    try {
      confetti({
        particleCount: 80,
        spread: 70,
      });
    } catch {}
    setSystemAlert({
      message: `Annonce "${newProp.title}" transmise pour validation préalable par l'admin Wiki !`,
      type: 'success',
    });
    setTimeout(() => {
      setSystemAlert(null);
    }, 4000);
  };

  // Handler: Admin approves property for platform listing
  const handleApproveProperty = (propertyId: string) => {
    setProperties((prev) =>
      prev.map((p) => (p.id === propertyId ? { ...p, approvalStatus: 'approved' as const } : p))
    );
    const approvedProp = properties.find((p) => p.id === propertyId);
    if (approvedProp) {
      savePropertyToFirestore({ ...approvedProp, approvalStatus: 'approved' }).catch((err) =>
        console.warn('Firestore prop save error:', err)
      );

      // 1. Send automated broadcast notification to tenants about the new available property
      const propNotif: AppNotification = {
        id: `notif-prop-${Date.now()}`,
        userId: 'all',
        role: 'tenant',
        title: '🏡 Nouveau bien disponible sur LOC !',
        message: `La propriété "${approvedProp.title}" à ${approvedProp.neighborhood} est désormais disponible. Éligible au micro-versement LOC !`,
        type: 'info',
        category: 'property',
        createdAt: new Date().toISOString(),
        isRead: false,
        actionUrl: approvedProp.id
      };
      saveNotificationToFirestore(propNotif).catch(e => console.warn('Firestore prop notify error:', e));

      // 2. Send automated notification to the landlord partner
      const landlordNotif: AppNotification = {
        id: `notif-landlord-prop-${Date.now()}`,
        userId: approvedProp.landlordId,
        role: 'landlord',
        title: '✅ Votre annonce a été approuvée !',
        message: `Votre annonce "${approvedProp.title}" a été validée par l'administration LOC et est désormais en ligne.`,
        type: 'success',
        category: 'dossier',
        createdAt: new Date().toISOString(),
        isRead: false,
        actionUrl: approvedProp.id
      };
      saveNotificationToFirestore(landlordNotif).catch(e => console.warn('Firestore landlord notify error:', e));
    }
    setSystemAlert({
      message: 'Bien immobilier approuvé et publié officiellement sur le catalogue LOC !',
      type: 'success',
    });
    setTimeout(() => setSystemAlert(null), 4000);
  };

  // Handler: Admin rejects property
  const handleRejectProperty = (propertyId: string) => {
    const updatedProps = properties.map((p) =>
      p.id === propertyId ? { ...p, approvalStatus: 'rejected' as const } : p
    );
    setProperties(updatedProps);
    const rejectedProp = updatedProps.find((p) => p.id === propertyId);
    if (rejectedProp) {
      savePropertyToFirestore(rejectedProp).catch((err) => console.warn('Firestore prop save error:', err));
    }
    setSystemAlert({
      message: 'Bien immobilier refusé. Le bailleur recevra une notification.',
      type: 'info',
    });
    setTimeout(() => setSystemAlert(null), 4000);
  };

  // Handler: Update property details in catalog
  const handleUpdateProperty = (updatedProp: Property) => {
    setProperties((prev) => prev.map((p) => (p.id === updatedProp.id ? updatedProp : p)));
    savePropertyToFirestore(updatedProp).catch((err) =>
      console.warn('Firestore property update error:', err)
    );
    setSystemAlert({
      message: `La fiche du bien "${updatedProp.title}" a été modifiée avec succès !`,
      type: 'success',
    });
    setTimeout(() => setSystemAlert(null), 4000);
  };

  // Handler: Delete property from catalog & Firestore
  const handleDeleteProperty = (propertyId: string) => {
    setProperties((prev) => prev.filter((p) => p.id !== propertyId));
    deletePropertyFromFirestore(propertyId).catch((err) =>
      console.warn('Firestore property delete error:', err)
    );
    setSystemAlert({
      message: 'Le bien immobilier a été supprimé du catalogue avec succès.',
      type: 'info',
    });
    setTimeout(() => setSystemAlert(null), 3000);
  };

  // Handler: Admin schedules appointment during application approval
  const handleConfirmSchedule = (
    application: TenantApplication,
    appointmentInfo: {
      date: string;
      time: string;
      location: string;
      purpose: string;
      note?: string;
    }
  ) => {
    // 1. Approve application
    setApplications((prevApps) =>
      prevApps.map((a) => (a.id === application.id ? { ...a, status: 'approved' as const } : a))
    );
    updateApplicationStatusInFirestore(application.id, 'approved').catch((err) =>
      console.warn('Firestore app update error:', err)
    );

    // Also mark property as unavailable since its caution is approved
    setProperties((prevProps) =>
      prevProps.map((p) => (p.id === application.propertyId ? { ...p, isAvailable: false } : p))
    );
    const targetProp = properties.find((p) => p.id === application.propertyId);
    if (targetProp) {
      savePropertyToFirestore({ ...targetProp, isAvailable: false }).catch((err) =>
        console.warn('Firestore property update error on caution approval:', err)
      );
    }

    // 2. Create visit appointment with pending tenant validation
    const newAppt: VisitAppointment = {
      id: `appt-${Date.now()}`,
      propertyId: application.propertyId,
      propertyTitle: application.propertyTitle,
      propertyAddress: application.propertyAddress || '',
      tenantId: application.tenantId,
      tenantName: application.tenantName,
      tenantPhone: application.tenantPhone,
      date: appointmentInfo.date,
      timeSlot: appointmentInfo.time,
      status: 'pending' as const,
      notes: `${appointmentInfo.purpose}. Lieu : ${appointmentInfo.location}. ${appointmentInfo.note ? `Note : ${appointmentInfo.note}` : ''}`,
    };
    setAppointments((prev) => [newAppt, ...prev.filter(a => a.id !== newAppt.id)]);
    saveAppointmentToFirestore(newAppt).catch((err) => console.warn('Firestore save error:', err));

    // 3. Send Notification & Chat with Interactive Calendar to the Candidate
    const candidateNotif: AppNotification = {
      id: `notif-app-appr-${Date.now()}`,
      userId: application.tenantId,
      role: 'tenant',
      title: '🎉 Dossier Validé & Calendrier Visite / Bail',
      message: `Félicitations ! Votre dossier pour "${application.propertyTitle}" a été approuvé. Veuillez valider votre créneau de visite et signature du bail dans votre chat.`,
      type: 'success',
      category: 'dossier',
      createdAt: new Date().toISOString(),
      isRead: false,
      actionUrl: `appt-${newAppt.id}`
    };
    setNotifications((prev) => [candidateNotif, ...prev]);
    saveNotificationToFirestore(candidateNotif).catch((e) => console.warn('Firestore notif save error:', e));

    const candidateChatText = `🎉 Félicitations ${application.tenantName} !\n\nVotre dossier de caution LOC pour le logement "${application.propertyTitle}" a été validé à 100% par le pôle risque.\n\n📅 CALENDRIER VISITE & VALIDATION DU BAIL :\nVeuillez confirmer ci-dessous le créneau proposé ou choisir votre convenance pour la visite et la finalisation du bail officiel.`;
    
    sendChatMessageToUser(
      application.tenantId,
      application.tenantName,
      'tenant',
      application.tenantPhone,
      application.propertyTitle,
      candidateChatText,
      {
        appointmentId: newAppt.id,
        propertyId: application.propertyId,
        propertyTitle: application.propertyTitle,
        propertyAddress: application.propertyAddress || appointmentInfo.location,
        date: appointmentInfo.date,
        timeSlot: appointmentInfo.time,
        location: appointmentInfo.location,
        purpose: appointmentInfo.purpose,
        isConfirmedByTenant: false,
      }
    );

    // 4. Send Notification & Chat to the Landlord
    const landlordId = application.landlordId || targetProp?.landlordId || 'landlord-1';
    const landlordNotif: AppNotification = {
      id: `notif-land-appr-${Date.now()}`,
      userId: landlordId,
      role: 'landlord',
      title: '🎉 Candidat Validé & Caution Garantie 100%',
      message: `La candidature de ${application.tenantName} pour "${application.propertyTitle}" a été approuvée par l'Administration LOC. La caution à 100% est garantie dès le 1er jour. Le calendrier a été transmis au candidat.`,
      type: 'success',
      category: 'dossier',
      createdAt: new Date().toISOString(),
      isRead: false,
    };
    setNotifications((prev) => [landlordNotif, ...prev]);
    saveNotificationToFirestore(landlordNotif).catch((e) => console.warn('Firestore notif save error:', e));

    const landlordChatText = `🎉 Bonnes nouvelles ! La candidature de ${application.tenantName} pour votre bien "${application.propertyTitle}" a été officiellement approuvée par l'Administration LOC avec caution garantie à 100% dès le 1er jour.\n\n📅 Le calendrier de visite et validation du bail a été envoyé au candidat dans son chat. Dès validation de son créneau, vous recevrez une confirmation immédiate.`;
    
    sendChatMessageToUser(
      landlordId,
      'Bailleur Partenaire',
      'landlord',
      '+221 77 123 45 67',
      application.propertyTitle,
      landlordChatText
    );

    setSystemAlert({
      message: `Candidature validée ! Le candidat et le bailleur ont été immédiatement notifiés par chat & notification avec le calendrier.`,
      type: 'success',
    });
    setTimeout(() => setSystemAlert(null), 4500);
  };

  // Handler: Candidate validates the Calendar Appointment for Visit & Lease
  const handleTenantValidateCalendar = (
    appointmentId: string,
    chosenDate: string,
    chosenTimeSlot: string,
    chosenLocation: string
  ) => {
    // 1. Update appointment state to confirmed
    setAppointments((prev) =>
      prev.map((appt) =>
        appt.id === appointmentId
          ? {
              ...appt,
              date: chosenDate,
              timeSlot: chosenTimeSlot,
              status: 'confirmed' as const,
              notes: `${appt.notes || ''} [Confirmé par le candidat le ${chosenDate} à ${chosenTimeSlot}]`.trim(),
            }
          : appt
      )
    );

    const appt = appointments.find((a) => a.id === appointmentId);
    const targetProp = properties.find((p) => p.id === appt?.propertyId);
    const propTitle = appt?.propertyTitle || targetProp?.title || 'Logement LOC';
    const landlordId = targetProp?.landlordId || 'landlord-1';
    const tenantName = appt?.tenantName || currentUser?.fullName || 'Locataire';

    // 2. Mark chat appointment invites as confirmed
    setConversations((prev) =>
      prev.map((conv) => ({
        ...conv,
        messages: conv.messages.map((msg) =>
          msg.appointmentInvite && msg.appointmentInvite.appointmentId === appointmentId
            ? {
                ...msg,
                appointmentInvite: {
                  ...msg.appointmentInvite,
                  date: chosenDate,
                  timeSlot: chosenTimeSlot,
                  location: chosenLocation,
                  isConfirmedByTenant: true,
                  confirmedAt: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
                },
              }
            : msg
        ),
      }))
    );

    // 3. Send Notification & Chat to Admin LOC
    const adminNotif: AppNotification = {
      id: `notif-adm-cal-${Date.now()}`,
      userId: 'admin-1',
      role: 'admin',
      title: '📅 Rendez-vous Visite & Bail Validé par le Candidat',
      message: `${tenantName} a confirmé son rendez-vous pour "${propTitle}" le ${chosenDate} à ${chosenTimeSlot} (${chosenLocation}).`,
      type: 'success',
      category: 'visite',
      createdAt: new Date().toISOString(),
      isRead: false,
    };
    setNotifications((prev) => [adminNotif, ...prev]);
    saveNotificationToFirestore(adminNotif).catch((e) => console.warn('Firestore admin notif save error:', e));

    const adminChatMsg = `📅 VALIDATION DU CALENDRIER :\nLe candidat ${tenantName} a validé son créneau pour "${propTitle}".\n• Date : ${chosenDate}\n• Heure : ${chosenTimeSlot}\n• Lieu : ${chosenLocation}\nLe bailleur et le candidat ont été synchronisés.`;
    sendChatMessageToUser(
      'admin-1',
      'Super Admin Wiki',
      'admin',
      '+221 77 900 00 01',
      propTitle,
      adminChatMsg
    );

    // 4. Send Notification & Chat to Landlord
    const landlordNotif: AppNotification = {
      id: `notif-land-cal-${Date.now()}`,
      userId: landlordId,
      role: 'landlord',
      title: '📅 Visite & Signature Confirmées par le Candidat',
      message: `Le candidat pour "${propTitle}" a validé le rendez-vous le ${chosenDate} à ${chosenTimeSlot} (${chosenLocation}).`,
      type: 'success',
      category: 'visite',
      createdAt: new Date().toISOString(),
      isRead: false,
    };
    setNotifications((prev) => [landlordNotif, ...prev]);
    saveNotificationToFirestore(landlordNotif).catch((e) => console.warn('Firestore landlord notif save error:', e));

    const landlordChatMsg = `📅 RENDEZ-VOUS CONFIRMÉ :\nLe candidat pour votre bien "${propTitle}" a confirmé son rendez-vous de visite et validation du bail :\n• Date : ${chosenDate}\n• Heure : ${chosenTimeSlot}\n• Lieu : ${chosenLocation}`;
    sendChatMessageToUser(
      landlordId,
      'Bailleur Partenaire',
      'landlord',
      '+221 77 123 45 67',
      propTitle,
      landlordChatMsg
    );

    // 5. Confirmation in Candidate's chat
    if (appt?.tenantId) {
      const tenantConfirmChat = `✅ Votre créneau de rendez-vous pour "${propTitle}" le ${chosenDate} à ${chosenTimeSlot} a été confirmé. L'Administration LOC et le propriétaire ont été automatiquement notifiés.`;
      sendChatMessageToUser(
        appt.tenantId,
        tenantName,
        'tenant',
        appt.tenantPhone || '+221 77 000 00 00',
        propTitle,
        tenantConfirmChat
      );
    }

    setSystemAlert({
      message: `Rendez-vous validé avec succès ! L'équipe LOC et le bailleur ont été informés en temps réel.`,
      type: 'success',
    });
    setTimeout(() => setSystemAlert(null), 4500);
  };

  // Handler: Tenant reschedules an appointment
  const handleTenantRescheduleAppointment = (
    appointmentId: string,
    newDate: string,
    newTimeSlot: string,
    reason?: string
  ) => {
    let updatedApptObj: VisitAppointment | null = null;
    setAppointments((prev) =>
      prev.map((appt) => {
        if (appt.id === appointmentId) {
          updatedApptObj = {
            ...appt,
            date: newDate,
            timeSlot: newTimeSlot,
            status: 'pending' as const,
            notes: `Reprogrammé par le candidat au ${newDate} (${newTimeSlot}). ${reason ? `Motif: ${reason}` : ''}`.trim(),
          };
          return updatedApptObj;
        }
        return appt;
      })
    );

    const appt = appointments.find((a) => a.id === appointmentId);
    const targetProp = properties.find((p) => p.id === appt?.propertyId);
    const propTitle = appt?.propertyTitle || targetProp?.title || 'Logement LOC';
    const landlordId = targetProp?.landlordId || 'landlord-1';
    const tenantName = appt?.tenantName || currentUser?.fullName || 'Locataire';

    if (updatedApptObj) {
      saveAppointmentToFirestore(updatedApptObj).catch((err) => console.warn('Firestore reschedule error:', err));
    }

    // 1. Update chat invite if any
    setConversations((prev) =>
      prev.map((conv) => ({
        ...conv,
        messages: conv.messages.map((msg) =>
          msg.appointmentInvite && msg.appointmentInvite.appointmentId === appointmentId
            ? {
                ...msg,
                appointmentInvite: {
                  ...msg.appointmentInvite,
                  date: newDate,
                  timeSlot: newTimeSlot,
                  isConfirmedByTenant: false,
                },
              }
            : msg
        ),
      }))
    );

    // 2. Send Notification & Chat to Admin
    const adminNotif: AppNotification = {
      id: `notif-adm-resched-${Date.now()}`,
      userId: 'admin-1',
      role: 'admin',
      title: '🔄 Rendez-vous Reprogrammé par le Candidat',
      message: `${tenantName} a demandé la reprogrammation de son rendez-vous pour "${propTitle}" au ${newDate} (${newTimeSlot}). ${reason ? `Motif : ${reason}` : ''}`,
      type: 'info',
      category: 'visite',
      createdAt: new Date().toISOString(),
      isRead: false,
    };
    setNotifications((prev) => [adminNotif, ...prev]);
    saveNotificationToFirestore(adminNotif).catch((e) => console.warn('Firestore notif error:', e));

    const adminChatMsg = `🔄 REPROGRAMMATION RENDEZ-VOUS :\nLe candidat ${tenantName} a reprogrammé son rendez-vous pour "${propTitle}".\n• Nouvelle Date : ${newDate}\n• Créneau : ${newTimeSlot}\n${reason ? `• Motif : ${reason}\n` : ''}Le bailleur et la plateforme LOC sont synchronisés.`;
    sendChatMessageToUser(
      'admin-1',
      'Super Admin Wiki',
      'admin',
      '+221 77 900 00 01',
      propTitle,
      adminChatMsg
    );

    // 3. Send Notification & Chat to Landlord
    const landlordNotif: AppNotification = {
      id: `notif-land-resched-${Date.now()}`,
      userId: landlordId,
      role: 'landlord',
      title: '🔄 Rendez-vous Reprogrammé par le Candidat',
      message: `Le candidat pour "${propTitle}" a reprogrammé son rendez-vous au ${newDate} (${newTimeSlot}).`,
      type: 'info',
      category: 'visite',
      createdAt: new Date().toISOString(),
      isRead: false,
    };
    setNotifications((prev) => [landlordNotif, ...prev]);
    saveNotificationToFirestore(landlordNotif).catch((e) => console.warn('Firestore notif error:', e));

    const landlordChatMsg = `🔄 DEMANDE DE REPROGRAMMATION :\nLe candidat pour votre bien "${propTitle}" a décalé la visite/rendez-vous :\n• Nouvelle Date : ${newDate}\n• Créneau : ${newTimeSlot}\n${reason ? `• Motif : ${reason}` : ''}`;
    sendChatMessageToUser(
      landlordId,
      'Bailleur Partenaire',
      'landlord',
      '+221 77 123 45 67',
      propTitle,
      landlordChatMsg
    );

    // 4. Confirmation in Candidate's chat
    const tenantTargetId = appt?.tenantId || currentUser?.id || 'tenant-demo';
    const tenantConfirmChat = `🔄 Votre rendez-vous pour "${propTitle}" a bien été reprogrammé au ${newDate} (${newTimeSlot}). L'équipe LOC et le propriétaire ont été automatiquement notifiés.`;
    sendChatMessageToUser(
      tenantTargetId,
      tenantName,
      'tenant',
      appt?.tenantPhone || currentUser?.phone || '+221 77 000 00 00',
      propTitle,
      tenantConfirmChat
    );

    setSystemAlert({
      message: `Rendez-vous reprogrammé au ${newDate} à ${newTimeSlot} ! Le bailleur et l'équipe LOC ont été notifiés par chat & notification.`,
      type: 'success',
    });
    setTimeout(() => setSystemAlert(null), 4500);
  };

  // Handler: Update Reserve Fund (Admin Wiki)
  const handleUpdateReserveFund = (amount: number) => {
    setReserveFundAmount(amount);
    setSystemAlert({
      message: `Fonds de réserve mobilisé défini à ${amount.toLocaleString('fr-FR')} FCFA par l'Admin Wiki.`,
      type: 'success',
    });
    setTimeout(() => setSystemAlert(null), 4000);
  };

  // Handler: Admin triggers arrears action
  const handleTriggerReminder = (caseId: string, type: 'sms' | 'whatsapp' | 'call') => {
    setSystemAlert({
      message: `Relance ${type.toUpperCase()} automatique transmise au locataire avec lien de micro-paiement Wave/OM.`,
      type: 'success',
    });
    setTimeout(() => {
      setSystemAlert(null);
    }, 4000);
  };

  const handleActivateGuarantee = (caseId: string) => {
    setSystemAlert({
      message: `Fonds de garantie LOC activé : Indemnité versée au bailleur sous 24h ouvrées.`,
      type: 'success',
    });
    setTimeout(() => {
      setSystemAlert(null);
    }, 4000);
  };

  const handleSendMessage = (conversationId: string, text: string) => {
    const targetConv = conversations.find(c => c.id === conversationId);
    if (targetConv) {
      const newMsg = {
        id: `msg-${Date.now()}`,
        senderId: 'admin-1',
        senderName: 'LOC Support & Risque',
        senderRole: 'admin' as const,
        text,
        timestamp: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
        isRead: true,
      };
      const updatedConv = {
        ...targetConv,
        lastMessage: text,
        lastMessageTime: newMsg.timestamp,
        messages: [...targetConv.messages, newMsg],
      };
      setConversations((prev) => prev.map((c) => c.id === conversationId ? updatedConv : c));
      saveConversationToFirestore(updatedConv).catch(err => console.warn('Firestore conv save error:', err));
    }
  };

  const handleAddLandlord = (newLandlord: LandlordPartner) => {
    setLandlords((prev) => [newLandlord, ...prev]);
    saveLandlordToFirestore(newLandlord).catch(err => console.warn('Firestore landlord save error:', err));
    setSystemAlert({
      message: `Nouveau partenaire bailleur ${newLandlord.name} (${newLandlord.companyName || 'Privé'}) enregistré avec succès !`,
      type: 'success',
    });
    setTimeout(() => {
      setSystemAlert(null);
    }, 4000);
  };

  const handleUpdateLandlord = (updatedLandlord: LandlordPartner) => {
    setLandlords((prev) => prev.map((l) => l.id === updatedLandlord.id ? updatedLandlord : l));
    saveLandlordToFirestore(updatedLandlord).catch(err => console.warn('Firestore landlord update error:', err));
    setSystemAlert({
      message: `Dossier du bailleur ${updatedLandlord.name} mis à jour avec succès !`,
      type: 'success',
    });
    setTimeout(() => setSystemAlert(null), 3500);
  };

  const handleAddPropertyForLandlord = (newProp: Property) => {
    setProperties((prev) => [newProp, ...prev.filter(p => p.id !== newProp.id)]);
    savePropertyToFirestore(newProp).catch(err => console.warn('Firestore property save error:', err));
    setSystemAlert({
      message: `Nouveau bien "${newProp.title}" rattaché avec succès au bailleur !`,
      type: 'success',
    });
    setTimeout(() => setSystemAlert(null), 4000);
  };

  const handleResetPlatformData = async () => {
    try {
      await purgeAllDemoDataFromFirestore();
      setCurrentUser(null);
      setCurrentAdmin(null);
      setApplications([]);
      setMicroPayments([]);
      setReceipts([]);
      setArrears([]);
      setLandlords([]);
      setConversations([]);
      setAppointments([]);
      setNotifications([]);
      setSignalements([]);
      setPaidThisMonth(0);
      setTotalDueThisMonth(0);
      setDepositMonthsPaid(0);
      setReserveFundAmount(0);

      const keysToClear = [
        'loc_applications',
        'loc_payments',
        'loc_receipts',
        'loc_arrears',
        'loc_landlords',
        'loc_conversations',
        'loc_appointments',
        'loc_notifications',
        'loc_signalements',
        'loc_current_user',
        'loc_current_admin',
        'loc_active_role',
        'loc_cleaned_demo_v1',
        'loc_admin_tab',
        'ker_applications',
        'ker_payments',
        'ker_receipts',
        'ker_arrears',
        'ker_landlords',
        'ker_conversations',
        'ker_appointments',
        'ker_notifications',
        'ker_signalements',
        'ker_current_user',
        'ker_current_admin',
        'ker_active_role',
        'ker_cleaned_demo_v1',
        'ker_admin_tab'
      ];
      keysToClear.forEach(k => localStorage.removeItem(k));

      setSystemAlert({
        message: '✅ Remise à zéro réussie ! Tous les profils démos, candidatures, notifications et chiffres ont été réinitialisés à 0.',
        type: 'success',
      });
      setTimeout(() => setSystemAlert(null), 5000);
    } catch (e) {
      console.error('Reset error:', e);
    }
  };

  const handleUpdateArrearsStatus = (caseId: string, newStatus: ArrearsCase['status'], notes?: string) => {
    setArrears((prev) =>
      prev.map((c) => {
        if (c.id === caseId) {
          return {
            ...c,
            status: newStatus,
            notes: notes || c.notes,
          };
        }
        return c;
      })
    );
    updateArrearsStatusInFirestore(caseId, newStatus, notes).catch(err => console.warn('Firestore arrears update error:', err));
  };

  // Calculate unread notification count specifically for the logged in user & active role
  const filteredNotificationsCount = notifications.filter(notif => {
    if (!currentUser && !currentAdmin) return false;
    
    if (activeRole === 'admin') {
      return (notif.role === 'admin' || notif.userId === 'admin' || notif.userId === 'all' || (currentAdmin && notif.userId === currentAdmin.id)) && !notif.isRead;
    }
    
    if (activeRole === 'landlord') {
      return (notif.role === 'landlord' || (currentUser && notif.userId === currentUser.id) || notif.userId === 'all') && !notif.isRead;
    }
    
    if (activeRole === 'tenant') {
      return (notif.role === 'tenant' && (notif.userId === 'all' || (currentUser && notif.userId === currentUser.id) || notif.userId === 'tenant-demo')) && !notif.isRead;
    }
    
    return false;
  }).length;

  // Active lease status & Caution Ineligibility Rule:
  // "Une fois bail signé par le locataire : Rendre inéligible tous les biens immobilier jusqu'au remboursement de la caution. (Rendre éligible au mois 7 si tous les paiements ont été effectués)"
  const tenantActiveLease = applications.find(
    (a) =>
      (a.tenantId === currentUser?.id || (!currentUser?.id && a.tenantId === 'tenant-demo')) &&
      (a.status === 'lease_signed' || a.status === 'approved')
  );

  const isReimbursingCaution = activeRole === 'tenant' && !!tenantActiveLease && depositMonthsPaid < 6;
  const cautionMonthsPaidCount = depositMonthsPaid;
  const totalCautionMonthsCount = 6;

  // Smart Consultation and Redirection for Notifications
  const handleConsultNotification = (notif: AppNotification) => {
    // 1. Mark as read in state and Firestore
    setNotifications((prev) =>
      prev.map((n) => (n.id === notif.id ? { ...n, isRead: true } : n))
    );
    markNotificationAsReadInFirestore(notif.id).catch((e) =>
      console.warn('Firestore mark read error:', e)
    );

    // 2. Close notification center
    setIsNotifCenterOpen(false);

    // 3. Auto-switch role if notification belongs specifically to another workspace
    let currentRole = activeRole;
    if (notif.role && notif.role !== 'all' && notif.role !== activeRole) {
      if (notif.role === 'admin' || notif.role === 'landlord' || notif.role === 'tenant') {
        handleRoleChange(notif.role);
        currentRole = notif.role;
      }
    }

    const titleLower = (notif.title || '').toLowerCase();
    const msgLower = (notif.message || '').toLowerCase();
    const action = notif.actionUrl || '';

    // A. Lease / Contract / Dossiers / Applications
    if (
      action === '#application' ||
      notif.category === 'dossier' ||
      titleLower.includes('bail') ||
      titleLower.includes('contrat') ||
      titleLower.includes('dossier') ||
      titleLower.includes('candidature') ||
      msgLower.includes('bail') ||
      msgLower.includes('signer') ||
      msgLower.includes('candidature')
    ) {
      const targetApp = applications.find(
        (a) =>
          a.id === action ||
          a.tenantId === currentUser?.id ||
          a.status === 'approved' ||
          a.status === 'lease_signed'
      ) || applications[0];

      if (
        titleLower.includes('bail') ||
        titleLower.includes('contrat') ||
        msgLower.includes('signer') ||
        titleLower.includes('approuv') ||
        titleLower.includes('validé')
      ) {
        if (targetApp) {
          setLeaseApplicationToSign(targetApp);
        }
      }

      if (currentRole === 'tenant') {
        setTenantTab('tracking');
      } else if (currentRole === 'landlord') {
        setLandlordTab('applications');
      } else if (currentRole === 'admin') {
        setAdminTab('applications');
      }
      return;
    }

    // B. Property / Annonce consultation
    if (
      action === '#properties' ||
      action.startsWith('prop-') ||
      notif.category === 'property' ||
      titleLower.includes('bien') ||
      titleLower.includes('annonce') ||
      msgLower.includes('annonce')
    ) {
      const propId = action.replace('#properties', '').trim() || properties[0]?.id;
      const targetProp = properties.find((p) => p.id === propId || p.id === action) || properties[0];
      if (targetProp) {
        setSelectedProperty(targetProp);
      }

      if (!currentUser) {
        setPublicView('catalog');
      } else if (currentRole === 'tenant') {
        setTenantTab('explore');
      } else if (currentRole === 'landlord') {
        setLandlordTab('properties');
      } else if (currentRole === 'admin') {
        setAdminTab('properties');
      }
      return;
    }

    // C. Visit & Appointment management
    if (
      action === '#appointments' ||
      action.startsWith('appt-') ||
      notif.category === 'visite' ||
      titleLower.includes('rendez-vous') ||
      titleLower.includes('visite') ||
      titleLower.includes('calendrier') ||
      msgLower.includes('visite')
    ) {
      if (currentRole === 'tenant') {
        setTenantTab('dashboard');
      } else if (currentRole === 'landlord') {
        setLandlordTab('appointments');
      } else if (currentRole === 'admin') {
        setAdminTab('appointments');
      }
      return;
    }

    // D. Payment, Tranche, Rent & Receipts
    if (
      action === '#receipts' ||
      action === '#rents' ||
      notif.category === 'payment_reminder' ||
      notif.category === 'payment_delay' ||
      notif.category === 'penalty' ||
      titleLower.includes('quittance') ||
      titleLower.includes('versement') ||
      titleLower.includes('tranche') ||
      titleLower.includes('paiement') ||
      titleLower.includes('loyer') ||
      msgLower.includes('quittance') ||
      msgLower.includes('payer') ||
      msgLower.includes('verser')
    ) {
      if (titleLower.includes('quittance') || action === '#receipts') {
        if (receipts.length > 0) {
          setSelectedReceipt(receipts[0]);
        }
      }

      if (currentRole === 'tenant') {
        setTenantTab('rents');
        if (notif.category === 'payment_reminder' || notif.category === 'payment_delay' || titleLower.includes('loyer') || titleLower.includes('tranche')) {
          setIsPaymentModalOpen(true);
        }
      } else if (currentRole === 'landlord') {
        setLandlordTab('revenues');
      } else if (currentRole === 'admin') {
        if (titleLower.includes('impayé') || titleLower.includes('recouvrement') || notif.category === 'penalty' || notif.category === 'payment_delay') {
          setAdminTab('recovery');
        } else {
          setAdminTab('settlements');
        }
      }
      return;
    }

    // E. Messaging / Discussion / Chat
    if (
      action === '#chat' ||
      action.startsWith('conv-') ||
      notif.category === 'feature' ||
      titleLower.includes('message') ||
      titleLower.includes('discussion') ||
      msgLower.includes('message') ||
      msgLower.includes('chat')
    ) {
      if (action.startsWith('conv-')) {
        setSelectedAdminConversationId(action);
      }

      if (currentRole === 'tenant') {
        setTenantTab('dashboard');
      } else if (currentRole === 'landlord') {
        setLandlordTab('chat');
      } else if (currentRole === 'admin') {
        setAdminTab('chat');
      }
      return;
    }

    // F. Fallback default routing
    if (currentRole === 'tenant') {
      setTenantTab('dashboard');
    } else if (currentRole === 'landlord') {
      setLandlordTab('revenues');
    } else if (currentRole === 'admin') {
      setAdminTab('applications');
    }
  };

  return (
    <div className="min-h-screen bg-[#FAFAFC] text-slate-800 flex flex-col selection:bg-blue-600 selection:text-white font-sans">
      {/* Top Universal Responsive Navigation Header */}
      <Header
        activeRole={activeRole}
        currentUser={currentUser}
        onRoleChange={handleRoleChange}
        onOpenCalculator={() => setIsCalculatorOpen(true)}
        onOpenKYC={() => setIsKYCOpen(true)}
        onOpenProfile={() => setIsProfileModalOpen(true)}
        onOpenAuth={(role) => handleOpenAuth(role)}
        onLogout={handleLogout}
        onNavigateHome={() => {
          if (currentUser) {
            handleLogout();
          } else {
            setPublicView('home');
          }
        }}
        onNavigateCatalog={() => setPublicView('catalog')}
        kycScore={tenantKYCScore}
        isSuperAdminLoggedIn={!!currentAdmin}
        unreadNotificationsCount={filteredNotificationsCount}
        onToggleNotifications={() => setIsNotifCenterOpen(!isNotifCenterOpen)}
      />

      {/* Floating System Alert Notification */}
      {systemAlert && (
        <div className="max-w-7xl mx-auto w-full px-3 sm:px-6 lg:px-8 mt-3 sm:mt-4">
          <div className="p-3 sm:p-3.5 rounded-2xl bg-white border border-blue-200 text-xs text-blue-900 flex items-center justify-between gap-3 shadow-md animate-in slide-in-from-top duration-300">
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-4 h-4 text-blue-600 shrink-0" />
              <span className="font-semibold leading-relaxed">{systemAlert.message}</span>
            </div>
            <button
              onClick={() => setSystemAlert(null)}
              className="text-slate-400 hover:text-slate-700 text-xs font-bold px-2 py-1"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-8 pb-24 md:pb-12">
        
        {/* ========================================================================= */}
        {/* A. PUBLIC INTERFACE (VISIBLE LORSQU'AUCUN UTILISATEUR N'EST CONNECTÉ)     */}
        {/* ========================================================================= */}
        {!currentUser ? (
          <>
            {publicView === 'home' ? (
              <LandingPage
                properties={properties}
                onSelectProperty={(prop) => setSelectedProperty(prop)}
                onOpenAuth={(role) => handleOpenAuth(role)}
                onOpenCalculator={() => setIsCalculatorOpen(true)}
                onOpenCatalog={() => setPublicView('catalog')}
              />
            ) : (
              /* Public Catalog View */
              <div className="space-y-6">
                <div className="flex items-center justify-between gap-4 border-b border-slate-200 pb-4 flex-wrap">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setPublicView('home')}
                      className="p-2 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 hover:text-slate-900 transition-colors shadow-xs"
                      title="Retour à l'accueil"
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                    <div>
                      <h1 className="text-xl sm:text-2xl font-black text-slate-900">Catalogue des Logements à Dakar</h1>
                      <p className="text-xs text-slate-500">Tous les biens sont éligibles à l'apport réduit 1/3 LOC</p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleOpenAuth('tenant')}
                    className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-sm shadow-blue-600/20 flex items-center gap-2"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span>Se connecter pour candidater</span>
                  </button>
                </div>

                <PropertyList
                  properties={properties}
                  onSelectProperty={(prop) => setSelectedProperty(prop)}
                  onOpenCalculator={() => setIsCalculatorOpen(true)}
                  isReimbursingCaution={isReimbursingCaution}
                  cautionMonthsPaid={cautionMonthsPaidCount}
                  totalCautionMonths={totalCautionMonthsCount}
                />
              </div>
            )}
          </>
        ) : (
          /* ========================================================================= */
          /* B. ESPACES UTILISATEURS SÉPARÉS (UNIQUEMENT VISIBLES APRÈS CONNEXION)     */
          /* ========================================================================= */
          <>
            {/* ---------------- 1. ESPACE PRIVÉ LOCATAIRE ---------------- */}
            {activeRole === 'tenant' && (
              <div className="space-y-4 sm:space-y-6">
                {/* Desktop Tenant Tabs */}
                <div className="hidden md:flex items-center justify-between border-b border-slate-200 pb-3 gap-3">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setTenantTab('dashboard')}
                      className={`px-4 py-2.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 ${
                        tenantTab === 'dashboard'
                          ? 'bg-blue-600 text-white shadow-sm'
                          : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                      }`}
                    >
                      <FileCheck className="w-4 h-4" />
                      <span>Mon Espace Locataire</span>
                    </button>

                    <button
                      onClick={() => setTenantTab('explore')}
                      className={`px-4 py-2.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 ${
                        tenantTab === 'explore'
                          ? 'bg-blue-600 text-white shadow-sm'
                          : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                      }`}
                    >
                      <Building2 className="w-4 h-4" />
                      <span>Rechercher un logement ({properties.length})</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span>Locataire : <strong className="text-slate-900">{currentUser.fullName}</strong></span>
                    <button
                      onClick={() => setIsProfileModalOpen(true)}
                      className="px-2.5 py-1 rounded-xl bg-blue-50 text-blue-700 hover:bg-blue-100 font-bold border border-blue-200 transition-all cursor-pointer"
                    >
                      Modifier profil
                    </button>
                  </div>
                </div>

                {/* TAB: Dashboard */}
                {tenantTab === 'dashboard' && (
                  <TenantDashboard
                    currentProperty={currentRentedProperty}
                    properties={properties}
                    paidThisMonth={paidThisMonth}
                    totalDueThisMonth={totalDueThisMonth}
                    depositMonthsPaid={depositMonthsPaid}
                    microPayments={microPayments}
                    receipts={receipts}
                    onOpenPayModal={handleOpenPaymentModal}
                    onOpenPaymentModal={handleOpenPaymentModal}
                    onViewReceipt={(rec) => setSelectedReceipt(rec)}
                    onViewContract={() => {
                      const appToSign = applications.find(
                        (a) => (a.tenantId === currentUser?.id || a.tenantId === 'tenant-demo') && (a.status === 'approved' || a.status === 'lease_signed')
                      ) || applications[0];
                      if (appToSign) {
                        setLeaseApplicationToSign(appToSign);
                      } else {
                        setSystemAlert({
                          message: 'Contrat de bail certifié LOC N° BAIL-DKR-2026-05 disponible.',
                          type: 'info',
                        });
                      }
                    }}
                    onOpenCalculator={() => setIsCalculatorOpen(true)}
                    onOpenKYCModal={() => setIsKYCOpen(true)}
                    onOpenProfile={() => setIsProfileModalOpen(true)}
                    onApplyAlternativeProperty={(prop) => handleApplyProperty(prop)}
                    applications={applications}
                    appointments={appointments}
                    conversations={conversations}
                    signalements={signalements}
                    onAddSignalement={handleAddSignalement}
                    onSendMessage={handleSendTenantMessage}
                    tenantId={currentUser?.id}
                    currentUser={currentUser}
                    tenantKYCScore={tenantKYCScore}
                    onValidateAppointment={handleTenantValidateCalendar}
                    onRescheduleAppointment={handleTenantRescheduleAppointment}
                    onAddAppointment={(newAppt) => {
                      setAppointments((prev) => [newAppt, ...prev]);
                      saveAppointmentToFirestore(newAppt).catch((e) => console.warn('Firestore new appt error:', e));
                      setSystemAlert({
                        message: `Demande de rendez-vous enregistrée pour "${newAppt.propertyTitle}" !`,
                        type: 'success',
                      });
                      setTimeout(() => setSystemAlert(null), 3500);
                    }}
                  />
                )}

                {/* TAB: Explore */}
                {tenantTab === 'explore' && (
                  <PropertyList
                    properties={properties}
                    onSelectProperty={(prop) => setSelectedProperty(prop)}
                    onOpenCalculator={() => setIsCalculatorOpen(true)}
                    isReimbursingCaution={isReimbursingCaution}
                    cautionMonthsPaid={cautionMonthsPaidCount}
                    totalCautionMonths={totalCautionMonthsCount}
                  />
                )}

                {/* TAB: KYC */}
                {tenantTab === 'kyc' && (
                  <div className="space-y-4 max-w-3xl mx-auto">
                    <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-8 shadow-sm space-y-6">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <div>
                          <h2 className="text-lg sm:text-xl font-extrabold text-slate-900">Mon Dossier Locataire LOC</h2>
                          <p className="text-xs text-slate-500 font-medium">{currentUser.fullName} • {currentUser.profession} • {currentUser.email}</p>
                        </div>
                        <span className="px-3.5 py-1.5 rounded-full text-xs font-black bg-emerald-100 text-emerald-800 border border-emerald-200">
                          Score : {tenantKYCScore}/100
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                        <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex justify-between items-center">
                          <span className="text-slate-500">Revenu mensuel déclaré :</span>
                          <span className="font-mono font-bold text-slate-900">450 000 FCFA</span>
                        </div>
                        <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex justify-between items-center">
                          <span className="text-slate-500">Employeur certifié :</span>
                          <span className="font-bold text-slate-900">Sonatel / Orange</span>
                        </div>
                        <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex justify-between items-center">
                          <span className="text-slate-500">Pièces justificatives :</span>
                          <span className="font-bold text-emerald-700">CNI + Fiches de paie (3/3)</span>
                        </div>
                        <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex justify-between items-center">
                          <span className="text-slate-500">Statut éligibilité LOC :</span>
                          <span className="font-bold text-blue-700">Éligible 1/3 d'apport</span>
                        </div>
                      </div>

                      <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 text-xs text-slate-700 space-y-1">
                        <div className="font-bold text-blue-900 flex items-center gap-1.5">
                          <ShieldCheck className="w-4 h-4 text-blue-600" />
                          <span>Audit & Sécurité LOC</span>
                        </div>
                        <p className="text-[11px] text-slate-600 leading-relaxed">
                          Votre dossier de solvabilité est certifié. Lors de votre candidature, la validation finale est transmise directement aux analystes du pôle risque LOC.
                        </p>
                      </div>

                      <button
                        onClick={() => setIsKYCOpen(true)}
                        className="w-full py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm transition-all"
                      >
                        Mettre à jour mon dossier KYC & Garant
                      </button>
                    </div>
                  </div>
                )}

                {/* TAB: Tracking */}
                {tenantTab === 'tracking' && (
                  <div className="max-w-4xl mx-auto space-y-6">
                    <ApplicationTracker
                      applications={applications}
                      properties={properties}
                      onSelectProperty={(prop) => setSelectedProperty(prop)}
                      onApplyAlternative={(prop) => handleApplyProperty(prop)}
                      tenantId={currentUser?.id}
                      onValidateAppointment={handleTenantValidateCalendar}
                    />
                  </div>
                )}
              </div>
            )}

            {/* ---------------- 2. ESPACE PRIVÉ PROPRIÉTAIRE & COURTIER ---------------- */}
            {activeRole === 'landlord' && (
              <LandlordDashboard
                properties={properties.filter(p => currentUser?.id ? (p.landlordId === currentUser.id || p.landlordId === 'landlord-1' || p.landlordId === 'broker-1') : true)}
                applications={applications}
                currentUser={currentUser || mockUserProfiles.landlord}
                appointments={appointments}
                conversations={conversations}
                paidThisMonth={paidThisMonth}
                microPayments={microPayments}
                activeTab={landlordTab}
                onTabChange={setLandlordTab}
                onOpenNewPropertyModal={() => setIsNewPropertyModalOpen(true)}
                onApproveApplication={handleApproveApplication}
                onRejectApplication={handleRejectApplication}
                onOpenLeaseModal={(app) => setLeaseApplicationToSign(app)}
                onTogglePropertyAvailability={handleTogglePropertyAvailability}
                onUpdateProfile={handleUpdateProfile}
                onConfirmAppointment={handleConfirmAppointment}
                onCancelAppointment={handleCancelAppointment}
                onAddAppointment={handleAddAppointment}
                onSendMessage={handleSendLandlordMessage}
                onSendLeaseSignatureNotification={handleSendLeaseNotification}
                onSubmitAccreditation={handleSubmitAccreditation}
                onTriggerPayoutRequest={handleTriggerPayoutRequest}
                onEditProperty={setEditingProperty}
                onDeleteProperty={handleDeleteProperty}
              />
            )}

            {/* ---------------- 3. ESPACE PRIVÉ SUPERVISION ADMIN & RISQUE ---------------- */}
            {activeRole === 'admin' && (
              <>
                {!currentAdmin ? (
                  <AdminAuthGate
                    adminUsers={adminUsers}
                    onLoginSuccess={(admin) => {
                      setCurrentAdmin(admin);
                      setSystemAlert({
                        message: `Superviseur LOC connecté : ${admin.fullName} (${admin.isSuperAdmin ? 'Super Admin' : 'Admin'})`,
                        type: 'success',
                      });
                      setTimeout(() => setSystemAlert(null), 4000);
                    }}
                  />
                ) : (
                  <AdminDashboard
                    arrears={arrears}
                    properties={properties}
                    applications={applications}
                    landlords={landlords}
                    conversations={conversations}
                    adminUsers={adminUsers}
                    currentAdmin={currentAdmin}
                    notifications={notifications}
                    activeTab={adminTab}
                    onTabChange={setAdminTab}
                    selectedConversationId={selectedAdminConversationId}
                    onSelectConversation={setSelectedAdminConversationId}
                    onToggleNotifications={() => setIsNotifCenterOpen(!isNotifCenterOpen)}
                    onResetPlatformData={handleResetPlatformData}
                    microPayments={microPayments}
                    receipts={receipts}
                    reserveFundAmount={reserveFundAmount}
                    onUpdateReserveFund={handleUpdateReserveFund}
                    onApproveProperty={handleApproveProperty}
                    onRejectProperty={handleRejectProperty}
                    onTriggerReminder={handleTriggerReminder}
                    onActivateGuarantee={handleActivateGuarantee}
                    onOpenNewPropertyModal={() => setIsNewPropertyModalOpen(true)}
                    onApproveApplication={handleApproveApplication}
                    onRejectApplication={handleRejectApplication}
                    onOpenLeaseModal={(app) => setLeaseApplicationToSign(app)}
                    onSendMessage={handleSendMessage}
                    onStartNewConversation={(newConv) => {
                      setConversations((prev) => [newConv, ...prev.filter(c => c.id !== newConv.id)]);
                      saveConversationToFirestore(newConv).catch((err) => console.warn('Firestore conv save error:', err));
                    }}
                    onAddLandlord={handleAddLandlord}
                    onUpdateLandlord={handleUpdateLandlord}
                    onAddPropertyForLandlord={handleAddPropertyForLandlord}
                    onUpdateProperty={(updatedProp) => {
                      setProperties((prev) => prev.map((p) => (p.id === updatedProp.id ? updatedProp : p)));
                      savePropertyToFirestore(updatedProp).catch((err) => console.warn('Firestore prop save error:', err));
                    }}
                    onAddAdminUser={(newAdmin) => {
                      setAdminUsers([...adminUsers, newAdmin]);
                      setSystemAlert({
                        message: `Admin @${newAdmin.username} ajouté avec succès !`,
                        type: 'success',
                      });
                      setTimeout(() => setSystemAlert(null), 4000);
                    }}
                    onUpdateAdminUser={(updatedAdmin) => {
                      setAdminUsers((prev) => prev.map(a => a.id === updatedAdmin.id ? updatedAdmin : a));
                      if (currentAdmin && currentAdmin.id === updatedAdmin.id) {
                        setCurrentAdmin(updatedAdmin);
                      }
                      setSystemAlert({
                        message: `Profil de l'admin @${updatedAdmin.username} mis à jour avec succès !`,
                        type: 'success',
                      });
                      setTimeout(() => setSystemAlert(null), 4000);
                    }}
                    onLogoutAdmin={() => {
                      setCurrentAdmin(null);
                      setSystemAlert({
                        message: 'Session Administrateur déconnectée.',
                        type: 'info',
                      });
                      setTimeout(() => setSystemAlert(null), 3000);
                    }}
                    onSelectProperty={(prop) => setSelectedProperty(prop)}
                    onUpdateArrearsStatus={handleUpdateArrearsStatus}
                    onEditProperty={setEditingProperty}
                    onApproveWithAppointment={setAppToApproveWithAppointment}
                    onCancelLeaseValidation={handleCancelLeaseValidation}
                    onUpdateApplicationScore={handleUpdateApplicationScore}
                    onTogglePropertyAvailability={handleTogglePropertyAvailability}
                    onDeleteProperty={handleDeleteProperty}
                    appointments={appointments}
                    signalements={signalements}
                    onUpdateSignalement={handleUpdateSignalement}
                    onAddSignalement={handleAddSignalement}
                    onConfirmAppointment={handleConfirmAppointment}
                    onCancelAppointment={handleCancelAppointment}
                    onAddAppointment={handleAddAppointment}
                    onUpdateAppointment={(appt) => {
                      setAppointments((prev) => prev.map((a) => (a.id === appt.id ? appt : a)));
                    }}
                  />
                )}
              </>
            )}
          </>
        )}
      </main>

      {/* Bottom Navigation for Mobile Devices (only shown when tenant is logged in) */}
      {currentUser && activeRole === 'tenant' && (
        <BottomNav
          activeRole={activeRole}
          currentTab={tenantTab}
          onTabChange={(tab) => setTenantTab(tab)}
          onOpenCalculator={() => setIsCalculatorOpen(true)}
        />
      )}

      {/* ========================================================================= */}
      {/* MODALES & POPUPS                                                          */}
      {/* ========================================================================= */}
      
      {/* Dedicated Authentication Modal (Locataire, Propriétaire, Admin) */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLoginSuccess={handleLoginSuccess}
        onRegisterUser={handleRegisterUser}
        registeredUsers={registeredUsers}
        initialRole={authInitialRole}
        adminUsers={adminUsers}
      />

      {/* Property Details & Dynamic Schedule Modal */}
      <PropertyDetailModal
        property={selectedProperty}
        onClose={() => setSelectedProperty(null)}
        onApply={(prop) => {
          handleApplyProperty(prop);
          setSelectedProperty(null);
        }}
        hasApplied={applications.some(a => a.propertyId === selectedProperty?.id && a.tenantId === currentUser?.id)}
        isReimbursingCaution={isReimbursingCaution}
        cautionMonthsPaid={cautionMonthsPaidCount}
        totalCautionMonths={totalCautionMonthsCount}
      />

      {/* Dynamic Multi-Profession Apply Modal (Solvabilité, Pièces & Garant) */}
      <ApplyPropertyModal
        property={propertyToApply}
        currentUser={currentUser}
        isOpen={isApplyModalOpen}
        onClose={() => {
          setIsApplyModalOpen(false);
          setPropertyToApply(null);
        }}
        onSubmitApplication={handleSaveApplication}
      />

      {/* Standalone Dynamic Rent & Deposit Calculator */}
      <CalculatorModal
        isOpen={isCalculatorOpen}
        onClose={() => setIsCalculatorOpen(false)}
        initialRent={100000}
      />

      {/* KYC Solvency Modal */}
      <KYCModal
        isOpen={isKYCOpen}
        onClose={() => setIsKYCOpen(false)}
        onSaveKYC={(score) => {
          setTenantKYCScore(score);
          setSystemAlert({
            message: `Dossier de solvabilité mis à jour avec un score de ${score}/100 !`,
            type: 'success',
          });
          setTimeout(() => setSystemAlert(null), 4000);
        }}
      />

      {/* User Profile Editing Modal */}
      <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        currentUser={currentUser}
        onSaveProfile={handleSaveProfile}
      />

      {/* Multichannel Mobile Money & Card Payment Modal (Tranches du 1er au 30) */}
      <MobileMoneyModal
        isOpen={isPaymentModalOpen}
        onClose={() => {
          setIsPaymentModalOpen(false);
          setPaymentPresetAmount(undefined);
        }}
        currentMonthDueTotal={totalDueThisMonth > 0 ? totalDueThisMonth : 133333}
        currentMonthPaidAmount={paidThisMonth}
        initialPresetAmount={paymentPresetAmount}
        onPaymentSuccess={handlePaymentSuccess}
      />

      {/* Certified Rent Receipt Modal */}
      <ReceiptModal
        receipt={selectedReceipt}
        onClose={() => setSelectedReceipt(null)}
      />

      {/* Landlord New Property Publishing & Editing Modal */}
      <NewPropertyModal
        isOpen={isNewPropertyModalOpen || editingProperty !== null}
        onClose={() => {
          setIsNewPropertyModalOpen(false);
          setEditingProperty(null);
        }}
        onAddProperty={handleAddProperty}
        onUpdateProperty={handleUpdateProperty}
        onDeleteProperty={handleDeleteProperty}
        onToggleAvailability={handleTogglePropertyAvailability}
        propertyToEdit={editingProperty}
        currentUser={currentUser || undefined}
      />

      {/* Approve application and Schedule Appointment Modal */}
      <ApproveAppointmentModal
        isOpen={appToApproveWithAppointment !== null}
        application={appToApproveWithAppointment}
        onClose={() => setAppToApproveWithAppointment(null)}
        onConfirmSchedule={handleConfirmSchedule}
      />

      {/* Landlord & Tenant Digital Lease Signing Modal */}
      <LeaseModal
        application={leaseApplicationToSign}
        onClose={() => setLeaseApplicationToSign(null)}
        onSignComplete={handleSignLeaseComplete}
        currentRole={activeRole}
        currentUserName={currentUser?.fullName || (activeRole === 'admin' ? currentAdmin?.name : undefined)}
      />

      {/* Slide-out Notification Center with Live Automation Simulator */}
      <NotificationCenter
        isOpen={isNotifCenterOpen}
        onClose={() => setIsNotifCenterOpen(false)}
        notifications={notifications}
        currentUser={currentUser}
        currentAdmin={currentAdmin}
        activeRole={activeRole}
        onNavigateTab={(tab) => setTenantTab(tab)}
        onConsultNotification={handleConsultNotification}
      />

      {/* Floating Live Support Chat Widget */}
      <FloatingChatWidget
        currentUser={currentUser}
        conversations={conversations}
        onSendMessage={handleSendMessage}
        onValidateAppointment={handleTenantValidateCalendar}
      />
    </div>
  );
}

