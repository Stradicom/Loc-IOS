import { DepositFinancingPlan, LandlordFinancialPlan, ClassicDirectPaymentPlan } from '../types';

/**
 * Calculates the exact LOC deposit micro-financing plan
 * 
 * Règle LOC Option 1 (Micro-Financement Caution) :
 * - Le package total est de 3 mois de loyer (2 mois de caution incluant le 1er mois + 1 mois de frais de courtage).
 * - Apport initial (Mois 0 / Entrée) = 1er mois + 1/3 de la caution restante (à savoir les 2 mois restants) + 10% de la caution globale pour frais de dossier.
 *   => Soit : 1er mois (1 loyer) + (2 mois / 3) + 10% de la caution globale (total 3 mois).
 * - Reliquat étalé sur 6 mois = les 2/3 des 2 mois restants (soit 4/3 de mois de loyer au total), divisés sur 6 mois.
 *   => Mensualité d'étalement (Mois 1 à 6) = (2 mois * 2/3) / 6 = 4/18 = 2/9 de loyer par mois.
 * - Frais de gestion de la plateforme LOC pour les locataires (10% du loyer) : Démarrent dès le 1er mois de loyer !
 *   => Mois 1 à 6 : Loyer + mensualité d'étalement caution + 10% frais de gestion LOC.
 *   => À partir du 7ème mois : Caution 100% amortie, reste le loyer + 10% frais de gestion LOC.
 * 
 * @param monthlyRent Loyer mensuel en FCFA
 * @param depositMonths Caution légale en mois (défaut 2 mois, dont le 1er mois est inclus)
 * @param brokerFeeMonths Frais de courtage / agence en mois (défaut 1 mois)
 * @param serviceFeeRate Taux des frais de dossier LOC (10% de la caution globale à l'entrée)
 * @param managementFeeRate Taux de commission frais de gestion plateforme locataire dès le 1er mois (10%)
 */
export function calculateDepositPlan(
  monthlyRent: number,
  depositMonths: number = 2,
  brokerFeeMonths: number = 1,
  serviceFeeRate: number = 0.10,
  managementFeeRate: number = 0.10
): DepositFinancingPlan {
  const safeRent = Math.max(0, Number(monthlyRent) || 0);
  const safeDepositMonths = Math.max(1, Number(depositMonths) || 2);
  const safeBrokerFeeMonths = Math.max(0, Number(brokerFeeMonths) || 1);

  // Package global traditionnel : 2 mois de caution (incluant le 1er mois) + 1 mois de courtage = 3 mois au total
  const legalDeposit = safeRent * safeDepositMonths; // 2 mois (1er mois inclus dedans + 1 mois de garantie)
  const brokerFee = safeRent * safeBrokerFeeMonths; // 1 mois de courtage
  const totalDepositAndBrokerage = legalDeposit + brokerFee; // 3 mois de loyer au total
  const totalPackageMonths = safeDepositMonths + safeBrokerFeeMonths; // 3 mois

  // Frais de dossier LOC : 10% de la caution globale (totalDepositAndBrokerage)
  const serviceFee = Math.round(totalDepositAndBrokerage * serviceFeeRate);

  // Le 1er mois de loyer (qui fait partie du package d'entrée)
  const initialRentShare = safeRent;

  // La caution restante à traiter = le package total moins le 1er mois
  const remainingDepositMonths = Math.max(0, totalPackageMonths - 1); // 2 mois restants (1 mois de garantie + 1 mois de courtage)
  const remainingDepositTotal = safeRent * remainingDepositMonths;

  // 1/3 de la caution restante (2 mois) payé à l'entrée
  const initialDepositShare = Math.round(remainingDepositTotal / 3); // (2 * loyer) / 3

  // Le reliquat de caution restante (les 2/3 des 2 mois) à étaler sur 6 mois
  const deferredDepositTotal = remainingDepositTotal - initialDepositShare; // (4/3) * loyer
  const monthlyDepositInstallment = Math.round(deferredDepositTotal / 6); // étalé sur 6 mois

  // Apport initial global exigé à l'entrée avec LOC : 1er mois + 1/3 de la caution restante + 10% de la caution globale de frais de dossier
  const initialTotalDue = initialRentShare + initialDepositShare + serviceFee;

  // Sans LOC (marché traditionnel sénégalais) : Totalité des 3 mois d'un coup (2 mois caution dont 1er mois + 1 mois courtier)
  const standardInitialDue = totalDepositAndBrokerage; // 3 mois de loyer

  // Économie immédiate réalisée à l'emménagement
  const immediateSavings = Math.max(0, standardInitialDue - initialTotalDue);
  const savingsPercent = standardInitialDue > 0 ? Math.round((immediateSavings / standardInitialDue) * 100) : 0;

  // Frais de gestion de la plateforme LOC pour locataire (10% du loyer)
  const managementFeeAmount = Math.round(safeRent * managementFeeRate);

  // Mensualités globales du locataire (Mois 1 à 6 : Loyer + caution étalée + 10% gestion LOC)
  const monthlyTotalMonths1to6 = safeRent + monthlyDepositInstallment + managementFeeAmount;
  // À partir du 7ème mois (caution 100% amortie + 10% gestion LOC)
  const monthlyTotalMonth7Onwards = safeRent + managementFeeAmount;

  return {
    monthlyRent: safeRent,
    depositMonths: safeDepositMonths,
    brokerFeeMonths: safeBrokerFeeMonths,
    totalPackageMonths,
    legalDeposit,
    brokerFee,
    totalDepositAndBrokerage,
    serviceFee,
    initialDepositShare,
    initialRentShare,
    initialTotalDue,
    standardInitialDue,
    immediateSavings,
    savingsPercent,
    deferredDepositTotal,
    monthlyDepositInstallment,
    monthlyTotalMonths1to6,
    managementFeeRate,
    managementFeeAmount,
    monthlyTotalMonth7Onwards,
  };
}

/**
 * Calcule l'option de Paiement Classique (Sans LOC) :
 * - Paiement du package traditionnel au comptant (2 mois caution + 1 mois courtier = 3 mois)
 * - Bail accordé après visite des lieux
 * - Sans frais de dossier (0 FCFA)
 * - Frais de gestion plateforme : 10% pour le locataire
 * 
 * @param monthlyRent Montant du loyer mensuel en FCFA
 * @param depositMonths Caution légale en mois (défaut 2)
 * @param brokerFeeMonths Honoraires de courtage en mois (défaut 1)
 * @param managementFeeRate Taux de gestion plateforme pour le locataire (10%)
 */
export function calculateClassicPlan(
  monthlyRent: number,
  depositMonths: number = 2,
  brokerFeeMonths: number = 1,
  managementFeeRate: number = 0.10
): ClassicDirectPaymentPlan {
  const legalDeposit = monthlyRent * depositMonths;
  const brokerFee = monthlyRent * brokerFeeMonths;
  const totalDepositAndBrokerage = legalDeposit + brokerFee; // 3 mois au comptant
  const totalPackageMonths = depositMonths + brokerFeeMonths;
  const initialTotalDue = totalDepositAndBrokerage; // Paiement comptant total à l'entrée
  const serviceFee = 0; // Sans frais de dossier (0 FCFA)
  const managementFeeAmount = Math.round(monthlyRent * managementFeeRate);
  const monthlyTotalRent = monthlyRent + managementFeeAmount;

  return {
    monthlyRent,
    depositMonths,
    brokerFeeMonths,
    totalPackageMonths,
    legalDeposit,
    brokerFee,
    totalDepositAndBrokerage,
    initialTotalDue,
    serviceFee,
    managementFeeRate,
    managementFeeAmount,
    monthlyTotalRent,
    bailGrantCondition: 'Bail accordé après visite physique des lieux',
  };
}

/**
 * Calcule le plan financier du Propriétaire Bailleur et Agence dont le bail est géré par LOC
 * 
 * Règle LOC :
 * - Frais de gestion de plateforme de 3% du montant du loyer pour les agences et propriétaires dont le bail est géré par LOC.
 * - Prise en charge de la gestion locative, baux certifiés OHADA, 100% loyers garantis à date fixe, zéro impayé.
 * - La caution légale de 2 mois est perçue à 100% par le propriétaire dès J+1 sans aucune retenue.
 * 
 * @param monthlyRent Montant du loyer mensuel en FCFA
 * @param isManagedLease Indique si le bail est géré par LOC (défaut true)
 * @param commissionRate Taux de commission de gestion LOC propriétaire (3%)
 */
export function calculateLandlordPlan(
  monthlyRent: number,
  isManagedLease: boolean = true,
  commissionRate: number = 0.03,
  isBroker: boolean = false
): LandlordFinancialPlan {
  const effectiveRate = (isManagedLease && !isBroker) ? commissionRate : 0;
  const commissionAmount = Math.round(monthlyRent * effectiveRate);
  const netRentPayout = monthlyRent - commissionAmount; // 97% du loyer pour le propriétaire, 100% pour le courtier
  const guaranteedDepositMonths = 2;
  const guaranteedDepositAmount = monthlyRent * guaranteedDepositMonths; // 100% perçu à J+1

  return {
    grossMonthlyRent: monthlyRent,
    isManagedLease,
    commissionRate: effectiveRate,
    commissionAmount,
    netRentPayout,
    guaranteedDepositMonths,
    guaranteedDepositAmount,
  };
}

/**
 * Format currency in FCFA (e.g. 100 000 FCFA)
 */
export function formatFCFA(amount: number): string {
  return new Intl.NumberFormat('fr-FR', {
    maximumFractionDigits: 0,
  }).format(amount) + ' FCFA';
}

/**
 * Returns the current active period name (e.g., "Septembre 2026")
 */
export function getCurrentPeriod(date: Date = new Date()): string {
  const month = date.toLocaleDateString('fr-FR', { month: 'long' });
  const capitalizedMonth = month.charAt(0).toUpperCase() + month.slice(1);
  const year = date.getFullYear();
  return `${capitalizedMonth} ${year}`;
}

/**
 * Returns the next period name (e.g., "Octobre 2026")
 */
export function getNextPeriod(date: Date = new Date()): string {
  const next = new Date(date);
  next.setMonth(next.getMonth() + 1);
  const month = next.toLocaleDateString('fr-FR', { month: 'long' });
  const capitalizedMonth = month.charAt(0).toUpperCase() + month.slice(1);
  const year = next.getFullYear();
  return `${capitalizedMonth} ${year}`;
}

/**
 * Returns the first day of next month (e.g., "1er Octobre 2026")
 */
export function getNextMonthFirstDay(date: Date = new Date()): string {
  const next = new Date(date);
  next.setMonth(next.getMonth() + 1);
  const month = next.toLocaleDateString('fr-FR', { month: 'long' });
  const capitalizedMonth = month.charAt(0).toUpperCase() + month.slice(1);
  const year = next.getFullYear();
  return `1er ${capitalizedMonth} ${year}`;
}

/**
 * Returns the due date for the current period (e.g., "5 Septembre 2026")
 */
export function getCurrentDueDate(day: number = 5, date: Date = new Date()): string {
  const month = date.toLocaleDateString('fr-FR', { month: 'long' });
  const capitalizedMonth = month.charAt(0).toUpperCase() + month.slice(1);
  const year = date.getFullYear();
  return `${day} ${capitalizedMonth} ${year}`;
}

/**
 * Computes solvency score from financial inputs (0 - 100)
 */
export function computeSolvencyScore(
  income: number,
  rent: number,
  employmentType: string,
  hasGuarantor: boolean,
  hasDocuments: boolean
): { score: number; level: 'faible' | 'modéré' | 'élevé'; recommendation: string } {
  const safeIncome = Math.max(0, Number(income) || 0);
  const safeRent = Math.max(0, Number(rent) || 0);

  if (safeIncome <= 0) {
    return {
      score: 30,
      level: 'élevé',
      recommendation: "Revenu non renseigné — Justificatifs de revenus requis pour évaluation",
    };
  }

  let score = 50;

  // Rent to income ratio (Effort rate)
  const ratio = (safeRent / safeIncome) * 100;
  if (ratio <= 25) score += 25;
  else if (ratio <= 33) score += 20;
  else if (ratio <= 45) score += 10;
  else score -= 15;

  // Stability of employment
  if (employmentType === 'cdi' || employmentType === 'fonctionnaire') score += 15;
  else if (employmentType === 'entrepreneur') score += 10;
  else if (employmentType === 'cdd') score += 5;

  // Guarantor
  if (hasGuarantor) score += 10;

  // Verified documents
  if (hasDocuments) score += 10;

  score = Math.max(10, Math.min(99, score));

  let level: 'faible' | 'modéré' | 'élevé' = 'faible';
  let recommendation = "Dossier solide — Éligible à l'échelonnement sans restriction";

  if (score >= 75) {
    level = 'faible';
    recommendation = "Excellente solvabilité — Taux d'approbation instantané 100%";
  } else if (score >= 50) {
    level = 'modéré';
    recommendation = "Solvabilité convenable — Accord sous réserve d'un garant ou acompte standard";
  } else {
    level = 'élevé';
    recommendation = "Risque d'impayé accru — Garantie additionnelle requise";
  }

  return { score, level, recommendation };
}
