import { getNeighborhoodCoordinates } from '../data/dakarNeighborhoods';

export interface GeoCoordinate {
  lat: number;
  lng: number;
}

export interface DakarLandmark {
  id: string;
  name: string;
  category: 'transit' | 'landmark' | 'hub';
  coordinates: GeoCoordinate;
  description: string;
}

export const DAKAR_KEY_HUBS: DakarLandmark[] = [
  {
    id: 'current_gps',
    name: '📍 Ma position GPS en direct',
    category: 'transit',
    coordinates: { lat: 14.7167, lng: -17.4677 },
    description: 'Position GPS détectée sur votre smartphone'
  },
  {
    id: 'plateau_place_indep',
    name: 'Place de l\'Indépendance (Plateau)',
    category: 'hub',
    coordinates: { lat: 14.6710, lng: -17.4330 },
    description: 'Centre des affaires & ministères'
  },
  {
    id: 'ucad_fann',
    name: 'Université Cheikh Anta Diop (UCAD / Fann)',
    category: 'hub',
    coordinates: { lat: 14.6912, lng: -17.4695 },
    description: 'Campus universitaire & Corniche Ouest'
  },
  {
    id: 'keur_gorgui_vdn',
    name: 'Cité Keur Gorgui / VDN',
    category: 'hub',
    coordinates: { lat: 14.7095, lng: -17.4660 },
    description: 'Pôle d\'entreprises, banques & Sonatel'
  },
  {
    id: 'liberte_6',
    name: 'Rond-Point Liberté 6',
    category: 'transit',
    coordinates: { lat: 14.7230, lng: -17.4590 },
    description: 'Grand carrefour de bus & taxis'
  },
  {
    id: 'patte_oie',
    name: 'Patte d\'Oie / Échangeur Autoroute',
    category: 'transit',
    coordinates: { lat: 14.7460, lng: -17.4390 },
    description: 'Accès autoroute à péage & VDN'
  },
  {
    id: 'almadies_ngor',
    name: 'Rond-Point Ngor / Almadies',
    category: 'landmark',
    coordinates: { lat: 14.7454, lng: -17.5144 },
    description: 'Zone côtière, restaurants & résidences'
  },
  {
    id: 'guediawaye_brt',
    name: 'Guédiawaye (Station Terminus BRT)',
    category: 'transit',
    coordinates: { lat: 14.7800, lng: -17.3880 },
    description: 'Ligne directe Bus Rapid Transit'
  },
  {
    id: 'pikine_ter',
    name: 'Pikine (Gare TER)',
    category: 'transit',
    coordinates: { lat: 14.7560, lng: -17.3940 },
    description: 'Train Express Régional Dakar-Diamniadio'
  },
  {
    id: 'aeroport_dss',
    name: 'Aéroport Int. Blaise Diagne (AIBD / DSS)',
    category: 'transit',
    coordinates: { lat: 14.6711, lng: -17.0733 },
    description: 'Aéroport international'
  }
];

// Calculate Haversine distance in kilometers
export function calculateDistanceKm(from: GeoCoordinate, to: GeoCoordinate): number {
  const R = 6371; // Rayon Terre en km
  const dLat = ((to.lat - from.lat) * Math.PI) / 180;
  const dLon = ((to.lng - from.lng) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((from.lat * Math.PI) / 180) *
      Math.cos((to.lat * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const rawDist = R * c;
  
  // Apply realistic Dakar road detour factor (~1.32x)
  return Math.round(rawDist * 1.32 * 10) / 10;
}

export interface RouteEstimate {
  distanceKm: number;
  drivingMinutes: number;
  transitMinutes: number;
  walkingMinutes: number;
  taxiPriceMin: number;
  taxiPriceMax: number;
  recommendedLines: string[];
  trafficStatus: 'fluide' | 'modéré' | 'dense';
  keyLandmarks: string[];
  directions: { stepNumber: number; instruction: string; detail?: string }[];
}

export function computeDakarRoute(
  from: GeoCoordinate,
  to: GeoCoordinate,
  destinationNeighborhood: string,
  destinationAddress: string
): RouteEstimate {
  const distanceKm = calculateDistanceKm(from, to);

  // Travel time computations
  // Average car speed in Dakar traffic: ~22-26 km/h
  const drivingMinutes = Math.max(5, Math.round((distanceKm / 24) * 60));
  
  // Average transit speed (Bus Dem Dikk / Tata with stops): ~14-18 km/h + 8 min wait
  const transitMinutes = Math.max(10, Math.round((distanceKm / 16) * 60 + 8));
  
  // Average walking speed: 4.8 km/h
  const walkingMinutes = Math.round((distanceKm / 4.8) * 60);

  // Dakar Taxi estimation (base: 500 FCFA + ~180-250 FCFA/km)
  const taxiPriceMin = Math.round((700 + distanceKm * 180) / 100) * 100;
  const taxiPriceMax = Math.round((1200 + distanceKm * 260) / 100) * 100;

  // Transit suggestions based on destination
  const recommendedLines: string[] = [];
  const lowerDest = destinationNeighborhood.toLowerCase();

  if (lowerDest.includes('almadies') || lowerDest.includes('ngor')) {
    recommendedLines.push('Bus Dem Dikk 3', 'Tata Ligne 49', 'Ligne 14');
  } else if (lowerDest.includes('plateau') || lowerDest.includes('médina')) {
    recommendedLines.push('Bus Dem Dikk 1 & 6', 'BRT Station Petersen', 'Tata Ligne 218');
  } else if (lowerDest.includes('mermoz') || lowerDest.includes('ouakam') || lowerDest.includes('mamelles')) {
    recommendedLines.push('Bus Dem Dikk 7', 'Tata Ligne 34', 'Tata Ligne 43');
  } else if (lowerDest.includes('point e') || lowerDest.includes('fann')) {
    recommendedLines.push('Bus Dem Dikk 10', 'Tata Ligne 25', 'Tata Ligne 39');
  } else if (lowerDest.includes('parcelles') || lowerDest.includes('foire') || lowerDest.includes('yoff')) {
    recommendedLines.push('Bus Dem Dikk 8', 'Tata Ligne 219', 'Ligne 36');
  } else if (lowerDest.includes('pikine') || lowerDest.includes('guédiawaye')) {
    recommendedLines.push('Ligne BRT Direct', 'Gare TER', 'Tata Ligne 67');
  } else {
    recommendedLines.push('Bus Dem Dikk Ligne Principale', 'Réseau AFTU / Tata', 'Taxis Clandos / Urbains');
  }

  // Key neighborhood landmarks
  const keyLandmarks: string[] = [
    `Quartier : ${destinationNeighborhood}`,
    destinationAddress || `Secteur ${destinationNeighborhood}`,
    `Proximité grands axes : VDN / Corniche / Route Nationale`,
    `Repères : Commerces, pharmacies et stations services du secteur`
  ];

  // Turn-by-turn guidance steps tailored for Dakar navigation
  const directions = [
    {
      stepNumber: 1,
      instruction: `Prendre la direction vers le grand axe le plus proche (VDN, Corniche Ouest ou Autoroute à Péage).`,
      detail: `Distance estimée depuis votre point de départ : ~${(distanceKm * 0.25).toFixed(1)} km.`
    },
    {
      stepNumber: 2,
      instruction: `Suivre les panneaux indicateurs vers le secteur de ${destinationNeighborhood}.`,
      detail: `Trajet direct via les voies principales de Dakar.`
    },
    {
      stepNumber: 3,
      instruction: `Aux abords de ${destinationNeighborhood}, vous référer à l'adresse exacte : ${destinationAddress || `Centre de ${destinationNeighborhood}`}.`,
      detail: `Points d'intérêt proches pour orienter votre chauffeur/taxi.`
    },
    {
      stepNumber: 4,
      instruction: `Arrivée à destination au logement sélectionné.`,
      detail: `Coordonnées GPS directes : ${to.lat.toFixed(5)}, ${to.lng.toFixed(5)}.`
    }
  ];

  return {
    distanceKm,
    drivingMinutes,
    transitMinutes,
    walkingMinutes,
    taxiPriceMin,
    taxiPriceMax,
    recommendedLines,
    trafficStatus: drivingMinutes > 30 ? 'dense' : drivingMinutes > 15 ? 'modéré' : 'fluide',
    keyLandmarks,
    directions
  };
}

export function getGoogleMapsNavigationUrl(to: GeoCoordinate, from?: GeoCoordinate): string {
  if (from) {
    return `https://www.google.com/maps/dir/?api=1&origin=${from.lat},${from.lng}&destination=${to.lat},${to.lng}&travelmode=driving`;
  }
  return `https://www.google.com/maps/dir/?api=1&destination=${to.lat},${to.lng}&travelmode=driving`;
}

export function getWazeNavigationUrl(to: GeoCoordinate): string {
  return `https://waze.com/ul?ll=${to.lat},${to.lng}&navigate=yes`;
}

export function getAppleMapsNavigationUrl(to: GeoCoordinate): string {
  return `https://maps.apple.com/?daddr=${to.lat},${to.lng}&dirflg=d`;
}

export function getOpenStreetMapUrl(to: GeoCoordinate, zoom = 16): string {
  return `https://www.openstreetmap.org/?mlat=${to.lat}&mlon=${to.lng}#map=${zoom}/${to.lat}/${to.lng}`;
}

export function getWhatsAppShareText(
  propertyTitle: string,
  neighborhood: string,
  address: string,
  coords: GeoCoordinate
): string {
  const mapsUrl = `https://www.google.com/maps?q=${coords.lat},${coords.lng}`;
  return encodeURIComponent(
    `Bonjour ! Voici la localisation du logement certifié Loc pour notre visite :\n\n🏠 *${propertyTitle}*\n📍 *Quartier :* ${neighborhood}, Dakar\n📌 *Adresse :* ${address}\n🗺️ *Lien GPS Google Maps :* ${mapsUrl}\nCoordonnées : ${coords.lat}, ${coords.lng}`
  );
}
