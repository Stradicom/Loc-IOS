import { ChatConversation, ChatMessage } from '../types';

/**
 * Extracts or computes a numeric timestamp (ms since epoch) for a conversation.
 * Handles explicit updatedAt/createdAt, message IDs, time strings (HH:mm, Hier, etc.).
 */
export function getConversationTimestamp(conv: ChatConversation): number {
  // 1. Explicit numeric updatedAt
  if (typeof conv.updatedAt === 'number' && !isNaN(conv.updatedAt) && conv.updatedAt > 0) {
    return conv.updatedAt;
  }

  // 2. Check the most recent message in the conversation
  if (conv.messages && conv.messages.length > 0) {
    const lastMsg = conv.messages[conv.messages.length - 1];
    if (lastMsg) {
      // Check for numeric timestamp encoded in ID (e.g. msg-1725890000000)
      const msgIdMatch = lastMsg.id.match(/^msg-(\d{10,})/);
      if (msgIdMatch) {
        const parsed = parseInt(msgIdMatch[1], 10);
        if (!isNaN(parsed) && parsed > 1600000000000) {
          return parsed;
        }
      }

      // Check text timestamp in message
      const parsedTime = parseTextTimestamp(lastMsg.timestamp);
      if (parsedTime > 0) {
        return parsedTime;
      }
    }
  }

  // 3. Check for numeric timestamp in conversation ID (e.g. conv-1725890000000)
  const convIdMatch = conv.id.match(/^conv-(\d{10,})/);
  if (convIdMatch) {
    const parsed = parseInt(convIdMatch[1], 10);
    if (!isNaN(parsed) && parsed > 1600000000000) {
      return parsed;
    }
  }

  // 4. Parse lastMessageTime string
  if (conv.lastMessageTime) {
    const parsedTime = parseTextTimestamp(conv.lastMessageTime);
    if (parsedTime > 0) {
      return parsedTime;
    }
  }

  // 5. Explicit createdAt if available
  if (typeof conv.createdAt === 'number' && !isNaN(conv.createdAt) && conv.createdAt > 0) {
    return conv.createdAt;
  }

  // Fallback: mock IDs conv-1, conv-2, conv-3, conv-4, conv-5 ordered descending
  const mockOrder: Record<string, number> = {
    'conv-1': 1000000000000 + 50000,
    'conv-2': 1000000000000 + 40000,
    'conv-3': 1000000000000 + 30000,
    'conv-4': 1000000000000 + 20000,
    'conv-5': 1000000000000 + 10000,
  };

  return mockOrder[conv.id] || 0;
}

/**
 * Parses common human-readable French date/time strings to epoch milliseconds.
 */
function parseTextTimestamp(raw?: string): number {
  if (!raw) return 0;
  const str = raw.trim();

  // Try standard ISO or parseable format first
  const parsedDirect = Date.parse(str);
  if (!isNaN(parsedDirect) && parsedDirect > 1600000000000) {
    return parsedDirect;
  }

  const now = new Date();

  // Format: "10:42" or "14:15" (Today at HH:mm)
  const timeOnlyMatch = str.match(/^(\d{1,2}):(\d{2})$/);
  if (timeOnlyMatch) {
    const hours = parseInt(timeOnlyMatch[1], 10);
    const minutes = parseInt(timeOnlyMatch[2], 10);
    const d = new Date(now);
    d.setHours(hours, minutes, 0, 0);
    return d.getTime();
  }

  // Format: "Aujourd'hui 10:42" or "Aujourd'hui"
  if (str.toLowerCase().startsWith("aujourd'hui")) {
    const timeMatch = str.match(/(\d{1,2}):(\d{2})/);
    const d = new Date(now);
    if (timeMatch) {
      d.setHours(parseInt(timeMatch[1], 10), parseInt(timeMatch[2], 10), 0, 0);
    }
    return d.getTime();
  }

  // Format: "Hier 14:22" or "Hier"
  if (str.toLowerCase().startsWith('hier')) {
    const timeMatch = str.match(/(\d{1,2}):(\d{2})/);
    const d = new Date(now);
    d.setDate(d.getDate() - 1);
    if (timeMatch) {
      d.setHours(parseInt(timeMatch[1], 10), parseInt(timeMatch[2], 10), 0, 0);
    } else {
      d.setHours(12, 0, 0, 0);
    }
    return d.getTime();
  }

  // Format: "23 Août 11:00" or similar
  const frenchMonths: Record<string, number> = {
    janv: 0, jan: 0, janvier: 0,
    févr: 1, fevr: 1, février: 1, fevrier: 1,
    mars: 2,
    avr: 3, avril: 3,
    mai: 4,
    juin: 5,
    juil: 6, juillet: 6,
    août: 7, aout: 7,
    sept: 8, septembre: 8,
    oct: 9, octobre: 9,
    nov: 10, novembre: 10,
    déc: 11, dec: 11, décembre: 11, decembre: 11,
  };

  const frenchDateMatch = str.match(/(\d{1,2})\s+([a-zA-Zéû]+)(?:\s+(\d{1,2}):(\d{2}))?/i);
  if (frenchDateMatch) {
    const day = parseInt(frenchDateMatch[1], 10);
    const monthKey = frenchDateMatch[2].toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    let monthIdx = -1;
    for (const [k, v] of Object.entries(frenchMonths)) {
      if (monthKey.startsWith(k.normalize('NFD').replace(/[\u0300-\u036f]/g, ''))) {
        monthIdx = v;
        break;
      }
    }
    if (monthIdx !== -1) {
      const d = new Date(now.getFullYear(), monthIdx, day);
      if (frenchDateMatch[3] && frenchDateMatch[4]) {
        d.setHours(parseInt(frenchDateMatch[3], 10), parseInt(frenchDateMatch[4], 10), 0, 0);
      } else {
        d.setHours(12, 0, 0, 0);
      }
      return d.getTime();
    }
  }

  return 0;
}

/**
 * Sorts conversations strictly by descending date and time (most recent first).
 */
export function sortConversationsByDate(conversations: ChatConversation[]): ChatConversation[] {
  return [...conversations].sort((a, b) => {
    const timeA = getConversationTimestamp(a);
    const timeB = getConversationTimestamp(b);
    return timeB - timeA;
  });
}

/**
 * Inserts a newly started conversation at the very top (index 0)
 * and sorts all other conversations by date and time.
 */
export function insertNewConversationAtTop(
  newConv: ChatConversation,
  existingConversations: ChatConversation[]
): ChatConversation[] {
  const now = Date.now();
  const convWithTimestamp: ChatConversation = {
    ...newConv,
    updatedAt: now,
    createdAt: newConv.createdAt || now,
    lastMessageTime: newConv.lastMessageTime || new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
  };

  const others = existingConversations.filter(c => c.id !== newConv.id);
  const sortedOthers = sortConversationsByDate(others);

  return [convWithTimestamp, ...sortedOthers];
}

/**
 * Formats a clean date/time display label for conversation badges.
 */
export function formatConversationBadge(conv: ChatConversation): { label: string; isToday: boolean } {
  const ts = getConversationTimestamp(conv);
  if (!ts || ts === 0) {
    return { label: conv.lastMessageTime || '', isToday: false };
  }

  const date = new Date(ts);
  const now = new Date();
  const isSameDay =
    date.getDate() === now.getDate() &&
    date.getMonth() === now.getMonth() &&
    date.getFullYear() === now.getFullYear();

  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  const isYesterday =
    date.getDate() === yesterday.getDate() &&
    date.getMonth() === yesterday.getMonth() &&
    date.getFullYear() === yesterday.getFullYear();

  const timeStr = date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

  if (isSameDay) {
    return { label: timeStr, isToday: true };
  } else if (isYesterday) {
    return { label: `Hier ${timeStr}`, isToday: false };
  } else {
    const dayStr = date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
    return { label: `${dayStr} ${timeStr}`, isToday: false };
  }
}
