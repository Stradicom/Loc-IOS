import { 
  collection, 
  onSnapshot, 
  setDoc, 
  doc, 
  updateDoc, 
  getDocs, 
  deleteDoc,
  writeBatch
} from 'firebase/firestore';
import { signInWithPopup, signOut } from 'firebase/auth';
import { db, auth, googleProvider, handleFirestoreError, OperationType } from '../lib/firebase';
import { 
  Property, 
  TenantApplication, 
  VisitAppointment, 
  UserProfile, 
  MicroPayment, 
  RentReceipt,
  LandlordPartner,
  ChatConversation,
  ArrearsCase,
  AppNotification,
  SignalementItem
} from '../types';
import { initialProperties, initialNotifications } from '../data/mockData';

// 1. Universal Real-time Subscription with Non-destructive Auto-seeding
export function subscribeCollection<T extends { id: string }>(
  collectionName: string,
  onData: (data: T[]) => void,
  initialDefaults?: T[]
): () => void {
  const colRef = collection(db, collectionName);
  
  return onSnapshot(
    colRef,
    (snapshot) => {
      const firestoreData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id }) as T);
      const firestoreIds = new Set(firestoreData.map(d => d.id));

      // Preserve any initial baseline records that are not yet in Firestore so data is never deleted
      const missingDefaults = (initialDefaults || []).filter(d => !firestoreIds.has(d.id));

      if (missingDefaults.length > 0) {
        // Sync missing baseline data to Firestore in the background without blocking or overwriting
        const batch = writeBatch(db);
        missingDefaults.forEach((item) => {
          const docRef = doc(db, collectionName, item.id);
          batch.set(docRef, item, { merge: true });
        });
        batch.commit().catch((e) => {
          console.warn(`[Firebase Seeding] Background sync for ${collectionName}:`, e);
        });
      }

      // Combine: newest / modified items from Firestore first, plus all preserved baseline records
      const combined = [...firestoreData, ...missingDefaults];
      onData(combined);
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, collectionName);
      // Fallback gracefully to initialDefaults on connection issue without clearing data
      if (initialDefaults && initialDefaults.length > 0) {
        onData(initialDefaults);
      }
    }
  );
}

// 2. Google Authentication
export async function loginWithGoogle(): Promise<UserProfile | null> {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;
    
    const userDocRef = doc(db, 'users', user.uid);
    const { getDoc } = await import('firebase/firestore');
    const userDoc = await getDoc(userDocRef);
    
    if (userDoc.exists()) {
      return userDoc.data() as UserProfile;
    }
    
    const nameParts = (user.displayName || '').split(' ');
    const firstName = nameParts[0] || 'Prénom';
    const lastName = nameParts.slice(1).join(' ') || 'Nom';
    
    const newProfile: UserProfile = {
      id: user.uid,
      role: 'tenant',
      firstName,
      lastName,
      fullName: user.displayName || 'Utilisateur Google',
      email: user.email || '',
      phone: user.phoneNumber || '',
      avatarText: (user.displayName || 'U').substring(0, 2).toUpperCase(),
      badgeLabel: 'Locataire Google Vérifié',
      details: 'Compte Google Loc • En attente de choix d\'un bien',
      isIdVerified: true,
      isNewUser: true,
      monthlyIncome: 650000,
      profession: 'Ingénieur Logiciel',
    };
    
    await setDoc(userDocRef, newProfile);
    return newProfile;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'users');
    return null;
  }
}

export async function logoutUser(): Promise<void> {
  try {
    await signOut(auth);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'users');
  }
}

// 3. Properties Management
export async function fetchPropertiesFromFirestore(): Promise<Property[]> {
  try {
    const colRef = collection(db, 'properties');
    const snapshot = await getDocs(colRef);
    if (snapshot.empty) {
      const batch = writeBatch(db);
      initialProperties.forEach((item) => {
        batch.set(doc(db, 'properties', item.id), item);
      });
      await batch.commit();
      return initialProperties;
    }
    return snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id }) as Property);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, 'properties');
    return [];
  }
}

export async function savePropertyToFirestore(property: Property): Promise<void> {
  try {
    await setDoc(doc(db, 'properties', property.id), property);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `properties/${property.id}`);
  }
}

export async function updatePropertyAvailabilityInFirestore(propertyId: string, isAvailable: boolean): Promise<void> {
  try {
    await updateDoc(doc(db, 'properties', propertyId), { isAvailable });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `properties/${propertyId}`);
  }
}

export async function deletePropertyFromFirestore(propertyId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'properties', propertyId));
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `properties/${propertyId}`);
  }
}

// 4. Applications Management
export async function saveApplicationToFirestore(app: TenantApplication): Promise<void> {
  try {
    await setDoc(doc(db, 'applications', app.id), app);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `applications/${app.id}`);
  }
}

export async function updateApplicationStatusInFirestore(
  appId: string, 
  status: TenantApplication['status'],
  extraData?: Partial<TenantApplication>
): Promise<void> {
  try {
    await updateDoc(doc(db, 'applications', appId), { status, ...(extraData || {}) });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `applications/${appId}`);
  }
}

// 5. Appointments Management
export async function saveAppointmentToFirestore(appt: VisitAppointment): Promise<void> {
  try {
    await setDoc(doc(db, 'appointments', appt.id), appt);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `appointments/${appt.id}`);
  }
}

export async function updateAppointmentStatusInFirestore(apptId: string, status: VisitAppointment['status']): Promise<void> {
  try {
    await updateDoc(doc(db, 'appointments', apptId), { status });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `appointments/${apptId}`);
  }
}

export async function updateAppointmentInFirestore(apptId: string, updates: Partial<VisitAppointment>): Promise<void> {
  try {
    await updateDoc(doc(db, 'appointments', apptId), updates);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `appointments/${apptId}`);
  }
}

// 6. User Profile Management
export async function fetchUsersFromFirestore(): Promise<UserProfile[]> {
  try {
    const colRef = collection(db, 'users');
    const snapshot = await getDocs(colRef);
    return snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id }) as UserProfile);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, 'users');
    return [];
  }
}

export async function saveUserProfileToFirestore(profile: UserProfile): Promise<void> {
  try {
    if (!profile || !profile.id) return;
    await setDoc(doc(db, 'users', profile.id), profile);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${profile.id}`);
  }
}

// 7. Payments & Receipts
export async function savePaymentToFirestore(payment: MicroPayment): Promise<void> {
  try {
    await setDoc(doc(db, 'payments', payment.id), payment);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `payments/${payment.id}`);
  }
}

export async function saveReceiptToFirestore(receipt: RentReceipt): Promise<void> {
  try {
    await setDoc(doc(db, 'receipts', receipt.id), receipt);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `receipts/${receipt.id}`);
  }
}

// 8. Landlords Management
export async function saveLandlordToFirestore(landlord: LandlordPartner): Promise<void> {
  try {
    await setDoc(doc(db, 'landlords', landlord.id), landlord);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `landlords/${landlord.id}`);
  }
}

// 9. Chat Conversations
export async function saveConversationToFirestore(conversation: ChatConversation): Promise<void> {
  try {
    await setDoc(doc(db, 'conversations', conversation.id), conversation);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `conversations/${conversation.id}`);
  }
}

// 10. Arrears Tracking
export async function saveArrearsToFirestore(caseItem: ArrearsCase): Promise<void> {
  try {
    await setDoc(doc(db, 'arrears', caseItem.id), caseItem);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `arrears/${caseItem.id}`);
  }
}

export async function updateArrearsStatusInFirestore(caseId: string, status: ArrearsCase['status'], notes?: string): Promise<void> {
  try {
    const updatePayload: any = { status };
    if (notes) {
      updatePayload.notes = notes;
    }
    await updateDoc(doc(db, 'arrears', caseId), updatePayload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `arrears/${caseId}`);
  }
}

// 11. Notifications Management
export async function saveNotificationToFirestore(notif: AppNotification): Promise<void> {
  try {
    await setDoc(doc(db, 'notifications', notif.id), notif);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `notifications/${notif.id}`);
  }
}

export async function markNotificationAsReadInFirestore(notifId: string): Promise<void> {
  try {
    await updateDoc(doc(db, 'notifications', notifId), { isRead: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `notifications/${notifId}`);
  }
}

export async function markAllNotificationsAsReadInFirestore(notifIds: string[]): Promise<void> {
  try {
    const batch = writeBatch(db);
    notifIds.forEach((id) => {
      batch.update(doc(db, 'notifications', id), { isRead: true });
    });
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, 'notifications');
  }
}

// 12. Signalements & Interventions
export async function saveSignalementToFirestore(sig: SignalementItem): Promise<void> {
  try {
    await setDoc(doc(db, 'signalements', sig.id), sig);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `signalements/${sig.id}`);
  }
}

export async function updateSignalementInFirestore(sigId: string, updates: Partial<SignalementItem>): Promise<void> {
  try {
    await updateDoc(doc(db, 'signalements', sigId), updates);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `signalements/${sigId}`);
  }
}

// 13. Purge All Demo Data
export async function purgeAllDemoDataFromFirestore(): Promise<void> {
  const collectionsToClear = [
    'applications',
    'appointments',
    'payments',
    'receipts',
    'arrears',
    'conversations',
    'landlords',
    'notifications',
    'signalements'
  ];

  for (const colName of collectionsToClear) {
    try {
      const colRef = collection(db, colName);
      const snapshot = await getDocs(colRef);
      const batch = writeBatch(db);
      snapshot.docs.forEach((doc) => {
        batch.delete(doc.ref);
      });
      await batch.commit();
    } catch (e) {
      console.warn(`Error purging collection ${colName}:`, e);
    }
  }

  // Clear visual storage keys
  const keysToRemove = [
    'ker_current_user',
    'ker_current_admin',
    'ker_tenant_tab',
    'ker_active_role'
  ];
  keysToRemove.forEach((k) => {
    localStorage.removeItem(k);
  });
}
