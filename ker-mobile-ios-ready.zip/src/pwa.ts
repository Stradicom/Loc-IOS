// Enregistrement du service worker (web/PWA uniquement, pas dans l'app native Capacitor)
export function registerServiceWorker() {
  const isNative = typeof (window as any).Capacitor !== 'undefined' && (window as any).Capacitor.isNativePlatform?.();
  if (isNative || !('serviceWorker' in navigator) || !import.meta.env.PROD) return;
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch((err) => console.warn('SW non enregistré', err));
  });
}
