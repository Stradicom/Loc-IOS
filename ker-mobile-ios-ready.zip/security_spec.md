# Security Specification for Firestore Rules

## 1. Data Invariants
- An unauthenticated user cannot read private user records or write applications/properties.
- Public read is allowed for available `properties` listings so prospective tenants can browse the catalog.
- Only authenticated users can write applications, and the `tenantId` must strictly equal `request.auth.uid`.
- Only property owners or admins can approve/reject tenant applications and modify property statuses.
- Appointment creation requires authentication and `tenantId == request.auth.uid`.
- Payments and Receipts are strictly readable by the relevant tenant, landlord, or admin.

## 2. The Dirty Dozen Attack Vectors
1. **Unauthenticated Property Creation**: Malicious actor posts fake property without signing in. (Blocked by `isSignedIn()`)
2. **Identity Spoofing on Application**: User A submits an application with `tenantId = "user_b"`. (Blocked by `incoming().tenantId == request.auth.uid`)
3. **Ghost Keys Injection**: User injects `isAdmin: true` into a profile update. (Blocked by `affectedKeys().hasOnly(...)`)
4. **ID Poisoning Attack**: 200KB junk ID supplied in doc path. (Blocked by `isValidId(id)`)
5. **Arbitrary Status Escalation**: Tenant self-approves application to `approved`. (Blocked by landlord/admin role check)
6. **Malicious Negative Rent**: Property created with `monthlyRent = -500000`. (Blocked by `data.monthlyRent > 0`)
7. **Cross-Tenant Receipt Tampering**: User A attempts to edit User B's receipt. (Blocked by immutable receipt rule)
8. **Unbounded Payload Flood**: 2MB description string. (Blocked by `.size() <= 2000`)
9. **Fake Email Admin Claim**: User presents unverified spoofed email. (Blocked by `email_verified == true`)
10. **Orphaned Payment Record**: Payment without valid user ID. (Blocked by `incoming().userId == request.auth.uid`)
11. **Cross-Tenant Conversation Hijacking**: Malicious actor reads private chats. (Blocked by participant checks)
12. **Appointment Time-slot Tampering**: Malicious actor cancels appointments without ownership. (Blocked by ownership/participant check)

## 3. Test Runner
Verified against the 8 pillars of hardened security rules.
