import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'sn.ker.app',          // identifiant unique (à adapter avant publication)
  appName: 'KËR',
  webDir: 'dist',
  backgroundColor: '#FFFFFF',
  server: { androidScheme: 'https' },
  plugins: {
    SplashScreen: { launchShowDuration: 1200, backgroundColor: '#0A58CA', showSpinner: false },
    StatusBar: { style: 'LIGHT', backgroundColor: '#0A58CA' }
  }
};
export default config;
