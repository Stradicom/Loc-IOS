# KËR — Application mobile (iOS & Android)

Deux voies, au choix (elles se complètent).

## Voie 1 — Installation directe (PWA), la plus rapide
1. `npm install && npm run build`
2. Déployez le dossier `dist/` en **HTTPS** (Firebase Hosting, Netlify, Vercel, Cloudflare Pages…).
   - Ajoutez le domaine dans Firebase Console → Authentication → Domaines autorisés.
3. Sur le téléphone :
   - **Android (Chrome)** : ouvrir l'URL → menu ⋮ → « Installer l'application ».
   - **iPhone (Safari)** : ouvrir l'URL → Partager → « Sur l'écran d'accueil ».

## Voie 2 — Applications natives (Capacitor)
- **Android (APK)** — sans Android Studio : GitHub → Actions → « Build APK Android » → télécharger `app-debug.apk` et l'installer.
  En local : `npm install && npx cap add android && npm run assets && npm run android`
- **iOS** — nécessite un Mac + Xcode + compte Apple Developer :
  `npm install && npx cap add ios && npm run assets && npm run ios`
- Avant publication, changez `appId` dans `capacitor.config.ts` (actuellement `sn.ker.app`).
- Pour publier sur Google Play / App Store : signature de l'app + comptes développeur (25 $ une fois / 99 $ par an).

## Points d'attention
- La connexion Google (popup Firebase) peut ne pas fonctionner dans l'app native : utilisez email/mot de passe ou ajoutez `@capacitor-firebase/authentication`.
- Les clés Gemini (`GEMINI_API_KEY`) ne doivent pas être embarquées dans l'app ; passez par un backend.
